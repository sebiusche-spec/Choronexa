/* Chronexa prototype — interface. Plain DOM, no dependencies. Data lives in this browser only. */
(function () {
  "use strict";

  const L = window.ChronexaLogic;
  const STORE_KEY = "chronexa.prototype.v1";
  const PX_PER_MIN = 0.6; // 24 h = 864 px on the timeline
  const SUBJECTS = ["Physics", "Chemistry", "Mathematics", "Computer Science", "English"];
  const ANIM_LABEL = {
    auto: "Automatic", none: "Off", wake: "Wake up", brush: "Brushing", bath: "Bath", study: "Study",
    physics: "Physics", chemistry: "Chemistry", maths: "Mathematics", computing: "Computer science",
    exercise: "Exercise", food: "Food", break: "Break", sleep: "Sleep", calm: "Calm",
  };
  const VIEWS = ["home", "planner", "todo", "focus", "alarms", "settings"];

  const $ = (sel, root = document) => root.querySelector(sel);
  const esc = (v) => String(v == null ? "" : v).replace(/[&<>"']/g, (c) =>
    ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

  let seq = 0;
  const makeId = () => "id" + Date.now().toString(36) + (seq++).toString(36);

  function freshState() {
    const today = L.dateKey(new Date());
    return {
      version: 1,
      activities: L.sampleActivities(today, makeId),
      todos: [
        { id: makeId(), title: "Email supervisor about lab slot", due: "", done: false },
        { id: makeId(), title: "Return library books", due: "", done: true },
      ],
      completions: {},
      focusLog: [],
      subjects: SUBJECTS.slice(),
      settings: { displayName: "Sir", theme: "system", motion: "auto", focusMinutes: 25 },
    };
  }

  function loadState() {
    try {
      const raw = localStorage.getItem(STORE_KEY);
      if (!raw) return null;
      const s = JSON.parse(raw);
      if (!s || !Array.isArray(s.activities) || !Array.isArray(s.todos)) return null;
      s.activities = s.activities.filter((a) => a && L.validate(a) === null);
      s.todos = s.todos.filter((t) => t && typeof t.title === "string");
      s.completions = s.completions && typeof s.completions === "object" ? s.completions : {};
      s.focusLog = Array.isArray(s.focusLog) ? s.focusLog : [];
      s.subjects = Array.isArray(s.subjects) ? s.subjects : SUBJECTS.slice();
      s.settings = Object.assign({ displayName: "Sir", theme: "system", motion: "auto", focusMinutes: 25 }, s.settings);
      return s;
    } catch (e) {
      return null;
    }
  }

  let state = loadState() || freshState();
  let plannerKey = L.dateKey(new Date());

  function save() {
    try {
      localStorage.setItem(STORE_KEY, JSON.stringify(state));
      return true;
    } catch (e) {
      toast("Couldn't save on this device. Storage may be full or disabled.");
      return false;
    }
  }

  let toastTimer = null;
  function toast(message) {
    const el = $("#toast");
    el.textContent = message;
    el.hidden = false;
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => { el.hidden = true; }, 2600);
  }

  // --- Formatting ---------------------------------------------------------------

  function fmtDuration(totalMin) {
    const m = Math.max(0, Math.round(totalMin));
    const h = Math.floor(m / 60);
    const r = m % 60;
    if (h === 0) return r + " min";
    return h + " h " + String(r).padStart(2, "0") + " min";
  }

  function fmtRange(a) {
    return L.formatTime(a.start) + "–" + L.formatTime(a.end);
  }

  function dayPart(hour) {
    if (hour < 12) return "Good morning";
    if (hour < 18) return "Good afternoon";
    return "Good evening";
  }

  function longDate(d) {
    return d.toLocaleDateString(undefined, { weekday: "long", day: "numeric", month: "long" });
  }

  function scene(anim) {
    if (!anim || anim === "none") return "";
    const bits = Array.from({ length: 8 }, (_, i) => `<i style="--i:${i + 1}"></i>`).join("");
    return `<div class="scene" data-anim="${esc(anim)}" aria-hidden="true">${bits}</div>`;
  }

  // --- Routing ------------------------------------------------------------------

  function currentView() {
    const h = (location.hash || "#home").slice(1);
    return VIEWS.includes(h) ? h : "home";
  }

  function route() {
    const name = currentView();
    document.querySelectorAll(".view").forEach((v) => v.classList.toggle("active", v.dataset.view === name));
    document.querySelectorAll("[data-nav]").forEach((a) => {
      if (a.dataset.nav === name) a.setAttribute("aria-current", "page");
      else a.removeAttribute("aria-current");
    });
    document.title = "Chronexa — " + name.charAt(0).toUpperCase() + name.slice(1);
    render(name);
    window.scrollTo(0, 0);
  }

  function render(name = currentView()) {
    if (name === "home") renderHome();
    if (name === "planner") renderPlanner();
    if (name === "todo") renderTodo();
    if (name === "focus") renderFocus();
    if (name === "alarms") renderAlarms();
    if (name === "settings") renderSettings();
  }

  // --- Home ---------------------------------------------------------------------

  function renderHome() {
    const now = new Date();
    const key = L.dateKey(now);
    const nowMin = now.getHours() * 60 + now.getMinutes();
    const status = L.dayStatus(state.activities, key, nowMin);
    const prog = L.progressOn(state.activities, state.completions, key);
    const todays = L.occurrencesOn(state.activities, key);
    const todayFocus = state.focusLog.filter((f) => f.day === key).reduce((t, f) => t + f.minutes, 0);
    const reminders = todays.filter((o) => o.activity.alert && o.start > nowMin).slice(0, 3);
    const anim = status.current ? L.chooseAnimation(status.current) : "calm";
    const name = state.settings.displayName ? ", " + esc(state.settings.displayName) : "";
    const circ = 2 * Math.PI * 38;

    $("#home-root").innerHTML = `
      <p class="muted small">${esc(longDate(now))}</p>
      <h2 class="page-title" style="margin-top:4px">${dayPart(now.getHours())}${name}</h2>

      <div class="orb-wrap" aria-hidden="true">
        <div class="ring r3"></div><div class="ring"></div><div class="ring r2"></div>
        <div class="orb"></div>
        <div class="orb-label"><div>
          <div class="clock" id="home-clock">${String(now.getHours()).padStart(2, "0")}:${String(now.getMinutes()).padStart(2, "0")}</div>
          <div class="small muted">${status.current ? "Now: " + esc(status.current.name) : "Free time"}</div>
        </div></div>
      </div>

      <div class="stack" style="margin-top:12px">
        <article class="card glow" aria-labelledby="now-h">
          <p class="eyebrow" id="now-h">Now</p>
          ${status.current ? `
            <p class="h2">${esc(status.current.name)}</p>
            <p class="muted small">${fmtRange(status.current)} · ${fmtDuration(status.minutesLeft)} left</p>
          ` : `<p class="h2">Nothing scheduled right now</p><p class="muted small">Enjoy the gap, or add an activity.</p>`}
          ${scene(status.current ? L.chooseAnimation(status.current) : "calm")}
        </article>

        <article class="card glow-violet" aria-labelledby="next-h">
          <p class="eyebrow" id="next-h">Next</p>
          ${status.next ? `
            <p class="h2">${esc(status.next.name)}</p>
            <p class="muted small">Starts ${L.formatTime(status.nextStart)} · in ${fmtDuration(status.minutesUntilNext)}</p>
          ` : `<p class="h2">No more activities today</p><p class="muted small">Tomorrow's plan is ready when you are.</p>`}
        </article>

        <article class="card" aria-labelledby="prog-h">
          <div class="row">
            <div class="progress" aria-hidden="true">
              <svg viewBox="0 0 92 92"><circle class="track" cx="46" cy="46" r="38"></circle>
                <circle class="bar" cx="46" cy="46" r="38" stroke-dasharray="${circ.toFixed(1)}" stroke-dashoffset="${(circ * (1 - prog.percent / 100)).toFixed(1)}"></circle></svg>
              <div class="label">${prog.percent}%</div>
            </div>
            <div class="grow">
              <p class="eyebrow" id="prog-h">Today</p>
              <p class="h2">${prog.total === 0 ? "Nothing planned" : prog.done + " of " + prog.total + " done"}</p>
              <p class="muted small">Focus today: ${fmtDuration(todayFocus)}</p>
            </div>
          </div>
        </article>

        <h3 class="section-title">Today's timeline</h3>
        ${todays.length === 0 ? `<div class="empty"><strong>No activities yet</strong>Add your first activity to see your day take shape.</div>` :
          todays.map((o) => {
            const done = !!state.completions[L.completionKey(o.activity.id, key)];
            const current = status.current && status.current.id === o.activity.id;
            return `<div class="item ${current ? "current" : ""} ${done ? "done" : ""}">
              <input type="checkbox" class="check" data-action="toggle-done" data-id="${esc(o.activity.id)}" data-key="${key}" ${done ? "checked" : ""} aria-label="Mark ${esc(o.activity.name)} done">
              <div class="grow"><div class="title">${esc(o.activity.name)}</div><div class="small muted">${fmtRange(o.activity)}</div></div>
            </div>`;
          }).join("")}

        <h3 class="section-title">Upcoming reminders</h3>
        ${reminders.length === 0 ? `<p class="muted small">No reminders left today. Turn one on in Alarms.</p>` :
          reminders.map((o) => `<div class="item"><span class="time">${L.formatTime(o.start)}</span><div class="grow title">${esc(o.activity.name)}</div></div>`).join("")}

        <h3 class="section-title">Quick actions</h3>
        <div class="row" style="flex-wrap:wrap">
          <button class="btn btn-primary" data-action="new-activity">Add activity</button>
          <button class="btn" data-go="todo">To-do</button>
          <button class="btn" data-go="focus">Focus</button>
          <button class="btn" data-go="alarms">Alarms</button>
        </div>
      </div>`;
    void anim;
  }

  // --- Planner ------------------------------------------------------------------

  function renderPlanner() {
    const key = plannerKey;
    const todayKey = L.dateKey(new Date());
    const occ = L.occurrencesOn(state.activities, key);
    const conflictIds = new Set();
    L.findOverlaps(occ).forEach(([a, b]) => { conflictIds.add(a.id); conflictIds.add(b.id); });

    // Segments drawn on the timeline: today's activities, plus the tail of yesterday's overnight ones.
    const segments = [];
    L.occurrencesOn(state.activities, L.keyOffset(key, -1))
      .filter((o) => o.end > L.DAY)
      .forEach((o) => segments.push({ a: o.activity, s: 0, e: o.end - L.DAY, carry: true }));
    occ.forEach((o) => segments.push({ a: o.activity, s: o.start, e: Math.min(o.end, L.DAY), carry: false }));

    const hourMarks = Array.from({ length: 25 }, (_, h) => {
      const top = (h * 60 * PX_PER_MIN).toFixed(1);
      const label = h === 24 ? "" : String(h).padStart(2, "0") + ":00";
      return `<div class="hour-line" style="top:${top}px"></div><div class="hour" style="top:${top}px">${label}</div>`;
    }).join("");

    const blocks = segments.map((seg) => {
      const top = (seg.s * PX_PER_MIN).toFixed(1);
      const natural = (seg.e - seg.s) * PX_PER_MIN;
      // Short activities are drawn as thin proportional bars. Their words are in the list below,
      // so they never pile up on top of each other.
      const tiny = natural < 28;
      const height = Math.max(natural, 4).toFixed(1);
      const done = !!state.completions[L.completionKey(seg.a.id, key)];
      const conflict = conflictIds.has(seg.a.id) ? " conflict" : "";
      const label = `${seg.a.name}, ${L.formatTime(seg.s)} to ${L.formatTime(seg.e)}${seg.carry ? ", continues from yesterday" : ""}`;
      const inner = tiny ? "" : `<div>${esc(seg.a.name)}</div><div class="small">${L.formatTime(seg.s)}–${L.formatTime(seg.e)}${seg.carry ? " (from yesterday)" : ""}</div>`;
      return `<button class="block${tiny ? " tiny" : ""}${conflict}${done ? " is-done" : ""}" style="top:${top}px;height:${height}px"
        data-action="edit-activity" data-id="${esc(seg.a.id)}" title="${esc(label)}" aria-label="${esc(label)}">${inner}</button>`;
    }).join("");

    const nowMin = new Date().getHours() * 60 + new Date().getMinutes();
    const nowLine = key === todayKey ? `<div class="now-line" style="top:${(nowMin * PX_PER_MIN).toFixed(1)}px" aria-hidden="true"></div>` : "";
    const prog = L.progressOn(state.activities, state.completions, key);
    const status = key === todayKey ? L.dayStatus(state.activities, key, nowMin) : null;

    $("#planner-root").innerHTML = `
      <div class="card" style="margin-bottom:12px">
        <div class="pair">
          <div class="field"><label for="planner-date">Day</label>
            <input class="input" type="date" id="planner-date" data-role="planner-date" value="${key}"></div>
          <div class="field"><label>Completed</label><div class="h2" style="margin:6px 0">${prog.done} of ${prog.total} · ${prog.percent}%</div></div>
        </div>
        ${status && status.current ? `<p class="small" style="margin:12px 0 0"><span class="eyebrow">Now</span> ${esc(status.current.name)} · ${fmtDuration(status.minutesLeft)} left</p>` : ""}
        ${status && status.next ? `<p class="small muted" style="margin:4px 0 0">Next: ${esc(status.next.name)} at ${L.formatTime(status.nextStart)}</p>` : ""}
      </div>

      <div class="row" style="flex-wrap:wrap;margin-bottom:12px">
        <button class="btn btn-primary" data-action="new-activity">Add activity</button>
        <button class="btn" data-action="today">Today</button>
        <div class="field" style="min-width:160px"><label for="copy-target">Copy this day to</label>
          <input class="input" type="date" id="copy-target"></div>
        <button class="btn" data-action="copy-day" style="align-self:end">Copy day</button>
      </div>

      ${conflictIds.size ? `<p class="warn" role="status">${conflictIds.size} activities overlap. Nothing has been moved — change the times to fix it.</p>` : ""}

      <div class="timeline" aria-label="24-hour timeline for ${key}">
        ${hourMarks}
        ${blocks}
        ${nowLine}
      </div>

      <h3 class="section-title">Activities</h3>
      ${occ.length === 0 ? `<div class="empty"><strong>Nothing planned for this day</strong>Add an activity, or copy another day here.</div>` :
        occ.map((o) => {
          const done = !!state.completions[L.completionKey(o.activity.id, key)];
          const conflict = conflictIds.has(o.activity.id) ? " conflict" : "";
          return `<div class="item${conflict}${done ? " done" : ""}">
            <input type="checkbox" class="check" data-action="toggle-done" data-id="${esc(o.activity.id)}" data-key="${key}" ${done ? "checked" : ""} aria-label="Mark ${esc(o.activity.name)} done">
            <div class="grow">
              <div class="title">${esc(o.activity.name)}</div>
              <div class="small muted">${fmtRange(o.activity)} · ${esc(categoryLabel(o.activity.category))}${o.activity.subject ? " · " + esc(o.activity.subject) : ""}${o.activity.repeat === "once" ? "" : " · " + (o.activity.repeat === "daily" ? "Daily" : "Weekdays")}</div>
              ${conflict ? `<div class="warn small">Overlaps another activity</div>` : ""}
            </div>
            <div class="actions">
              <button class="btn btn-ghost" data-action="edit-activity" data-id="${esc(o.activity.id)}" aria-label="Edit ${esc(o.activity.name)}">Edit</button>
              <button class="btn btn-ghost btn-danger" data-action="delete-activity" data-id="${esc(o.activity.id)}" aria-label="Delete ${esc(o.activity.name)}">Delete</button>
            </div>
          </div>`;
        }).join("")}`;
  }

  function categoryLabel(id) {
    const c = L.CATEGORIES.find((x) => x.id === id);
    return c ? c.label : "Other";
  }

  // --- Activity editor ----------------------------------------------------------

  let editingId = null;

  function openEditor(id) {
    editingId = id || null;
    const existing = id ? state.activities.find((a) => a.id === id) : null;
    const dateDefault = existing ? existing.date : plannerKey;
    const a = existing || { name: "", start: 540, end: 600, category: "routine", notes: "", repeat: "once", date: dateDefault, animation: "auto", alert: false, subject: "" };
    const hhmm = (m) => L.formatTime(m % L.DAY);
    $("#editor-title").textContent = existing ? "Edit activity" : "New activity";
    $("#editor-body").innerHTML = `
      <div class="field"><label for="f-name">Name</label>
        <input class="input" id="f-name" maxlength="60" placeholder="e.g. Physics revision" value="${esc(a.name)}" autocomplete="off"></div>
      <div class="pair">
        <div class="field"><label for="f-start">Start (HH:MM)</label>
          <input class="input" id="f-start" inputmode="numeric" placeholder="05:10" value="${hhmm(a.start)}"></div>
        <div class="field"><label for="f-end">End (HH:MM)</label>
          <input class="input" id="f-end" inputmode="numeric" placeholder="05:30" value="${hhmm(a.end)}"></div>
      </div>
      <p class="hint" id="f-hint">Ends after midnight? Just set an earlier end time, like 23:00 to 06:00.</p>
      <div class="pair">
        <div class="field"><label for="f-category">Category</label>
          <select class="select" id="f-category">${L.CATEGORIES.map((c) => `<option value="${c.id}" ${c.id === a.category ? "selected" : ""}>${c.label}</option>`).join("")}</select></div>
        <div class="field"><label for="f-subject">Subject</label>
          <input class="input" id="f-subject" list="subject-list" maxlength="40" placeholder="Optional" value="${esc(a.subject || "")}">
          <datalist id="subject-list">${state.subjects.map((s) => `<option value="${esc(s)}">`).join("")}</datalist></div>
      </div>
      <div class="pair">
        <div class="field"><label for="f-repeat">Repeat</label>
          <select class="select" id="f-repeat">
            <option value="once" ${a.repeat === "once" ? "selected" : ""}>Once</option>
            <option value="daily" ${a.repeat === "daily" ? "selected" : ""}>Every day</option>
            <option value="weekdays" ${a.repeat === "weekdays" ? "selected" : ""}>Weekdays</option>
          </select></div>
        <div class="field"><label for="f-date">Date</label>
          <input class="input" type="date" id="f-date" value="${a.date}"></div>
      </div>
      <div class="field"><label for="f-animation">Animation</label>
        <select class="select" id="f-animation">
          ${["auto", "none", ...L.ANIMATIONS].map((k) => `<option value="${k}" ${k === a.animation ? "selected" : ""}>${ANIM_LABEL[k]}</option>`).join("")}
        </select>
        <p class="hint" id="f-anim-hint"></p></div>
      <div class="field"><label for="f-notes">Notes</label>
        <textarea class="textarea" id="f-notes" maxlength="400" placeholder="Anything to remember">${esc(a.notes || "")}</textarea></div>
      <label class="row small" style="cursor:pointer">
        <input type="checkbox" id="f-alert" ${a.alert ? "checked" : ""}>
        <span>Remind me at the start. <span class="muted">Prototype only: no device alarm is set.</span></span>
      </label>
      <p class="error" id="f-error" role="alert"></p>
      <p class="warn" id="f-overlap" role="status"></p>
      <div class="footer-actions">
        ${existing ? `<button type="button" class="btn btn-ghost btn-danger" data-action="delete-from-editor">Delete</button>` : ""}
        <button type="button" class="btn" data-action="close-editor">Cancel</button>
        <button type="button" class="btn btn-primary" data-action="save-activity">Save activity</button>
      </div>`;
    updateEditorHints();
    $("#editor").showModal();
    $("#f-name").focus();
  }

  function readDraft() {
    const start = L.parseTime($("#f-start").value);
    const end = L.parseTime($("#f-end").value);
    const existing = editingId ? state.activities.find((x) => x.id === editingId) : null;
    return {
      id: editingId || "draft",
      name: $("#f-name").value.trim(),
      start: start == null ? NaN : start,
      end: end == null ? NaN : end,
      category: $("#f-category").value,
      subject: $("#f-subject").value.trim(),
      repeat: $("#f-repeat").value,
      date: $("#f-date").value,
      animation: $("#f-animation").value,
      notes: $("#f-notes").value.trim(),
      alert: $("#f-alert").checked,
      createdFrom: existing ? existing.id : null,
    };
  }

  function updateEditorHints() {
    const d = readDraft();
    const anim = d.animation === "auto" ? L.chooseAnimation({ ...d, animation: "auto" }) : d.animation;
    $("#f-anim-hint").textContent = d.animation === "auto"
      ? "Suggested: " + (ANIM_LABEL[anim] || "Calm") + " (picked from the name and category)."
      : "";
    const key = d.date || plannerKey;
    if (Number.isNaN(d.start) || Number.isNaN(d.end) || !d.name) {
      $("#f-overlap").textContent = "";
      return;
    }
    const draft = { ...d, id: d.id, start: d.start, end: d.end };
    const conflicts = L.conflictsFor(draft, key, state.activities);
    $("#f-overlap").textContent = conflicts.length
      ? "Overlaps " + conflicts.map((c) => "“" + c.name + "”").join(", ") + ". You can still save; nothing else will move."
      : "";
  }

  function saveEditor() {
    const d = readDraft();
    const errors = [];
    if (!d.name) errors.push("Give the activity a name.");
    if (Number.isNaN(d.start)) errors.push("Use HH:MM for the start time, like 05:10.");
    if (Number.isNaN(d.end)) errors.push("Use HH:MM for the end time, like 05:30.");
    if (!Number.isNaN(d.start) && !Number.isNaN(d.end) && d.start === d.end) errors.push("Start and end can't be the same.");
    if (!L.parseDateKey(d.date)) errors.push("Pick a date.");
    if (errors.length) {
      $("#f-error").textContent = errors[0];
      return;
    }
    const activity = {
      id: editingId || makeId(),
      name: d.name,
      start: d.start,
      end: d.end,
      category: d.category,
      notes: d.notes,
      repeat: d.repeat,
      date: d.date,
      animation: d.animation,
      alert: d.alert,
      subject: d.subject,
    };
    if (L.validate(activity) !== null) {
      $("#f-error").textContent = "Check the times and date, then try again.";
      return;
    }
    if (activity.subject && !state.subjects.some((s) => s.toLowerCase() === activity.subject.toLowerCase())) {
      state.subjects.push(activity.subject);
    }
    if (editingId) state.activities = state.activities.map((x) => (x.id === editingId ? activity : x));
    else state.activities.push(activity);
    if (!save()) return;
    $("#editor").close();
    toast(editingId ? "Activity updated" : "Activity added");
    plannerKey = d.date;
    render(currentView());
  }

  function deleteActivity(id) {
    const a = state.activities.find((x) => x.id === id);
    if (!a) return;
    if (!window.confirm("Delete “" + a.name + "”? Its completion history stays in your stats.")) return;
    state.activities = state.activities.filter((x) => x.id !== id);
    save();
    toast("Activity deleted");
    render(currentView());
  }

  // --- To-do --------------------------------------------------------------------

  let todoFilter = "open";

  function renderTodo() {
    const now = Date.now();
    const list = state.todos.filter((t) => todoFilter === "all" || (todoFilter === "open" ? !t.done : t.done));
    list.sort((x, y) => Number(x.done) - Number(y.done) || (x.due || "~").localeCompare(y.due || "~"));
    const openCount = state.todos.filter((t) => !t.done).length;
    const doneCount = state.todos.length - openCount;
    const chip = (key, label) => `<button class="chip" aria-pressed="${todoFilter === key}" data-filter="${key}">${label}</button>`;
    $("#todo-root").innerHTML = `
      <form class="card stack" id="todo-form" style="margin-bottom:14px" novalidate>
        <div class="field"><label for="todo-title">New to-do</label>
          <input class="input" id="todo-title" maxlength="120" placeholder="What needs doing?" autocomplete="off"></div>
        <div class="pair">
          <div class="field"><label for="todo-due">Due (optional)</label>
            <input class="input" type="datetime-local" id="todo-due"></div>
          <div class="field" style="align-self:end"><button class="btn btn-primary" type="submit">Add to-do</button></div>
        </div>
        <p class="error" id="todo-error" role="alert"></p>
      </form>
      <div class="row" style="flex-wrap:wrap;margin-bottom:12px">
        ${chip("open", "Open (" + openCount + ")")}${chip("done", "Done (" + doneCount + ")")}${chip("all", "All")}
      </div>
      ${list.length === 0 ? `<div class="empty"><strong>${state.todos.length === 0 ? "Nothing to do" : "Nothing here"}</strong>${state.todos.length === 0 ? "Add a to-do above. Items are saved in this browser." : "No items match this filter."}</div>` :
        `<div class="stack">${list.map((t) => {
          const overdue = !t.done && t.due && new Date(t.due).getTime() < now;
          return `<div class="item ${t.done ? "done" : ""}">
            <input type="checkbox" class="check" data-action="toggle-todo" data-id="${esc(t.id)}" ${t.done ? "checked" : ""} aria-label="Mark ${esc(t.title)} done">
            <div class="grow">
              <div class="title">${esc(t.title)}</div>
              <div class="small muted">${t.due ? "Due " + esc(formatDue(t.due)) : "No due date"}${overdue ? ' · <span class="warn">Overdue</span>' : ""}</div>
            </div>
            <button class="btn btn-ghost btn-danger" data-action="delete-todo" data-id="${esc(t.id)}" aria-label="Delete ${esc(t.title)}">Delete</button>
          </div>`;
        }).join("")}</div>`}`;
  }

  function formatDue(local) {
    const d = new Date(local);
    if (Number.isNaN(d.getTime())) return local;
    return d.toLocaleString(undefined, { weekday: "short", day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" });
  }

  // --- Focus --------------------------------------------------------------------

  let focus = { status: "idle", totalMs: 25 * 60000, remainingMs: 25 * 60000, endAt: 0 };

  function focusTotalMs() { return state.settings.focusMinutes * 60000; }

  function focusElapsedMs() {
    if (focus.status === "running") return Math.min(focus.totalMs, focus.totalMs - Math.max(0, focus.endAt - Date.now()));
    if (focus.status === "paused") return focus.totalMs - focus.remainingMs;
    return 0;
  }

  function focusRemainingMs() {
    if (focus.status === "running") return Math.max(0, focus.endAt - Date.now());
    if (focus.status === "paused") return focus.remainingMs;
    return focus.totalMs;
  }

  function focusTick() {
    if (focus.status !== "running") return;
    if (focusRemainingMs() > 0) return updateFocusDisplay();
    focus.status = "idle";
    focus.remainingMs = focus.totalMs;
    state.focusLog.push({ id: makeId(), minutes: Math.round(focus.totalMs / 60000), day: L.dateKey(new Date()), at: Date.now() });
    save();
    toast("Focus session complete. Nice work.");
    if (navigator.vibrate) navigator.vibrate([120, 80, 120]);
    renderFocus();
  }

  function renderFocus() {
    const total = focusTotalMs();
    focus.totalMs = total;
    if (focus.status === "idle") focus.remainingMs = total;
    const today = L.dateKey(new Date());
    const todayMin = state.focusLog.filter((f) => f.day === today).reduce((t, f) => t + f.minutes, 0);
    const label = { idle: "Ready", running: "Focusing", paused: "Paused" }[focus.status];
    const circ = 2 * Math.PI * 118;
    $("#focus-root").innerHTML = `
      <div class="card glow" style="text-align:center">
        <div class="focus-ring">
          <svg viewBox="0 0 260 260" aria-hidden="true">
            <circle class="track" cx="130" cy="130" r="118"></circle>
            <circle class="bar" id="focus-bar" cx="130" cy="130" r="118" stroke-dasharray="${circ.toFixed(1)}" stroke-dashoffset="${circ.toFixed(1)}"></circle>
          </svg>
          <div class="focus-time" role="timer" aria-live="off">
            <div><div class="big" id="focus-clock">--:--</div><div class="small muted" id="focus-state">${label}</div></div>
          </div>
        </div>
        <div class="row" style="justify-content:center;flex-wrap:wrap">
          ${focus.status === "running"
            ? `<button class="btn btn-primary" data-action="focus-pause">Pause</button>`
            : `<button class="btn btn-primary" data-action="focus-start">${focus.status === "paused" ? "Resume" : "Start"}</button>`}
          <button class="btn" data-action="focus-reset" ${focus.status === "idle" ? "disabled" : ""}>Reset</button>
        </div>
        <p class="small muted" style="margin:14px 0 0">Focus today: ${fmtDuration(todayMin)} · ${state.focusLog.filter((f) => f.day === today).length} sessions</p>
      </div>

      <h3 class="section-title">Session length</h3>
      <div class="row" style="flex-wrap:wrap">
        ${[15, 25, 50].map((m) => `<button class="chip" aria-pressed="${state.settings.focusMinutes === m}" data-focus-minutes="${m}">${m} min</button>`).join("")}
      </div>
      <p class="hint" style="margin-top:8px">Changing the length only applies when the timer is ready.</p>

      <h3 class="section-title">Recent sessions</h3>
      ${state.focusLog.length === 0 ? `<div class="empty"><strong>No sessions yet</strong>Finished sessions appear here. Reset or stopped sessions are not counted.</div>` :
        `<div class="stack">${state.focusLog.slice(-5).reverse().map((f) => `<div class="item"><span class="time">${esc(f.day)}</span><div class="grow title">${f.minutes} min focus</div></div>`).join("")}</div>`}`;
    updateFocusDisplay();
  }

  function updateFocusDisplay() {
    const clock = $("#focus-clock");
    if (!clock) return;
    const rem = Math.ceil(focusRemainingMs() / 1000);
    clock.textContent = String(Math.floor(rem / 60)).padStart(2, "0") + ":" + String(rem % 60).padStart(2, "0");
    const bar = $("#focus-bar");
    if (bar) {
      const circ = 2 * Math.PI * 118;
      const frac = focus.totalMs ? focusElapsedMs() / focus.totalMs : 0;
      bar.style.strokeDashoffset = (circ * (1 - frac)).toFixed(1);
    }
  }

  // --- Alarms -------------------------------------------------------------------

  function renderAlarms() {
    const withAlert = state.activities.filter((a) => a.alert).sort((x, y) => x.start - y.start);
    const others = state.activities.filter((a) => !a.alert).sort((x, y) => x.start - y.start);
    const row = (a) => `<label class="item" style="cursor:pointer">
        <span class="time">${L.formatTime(a.start)}</span>
        <span class="grow"><span class="title">${esc(a.name)}</span><br><span class="small muted">${esc(repeatLabel(a))}</span></span>
        <input type="checkbox" class="check" data-action="toggle-alert" data-id="${esc(a.id)}" ${a.alert ? "checked" : ""} aria-label="Remind me for ${esc(a.name)}">
      </label>`;
    $("#alarms-root").innerHTML = `
      <div class="card" style="margin-bottom:14px">
        <p class="eyebrow">Preview</p>
        <p class="small muted" style="margin:6px 0 0">This screen previews how reminders are chosen. It does not ring, vibrate or notify you. On Android, reminders use the system alarm service and need the notification and exact-alarm permissions.</p>
      </div>
      <h3 class="section-title">Reminders on</h3>
      ${withAlert.length ? `<div class="stack">${withAlert.map(row).join("")}</div>` : `<div class="empty"><strong>No reminders on</strong>Turn on “Remind me” for an activity to see it here.</div>`}
      <h3 class="section-title">Other activities</h3>
      ${others.length ? `<div class="stack">${others.map(row).join("")}</div>` : `<p class="muted small">Every activity has a reminder on.</p>`}`;
  }

  function repeatLabel(a) {
    const when = a.repeat === "once" ? "Once on " + a.date : a.repeat === "daily" ? "Every day" : "Weekdays";
    return when + " · " + fmtRange(a);
  }

  // --- Settings -----------------------------------------------------------------

  function renderSettings() {
    const s = state.settings;
    const chip = (group, value, label, on) => `<button class="chip" aria-pressed="${on}" data-set="${group}" data-value="${value}">${label}</button>`;
    $("#settings-root").innerHTML = `
      <div class="stack">
        <div class="card">
          <div class="field"><label for="set-name">Name for greetings</label>
            <input class="input" id="set-name" maxlength="30" value="${esc(s.displayName)}" placeholder="Leave empty for a plain greeting"></div>
        </div>

        <div class="card">
          <p class="label">Theme</p>
          <div class="row" style="flex-wrap:wrap;margin-top:8px">
            ${chip("theme", "system", "System", s.theme === "system")}
            ${chip("theme", "dark", "Dark", s.theme === "dark")}
            ${chip("theme", "light", "Light", s.theme === "light")}
          </div>
        </div>

        <div class="card">
          <p class="label">Animations</p>
          <div class="row" style="flex-wrap:wrap;margin-top:8px">
            ${chip("motion", "auto", "Automatic", s.motion === "auto")}
            ${chip("motion", "on", "Always on", s.motion === "on")}
            ${chip("motion", "off", "Off", s.motion === "off")}
          </div>
          <p class="hint" style="margin-top:8px">Automatic follows your phone's “Reduce motion” setting.</p>
        </div>

        <div class="card">
          <p class="label">Privacy and permissions</p>
          <p class="small muted" style="margin:6px 0 0">Everything stays in this browser. Nothing is sent to a server, and this prototype asks for no permissions. The Android app will explain notification and exact-alarm permissions before asking for them.</p>
        </div>

        <div class="card">
          <p class="label">Data</p>
          <p class="small muted" style="margin:6px 0 12px">Reset puts back the sample day and to-dos. Your own items are removed.</p>
          <button class="btn btn-danger" data-action="reset-data">Reset to sample data</button>
        </div>

        <p class="hint">Chronexa prototype 0.2 · Visual preview of the planned Android app.</p>
      </div>`;
  }

  // --- Applying settings to the page -------------------------------------------

  function applySettings() {
    document.documentElement.dataset.theme = state.settings.theme;
    document.documentElement.dataset.motion = state.settings.motion;
  }

  // --- Events -------------------------------------------------------------------

  document.addEventListener("click", (e) => {
    const t = e.target.closest("[data-action],[data-go],[data-set],[data-filter],[data-focus-minutes]");
    if (!t) return;
    if (t.dataset.go) return (location.hash = t.dataset.go);
    if (t.dataset.set) return setting(t.dataset.set, t.dataset.value);
    if (t.dataset.filter) { todoFilter = t.dataset.filter; return renderTodo(); }
    if (t.dataset.focusMinutes) {
      if (focus.status !== "idle") return toast("Stop or reset the timer to change its length.");
      state.settings.focusMinutes = Number(t.dataset.focusMinutes);
      save();
      return renderFocus();
    }
    const id = t.dataset.id;
    switch (t.dataset.action) {
      case "new-activity": return openEditor(null);
      case "edit-activity": return openEditor(id);
      case "delete-activity": return deleteActivity(id);
      case "delete-from-editor": {
        $("#editor").close();
        return deleteActivity(editingId);
      }
      case "save-activity": return saveEditor();
      case "close-editor": return $("#editor").close();
      case "today": plannerKey = L.dateKey(new Date()); return renderPlanner();
      case "copy-day": return copyDay();
      case "toggle-done": {
        const k = L.completionKey(id, t.dataset.key);
        if (state.completions[k]) delete state.completions[k];
        else state.completions[k] = true;
        save();
        return render(currentView());
      }
      case "toggle-todo": {
        const item = state.todos.find((x) => x.id === id);
        if (item) item.done = !item.done;
        save();
        return renderTodo();
      }
      case "delete-todo": {
        state.todos = state.todos.filter((x) => x.id !== id);
        save();
        toast("To-do deleted");
        return renderTodo();
      }
      case "toggle-alert": {
        state.activities = state.activities.map((a) => (a.id === id ? { ...a, alert: !a.alert } : a));
        save();
        return renderAlarms();
      }
      case "focus-start": {
        if (focus.status === "paused") { focus.endAt = Date.now() + focus.remainingMs; focus.status = "running"; }
        else { focus.totalMs = focusTotalMs(); focus.endAt = Date.now() + focus.totalMs; focus.status = "running"; }
        return renderFocus();
      }
      case "focus-pause": {
        focus.remainingMs = Math.max(0, focus.endAt - Date.now());
        focus.status = "paused";
        return renderFocus();
      }
      case "focus-reset": {
        focus.status = "idle";
        focus.remainingMs = focusTotalMs();
        focus.totalMs = focusTotalMs();
        return renderFocus();
      }
      case "reset-data": {
        if (!window.confirm("Reset to the sample day? Your activities, to-dos and focus history will be replaced.")) return;
        state = freshState();
        save();
        applySettings();
        toast("Sample data restored");
        return render(currentView());
      }
      default: return undefined;
    }
  });

  document.addEventListener("submit", (e) => {
    if (e.target.id !== "todo-form") return;
    e.preventDefault();
    const title = $("#todo-title").value.trim();
    const due = $("#todo-due").value;
    if (!title) {
      $("#todo-error").textContent = "Give the to-do a short title.";
      return;
    }
    state.todos.push({ id: makeId(), title, due, done: false });
    if (save()) toast("To-do added");
    renderTodo();
  });

  document.addEventListener("input", (e) => {
    if (e.target.closest("#editor")) updateEditorHints();
  });

  document.addEventListener("change", (e) => {
    const r = e.target.dataset.role;
    if (r === "planner-date" && L.parseDateKey(e.target.value)) {
      plannerKey = e.target.value;
      renderPlanner();
    }
    if (e.target.id === "set-name") {
      state.settings.displayName = e.target.value.trim().slice(0, 30);
      save();
      toast("Greeting updated");
    }
    if (e.target.closest && e.target.closest("#editor")) updateEditorHints();
  });

  function setting(group, value) {
    if (group === "theme") state.settings.theme = value;
    if (group === "motion") state.settings.motion = value;
    save();
    applySettings();
    renderSettings();
  }

  function copyDay() {
    const target = $("#copy-target").value;
    if (!L.parseDateKey(target)) return toast("Pick a day to copy to first.");
    if (target === plannerKey) return toast("Choose a different day to copy to.");
    const { created, skipped } = L.copyDay(state.activities, plannerKey, target, makeId);
    if (created.length === 0) return toast("Nothing to copy: those activities are already there.");
    state.activities.push(...created);
    save();
    toast("Copied " + created.length + (created.length === 1 ? " activity" : " activities") + (skipped ? " · " + skipped + " already there" : ""));
    renderPlanner();
  }

  // --- Live clock and pause when hidden -----------------------------------------

  let lastMinute = -1;
  setInterval(() => {
    if (document.hidden) return;
    const now = new Date();
    const view = currentView();
    if (view === "focus" && focus.status === "running") focusTick();
    if (now.getMinutes() !== lastMinute) {
      lastMinute = now.getMinutes();
      if (view === "home" || view === "planner") render(view);
    }
    if (view === "home") {
      const c = $("#home-clock");
      if (c) c.textContent = String(now.getHours()).padStart(2, "0") + ":" + String(now.getMinutes()).padStart(2, "0");
    }
  }, 1000);

  document.addEventListener("visibilitychange", () => {
    document.body.classList.toggle("page-hidden", document.hidden);
    if (!document.hidden) { lastMinute = -1; render(currentView()); }
  });

  $("#editor").addEventListener("cancel", () => { editingId = null; });

  window.addEventListener("hashchange", route);
  applySettings();
  if (!location.hash) history.replaceState(null, "", "#home");
  route();
  save();
})();
