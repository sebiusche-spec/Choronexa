/*
 * Chronexa prototype — pure logic. No DOM access, so it can be tested under Node.
 * Times are minutes from local midnight (0–1439). An activity whose end is not after its
 * start runs past midnight; its end is treated as end + 1440.
 */
(function (root, factory) {
  const api = factory();
  if (typeof module === "object" && module.exports) module.exports = api;
  else root.ChronexaLogic = api;
})(typeof self !== "undefined" ? self : this, function () {
  const DAY = 1440;

  const CATEGORIES = [
    { id: "routine", label: "Routine" },
    { id: "study", label: "Study" },
    { id: "exercise", label: "Exercise" },
    { id: "food", label: "Food" },
    { id: "break", label: "Break" },
    { id: "sleep", label: "Sleep" },
    { id: "other", label: "Other" },
  ];

  const ANIMATIONS = [
    "wake", "brush", "bath", "study", "physics", "chemistry", "maths",
    "computing", "exercise", "food", "break", "sleep", "calm",
  ];

  // Keyword rules, checked in order. The first match wins, so more specific words come first.
  const KEYWORD_RULES = [
    [/\b(wake|sunrise|morning|alarm)\b/i, "wake"],
    [/\b(brush|teeth|dental|floss)\b/i, "brush"],
    [/\b(bath|shower|wash)\b/i, "bath"],
    [/\b(physics|mechanics|kinematics|optics)\b/i, "physics"],
    [/\b(chemistry|chem|molecule|reaction|organic)\b/i, "chemistry"],
    [/\b(math|maths|mathematics|algebra|calculus|geometry|equation)\b/i, "maths"],
    [/\b(code|coding|computer|programming|algorithm|python|javascript)\b/i, "computing"],
    [/\b(study|revision|revise|read|reading|homework|notes|english)\b/i, "study"],
    [/\b(gym|exercise|workout|run|running|yoga|stretch|push-?ups?)\b/i, "exercise"],
    [/\b(lunch|dinner|breakfast|meal|eat|eating|snack|food|coffee|tea)\b/i, "food"],
    [/\b(break|rest|pause|walk|recharge)\b/i, "break"],
    [/\b(sleep|bed|nap|night)\b/i, "sleep"],
  ];
  const CATEGORY_ANIMATION = {
    routine: "calm", study: "study", exercise: "exercise", food: "food",
    break: "break", sleep: "sleep", other: "calm",
  };

  /** Chooses an animation key for an activity. A manual choice always wins. */
  function chooseAnimation(activity) {
    if (activity.animation && activity.animation !== "auto") {
      return activity.animation === "none" ? "none" : activity.animation;
    }
    const name = String(activity.name || "");
    for (const [pattern, key] of KEYWORD_RULES) {
      if (pattern.test(name)) return key;
    }
    return CATEGORY_ANIMATION[activity.category] || "calm";
  }

  /** "05:10" → 310. Returns null for anything that is not a valid HH:MM. */
  function parseTime(text) {
    const m = /^(\d{1,2}):(\d{2})$/.exec(String(text || "").trim());
    if (!m) return null;
    const h = Number(m[1]);
    const min = Number(m[2]);
    if (min > 59 || h > 24 || (h === 24 && min !== 0)) return null;
    return h * 60 + min;
  }

  /** 310 → "05:10". 1440 reads as "24:00". */
  function formatTime(minutes) {
    if (minutes >= DAY) return "24:00";
    const h = Math.floor(minutes / 60);
    const m = minutes % 60;
    return String(h).padStart(2, "0") + ":" + String(m).padStart(2, "0");
  }

  /** Length in minutes, allowing for activities that cross midnight. */
  function durationOf(activity) {
    return activity.end > activity.start
      ? activity.end - activity.start
      : DAY - activity.start + activity.end;
  }

  /** Date keys are local YYYY-MM-DD strings, so no timezone shifts them. */
  function dateKey(date) {
    const y = date.getFullYear();
    const m = String(date.getMonth() + 1).padStart(2, "0");
    const d = String(date.getDate()).padStart(2, "0");
    return `${y}-${m}-${d}`;
  }

  function parseDateKey(key) {
    const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(key || "");
    if (!m) return null;
    return new Date(Number(m[1]), Number(m[2]) - 1, Number(m[3]));
  }

  /** Does this activity occur on the day with key [key]? */
  function occursOn(activity, key) {
    if (!activity.repeat || activity.repeat === "once") return activity.date === key;
    const day = parseDateKey(key);
    if (!day) return false;
    if (activity.date && key < activity.date) return false;
    if (activity.repeat === "daily") return true;
    if (activity.repeat === "weekdays") {
      const dow = day.getDay();
      return dow >= 1 && dow <= 5;
    }
    return false;
  }

  /**
   * Activities that occur on [key], as occurrence objects with absolute start and end minutes
   * relative to that day's midnight. An overnight activity's end may exceed 1440.
   */
  function occurrencesOn(activities, key) {
    return activities
      .filter((a) => occursOn(a, key))
      .map((a) => {
        const end = a.end > a.start ? a.end : a.end + DAY;
        return { activity: a, key, start: a.start, end };
      })
      .sort((x, y) => x.start - y.start || x.activity.id.localeCompare(y.activity.id));
  }

  /**
   * Pairs of same-day occurrences that share any time. Touching activities (05:10 then 05:10)
   * are not overlapping. Overnight parts are compared against the next day's morning too.
   * Nothing is changed — this only reports.
   */
  function findOverlaps(occurrences) {
    const pairs = [];
    for (let i = 0; i < occurrences.length; i++) {
      for (let j = i + 1; j < occurrences.length; j++) {
        const a = occurrences[i];
        const b = occurrences[j];
        if (overlapsWithShift(a, b)) pairs.push([a.activity, b.activity]);
      }
    }
    return pairs;
  }

  function overlapsWithShift(a, b) {
    // Shifts cover an overnight activity meeting the start of the following day.
    for (const shift of [0, DAY, -DAY]) {
      if (a.start < b.end + shift && b.start + shift < a.end) return true;
    }
    return false;
  }

  /** Would [candidate] overlap any existing activity on [key]? Ignores the candidate's own id. */
  function conflictsFor(candidate, key, activities) {
    const others = activities.filter((a) => a.id !== candidate.id);
    const mine = occurrencesOn([{ ...candidate, date: key, repeat: "once" }], key)[0];
    if (!mine) return [];
    return occurrencesOn(others, key).filter((o) => overlapsWithShift(mine, o)).map((o) => o.activity);
  }

  /** Validation key, or null when the activity can be saved. */
  function validate(activity) {
    if (!activity.name || !activity.name.trim()) return "name";
    if (!Number.isInteger(activity.start) || activity.start < 0 || activity.start >= DAY) return "start";
    if (!Number.isInteger(activity.end) || activity.end < 1 || activity.end > DAY) return "end";
    if (activity.end === activity.start) return "zero";
    if (activity.repeat === "once" && !parseDateKey(activity.date)) return "date";
    return null;
  }

  /**
   * The state of the day at minute [nowMin] on key [key]: the current activity, the next one,
   * minutes left in the current one, and minutes until the next one starts.
   * Overnight activities that started yesterday and are still running are included.
   */
  function dayStatus(activities, key, nowMin) {
    const today = occurrencesOn(activities, key);
    const yesterdayKey = keyOffset(key, -1);
    const carried = occurrencesOn(activities, yesterdayKey)
      .filter((o) => o.end > DAY)
      .map((o) => ({ ...o, start: o.start - DAY, end: o.end - DAY }));
    const all = [...carried, ...today];
    const current = all.find((o) => o.start <= nowMin && nowMin < o.end) || null;
    const upcoming = all
      .filter((o) => o.start > nowMin)
      .sort((x, y) => x.start - y.start);
    const next = upcoming[0] || null;
    return {
      current: current ? current.activity : null,
      currentEnd: current ? current.end : null,
      minutesLeft: current ? current.end - nowMin : null,
      next: next ? next.activity : null,
      nextStart: next ? next.start : null,
      minutesUntilNext: next ? next.start - nowMin : null,
      total: today.length,
    };
  }

  /** A date key shifted by [days]. */
  function keyOffset(key, days) {
    const d = parseDateKey(key);
    if (!d) return key;
    d.setDate(d.getDate() + days);
    return dateKey(d);
  }

  /** Completion state is stored as "activityId|dateKey" to count each activity once per day. */
  function completionKey(activityId, key) {
    return `${activityId}|${key}`;
  }

  /** Done and total for [key]. Only occurrences that exist on that day count. */
  function progressOn(activities, completions, key) {
    const occ = occurrencesOn(activities, key);
    const done = occ.filter((o) => completions[completionKey(o.activity.id, key)]).length;
    const percent = occ.length === 0 ? 0 : Math.floor((done * 100) / occ.length);
    return { done, total: occ.length, percent };
  }

  /**
   * Copies the day [fromKey] to [toKey] as one-off activities. An activity already present on
   * the target day with the same name and times is skipped, so repeated copies do not duplicate.
   * [makeId] supplies new ids. Returns the new activities and how many were skipped.
   */
  function copyDay(activities, fromKey, toKey, makeId) {
    const existing = occurrencesOn(activities, toKey).map((o) => signature(o.activity));
    const created = [];
    let skipped = 0;
    for (const o of occurrencesOn(activities, fromKey)) {
      const sig = signature(o.activity);
      if (existing.includes(sig)) {
        skipped++;
        continue;
      }
      existing.push(sig);
      created.push({
        ...o.activity,
        id: makeId(),
        date: toKey,
        repeat: "once",
      });
    }
    return { created, skipped };
  }

  function signature(a) {
    return `${a.name.trim().toLowerCase()}|${a.start}|${a.end}`;
  }

  /** Moves an activity to a new start, keeping its length. Returns a new object. */
  function reschedule(activity, newStart) {
    const len = durationOf(activity);
    const end = newStart + len;
    return { ...activity, start: newStart, end: end >= DAY && end !== DAY ? end - DAY : end };
  }

  /** Sample data for a first visit. Times and names follow the brief. */
  function sampleActivities(key, makeId) {
    const base = (name, start, end, category, extra = {}) => ({
      id: makeId(), name, start, end, category,
      notes: "", repeat: "daily", date: key, animation: "auto", alert: false, subject: "", ...extra,
    });
    return [
      base("Wake up", 300, 302, "routine", { alert: true }),
      base("Brush", 302, 310, "routine"),
      base("Bath", 310, 330, "routine"),
      base("Exercise", 330, 345, "exercise", { repeat: "weekdays" }),
      base("Physics revision", 450, 570, "study", { subject: "Physics", repeat: "weekdays", alert: true }),
      base("Lunch", 780, 810, "food"),
      base("Chemistry problems", 840, 960, "study", { subject: "Chemistry", repeat: "weekdays" }),
      base("Night sleep", 1350, 295, "sleep", { repeat: "daily" }),
    ];
  }

  return {
    DAY, CATEGORIES, ANIMATIONS, chooseAnimation, parseTime, formatTime, durationOf,
    dateKey, parseDateKey, occursOn, occurrencesOn, findOverlaps, conflictsFor, validate,
    dayStatus, keyOffset, completionKey, progressOn, copyDay, reschedule, sampleActivities,
  };
});
