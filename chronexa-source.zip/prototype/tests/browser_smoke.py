"""Browser checks for the Chronexa prototype. Needs: pip install playwright && python -m playwright install chromium

Run from the repository root:  python3 prototype/tests/browser_smoke.py
Exits non-zero if any page error appears or an expected value is wrong.
"""
import pathlib
import sys
from playwright.sync_api import sync_playwright

INDEX = (pathlib.Path(__file__).resolve().parent.parent / "index.html").as_uri()
failures = []

def check(label, actual, expected=None):
    ok = expected is None or actual == expected
    print(("PASS " if ok else "FAIL ") + f"{label}: {actual}")
    if not ok:
        failures.append(label)

with sync_playwright() as p:
    browser = p.chromium.launch()
    page = browser.new_page(viewport={"width": 390, "height": 844})
    errors = []
    page.on("pageerror", lambda e: errors.append(str(e)))
    page.on("console", lambda m: errors.append(m.text) if m.type == "error" else None)
    page.on("dialog", lambda d: d.accept())

    page.goto(INDEX + "#home"); page.wait_for_timeout(300)
    check("home greeting", page.locator("#home-root h2").first.inner_text(), None)

    for view in ["planner", "todo", "focus", "alarms", "settings"]:
        page.goto(INDEX + "#" + view); page.wait_for_timeout(120)
        check(f"{view} view opens", page.locator(f"#view-{view}").evaluate("e => e.classList.contains('active')"), True)

    # Planner: add an overnight activity through the real editor.
    page.goto(INDEX + "#planner"); page.wait_for_timeout(200)
    before = page.locator("#planner-root .timeline .block").count()
    page.click("#planner-root button:has-text('Add activity')"); page.wait_for_timeout(100)
    page.fill("#f-name", "Late reading"); page.fill("#f-start", "23:00"); page.fill("#f-end", "00:30")
    page.click("button[data-action='save-activity']"); page.wait_for_timeout(200)
    check("editor closes after a valid save", page.evaluate("document.getElementById('editor').open"), False)
    check("timeline gains the new block", page.locator("#planner-root .timeline .block").count(), before + 1)

    # Overlap warning appears but nothing is moved.
    page.click("#planner-root button:has-text('Add activity')"); page.wait_for_timeout(100)
    page.fill("#f-name", "Clash test"); page.fill("#f-start", "05:05"); page.fill("#f-end", "05:20"); page.wait_for_timeout(100)
    check("overlap warning names both clashes", "Brush" in page.locator("#f-overlap").inner_text() and "Bath" in page.locator("#f-overlap").inner_text(), True)
    page.click("button[data-action='close-editor']")

    # Completion ticks update progress and persist.
    page.locator("#planner-root input[data-action='toggle-done']").first.check(); page.wait_for_timeout(120)
    check("progress counts the tick", "1 of" in page.locator("text=Completed").locator("..").inner_text(), True)
    page.reload(); page.wait_for_timeout(200)
    stored = page.evaluate("JSON.parse(localStorage.getItem('chronexa.prototype.v1')).completions")
    check("completion persists across reload", len(stored), 1)

    # To-do add.
    page.goto(INDEX + "#todo"); page.wait_for_timeout(120)
    page.fill("#todo-title", "Buy graph paper"); page.click("#todo-form button[type=submit]"); page.wait_for_timeout(120)
    check("to-do is added", page.locator("#todo-root .item").count() >= 1, True)

    # Focus: start then reset.
    page.goto(INDEX + "#focus"); page.wait_for_timeout(120)
    page.click("button[data-action='focus-start']"); page.wait_for_timeout(300)
    check("focus shows running state", page.locator("#focus-state").inner_text(), "Focusing")
    page.click("button[data-action='focus-reset']"); page.wait_for_timeout(100)
    check("focus reset returns to ready", page.locator("#focus-state").inner_text(), "Ready")

    # Settings.
    page.goto(INDEX + "#settings"); page.wait_for_timeout(120)
    page.click("button[data-set='theme'][data-value='light']")
    check("theme choice applies", page.evaluate("document.documentElement.dataset.theme"), "light")

    check("no page errors", errors or "none", "none")
    browser.close()

if failures:
    print("FAILED:", failures)
    sys.exit(1)
print("all browser checks passed")
