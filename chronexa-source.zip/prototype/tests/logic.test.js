const test = require("node:test");
const assert = require("node:assert/strict");
const L = require("../assets/logic.js");

const KEY = "2026-10-23"; // a Friday
const MON = "2026-10-19";
let n = 0;
const id = () => "a" + ++n;
const act = (name, start, end, extra = {}) => ({
  id: id(), name, start, end, category: "routine", notes: "",
  repeat: "daily", date: KEY, animation: "auto", alert: false, subject: "", ...extra,
});

test("parseTime accepts HH:MM and rejects everything else", () => {
  assert.equal(L.parseTime("05:10"), 310);
  assert.equal(L.parseTime("24:00"), 1440);
  assert.equal(L.parseTime("00:00"), 0);
  assert.equal(L.parseTime("9:5"), null);
  assert.equal(L.parseTime("12:60"), null);
  assert.equal(L.parseTime("24:30"), null);
  assert.equal(L.parseTime(""), null);
  assert.equal(L.parseTime(undefined), null);
});

test("formatTime round-trips and shows 24:00 for the end of day", () => {
  assert.equal(L.formatTime(310), "05:10");
  assert.equal(L.formatTime(1440), "24:00");
  assert.equal(L.parseTime(L.formatTime(777)), 777);
});

test("durationOf handles same-day and overnight activities", () => {
  assert.equal(L.durationOf({ start: 300, end: 302 }), 2);
  assert.equal(L.durationOf({ start: 1380, end: 360 }), 420); // 23:00 to 06:00 is 7 hours
});

test("touching activities do not overlap; sharing a minute does", () => {
  const a = act("Brush", 302, 310);
  const b = act("Bath", 310, 330);
  assert.deepEqual(L.findOverlaps(L.occurrencesOn([a, b], KEY)), []);
  const c = act("Overlap", 309, 315);
  assert.equal(L.findOverlaps(L.occurrencesOn([a, c], KEY)).length, 1);
});

test("overnight activity overlaps an early-morning activity via the midnight shift", () => {
  const night = act("Study late", 1380, 60); // 23:00 to 01:00
  const early = act("Wake", 30, 60);          // 00:30 to 01:00 on the same date
  assert.equal(L.findOverlaps(L.occurrencesOn([night, early], KEY)).length, 1);
});

test("overnight activity that ends before its neighbour starts does not overlap", () => {
  const night = act("Sleep", 1380, 270); // 23:00 to 04:30
  const morning = act("Wake", 300, 302); // 05:00
  assert.deepEqual(L.findOverlaps(L.occurrencesOn([night, morning], KEY)), []);
});

test("conflictsFor ignores the activity's own previous version", () => {
  const a = act("Physics", 540, 600);
  assert.deepEqual(L.conflictsFor({ ...a, start: 550, end: 610 }, KEY, [a]), []);
  const b = act("Maths", 580, 620);
  assert.equal(L.conflictsFor({ ...a, id: "new" }, KEY, [b]).length, 1);
});

test("validate rejects bad input with a key and accepts a good activity", () => {
  assert.equal(L.validate(act("  ", 1, 2)), "name");
  assert.equal(L.validate(act("X", 540, 540)), "zero");
  assert.equal(L.validate(act("X", 540, 1441)), "end");
  assert.equal(L.validate(act("X", 540, 600, { repeat: "once", date: "bad" })), "date");
  assert.equal(L.validate(act("X", 540, 600)), null);
});

test("once activities occur only on their date", () => {
  const a = act("Dentist", 600, 660, { repeat: "once", date: KEY });
  assert.equal(L.occursOn(a, KEY), true);
  assert.equal(L.occursOn(a, "2026-10-24"), false);
});

test("daily activities start on their date and not before", () => {
  const a = act("Brush", 302, 310, { date: KEY });
  assert.equal(L.occursOn(a, KEY), true);
  assert.equal(L.occursOn(a, "2026-10-24"), true);
  assert.equal(L.occursOn(a, "2026-10-22"), false);
});

test("weekday activities skip Saturday and Sunday", () => {
  const a = act("Physics", 540, 600, { repeat: "weekdays", date: MON });
  assert.equal(L.occursOn(a, MON), true);            // Monday 19 Oct
  assert.equal(L.occursOn(a, KEY), true);            // Friday 23 Oct
  assert.equal(L.occursOn(a, "2026-10-24"), false);  // Saturday 24 Oct
  assert.equal(L.occursOn(a, "2026-10-25"), false);  // Sunday 25 Oct
});

test("dayStatus reports the current activity, minutes left, and the next start", () => {
  const acts = [act("Brush", 302, 310), act("Bath", 310, 330)];
  const s = L.dayStatus(acts, KEY, 305);
  assert.equal(s.current.name, "Brush");
  assert.equal(s.minutesLeft, 5);
  assert.equal(s.next.name, "Bath");
  assert.equal(s.minutesUntilNext, 5);
});

test("dayStatus between activities has no current activity", () => {
  const acts = [act("Brush", 302, 310), act("Bath", 320, 330)];
  const s = L.dayStatus(acts, KEY, 315);
  assert.equal(s.current, null);
  assert.equal(s.next.name, "Bath");
});

test("dayStatus carries an overnight activity from yesterday into the early morning", () => {
  // Started yesterday, so it must be on yesterday's date to be carried into today.
  const sleep = act("Sleep", 1380, 360, { date: "2026-10-22" }); // 23:00 to 06:00
  const s = L.dayStatus([sleep], KEY, 120); // 02:00 today
  assert.equal(s.current.name, "Sleep");
  assert.equal(s.minutesLeft, 240);
});

test("dayStatus after the last activity has no next", () => {
  const s = L.dayStatus([act("Brush", 302, 310)], KEY, 1000);
  assert.equal(s.next, null);
  assert.equal(s.minutesUntilNext, null);
});

test("progress counts each activity once per day and rounds down", () => {
  const a = act("A", 300, 310), b = act("B", 310, 320), c = act("C", 320, 330);
  const done = { [L.completionKey(a.id, KEY)]: true, [L.completionKey(b.id, KEY)]: true };
  assert.deepEqual(L.progressOn([a, b, c], done, KEY), { done: 2, total: 3, percent: 66 });
});

test("progress for an empty day is zero, not NaN", () => {
  assert.deepEqual(L.progressOn([], {}, KEY), { done: 0, total: 0, percent: 0 });
});

test("completion on another date does not count", () => {
  const a = act("A", 300, 310);
  const done = { [L.completionKey(a.id, "2026-10-22")]: true };
  assert.equal(L.progressOn([a], done, KEY).done, 0);
});

test("copyDay makes one-off copies on the target date and skips duplicates", () => {
  const a = act("Brush", 302, 310, { repeat: "once" }), b = act("Bath", 310, 330, { repeat: "once" });
  const existing = act("brush", 302, 310, { repeat: "once", date: "2026-10-24" }); // same name+times
  const { created, skipped } = L.copyDay([a, b, existing], KEY, "2026-10-24", id);
  assert.equal(skipped, 1);
  assert.equal(created.length, 1);
  assert.equal(created[0].name, "Bath");
  assert.equal(created[0].date, "2026-10-24");
  assert.equal(created[0].repeat, "once");
  assert.notEqual(created[0].id, b.id);
});

test("copying the same day twice creates nothing the second time", () => {
  const a = act("Brush", 302, 310, { repeat: "once" });
  const first = L.copyDay([a], KEY, "2026-10-24", id);
  const second = L.copyDay([a, ...first.created], KEY, "2026-10-24", id);
  assert.equal(second.created.length, 0);
});

test("reschedule keeps the length and wraps past midnight", () => {
  const a = act("Sleep", 1380, 360); // 7 hours
  const moved = L.reschedule(a, 1410); // 23:30
  assert.equal(moved.start, 1410);
  assert.equal(L.durationOf(moved), 420);
  assert.equal(moved.end, 390); // 06:30 next morning
});

test("chooseAnimation: a manual choice beats the keywords; 'none' turns it off", () => {
  assert.equal(L.chooseAnimation({ name: "Physics", category: "study", animation: "sleep" }), "sleep");
  assert.equal(L.chooseAnimation({ name: "Physics", category: "study", animation: "none" }), "none");
});

test("chooseAnimation: keywords first, then category, then calm", () => {
  assert.equal(L.chooseAnimation({ name: "Wake up", category: "other", animation: "auto" }), "wake");
  assert.equal(L.chooseAnimation({ name: "Brush teeth", category: "routine", animation: "auto" }), "brush");
  assert.equal(L.chooseAnimation({ name: "Chemistry", category: "study", animation: "auto" }), "chemistry");
  assert.equal(L.chooseAnimation({ name: "Essay", category: "study", animation: "auto" }), "study");
  assert.equal(L.chooseAnimation({ name: "Walk", category: "other", animation: "auto" }), "break");
  assert.equal(L.chooseAnimation({ name: "Zzz", category: "other", animation: "auto" }), "calm");
});

test("sample data is valid and matches the brief's times", () => {
  const sample = L.sampleActivities(KEY, id);
  assert.ok(sample.every((a) => L.validate(a) === null));
  const brush = sample.find((a) => a.name === "Brush");
  assert.equal(L.formatTime(brush.start) + "–" + L.formatTime(brush.end), "05:02–05:10");
});

test("the sample day has no overlapping activities", () => {
  const sample = L.sampleActivities(KEY, id);
  assert.deepEqual(L.findOverlaps(L.occurrencesOn(sample, KEY)), []);
});
