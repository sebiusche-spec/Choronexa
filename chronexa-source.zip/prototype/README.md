# Chronexa — visual prototype

A standalone, dependency-free HTML/CSS/JavaScript preview of the Chronexa planner.
It is a design and interaction prototype. It does **not** set alarms, send notifications, or request permissions.

## Open it on your phone

1. Download the project ZIP (or clone the branch) and extract it.
2. Open `prototype/index.html` in Chrome or Firefox on Android (use the Files app, then *Open with*).
3. Use the bottom bar to move between Home, Planner, To-do, Focus, Alarms and Settings.

If your browser does not keep changes made from a local file, host the `prototype/` folder as static
files instead (for example GitHub Pages). Nothing in it needs a server or a key.

## What works

- Home: greeting, live clock, current and next activity with a countdown, daily progress, today's checklist, quick actions.
- Planner: 24-hour minute-level timeline, add / edit / delete / complete, overnight activities, overlap warnings that never move anything, copy a day to another date.
- Activity editor: name, start and end (HH:MM), category, subject, repeat (once, every day, weekdays), date, notes, animation choice, reminder preview.
- Animations: 13 activity scenes, chosen from the name or category, or picked by hand, or turned off.
- To-do: add, complete, delete, due date and time, filters.
- Focus: start, pause, resume, reset, session length, finished sessions saved.
- Settings: name for the greeting, theme (system, light, dark), animations (automatic, always on, off), reset to sample data.
- Data stays in the browser (localStorage). Sample data is loaded on the first visit.

## What is not in this prototype yet

- A Monday-to-Sunday weekly overview of the planner.
- Subjects and study dashboard, Notes, Progress and Achievements screens.
- Side-by-side layout for overlapping activities (they draw on top of each other; the list shows the warning).
- Equations in the Mathematics scene and molecule bonds in the Chemistry scene (both are simpler shapes for now).
- Any real alarm, notification, or background behaviour (see `docs/ANDROID_INTEGRATION_PLAN.md`).

## Tests

```bash
# Logic: 25 tests on overlaps, overnight activities, repeats, completion, copy-day, animations.
node --test prototype/tests/logic.test.js

# Browser: real clicks, persistence, focus, settings, and error checks.
pip install playwright && python -m playwright install chromium
python3 prototype/tests/browser_smoke.py
```

The browser checks were run in headless Chromium on this branch. They have not been run on a real phone.
