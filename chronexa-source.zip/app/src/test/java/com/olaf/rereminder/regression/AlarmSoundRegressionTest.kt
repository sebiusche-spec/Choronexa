// Part of Chronexa, a derivative of reReminder 4.0.1 — GNU GPL v3. See NOTICE.
package com.olaf.rereminder.regression

import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

/** The sound feature must not weaken the rules that keep alarms and reminders safe. */
class AlarmSoundRegressionTest {

    private val manifest = File("src/main/AndroidManifest.xml").readText()

    @Test
    fun playbackServiceIsPrivate() {
        val block = manifest.substringAfter("android:name=\".service.ActivityAlarmService\"").substringBefore("/>")
        assertTrue(block.contains("android:exported=\"false\""))
    }

    @Test
    fun noBroadStorageAccessIsRequested() {
        // Files are chosen one at a time through the document picker; no storage permission is needed.
        assertTrue(!manifest.contains("READ_EXTERNAL_STORAGE"))
        assertTrue(!manifest.contains("READ_MEDIA_AUDIO"))
    }

    @Test
    fun existingReminderPlaybackIsUntouched() {
        val alarmService = File("src/main/java/com/olaf/rereminder/service/AlarmService.kt").readText()
        assertTrue(alarmService.contains("ServiceInfo.FOREGROUND_SERVICE_TYPE_SYSTEM_EXEMPTED"))
    }
}
