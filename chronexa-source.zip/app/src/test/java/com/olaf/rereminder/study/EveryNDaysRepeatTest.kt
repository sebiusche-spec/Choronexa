// Part of Chronexa, a derivative of reReminder 4.0.1 — GNU GPL v3. See NOTICE.
package com.olaf.rereminder.study

import com.olaf.rereminder.ui.study.schedule.EVERY_DAYS_MAX
import com.olaf.rereminder.ui.study.schedule.EVERY_DAYS_MIN
import com.olaf.rereminder.ui.study.schedule.clampEveryDays
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDate

class EveryNDaysRepeatTest {

    private val first = LocalDate.of(2026, 10, 26)

    private fun every(n: Int) = StudyTask(
        id = 1, title = "Review", firstDate = first, startMinute = 420, endMinute = 480,
        repeat = TaskRepeat.EVERY_N_DAYS, repeatEvery = n,
    )

    @Test
    fun occursOnTheFirstDayAndThenEveryNDays() {
        val t = every(3)
        assertTrue(t.occursOn(first))
        assertFalse(t.occursOn(first.plusDays(1)))
        assertFalse(t.occursOn(first.plusDays(2)))
        assertTrue(t.occursOn(first.plusDays(3)))
        assertTrue(t.occursOn(first.plusDays(6)))
        assertFalse(t.occursOn(first.plusDays(7)))
    }

    @Test
    fun neverOccursBeforeTheFirstDay() {
        assertFalse(every(2).occursOn(first.minusDays(2)))
        assertFalse(every(2).occursOn(first.minusDays(1)))
    }

    @Test
    fun aCountBelowTheMinimumIsTreatedAsTwo() {
        // A stored count of 1 would be "every day"; the rule keeps the minimum of two.
        assertFalse(every(1).occursOn(first.plusDays(1)))
        assertTrue(every(1).occursOn(first.plusDays(2)))
    }

    @Test
    fun clampKeepsTheEditorWithinItsRange() {
        assertEquals(EVERY_DAYS_MIN, clampEveryDays(0))
        assertEquals(EVERY_DAYS_MAX, clampEveryDays(500))
        assertEquals(7, clampEveryDays(7))
    }

    @Test
    fun theCountSurvivesASaveAndLoad() {
        val data = StudyData.initial().copy(tasks = listOf(every(5)))
        val back = (StudyCodec.decode(StudyCodec.encode(data)) as StudyCodec.DecodeResult.Ok).data.tasks.single()
        assertEquals(TaskRepeat.EVERY_N_DAYS, back.repeat)
        assertEquals(5, back.repeatEvery)
    }

    @Test
    fun anOlderFileWithoutTheCountStillLoads() {
        val text = """{"schemaVersion":8,"tasks":[{"id":4,"title":"Old","firstDate":"2026-10-26","startMinute":420,"endMinute":480,"repeat":"DAILY"}]}"""
        val task = (StudyCodec.decode(text) as StudyCodec.DecodeResult.Ok).data.tasks.single()
        assertEquals(TaskRepeat.DAILY, task.repeat)
        assertEquals(2, task.repeatEvery)
    }
}
