// Part of Chronexa, a derivative of reReminder 4.0.1 — GNU GPL v3. See NOTICE.
package com.olaf.rereminder.ui.study.schedule

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class ParseClockTest {

    @Test
    fun parsesMinuteLevelSlots() {
        assertEquals(5 * 60, parseClock("05:00", isEnd = false))
        assertEquals(5 * 60 + 10, parseClock("05:10", isEnd = true))
        assertEquals(5 * 60 + 30, parseClock(" 05:30 ", isEnd = true))
    }

    @Test
    fun endOfDayCanBeWrittenAsMidnightOrMidnightTwentyFour() {
        assertEquals(1440, parseClock("00:00", isEnd = true))
        assertEquals(1440, parseClock("24:00", isEnd = true))
    }

    @Test
    fun startCannotBeMidnightTwentyFour() {
        assertNull(parseClock("24:00", isEnd = false))
    }

    @Test
    fun rejectsMalformedAndOutOfRangeTimes() {
        assertNull(parseClock("9:5", isEnd = false))
        assertNull(parseClock("12:60", isEnd = false))
        assertNull(parseClock("25:00", isEnd = true))
        assertNull(parseClock("", isEnd = false))
        assertNull(parseClock("noon", isEnd = false))
    }
}
