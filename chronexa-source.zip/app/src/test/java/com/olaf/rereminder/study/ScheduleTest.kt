// Part of Chronexa, a derivative of reReminder 4.0.1 — GNU GPL v3. See NOTICE.
package com.olaf.rereminder.study

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.LocalDateTime

class ScheduleTest {

    private val monday = LocalDate.of(2026, 10, 19) // a Monday

    private fun task(
        id: Long,
        start: Int,
        end: Int,
        date: LocalDate = monday,
        repeat: TaskRepeat = TaskRepeat.NONE,
        weekdays: Set<DayOfWeek> = emptySet(),
        last: LocalDate? = null,
    ) = StudyTask(
        id = id, title = "t$id", firstDate = date, startMinute = start, endMinute = end,
        repeat = repeat, weekdays = weekdays, lastDate = last,
    )

    private fun hm(h: Int, m: Int) = h * 60 + m

    @Test
    fun oneOffTaskOccursOnlyOnItsDate() {
        val t = task(1, hm(9, 0), hm(10, 0))
        assertTrue(t.occursOn(monday))
        assertFalse(t.occursOn(monday.plusDays(1)))
    }

    @Test
    fun dailyTaskOccursEveryDay() {
        val t = task(1, hm(7, 0), hm(7, 30), repeat = TaskRepeat.DAILY)
        for (i in 0L..13L) assertTrue(t.occursOn(monday.plusDays(i)))
    }

    @Test
    fun weekdaysTaskSkipsTheWeekend() {
        val t = task(1, hm(7, 0), hm(7, 30), repeat = TaskRepeat.WEEKDAYS)
        assertTrue(t.occursOn(monday))
        assertFalse(t.occursOn(monday.plusDays(5))) // Saturday
        assertFalse(t.occursOn(monday.plusDays(6))) // Sunday
    }

    @Test
    fun weeklyTaskUsesChosenDays() {
        val t = task(1, hm(18, 0), hm(19, 0), repeat = TaskRepeat.WEEKLY,
            weekdays = setOf(DayOfWeek.WEDNESDAY, DayOfWeek.SATURDAY))
        assertTrue(t.occursOn(monday.plusDays(2)))  // Wednesday
        assertTrue(t.occursOn(monday.plusDays(5)))  // Saturday
        assertFalse(t.occursOn(monday))
    }

    @Test
    fun repeatStopsAfterLastDate() {
        val t = task(1, hm(7, 0), hm(7, 30), repeat = TaskRepeat.DAILY, last = monday.plusDays(2))
        assertTrue(t.occursOn(monday.plusDays(2)))
        assertFalse(t.occursOn(monday.plusDays(3)))
    }

    @Test
    fun taskBeforeFirstDateNeverOccurs() {
        val t = task(1, hm(7, 0), hm(7, 30), repeat = TaskRepeat.DAILY)
        assertFalse(t.occursOn(monday.minusDays(1)))
    }

    @Test
    fun minuteLevelSlotsAreKeptExactly() {
        // The user's example: 05:00–05:10 brush, 05:10–05:30 bath.
        val brush = task(1, hm(5, 0), hm(5, 10))
        val bath = task(2, hm(5, 10), hm(5, 30))
        val occ = occurrencesStartingOn(listOf(brush, bath), monday)
        assertEquals(LocalDateTime.of(2026, 10, 19, 5, 0), occ[0].startAt)
        assertEquals(LocalDateTime.of(2026, 10, 19, 5, 10), occ[0].endAt)
        assertEquals(LocalDateTime.of(2026, 10, 19, 5, 30), occ[1].endAt)
        assertEquals(10, brush.durationMinutes)
    }

    @Test
    fun touchingTasksDoNotOverlap() {
        val a = task(1, hm(9, 0), hm(10, 0))
        val b = task(2, hm(10, 0), hm(11, 0))
        assertTrue(findOverlaps(occurrencesStartingOn(listOf(a, b), monday)).isEmpty())
    }

    @Test
    fun partialOverlapIsReported() {
        val a = task(1, hm(9, 0), hm(10, 30))
        val b = task(2, hm(10, 0), hm(11, 0))
        val pairs = findOverlaps(occurrencesStartingOn(listOf(a, b), monday))
        assertEquals(1, pairs.size)
    }

    @Test
    fun overnightTaskOverlapsEarlyMorningTaskTheNextDay() {
        // Mon 22:00 → Tue 07:00 sleep-study block, and Tue 06:30–08:00 physics.
        val night = task(1, hm(22, 0), hm(7, 0))
        val morning = task(2, hm(6, 30), hm(8, 0), date = monday.plusDays(1))
        val tuesday = occurrencesTouching(listOf(night, morning), monday.plusDays(1))
        assertEquals(1, findOverlaps(tuesday).size)
    }

    @Test
    fun overnightTaskCountsOnItsStartDate() {
        val night = task(1, hm(22, 0), hm(6, 0))
        val occ = night.occurrenceOn(monday)
        assertEquals(LocalDateTime.of(2026, 10, 20, 6, 0), occ.endAt)
        assertTrue(night.crossesMidnight)
    }

    @Test
    fun editingATaskDoesNotConflictWithItsOwnOldVersion() {
        val existing = listOf(task(1, hm(9, 0), hm(10, 0)))
        val edited = task(1, hm(9, 15), hm(10, 15))
        assertTrue(conflictsFor(edited, monday, existing).isEmpty())
    }

    @Test
    fun newTaskReportsItsConflicts() {
        val existing = listOf(task(1, hm(9, 0), hm(10, 0)))
        val candidate = task(2, hm(9, 30), hm(10, 30))
        assertEquals(1, conflictsFor(candidate, monday, existing).size)
    }

    @Test
    fun overdueOnlyWhenNotDoneAndPastEnd() {
        val occ = task(1, hm(9, 0), hm(10, 0)).occurrenceOn(monday)
        val afterEnd = LocalDateTime.of(2026, 10, 19, 10, 1)
        assertTrue(isOverdue(occ, completed = false, now = afterEnd))
        assertFalse(isOverdue(occ, completed = true, now = afterEnd))
        assertFalse(isOverdue(occ, completed = false, now = LocalDateTime.of(2026, 10, 19, 9, 30)))
    }

    @Test
    fun dailyPercentRoundsDown() {
        val tasks = listOf(
            task(1, hm(9, 0), hm(10, 0)),
            task(2, hm(10, 0), hm(11, 0)),
            task(3, hm(11, 0), hm(12, 0)),
        )
        val done = setOf(Completion(1, monday), Completion(2, monday))
        val s = summarizeDay(tasks, done, monday)
        assertEquals(66, s.percent)
        assertFalse(s.allDone)
    }

    @Test
    fun emptyDayIsZeroPercentAndNotDone() {
        val s = summarizeDay(emptyList(), emptySet(), monday)
        assertEquals(0, s.percent)
        assertFalse(s.allDone)
    }

    @Test
    fun completionOnAnotherDateDoesNotCount() {
        val tasks = listOf(task(1, hm(9, 0), hm(10, 0), repeat = TaskRepeat.DAILY))
        val s = summarizeDay(tasks, setOf(Completion(1, monday.minusDays(1))), monday)
        assertEquals(0, s.completed)
    }

    @Test
    fun weekStartFollowsChosenFirstDay() {
        val wednesday = monday.plusDays(2)
        assertEquals(monday, weekStart(wednesday, DayOfWeek.MONDAY))
        // Sunday 18 Oct is the day before Monday 19 Oct.
        assertEquals(monday.minusDays(1), weekStart(wednesday, DayOfWeek.SUNDAY))
        assertEquals(wednesday, weekStart(wednesday, DayOfWeek.WEDNESDAY))
    }

    @Test
    fun validationRejectsBadTasks() {
        assertEquals("title_required", task(1, 0, 60).copy(title = " ").validationError())
        assertEquals("zero_length", task(1, hm(9, 0), hm(9, 0)).validationError())
        assertEquals("weekday_required",
            task(1, 0, 60, repeat = TaskRepeat.WEEKLY).validationError())
        assertNull(task(1, hm(5, 0), hm(5, 10)).validationError())
    }

    @Test
    fun wholeDayTaskIsValid() {
        val t = task(1, 0, MINUTES_PER_DAY)
        assertNull(t.validationError())
        assertEquals(MINUTES_PER_DAY, t.durationMinutes)
    }
}
