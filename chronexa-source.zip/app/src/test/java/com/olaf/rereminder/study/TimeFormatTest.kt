// Part of Chronexa, a derivative of reReminder 4.0.1 — GNU GPL v3. See NOTICE.
package com.olaf.rereminder.study

import org.junit.Assert.assertEquals
import org.junit.Test

class TimeFormatTest {

    private fun min(h: Int, m: Int) = h * 60 + m

    @Test
    fun midnightIsTwelveAm() {
        assertEquals("12:00 AM", clock12Hour(min(0, 0)))
        assertEquals("12:00 AM", clock12Hour(MINUTES_PER_DAY))
    }

    @Test
    fun noonIsTwelvePm() {
        assertEquals("12:00 PM", clock12Hour(min(12, 0)))
        assertEquals("12:30 PM", clock12Hour(min(12, 30)))
    }

    @Test
    fun morningTimesAreAm() {
        assertEquals("5:00 AM", clock12Hour(min(5, 0)))
        assertEquals("5:20 AM", clock12Hour(min(5, 20)))
        assertEquals("12:01 AM", clock12Hour(1))
        assertEquals("11:59 AM", clock12Hour(min(11, 59)))
    }

    @Test
    fun eveningTimesArePm() {
        assertEquals("8:45 PM", clock12Hour(min(20, 45)))
        assertEquals("1:00 PM", clock12Hour(min(13, 0)))
        assertEquals("11:00 PM", clock12Hour(min(23, 0)))
        assertEquals("11:59 PM", clock12Hour(min(23, 59)))
    }

    @Test
    fun exampleScheduleReadsAsTheBriefAsks() {
        // Wake up 5:00–5:02, Brush 5:02–5:10, Bath 5:10–5:30, Exercise 5:30–5:45.
        assertEquals("5:00 AM", clock12Hour(min(5, 0)))
        assertEquals("5:02 AM", clock12Hour(min(5, 2)))
        assertEquals("5:30 AM", clock12Hour(min(5, 30)))
        assertEquals("5:45 AM", clock12Hour(min(5, 45)))
    }

    @Test
    fun displayChangesNeverChangeTheStoredMinute() {
        // Editing and saving a task without changing its time keeps the minute exactly as stored.
        val stored = min(5, 20)
        val edited = StudyTask(id = 1, title = "Bath", firstDate = java.time.LocalDate.of(2026, 10, 23),
            startMinute = stored, endMinute = min(5, 30)).copy(title = "Morning bath")
        assertEquals(stored, edited.startMinute)
        assertEquals("5:20 AM", clock12Hour(edited.startMinute))
    }

    @Test
    fun everyMinuteOfTheDayFormatsWithoutError() {
        for (m in 0 until MINUTES_PER_DAY) {
            val text = clock12Hour(m)
            assertEquals(true, Regex("""^(1[0-2]|[1-9]):[0-5]\d (AM|PM)$""").matches(text))
        }
    }
}
