// Part of Chronexa, a derivative of reReminder 4.0.1 — GNU GPL v3. See NOTICE.
package com.olaf.rereminder.data

import com.olaf.rereminder.data.SoundChoice
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class VideoAlarmTest {

    private val video = VideoChoice(uri = "content://media/video/7", name = "Sunrise.mp4")
    private fun alarm(id: Int = 1) = Reminder(id = id, name = "Wake up")

    // --- Saving and reloading -------------------------------------------------------------

    @Test
    fun aVideoAssignmentRoundTripsThroughTheStore() {
        val saved = alarm().withVideo(video.copy(audio = VideoAudioMode.BOTH, volumePercent = 60, loop = false))
        val back = ReminderCodec.decode(ReminderCodec.encode(listOf(saved)), nowMillis = 0L).single()
        assertEquals(saved.video, back.video)
    }

    @Test
    fun anAlarmWithNoVideoReloadsWithNoVideo() {
        val back = ReminderCodec.decode(ReminderCodec.encode(listOf(alarm())), nowMillis = 0L).single()
        assertNull(back.video)
    }

    // --- Editing ----------------------------------------------------------------------------

    @Test
    fun editingAlarmsVideoReplacesOnlyTheVideo() {
        val first = alarm().withVideo(video)
        val other = video.copy(uri = "content://media/video/9", name = "Storm.mp4")
        val edited = first.withVideo(other)
        assertEquals(other, edited.video)
        assertEquals(first.sound, edited.sound)
        assertEquals(first.id, edited.id)
    }

    @Test
    fun eachAlarmKeepsItsOwnVideo() {
        val a = alarm(1).withVideo(video)
        val b = alarm(2).withVideo(video.copy(uri = "content://media/video/9"))
        assertTrue(a.video!!.uri != b.video!!.uri)
    }

    @Test
    fun removingTheVideoKeepsTheRingtoneAndSchedule() {
        val ringtone = alarm().copy(sound = SoundChoice(mode = SoundMode.DEFAULT, toneUri = "content://tones/1"))
        val withVideo = ringtone.withVideo(video)
        val removed = withVideo.withoutVideo()
        assertNull(removed.video)
        assertEquals(ringtone.sound, removed.sound)
        assertEquals(ringtone.nextTriggerAt, removed.nextTriggerAt)
    }

    @Test
    fun changingTheVideoDoesNotMoveTheAlarm() {
        val timed = alarm().copy(nextTriggerAt = 1_000L, anchorMillis = 500L)
        val changed = timed.withVideo(video)
        assertEquals(timed.nextTriggerAt, changed.nextTriggerAt)
        assertEquals(timed.anchorMillis, changed.anchorMillis)
    }

    // --- What plays ---------------------------------------------------------------------------

    @Test
    fun noVideoMeansTheNormalSound() {
        assertEquals(VideoPlayback.None, resolveVideoPlayback(null, canOpen = true))
    }

    @Test
    fun aVideoWithItsOwnAudioPlaysThatAudioOnly() {
        val play = resolveVideoPlayback(video.copy(audio = VideoAudioMode.VIDEO_AUDIO), canOpen = true) as VideoPlayback.Play
        assertTrue(play.playVideoAudio)
        assertTrue(!play.playRingtone)
    }

    @Test
    fun disablingTheVideoAudioKeepsTheRingtonePlaying() {
        // The video still shows, but its own sound is off: only the ringtone plays.
        val play = resolveVideoPlayback(video.copy(audio = VideoAudioMode.RINGTONE), canOpen = true) as VideoPlayback.Play
        assertTrue(!play.playVideoAudio)
        assertTrue(play.playRingtone)
    }

    @Test
    fun bothPlayTogether() {
        val play = resolveVideoPlayback(video.copy(audio = VideoAudioMode.BOTH), canOpen = true) as VideoPlayback.Play
        assertTrue(play.playVideoAudio && play.playRingtone)
    }

    @Test
    fun volumeIsKeptWithinZeroToOneHundred() {
        assertEquals(100, (resolveVideoPlayback(video.copy(volumePercent = 400), canOpen = true) as VideoPlayback.Play).volumePercent)
        assertEquals(0, (resolveVideoPlayback(video.copy(volumePercent = -5), canOpen = true) as VideoPlayback.Play).volumePercent)
    }

    @Test
    fun loopingFollowsTheSavedSetting() {
        assertTrue((resolveVideoPlayback(video.copy(loop = true), canOpen = true) as VideoPlayback.Play).loop)
        assertTrue(!(resolveVideoPlayback(video.copy(loop = false), canOpen = true) as VideoPlayback.Play).loop)
    }

    @Test
    fun aMissingVideoFallsBackToTheRingtone() {
        // The file was moved or deleted. The alarm must still be able to ring, so the fallback is the ringtone.
        assertEquals(VideoPlayback.FallbackToRingtone, resolveVideoPlayback(video, canOpen = false))
    }

    // --- Picking a file ---------------------------------------------------------------------

    @Test
    fun onlyMp4VideosAreAccepted() {
        assertTrue(isSupportedVideo("video/mp4", "Sunrise.mp4"))
        assertTrue(!isSupportedVideo("audio/mpeg", "Song.mp3"))
        assertTrue(!isSupportedVideo("image/png", "Photo.png"))
    }

    @Test
    fun aFileWithNoTypeIsAcceptedOnlyIfItIsNamedMp4() {
        assertTrue(isSupportedVideo(null, "clip.MP4"))
        assertTrue(!isSupportedVideo(null, "clip.mkv"))
    }

    @Test
    fun replacingTheFileKeepsTheSettingsTheUserChose() {
        val chosen = video.copy(audio = VideoAudioMode.BOTH, volumePercent = 35, loop = false)
        val replaced = chosen.replacingFile("content://media/video/9", "Storm.mp4")
        assertEquals("content://media/video/9", replaced.uri)
        assertEquals("Storm.mp4", replaced.name)
        assertEquals(VideoAudioMode.BOTH, replaced.audio)
        assertEquals(35, replaced.volumePercent)
        assertTrue(!replaced.loop)
    }

    @Test
    fun pickingFirstUsesTheDefaultSettings() {
        val first = (null as VideoChoice?).replacingFile("content://media/video/3", "Clip.mp4")
        assertEquals(VideoAudioMode.VIDEO_AUDIO, first.audio)
        assertEquals(100, first.volumePercent)
        assertTrue(first.loop)
    }

    @Test
    fun editingTheVideoOfASavedAlarmKeepsItsIdTimeRepeatAndRingtone() {
        val saved = alarm(7).copy(
            nextTriggerAt = 9_000L,
            anchorMillis = 4_000L,
            sound = SoundChoice(mode = SoundMode.TONE, toneUri = "content://tones/3"),
        ).withVideo(video)
        val edited = saved.withVideo(video.replacingFile("content://media/video/9", "Storm.mp4"))
        assertEquals(saved.id, edited.id)
        assertEquals(saved.nextTriggerAt, edited.nextTriggerAt)
        assertEquals(saved.anchorMillis, edited.anchorMillis)
        assertEquals(saved.repeat, edited.repeat)
        assertEquals(saved.sound, edited.sound)
        assertEquals("Storm.mp4", edited.video!!.name)
    }

    @Test
    fun theEditedVideoIsWhatIsSavedAndReloaded() {
        val edited = alarm(4).withVideo(video.replacingFile("content://media/video/9", "Storm.mp4").copy(volumePercent = 20))
        val back = ReminderCodec.decode(ReminderCodec.encode(listOf(edited)), nowMillis = 0L).single()
        assertEquals(edited.video, back.video)
    }
}
