// Part of Chronexa, a derivative of reReminder 4.0.1 — GNU GPL v3. See NOTICE.
package com.olaf.rereminder.regression

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

/**
 * Guards against a regression that broke the original reminder editor: Chronexa's study screens
 * once reused upstream string keys, so "Starts" threw and the reminder editor showed study wording.
 * These tests read the real resource file and the real sources, so they fail on the same mistake.
 */
class ReminderStringRegressionTest {

    private val strings: Map<String, String> by lazy {
        val xml = File("src/main/res/values/strings.xml").readText()
        Regex("""<string name="([^"]+)"[^>]*>(.*?)</string>""", RegexOption.DOT_MATCHES_ALL)
            .findAll(xml)
            .associate { it.groupValues[1] to it.groupValues[2] }
    }

    private fun source(path: String): String = File("src/main/java/com/olaf/rereminder/$path").readText()

    @Test
    fun startsLabelFormatsWithTheTextAndTimeItIsGiven() {
        // "Starts" formats a day label (text) and a clock time (text). This used to throw
        // IllegalFormatConversionException, because the key had been swapped for one that expects numbers.
        val pattern = strings.getValue("schedule_summary")
        val label = String.format(pattern, "Tomorrow", "08:30")
        assertEquals("Tomorrow · 08:30", label)
    }

    @Test
    fun originalReminderEditorWordingIsKept() {
        assertEquals("New reminder", strings.getValue("editor_new_title"))
        assertEquals("Edit reminder", strings.getValue("editor_edit_title"))
        assertEquals("Delete timer", strings.getValue("editor_delete"))
        assertEquals("Delete this timer?", strings.getValue("editor_delete_confirm_title"))
    }

    @Test
    fun originalReminderFilesDoNotUseStudyStrings() {
        val upstream = listOf(
            "ui/editor/ReminderEditorScreen.kt",
            "ui/format/Durations.kt",
            "utils/TimeLabels.kt",
            "ui/components/StartMomentDialog.kt",
            "ui/main/MainScreen.kt",
        )
        val studyPrefixes = Regex("""R\.string\.(task_|todo_|schedule_done_summary|home_|focus_|subjects_|achievements_|study_|settings_(focus|theme|motion|first|sessions|short|long|group_about|group_appearance))""")
        for (file in upstream) {
            val hits = studyPrefixes.findAll(source(file)).map { it.value }.toList()
            assertTrue("$file uses study strings: $hits", hits.isEmpty())
        }
    }

    @Test
    fun everyStudyKeyIsDistinctFromEveryUpstreamKey() {
        // Study keys carry their own prefixes, so none can silently shadow an upstream key.
        val studyKeys = listOf("task_new_title", "task_edit_title", "task_delete", "task_delete_confirm_title", "schedule_done_summary")
        for (key in studyKeys) {
            assertTrue("$key must exist", strings.containsKey(key))
        }
        assertFalse(strings.getValue("schedule_done_summary") == strings.getValue("schedule_summary"))
    }
}
