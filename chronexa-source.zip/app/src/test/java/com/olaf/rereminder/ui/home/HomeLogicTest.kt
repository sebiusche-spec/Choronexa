// Part of Chronexa, a derivative of reReminder 4.0.1 — GNU GPL v3. See NOTICE.
package com.olaf.rereminder.ui.home

import com.olaf.rereminder.data.Reminder
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class HomeLogicTest {

    @Test
    fun greetingFollowsTheTimeOfDay() {
        assertEquals(DayPart.EVENING, dayPartFor(0))
        assertEquals(DayPart.EVENING, dayPartFor(4))
        assertEquals(DayPart.MORNING, dayPartFor(5))
        assertEquals(DayPart.MORNING, dayPartFor(11))
        assertEquals(DayPart.AFTERNOON, dayPartFor(12))
        assertEquals(DayPart.AFTERNOON, dayPartFor(17))
        assertEquals(DayPart.EVENING, dayPartFor(18))
        assertEquals(DayPart.EVENING, dayPartFor(23))
    }

    @Test
    fun nextAlarmIsTheSoonestUpcomingEnabledReminder() {
        val now = 1_000L
        val reminders = listOf(
            Reminder(id = 1, name = "Disabled", enabled = false, nextTriggerAt = 1_500L),
            Reminder(id = 2, name = "Stale", enabled = true, nextTriggerAt = 500L),
            Reminder(id = 3, name = "Later", enabled = true, nextTriggerAt = 5_000L),
            Reminder(id = 4, name = "Soonest", enabled = true, nextTriggerAt = 3_000L),
        )
        assertEquals(
            NextAlarm("Soonest", 3_000L),
            nextAlarmFrom(reminders, masterEnabled = true, now = now) { it.name },
        )
    }

    @Test
    fun nothingIsNextWhileEverythingIsPaused() {
        val reminders = listOf(Reminder(id = 1, name = "A", enabled = true, nextTriggerAt = 9_000L))
        assertNull(nextAlarmFrom(reminders, masterEnabled = false, now = 1_000L) { it.name })
    }

    @Test
    fun nothingIsNextWhenNoReminderIsScheduled() {
        assertNull(nextAlarmFrom(emptyList(), masterEnabled = true, now = 1_000L) { it.name })
    }
}
