// Part of Chronexa, a derivative of reReminder 4.0.1 — GNU GPL v3. See NOTICE.
package com.olaf.rereminder.study

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDate
import java.time.LocalDateTime

class TimeRulesTest {

    private val day = LocalDate.of(2026, 10, 23)

    @Test
    fun pickedEndOfMidnightMeansEndOfDay() {
        assertEquals(MINUTES_PER_DAY, endMinuteFromPicker(0, startMinute = 22 * 60))
    }

    @Test
    fun midnightToMidnightStaysZeroSoItIsReportedAsEmpty() {
        assertEquals(0, endMinuteFromPicker(0, startMinute = 0))
        assertEquals("zero_length", timeRangeIssue(0, 0))
    }

    @Test
    fun ordinaryEndTimesAreKept() {
        assertEquals(10 * 60, endMinuteFromPicker(10 * 60, startMinute = 9 * 60))
    }

    @Test
    fun startEqualToEndIsRejected() {
        assertEquals("zero_length", timeRangeIssue(9 * 60, 9 * 60))
    }

    @Test
    fun overnightRangeIsAllowed() {
        // 23:00 to 06:00 is a real activity, not an error.
        assertNull(timeRangeIssue(23 * 60, 6 * 60))
    }

    @Test
    fun outOfRangeMinutesAreRejected() {
        assertEquals("time_out_of_range", timeRangeIssue(-1, 60))
        assertEquals("time_out_of_range", timeRangeIssue(60, MINUTES_PER_DAY))
    }

    @Test
    fun lengthCountsAcrossMidnight() {
        assertEquals(30, lengthMinutes(5 * 60 + 10, 5 * 60 + 40))
        assertEquals(7 * 60, lengthMinutes(23 * 60, 6 * 60))
        assertEquals(MINUTES_PER_DAY, lengthMinutes(0, MINUTES_PER_DAY))
    }

    @Test
    fun endsNextDayIsTrueOnlyForRangesThatCrossMidnight() {
        assertTrue(endsNextDay(23 * 60, 6 * 60))
        assertFalse(endsNextDay(22 * 60, MINUTES_PER_DAY)) // ends at midnight, same day
        assertFalse(endsNextDay(9 * 60, 10 * 60))
    }

    @Test
    fun todoNeedsADateBeforeAnyTime() {
        assertNull(todoDueMoment(null, 9 * 60))
        assertNull(todoDueMoment(null, null))
    }

    @Test
    fun todoWithDateAndNoTimeUsesTheDefaultTime() {
        assertEquals(day.atTime(9, 0), todoDueMoment(day, null))
    }

    @Test
    fun todoWithDateAndTimeKeepsBoth() {
        assertEquals(LocalDateTime.of(2026, 10, 23, 18, 30), todoDueMoment(day, 18 * 60 + 30))
    }
}
