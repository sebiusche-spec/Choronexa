// Part of Chronexa, a derivative of reReminder 4.0.1 — GNU GPL v3. See NOTICE.
package com.olaf.rereminder.study

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDate

class AlarmSoundTest {

    private val friday = LocalDate.of(2026, 10, 23)
    private val file = "content://com.android.providers.media.documents/document/audio%3A7"

    private fun task(sound: String = SOUND_DEFAULT, on: Boolean = true, name: String = "", slot: Int = 3) = StudyTask(
        id = 1, title = "Physics", firstDate = friday, startMinute = 450, endMinute = 570,
        alarmAtStart = true, sound = sound, alarmSoundOn = on, soundName = name, alarmSlot = slot,
    )

    private fun data(vararg tasks: StudyTask) = StudyData(
        subjects = emptyList(), tasks = tasks.toList(), completions = emptySet(),
        focusRecords = emptyList(), settings = StudySettings(),
    )

    // --- Reading the stored sound ----------------------------------------------------------

    @Test
    fun emptyAndDefaultMeanThePhonesAlarmSound() {
        assertEquals(AlarmSoundRef.DefaultTone, parseSoundRef(null))
        assertEquals(AlarmSoundRef.DefaultTone, parseSoundRef(""))
        assertEquals(AlarmSoundRef.DefaultTone, parseSoundRef("default"))
    }

    @Test
    fun silentIsNoSound() {
        assertEquals(AlarmSoundRef.Silent, parseSoundRef("silent"))
    }

    @Test
    fun aContentUriIsACustomFile() {
        assertEquals(AlarmSoundRef.Custom(file), parseSoundRef(file))
    }

    @Test
    fun unknownTextFallsBackToTheDefaultSound() {
        // A damaged or future value must never make a different sound play.
        assertEquals(AlarmSoundRef.DefaultTone, parseSoundRef("/sdcard/Music/x.mp3"))
        assertEquals(AlarmSoundRef.DefaultTone, parseSoundRef("javascript:alert(1)"))
    }

    @Test
    fun turningTheSoundOffKeepsTheChosenFileForLater() {
        assertEquals(AlarmSoundRef.Silent, playbackSound(soundOn = false, raw = file))
        assertEquals(AlarmSoundRef.Custom(file), playbackSound(soundOn = true, raw = file))
    }

    // --- One alarm, one playback ----------------------------------------------------------

    @Test
    fun aCodeAlreadyRingingIsNotStartedAgain() {
        assertFalse(shouldStartPlayback(setOf(2_000_006), 2_000_006))
        assertTrue(shouldStartPlayback(setOf(2_000_006), 2_000_008))
    }

    @Test
    fun codeZeroNeverPlays() {
        assertFalse(shouldStartPlayback(emptySet(), 0))
    }

    // --- Editing and rescheduling -----------------------------------------------------------

    @Test
    fun choosingADifferentSoundReschedulesTheAlarm() {
        val before = task(sound = SOUND_DEFAULT)
        val after = before.copy(sound = file, soundName = "Focus bell.mp3")
        val plan = planAlarmChanges(data(before), data(after))
        assertEquals(listOf(after), plan.scheduleTasks)
        assertEquals(setOf(3), plan.cancelSlots)
    }

    @Test
    fun switchingTheSoundOffReschedulesTheAlarm() {
        val before = task(sound = file, on = true)
        val after = before.copy(alarmSoundOn = false)
        assertEquals(listOf(after), planAlarmChanges(data(before), data(after)).scheduleTasks)
    }

    @Test
    fun renamingTheFileOnlyDoesNotTouchTheAlarm() {
        val before = task(sound = file, name = "old.mp3")
        val after = before.copy(soundName = "new.mp3")
        val plan = planAlarmChanges(data(before), data(after))
        assertTrue(plan.cancelSlots.isEmpty())
        assertTrue(plan.scheduleTasks.isEmpty())
    }

    @Test
    fun anotherTasksSoundIsNotChangedByThisTasksEdit() {
        val a = task(sound = file, slot = 3)
        val b = StudyTask(id = 2, title = "Chemistry", firstDate = friday, startMinute = 540, endMinute = 600,
            alarmAtStart = true, sound = SOUND_DEFAULT, alarmSlot = 4)
        val plan = planAlarmChanges(data(a, b), data(a.copy(sound = SOUND_SILENT), b))
        assertEquals(setOf(3), plan.cancelSlots)
        assertEquals(1, plan.scheduleTasks.size)
    }
}
