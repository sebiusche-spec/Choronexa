// Part of Chronexa, a derivative of reReminder 4.0.1 — GNU GPL v3. See NOTICE.
package com.olaf.rereminder.music

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

/** Removing a song from a playlist must keep the live queue sensible: the playing song moves on, nothing else moves. */
class QueueRemovalTest {

    private val a = "content://media/audio/1"
    private val b = "content://media/audio/2"
    private val c = "content://media/audio/3"
    private val d = "content://media/audio/4"

    private fun queue(index: Int, repeat: RepeatMode = RepeatMode.OFF) =
        PlaybackQueue(source = listOf(a, b, c, d), order = listOf(a, b, c, d), index = index, repeat = repeat)

    @Test
    fun removingASongBeforeTheCurrentOneKeepsTheSameSongPlaying() {
        val after = queue(index = 2).withoutTrack(a)
        assertEquals(c, after.current)
        assertEquals(listOf(b, c, d), after.order)
    }

    @Test
    fun removingASongAfterTheCurrentOneChangesNothingAboutPlayback() {
        val after = queue(index = 1).withoutTrack(d)
        assertEquals(b, after.current)
        assertEquals(listOf(a, b, c), after.order)
    }

    @Test
    fun removingTheCurrentSongMovesOnToTheNextRemainingSong() {
        assertEquals(c, queue(index = 1).withoutTrack(b).current)
    }

    @Test
    fun removingTheLastCurrentSongMovesToTheNewLastSong() {
        assertEquals(c, queue(index = 3).withoutTrack(d).current)
    }

    @Test
    fun removingASongNotInTheQueueChangesNothing() {
        val q = queue(index = 1)
        assertEquals(q, q.withoutTrack("content://nothing/9"))
    }

    @Test
    fun removingTheOnlySongEmptiesThePlayback() {
        val only = PlaybackQueue(source = listOf(a), order = listOf(a), index = 0)
        val after = only.withoutTrack(a)
        assertNull(after.current)
        assertEquals(emptyList<String>(), after.order)
        assertEquals(emptyList<String>(), after.source)
    }

    @Test
    fun aSongQueuedTwiceIsRemovedEverywhere() {
        val twice = PlaybackQueue(source = listOf(a, b, a), order = listOf(a, b, a), index = 1)
        val after = twice.withoutTrack(a)
        assertEquals(listOf(b), after.order)
        assertEquals(b, after.current)
        assertEquals(listOf(b), after.source)
    }

    @Test
    fun repeatAndShuffleSurviveARemoval() {
        val after = queue(index = 1, repeat = RepeatMode.ALL).withoutTrack(a)
        assertEquals(RepeatMode.ALL, after.repeat)
        assertEquals(false, after.shuffle)
    }
}
