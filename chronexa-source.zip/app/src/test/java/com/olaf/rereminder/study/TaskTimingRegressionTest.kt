// Part of Chronexa, a derivative of reReminder 4.0.1 — GNU GPL v3. See NOTICE.
package com.olaf.rereminder.study

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.Instant
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.ZoneId

/**
 * Regression tests for the timing path: a task's start and end, its duration, the alarm trigger, repeats,
 * rescheduling and duplicate prevention. The alarm sound itself is not tested here (it needs a device); these
 * tests pin the times the sound is scheduled for.
 */
class TaskTimingRegressionTest {

    private val zone = ZoneId.of("Europe/Berlin")
    private val day = LocalDate.of(2026, 10, 26)

    private fun at(date: LocalDate, hour: Int, minute: Int) =
        toEpochMillis(LocalDateTime.of(date, java.time.LocalTime.of(hour, minute)), zone)

    private fun local(millis: Long): LocalDateTime = Instant.ofEpochMilli(millis).atZone(zone).toLocalDateTime()

    private fun task(start: Int, end: Int, repeat: TaskRepeat = TaskRepeat.NONE, lead: Int = 0, alarm: Boolean = true) =
        StudyTask(
            id = 1, title = "Wake", firstDate = day, startMinute = start, endMinute = end,
            repeat = repeat, alarmAtStart = alarm, alert = false, reminderLeadMinutes = lead, alarmSlot = 1,
        )

    @Test
    fun aFiveToTwentyFourTaskAlarmsAtItsStartNotItsEnd() {
        val t = task(start = 5 * 60, end = 5 * 60 + 24)
        val trigger = nextActivityTrigger(t, AlarmKind.ALARM, at(day.minusDays(1), 12, 0), zone)
        assertEquals(at(day, 5, 0), trigger)
    }

    @Test
    fun theDurationDoesNotChangeTheAlarmTime() {
        val short = nextActivityTrigger(task(300, 324), AlarmKind.ALARM, at(day.minusDays(1), 12, 0), zone)
        val long = nextActivityTrigger(task(300, 600), AlarmKind.ALARM, at(day.minusDays(1), 12, 0), zone)
        assertEquals(short, long)
    }

    @Test
    fun aReminderLeadIsCountedBackFromTheStart() {
        val trigger = nextActivityTrigger(task(5 * 60, 5 * 60 + 24, lead = 5, alarm = false).copy(alert = true), AlarmKind.REMINDER, at(day.minusDays(1), 12, 0), zone)
        assertEquals(at(day, 4, 55), trigger)
    }

    @Test
    fun anOvernightTaskAlarmsAtItsStartTonight() {
        // Sleep 10:45 PM to 5:00 AM: the alarm is at 10:45 PM on the same day, not at 5:00 AM.
        val sleep = task(start = 22 * 60 + 45, end = 5 * 60)
        val trigger = nextActivityTrigger(sleep, AlarmKind.ALARM, at(day, 12, 0), zone)
        assertEquals(at(day, 22, 45), trigger)
    }

    @Test
    fun aDailyRepeatFiresOncePerDayAndNeverTwiceForTheSameOccurrence() {
        val daily = task(start = 7 * 60, end = 8 * 60, repeat = TaskRepeat.DAILY)
        val first = nextActivityTrigger(daily, AlarmKind.ALARM, at(day.minusDays(1), 12, 0), zone)!!
        assertEquals(at(day, 7, 0), first)
        // Asking again from the instant of that alarm must give the next day, never the same occurrence again.
        val second = nextActivityTrigger(daily, AlarmKind.ALARM, first, zone)!!
        assertEquals(at(day.plusDays(1), 7, 0), second)
        assertNotEquals(first, second)
    }

    @Test
    fun changingTheStartTimeMovesTheAlarmAndCancelsTheOldOne() {
        val before = task(start = 7 * 60, end = 8 * 60)
        val after = before.copy(startMinute = 9 * 60, endMinute = 10 * 60)
        val data = { t: StudyTask -> StudyData.initial().copy(tasks = listOf(t)) }
        val plan = planAlarmChanges(data(before), data(after))
        assertEquals(setOf(1), plan.cancelSlots)
        assertEquals(listOf(after), plan.scheduleTasks)
    }

    @Test
    fun changingOnlyTheEndTimeReschedulesTheSameMomentWithoutADuplicate() {
        // The end time is part of the alarm's settings, so the old alarm is cancelled and the same moment is set
        // again. Cancelling first means there is never two alarms for the one activity.
        val before = task(start = 7 * 60, end = 8 * 60)
        val after = before.copy(endMinute = 9 * 60)
        val data = { t: StudyTask -> StudyData.initial().copy(tasks = listOf(t)) }
        val plan = planAlarmChanges(data(before), data(after))
        assertEquals(setOf(1), plan.cancelSlots)
        assertEquals(listOf(after), plan.scheduleTasks)
        assertEquals(
            nextActivityTrigger(before, AlarmKind.ALARM, at(day.minusDays(1), 12, 0), zone),
            nextActivityTrigger(after, AlarmKind.ALARM, at(day.minusDays(1), 12, 0), zone),
        )
    }

    @Test
    fun deletingATaskCancelsItsAlarmAndSchedulesNothing() {
        val t = task(start = 7 * 60, end = 8 * 60)
        val plan = planAlarmChanges(StudyData.initial().copy(tasks = listOf(t)), StudyData.initial())
        assertEquals(setOf(1), plan.cancelSlots)
        assertTrue(plan.scheduleTasks.isEmpty())
    }

    @Test
    fun aTaskWithNoAlarmHasNoAlarmTrigger() {
        assertNull(nextActivityTrigger(task(7 * 60, 8 * 60, alarm = false), AlarmKind.ALARM, at(day.minusDays(1), 12, 0), zone))
    }

    @Test
    fun theTimeTheUserSeesMatchesTheStoredMinute() {
        // 5:00 AM and 5:24 AM are stored as minutes 300 and 324, and the trigger is that same moment.
        val trigger = nextActivityTrigger(task(300, 324), AlarmKind.ALARM, at(day.minusDays(1), 12, 0), zone)!!
        assertEquals(LocalDateTime.of(day, java.time.LocalTime.of(5, 0)), local(trigger))
    }
}
