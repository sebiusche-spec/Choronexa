// Part of Chronexa, a derivative of reReminder 4.0.1 — GNU GPL v3. See NOTICE.
package com.olaf.rereminder.study

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.ZoneId

/** Which start alarms are still current: the rule that stops an edited or disabled task from playing late. */
class TaskAudioWindowTest {

    private val zone = ZoneId.of("Europe/Berlin")
    private val day = LocalDate.of(2026, 10, 26)
    private fun at(date: LocalDate, hour: Int, minute: Int) =
        toEpochMillis(LocalDateTime.of(date, LocalTime.of(hour, minute)), zone)

    private fun task(start: Int, end: Int, on: Boolean = true, uri: String = "content://a/1", repeat: TaskRepeat = TaskRepeat.NONE) =
        StudyTask(id = 1, title = "Breathing", firstDate = day, startMinute = start, endMinute = end,
            repeat = repeat, continuousAudio = on, taskAudioUri = uri, alarmSlot = 2)

    @Test
    fun theCurrentStartIsRecognisedWithItsEndTime() {
        val window = taskAudioWindowStartingAt(task(300, 324), at(day, 5, 0), zone)!!
        assertEquals(at(day, 5, 0), window.first)
        assertEquals(at(day, 5, 24), window.second)
    }

    @Test
    fun aStaleStartAfterAnEditIsIgnored() {
        // The task was moved to 6:00 AM; the 5:00 AM start that was armed before is no longer current.
        assertNull(taskAudioWindowStartingAt(task(360, 384), at(day, 5, 0), zone))
    }

    @Test
    fun aDisabledTaskNeverStarts() {
        assertNull(taskAudioWindowStartingAt(task(300, 324, on = false), at(day, 5, 0), zone))
    }

    @Test
    fun aTaskWithNoFileNeverStarts() {
        assertNull(taskAudioWindowStartingAt(task(300, 324, uri = ""), at(day, 5, 0), zone))
    }

    @Test
    fun aDailyTaskIsCurrentOnEachDay() {
        val daily = task(300, 324, repeat = TaskRepeat.DAILY)
        assertEquals(at(day.plusDays(1), 5, 24), taskAudioWindowStartingAt(daily, at(day.plusDays(1), 5, 0), zone)!!.second)
    }

    @Test
    fun anOvernightWindowEndsTheNextMorning() {
        val sleep = task(22 * 60 + 45, 5 * 60)
        val window = taskAudioWindowStartingAt(sleep, at(day, 22, 45), zone)!!
        assertEquals(at(day.plusDays(1), 5, 0), window.second)
    }
}
