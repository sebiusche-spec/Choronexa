// Part of Chronexa, a derivative of reReminder 4.0.1 — GNU GPL v3. See NOTICE.
package com.olaf.rereminder.study.chapters

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ChapterMasterTest {

    private val seeded = ChapterMaster.seeded()

    @Test
    fun theChartsChaptersAreSeededInPrintedOrder() {
        assertEquals(13, seeded.chapters.count { it.subject == Subject.MATHEMATICS })
        assertEquals(14, seeded.chapters.count { it.subject == Subject.PHYSICS })
        assertEquals(16, seeded.chapters.count { it.subject == Subject.CHEMISTRY })
        assertEquals("Relations & Functions", seeded.chapters.first().name)
        assertEquals("Chemistry in Everyday Life", seeded.chapters.last().name)
    }

    @Test
    fun everyChapterStartsUncertainWithNoStepsTicked() {
        assertTrue(seeded.chapters.all { it.status == ChapterStatus.UNCERTAIN && it.steps.isEmpty() })
    }

    @Test
    fun noProgressIsShownUntilAChapterIsIncluded() {
        // With nothing included there is no honest percentage: it is null, not 0 and not invented.
        assertNull(seeded.subjectPercent(Subject.PHYSICS))
        assertNull(seeded.overallPercent())
    }

    @Test
    fun progressCountsOnlyIncludedChapters() {
        val m = seeded
            .withStatus("phy-01", ChapterStatus.INCLUDED)
            .withStatus("phy-02", ChapterStatus.INCLUDED)
            .toggleStep("phy-01", ChapterStep.LEARN_CONCEPT)
            .toggleStep("phy-01", ChapterStep.READ_NOTES)
            .toggleStep("phy-01", ChapterStep.MARK_COMPLETED)
            .toggleStep("phy-03", ChapterStep.LEARN_CONCEPT) // phy-03 is not included, so it must not count
        // Two included chapters, eight steps each: 3 of 16 steps ticked is 18%.
        assertEquals(18, m.subjectPercent(Subject.PHYSICS))
    }

    @Test
    fun excludingAChapterRemovesItFromTheSubjectAverage() {
        val m = seeded
            .withStatus("chem-01", ChapterStatus.INCLUDED)
            .withStatus("chem-02", ChapterStatus.INCLUDED)
            .toggleStep("chem-01", ChapterStep.LEARN_CONCEPT)
        assertEquals(6, m.subjectPercent(Subject.CHEMISTRY)) // 1 of 16 steps
        // Excluding chem-02 leaves one included chapter with one of eight steps ticked: 12%.
        assertEquals(12, m.withStatus("chem-02", ChapterStatus.EXCLUDED).subjectPercent(Subject.CHEMISTRY))
    }

    @Test
    fun tickingAStepTwiceReturnsToWhereItStarted() {
        val once = seeded.toggleStep("math-01", ChapterStep.SOLVE_EXAMPLES)
        assertTrue(ChapterStep.SOLVE_EXAMPLES in once.chapters.first().steps)
        val twice = once.toggleStep("math-01", ChapterStep.SOLVE_EXAMPLES)
        assertFalse(ChapterStep.SOLVE_EXAMPLES in twice.chapters.first().steps)
    }

    @Test
    fun anUnknownChapterIdChangesNothing() {
        assertEquals(seeded, seeded.withStatus("nope-99", ChapterStatus.INCLUDED).toggleStep("nope-99", ChapterStep.MARK_REVISION))
    }

    @Test
    fun includedChaptersAreListedInChapterOrder() {
        val m = seeded.withStatus("math-03", ChapterStatus.INCLUDED).withStatus("math-01", ChapterStatus.INCLUDED)
        assertEquals(listOf("math-01", "math-03"), m.includedFor(Subject.MATHEMATICS).map { it.id })
    }

    @Test
    fun progressSurvivesAnEncodeAndDecode() {
        val m = seeded.withStatus("math-02", ChapterStatus.EXCLUDED).toggleStep("math-02", ChapterStep.MARK_REVISION)
        val back = (ChapterCodec.decode(ChapterCodec.encode(m)) as ChapterCodec.Decoded.Ok).master
        assertEquals(m, back)
    }

    @Test
    fun aNewerFileIsReportedNotParsed() {
        val text = """{"schemaVersion":2,"chapters":[]}"""
        assertEquals(2, (ChapterCodec.decode(text) as ChapterCodec.Decoded.FutureVersion).version)
    }

    @Test
    fun damagedTextIsInvalid() {
        assertTrue(ChapterCodec.decode("{chapters") is ChapterCodec.Decoded.Invalid)
    }

    @Test
    fun anUnknownStatusIsUncertainNotIncluded() {
        val text = """{"schemaVersion":1,"chapters":[{"id":"x-1","subject":"PHYSICS","number":1,"name":"A","status":"MAYBE"}]}"""
        val c = (ChapterCodec.decode(text) as ChapterCodec.Decoded.Ok).master.chapters.single()
        assertEquals(ChapterStatus.UNCERTAIN, c.status)
    }

    @Test
    fun anUnknownSubjectIsDroppedRatherThanGuessed() {
        val text = """{"schemaVersion":1,"chapters":[{"id":"x-1","subject":"ART","number":1,"name":"A"}]}"""
        assertTrue((ChapterCodec.decode(text) as ChapterCodec.Decoded.Ok).master.chapters.isEmpty())
    }
}
