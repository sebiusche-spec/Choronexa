// Part of Chronexa, a derivative of reReminder 4.0.1 — GNU GPL v3. See NOTICE.
package com.olaf.rereminder.study.chapters

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ChapterFilterTest {

    private val master = ChapterMaster.seeded()
        .withStatus("phy-02", ChapterStatus.INCLUDED)
        .withStatus("phy-05", ChapterStatus.EXCLUDED)

    @Test
    fun aSubjectShowsOnlyItsOwnChaptersInOrder() {
        val list = master.visibleChapters(Subject.PHYSICS, "", ChapterFilter.ALL)
        assertEquals(14, list.size)
        assertTrue(list.all { it.subject == Subject.PHYSICS })
        assertEquals((1..14).toList(), list.map { it.number })
    }

    @Test
    fun searchIgnoresCaseAndMatchesPartOfAName() {
        val list = master.visibleChapters(Subject.PHYSICS, "  CAPACITANCE ", ChapterFilter.ALL)
        assertEquals(listOf("Electrostatic Potential & Capacitance"), list.map { it.name })
    }

    @Test
    fun aBlankSearchShowsEverything() {
        assertEquals(16, master.visibleChapters(Subject.CHEMISTRY, "   ", ChapterFilter.ALL).size)
    }

    @Test
    fun theStatusFilterKeepsOnlyThatStatus() {
        assertEquals(listOf("phy-02"), master.visibleChapters(Subject.PHYSICS, "", ChapterFilter.INCLUDED).map { it.id })
        assertEquals(listOf("phy-05"), master.visibleChapters(Subject.PHYSICS, "", ChapterFilter.EXCLUDED).map { it.id })
        assertEquals(12, master.visibleChapters(Subject.PHYSICS, "", ChapterFilter.UNCERTAIN).size)
    }

    @Test
    fun searchAndFilterCombine() {
        // "optics" matches "Ray Optics & Optical Instruments" and "Wave Optics". Both are uncertain, so the
        // uncertain filter keeps both. The excluded filter keeps only the excluded chapter, which has no "optics".
        assertEquals(
            listOf("Ray Optics & Optical Instruments", "Wave Optics"),
            master.visibleChapters(Subject.PHYSICS, "optics", ChapterFilter.UNCERTAIN).map { it.name },
        )
        assertTrue(master.visibleChapters(Subject.PHYSICS, "optics", ChapterFilter.EXCLUDED).isEmpty())
        assertTrue(master.visibleChapters(Subject.PHYSICS, "optics", ChapterFilter.INCLUDED).isEmpty())
    }

    @Test
    fun combinedSearchOnAllStatusesMatchesEveryStatus() {
        assertEquals(2, master.visibleChapters(Subject.PHYSICS, "optics", ChapterFilter.ALL).size)
    }

    @Test
    fun searchIsCaseInsensitiveWhenCombinedWithAStatus() {
        assertEquals(
            master.visibleChapters(Subject.PHYSICS, "optics", ChapterFilter.UNCERTAIN).map { it.id },
            master.visibleChapters(Subject.PHYSICS, "OPTICS", ChapterFilter.UNCERTAIN).map { it.id },
        )
    }

    @Test
    fun surroundingSpacesInTheSearchAreIgnored() {
        assertEquals(
            master.visibleChapters(Subject.PHYSICS, "wave", ChapterFilter.ALL).map { it.id },
            master.visibleChapters(Subject.PHYSICS, "   wave  ", ChapterFilter.ALL).map { it.id },
        )
    }

    @Test
    fun aSearchForAnotherSubjectsChapterReturnsNothingHere() {
        // "Polymers" is a Chemistry chapter: it must not appear in the Physics list.
        assertTrue(master.visibleChapters(Subject.PHYSICS, "polymers", ChapterFilter.ALL).isEmpty())
        assertEquals(1, master.visibleChapters(Subject.CHEMISTRY, "polymers", ChapterFilter.ALL).size)
    }

    @Test
    fun aSearchWithNoMatchReturnsAnEmptyListNotAnError() {
        assertTrue(master.visibleChapters(Subject.MATHEMATICS, "quantum", ChapterFilter.ALL).isEmpty())
    }
}
