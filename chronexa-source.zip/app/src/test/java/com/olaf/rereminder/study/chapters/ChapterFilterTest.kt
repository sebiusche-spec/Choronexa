// Part of Chronexa, a derivative of reReminder 4.0.1 — GNU GPL v3. See NOTICE.
package com.olaf.rereminder.study.chapters

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ChapterFilterTest {

    private val master = ChapterMaster.seeded()
        .withStatus("phy-02", ChapterStatus.INCLUDED)
        .withStatus("phy-05", ChapterStatus.EXCLUDED)

    @Test
    fun aSubjectShowsOnlyItsOwnChaptersInOrder() {
        val list = master.visibleChapters(Subject.PHYSICS, "", ChapterFilter.ALL)
        assertEquals(14, list.size)
        assertTrue(list.all { it.subject == Subject.PHYSICS })
        assertEquals((1..14).toList(), list.map { it.number })
    }

    @Test
    fun searchIgnoresCaseAndMatchesPartOfAName() {
        val list = master.visibleChapters(Subject.PHYSICS, "  CAPACITANCE ", ChapterFilter.ALL)
        assertEquals(listOf("Electrostatic Potential & Capacitance"), list.map { it.name })
    }

    @Test
    fun aBlankSearchShowsEverything() {
        assertEquals(16, master.visibleChapters(Subject.CHEMISTRY, "   ", ChapterFilter.ALL).size)
    }

    @Test
    fun theStatusFilterKeepsOnlyThatStatus() {
        assertEquals(listOf("phy-02"), master.visibleChapters(Subject.PHYSICS, "", ChapterFilter.INCLUDED).map { it.id })
        assertEquals(listOf("phy-05"), master.visibleChapters(Subject.PHYSICS, "", ChapterFilter.EXCLUDED).map { it.id })
        assertEquals(12, master.visibleChapters(Subject.PHYSICS, "", ChapterFilter.UNCERTAIN).size)
    }

    @Test
    fun searchAndFilterCombine() {
        assertTrue(master.visibleChapters(Subject.PHYSICS, "optics", ChapterFilter.EXCLUDED).isEmpty())
        assertEquals(1, master.visibleChapters(Subject.PHYSICS, "optics", ChapterFilter.UNCERTAIN).size)
    }
}
