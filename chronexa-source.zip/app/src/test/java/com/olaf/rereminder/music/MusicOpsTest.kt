// Part of Chronexa, a derivative of reReminder 4.0.1 — GNU GPL v3. See NOTICE.
package com.olaf.rereminder.music

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class MusicOpsTest {

    private val a = Track("content://media/audio/1", "Quadratics", "Ms Lee")
    private val b = Track("content://media/audio/2", "Forces", "Mr Shaw")
    private val c = Track("content://media/audio/3", "Calm Rain", "Ambient")

    private fun uris(lib: MusicLibrary, id: String) = lib.playlists.first { it.id == id }.trackUris

    @Test
    fun aSongCanBeInSeveralPlaylistsWithOneLibraryEntry() {
        val lib = MusicLibrary.initial().addTrackTo("mathematics", a).addTrackTo("physics", a)
        assertEquals(listOf(a.uri), uris(lib, "mathematics"))
        assertEquals(listOf(a.uri), uris(lib, "physics"))
        assertEquals(1, lib.tracks.size)
    }

    @Test
    fun addingTheSameSongTwiceDoesNotDuplicateIt() {
        val lib = MusicLibrary.initial().addTrackTo("mathematics", a).addTrackTo("mathematics", a)
        assertEquals(1, uris(lib, "mathematics").size)
        assertEquals(1, lib.tracks.size)
    }

    @Test
    fun removingFromOnePlaylistKeepsTheFileInTheLibraryAndInOtherPlaylists() {
        val lib = MusicLibrary.initial().addTrackTo("mathematics", a).addTrackTo("physics", a)
            .removeFromPlaylist("mathematics", a.uri)
        assertTrue(uris(lib, "mathematics").isEmpty())
        assertEquals(listOf(a.uri), uris(lib, "physics"))
        assertEquals(listOf(a), lib.tracks)
    }

    @Test
    fun removingFromFavoritesLeavesOtherPlaylistsAlone() {
        val lib = MusicLibrary.initial().addTrackTo("relaxation", c).addTrackTo(PLAYLIST_FAVORITES, c)
            .removeFromPlaylist(PLAYLIST_FAVORITES, c.uri)
        assertTrue(uris(lib, PLAYLIST_FAVORITES).isEmpty())
        assertEquals(listOf(c.uri), uris(lib, "relaxation"))
    }

    @Test
    fun togglingFavoriteAddsAndRemoves() {
        val lib = MusicLibrary.initial().addTrackTo("english", b)
        val starred = lib.toggleFavorite(b.uri)
        assertEquals(listOf(b.uri), uris(starred, PLAYLIST_FAVORITES))
        assertEquals(uris(lib, PLAYLIST_FAVORITES), uris(starred.toggleFavorite(b.uri), PLAYLIST_FAVORITES))
    }

    @Test
    fun deletingACustomPlaylistKeepsEveryAudioFileAndOtherPlaylists() {
        val made = MusicLibrary.initial().createPlaylist("Exam week")
        val id = made.playlists.last().id
        val lib = made.addTrackTo(id, a).addTrackTo("physics", a).deletePlaylist(id)
        assertTrue(lib.playlists.none { it.id == id })
        assertEquals(listOf(a), lib.tracks)
        assertEquals(listOf(a.uri), uris(lib, "physics"))
    }

    @Test
    fun builtInPlaylistsCannotBeDeleted() {
        val lib = MusicLibrary.initial()
        assertEquals(lib, lib.deletePlaylist("mathematics"))
    }

    @Test
    fun customPlaylistIdsAreNeverReused() {
        val lib = MusicLibrary.initial().createPlaylist("One").createPlaylist("Two")
        val ids = lib.playlists.filter { !it.builtIn }.map { it.id }
        assertEquals(2, ids.toSet().size)
        val after = lib.deletePlaylist(ids.first()).createPlaylist("Three")
        assertFalse(after.playlists.any { it.id == ids.first() })
    }

    @Test
    fun blankNamesAreRefused() {
        val lib = MusicLibrary.initial()
        assertEquals(lib, lib.createPlaylist("   "))
        assertEquals(lib, lib.renamePlaylist("physics", ""))
    }

    @Test
    fun renamingKeepsTheTracks() {
        val lib = MusicLibrary.initial().addTrackTo("physics", a).renamePlaylist("physics", "  Mechanics  ")
        val physics = lib.playlists.first { it.id == "physics" }
        assertEquals("Mechanics", physics.name)
        assertEquals(listOf(a.uri), physics.trackUris)
    }

    @Test
    fun reorderMovesATrackWithinItsPlaylist() {
        val lib = MusicLibrary.initial().addTrackTo("english", a).addTrackTo("english", b).addTrackTo("english", c)
        assertEquals(listOf(b.uri, c.uri, a.uri), uris(lib.reorder("english", 0, 2), "english"))
        assertEquals(uris(lib, "english"), uris(lib.reorder("english", 0, 9), "english"))
    }

    @Test
    fun aMissingTrackIsSkippedAndCounted() {
        val broken = MusicLibrary.initial().copy(
            playlists = MusicLibrary.initial().playlists.map {
                if (it.id == "physics") it.copy(trackUris = listOf(a.uri, "content://gone/9")) else it
            },
            tracks = listOf(a),
        )
        val contents = broken.contentsOf("physics")
        assertEquals(listOf(a), contents.tracks)
        assertEquals(1, contents.missingCount)
    }

    @Test
    fun searchFindsTitlesAndArtistsIgnoringCase() {
        val all = listOf(a, b, c)
        assertEquals(listOf(a), searchTracks(all, "QUADRA"))
        assertEquals(listOf(c), searchTracks(all, "ambient"))
        assertEquals(all, searchTracks(all, "  "))
        assertTrue(searchTracks(all, "nothing here").isEmpty())
    }

    @Test
    fun theDefaultLibraryHasTheBriefsPlaylists() {
        val names = MusicLibrary.initial().playlists.map { it.name }
        assertEquals(listOf("Mathematics", "Physics", "Chemistry", "Computer Science", "English", "Relaxation", "Favorites"), names)
        assertNotEquals(0, MusicLibrary.initial().nextPlaylistNumber)
    }
}
