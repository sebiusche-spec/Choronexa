// Part of Chronexa, a derivative of reReminder 4.0.1 — GNU GPL v3. See NOTICE.
package com.olaf.rereminder.study

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.ZoneId

class AlarmPlanningTest {

    private val zone = ZoneId.of("Europe/Berlin")
    private val friday = LocalDate.of(2026, 10, 23)

    private fun at(date: LocalDate, hour: Int, minute: Int) = toEpochMillis(date.atTime(hour, minute), zone)

    private fun task(
        id: Long = 1,
        start: Int = 7 * 60 + 30,
        end: Int = 9 * 60 + 30,
        date: LocalDate = friday,
        repeat: TaskRepeat = TaskRepeat.NONE,
        weekdays: Set<DayOfWeek> = emptySet(),
        alert: Boolean = true,
        lead: Int = 5,
        alarm: Boolean = false,
        slot: Int = 3,
    ) = StudyTask(
        id = id, title = "Physics", firstDate = date, startMinute = start, endMinute = end,
        repeat = repeat, weekdays = weekdays, alert = alert, reminderLeadMinutes = lead,
        alarmAtStart = alarm, alarmSlot = slot,
    )

    // --- Request codes -------------------------------------------------------------------

    @Test
    fun activityCodesStayAboveReminderAndSnoozeRanges() {
        for (slot in 1..50) for (kind in AlarmKind.values()) {
            assertTrue(requestCodeFor(slot, kind) >= ACTIVITY_CODE_BASE)
        }
        // Snoozes are 1 000 000 + reminder id; reminder ids stay far below 1 000 000.
        assertTrue(ACTIVITY_CODE_BASE > 1_000_000 + 999_999) // highest snooze code sits below the activity range
    }

    @Test
    fun everySlotAndKindGetsADifferentCode() {
        val codes = (1..5000).flatMap { slot -> AlarmKind.values().map { requestCodeFor(slot, it) } }
        assertEquals(codes.size, codes.toSet().size)
    }

    // --- Reminder and alarm times --------------------------------------------------------

    @Test
    fun defaultReminderIsFiveMinutesBeforeStart() {
        val t = task()
        assertEquals(at(friday, 7, 25), nextActivityTrigger(t, AlarmKind.REMINDER, at(friday, 6, 0), zone))
    }

    @Test
    fun atStartLeadReplacesTheReminderWithTheAlarm() {
        val t = task(lead = 0, alarm = true)
        assertNull(nextActivityTrigger(t, AlarmKind.REMINDER, at(friday, 6, 0), zone))
        assertEquals(at(friday, 7, 30), nextActivityTrigger(t, AlarmKind.ALARM, at(friday, 6, 0), zone))
    }

    @Test
    fun reminderAndAlarmBothFireWhenLeadIsPositive() {
        val t = task(lead = 5, alarm = true)
        assertEquals(at(friday, 7, 25), nextActivityTrigger(t, AlarmKind.REMINDER, at(friday, 6, 0), zone))
        assertEquals(at(friday, 7, 30), nextActivityTrigger(t, AlarmKind.ALARM, at(friday, 6, 0), zone))
    }

    @Test
    fun disabledActivityHasNoTriggers() {
        val t = task(alert = false, alarm = false)
        assertNull(nextActivityTrigger(t, AlarmKind.REMINDER, 0L, zone))
        assertNull(nextActivityTrigger(t, AlarmKind.ALARM, 0L, zone))
    }

    @Test
    fun aTriggerThatHasJustFiredIsNotReturnedAgain() {
        val t = task(repeat = TaskRepeat.DAILY)
        val fired = at(friday, 7, 25)
        assertEquals(at(friday.plusDays(1), 7, 25), nextActivityTrigger(t, AlarmKind.REMINDER, fired, zone))
    }

    @Test
    fun dailyActivityMovesToTomorrowOnceTodaysHasPassed() {
        val t = task(repeat = TaskRepeat.DAILY)
        assertEquals(at(friday.plusDays(1), 7, 25), nextActivityTrigger(t, AlarmKind.REMINDER, at(friday, 8, 0), zone))
    }

    @Test
    fun weekdayActivitySkipsTheWeekend() {
        val t = task(repeat = TaskRepeat.WEEKDAYS)
        val monday = friday.plusDays(3) // Friday 23 Oct → Monday 26 Oct
        assertEquals(at(monday, 7, 25), nextActivityTrigger(t, AlarmKind.REMINDER, at(friday, 8, 0), zone))
    }

    @Test
    fun overnightActivityFiresBeforeItStartsLateInTheEvening() {
        val t = task(start = 23 * 60, end = 6 * 60, lead = 10)
        assertEquals(at(friday, 22, 50), nextActivityTrigger(t, AlarmKind.REMINDER, at(friday, 12, 0), zone))
    }

    // --- To-dos ----------------------------------------------------------------------------

    private fun todo(due: java.time.LocalDateTime?, done: Boolean = false, alert: Boolean = true,
                     lead: Int = 15, alarm: Boolean = false) = TodoItem(
        id = 5, title = "Pay fees", dueAt = due, done = done, alert = alert,
        reminderLeadMinutes = lead, alarmAtDue = alarm, alarmSlot = 4,
    )

    @Test
    fun todoReminderComesBeforeItsDueTime() {
        val item = todo(friday.atTime(10, 0))
        assertEquals(at(friday, 9, 45), nextTodoTrigger(item, AlarmKind.REMINDER, at(friday, 8, 0), zone))
    }

    @Test
    fun todoAlarmFiresAtTheDueTimeAlongsideTheReminder() {
        val item = todo(friday.atTime(10, 0), alarm = true)
        assertEquals(at(friday, 10, 0), nextTodoTrigger(item, AlarmKind.ALARM, at(friday, 8, 0), zone))
        assertEquals(at(friday, 9, 45), nextTodoTrigger(item, AlarmKind.REMINDER, at(friday, 8, 0), zone))
    }

    @Test
    fun doneOrUndatedTodosHaveNoTriggers() {
        assertNull(nextTodoTrigger(todo(friday.atTime(10, 0), done = true), AlarmKind.REMINDER, 0L, zone))
        assertNull(nextTodoTrigger(todo(null), AlarmKind.REMINDER, 0L, zone))
        assertNull(nextTodoTrigger(todo(friday.atTime(10, 0), alert = false), AlarmKind.REMINDER, 0L, zone))
    }

    // --- Occurrence date and clamping -------------------------------------------------------

    @Test
    fun firedReminderMapsBackToTheOccurrenceDate() {
        assertEquals(friday, occurrenceDateOf(at(friday, 7, 25), 5, zone))
    }

    @Test
    fun leadIsKeptInItsRange() {
        assertEquals(0, clampLead(-3))
        assertEquals(MAX_LEAD_MINUTES, clampLead(5000))
        assertEquals(30, clampLead(30))
    }

    // --- Slots and change detection ---------------------------------------------------------

    private fun emptyData(tasks: List<StudyTask> = emptyList(), todos: List<TodoItem> = emptyList(), next: Int = 1) =
        StudyData(
            subjects = emptyList(), tasks = tasks, completions = emptySet(), focusRecords = emptyList(),
            settings = StudySettings(), todos = todos, nextAlarmSlot = next,
        )

    @Test
    fun slotsAreAssignedOnceAndOnlyWhereAnAlarmIsWanted() {
        val needs = task(id = 1, slot = 0)
        val plain = task(id = 2, slot = 0, alert = false, alarm = false)
        val data = assignAlarmSlots(emptyData(tasks = listOf(needs, plain), next = 10))
        assertEquals(10, data.tasks.first { it.id == 1L }.alarmSlot)
        assertEquals(0, data.tasks.first { it.id == 2L }.alarmSlot)
        assertEquals(11, data.nextAlarmSlot)
        // Running it again changes nothing: the slot is kept.
        assertEquals(data, assignAlarmSlots(data))
    }

    @Test
    fun slotsAreNeverHandedOutTwice() {
        val first = assignAlarmSlots(emptyData(tasks = listOf(task(id = 1, slot = 0)), next = 1))
        val later = assignAlarmSlots(first.copy(tasks = first.tasks + task(id = 2, slot = 0)))
        assertNotEquals(later.tasks[0].alarmSlot, later.tasks[1].alarmSlot)
    }

    @Test
    fun changingTheLeadChangesTheFingerprintButRenamingDoesNot() {
        val base = task(lead = 5)
        assertNotEquals(base.alarmFingerprint(), task(lead = 10).alarmFingerprint())
        assertEquals(base.alarmFingerprint(), base.copy(title = "Renamed").alarmFingerprint())
    }

    @Test
    fun finishingATodoChangesItsFingerprint() {
        val open = todo(friday.atTime(10, 0))
        assertNotEquals(open.alarmFingerprint(), open.copy(done = true).alarmFingerprint())
    }

    @Test
    fun aDisabledReminderHasNoPendingEventAndNoFingerprintOfItsOwn() {
        assertFalse(isKindActive(alert = false, alarmAtStart = false, lead = 5, kind = AlarmKind.REMINDER))
        assertTrue(isKindActive(alert = true, alarmAtStart = false, lead = 5, kind = AlarmKind.REMINDER))
    }

    // --- Stale alarms -------------------------------------------------------------------

    @Test
    fun aMovedActivityMakesTheOldTriggerStale() {
        // The fire-time check: an alarm is only shown if it is still the current trigger.
        val original = task(lead = 5)                              // starts 07:30, reminder 07:25
        val oldTrigger = nextActivityTrigger(original, AlarmKind.REMINDER, at(friday, 6, 0), zone)
        val moved = original.copy(startMinute = 8 * 60, endMinute = 10 * 60)
        val current = nextActivityTrigger(moved, AlarmKind.REMINDER, oldTrigger!! - 1, zone)
        assertEquals(at(friday, 7, 55), current)
        assertNotEquals(oldTrigger, current)
    }

    @Test
    fun aDeletedOrDisabledActivityHasNoCurrentTrigger() {
        val disabled = task(alert = false)
        assertNull(nextActivityTrigger(disabled, AlarmKind.REMINDER, at(friday, 6, 0), zone))
    }

    @Test
    fun aReminderBelongsToTheOccurrenceItWarnsAbout() {
        // A reminder at 07:25 for a 07:30 start, on Friday, is ticked against Friday's occurrence.
        val trigger = at(friday, 7, 25)
        assertEquals(friday, occurrenceDateOf(trigger, 5, zone))
    }
}
