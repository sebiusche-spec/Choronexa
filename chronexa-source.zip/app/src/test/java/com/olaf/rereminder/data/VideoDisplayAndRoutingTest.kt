// Part of Chronexa, a derivative of reReminder 4.0.1 — GNU GPL v3. See NOTICE.
package com.olaf.rereminder.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/** Video alarms must reach the alarm screen, and FIT and FILL must keep the aspect ratio. */
class VideoDisplayAndRoutingTest {

    private val tolerance = 0.01f

    private fun assertScale(expected: Pair<Float, Float>, actual: Pair<Float, Float>) {
        assertEquals(expected.first, actual.first, tolerance)
        assertEquals(expected.second, actual.second, tolerance)
    }

    // --- Routing: a video alarm rings through the alarm service ---------------------------------

    @Test
    fun aVideoAlarmRingsAsAnAlarmEvenWithANotificationStyle() {
        assertTrue(ringsAsAlarmRoute(offset = 0, isAlarmStyle = false, forced = false, hasVideo = true))
    }

    @Test
    fun anAlarmWithNoVideoKeepsItsNotificationStyle() {
        assertFalse(ringsAsAlarmRoute(offset = 0, isAlarmStyle = false, forced = false, hasVideo = false))
    }

    @Test
    fun anEarlyReminderNeverRingsAsAnAlarmEvenWithAVideo() {
        assertFalse(ringsAsAlarmRoute(offset = 10, isAlarmStyle = true, forced = false, hasVideo = true))
    }

    @Test
    fun theAlarmStyleAndForcedAlarmsStillRingAsAlarms() {
        assertTrue(ringsAsAlarmRoute(offset = 0, isAlarmStyle = true, forced = false, hasVideo = false))
        assertTrue(ringsAsAlarmRoute(offset = 0, isAlarmStyle = false, forced = true, hasVideo = false))
    }

    // --- FIT and FILL keep the aspect ratio -------------------------------------------------------

    @Test
    fun fitShowsAPortraitViewsLandscapeVideoWithBarsAndNoCrop() {
        // A 1920x1080 video on a 1080x2400 screen: full width, a band of height.
        assertScale(1f to 0.253f, videoScale(1080, 2400, 1920, 1080, fill = false))
    }

    @Test
    fun fillCoversAPortraitViewsLandscapeVideoAndCropsTheSides() {
        assertScale(3.951f to 1f, videoScale(1080, 2400, 1920, 1080, fill = true))
    }

    @Test
    fun aPortraitVideoOnAPortraitScreenNeedsNoScaleInEitherMode() {
        assertScale(1f to 1f, videoScale(1080, 2400, 1080, 2400, fill = false))
        assertScale(1f to 1f, videoScale(1080, 2400, 1080, 2400, fill = true))
    }

    @Test
    fun aPortraitVideoOnALandscapeScreenFillsByCroppingTheTop() {
        // Portrait 1080x1920 on a 2400x1080 screen: FILL covers the width and crops the height.
        assertScale(1f to 3.951f, videoScale(2400, 1080, 1080, 1920, fill = true))
        assertScale(0.253f to 1f, videoScale(2400, 1080, 1080, 1920, fill = false))
    }

    @Test
    fun aMissingSizeLeavesTheVideoUnchanged() {
        assertScale(1f to 1f, videoScale(0, 2400, 1920, 1080, fill = true))
        assertScale(1f to 1f, videoScale(1080, 2400, 0, 0, fill = false))
    }

    @Test
    fun theDisplayModeSurvivesAResolveAndDefaultsToFit() {
        val video = VideoChoice(uri = "content://media/video/1")
        assertFalse(video.fill)
        val play = resolveVideoPlayback(video.copy(fill = true), canOpen = true) as VideoPlayback.Play
        assertTrue(play.fill)
    }
}
