// Part of Chronexa, a derivative of reReminder 4.0.1 — GNU GPL v3. See NOTICE.
package com.olaf.rereminder.regression

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

/** The footer must show the Chronexa credit, and the old Europe phrase must not return to any visible text. */
class FooterRegressionTest {

    private val expected = "🇮🇳 Made with ❤️ in Jharkhand, India 🌿"
    private val oldPhrases = listOf("Made with passion in Europe", "Mit Leidenschaft in Europa", "ic_eu_flag")

    private fun stringValue(path: String, name: String): String {
        val xml = File(path).readText()
        val m = Regex("""<string name="$name"[^>]*>(.*?)</string>""", RegexOption.DOT_MATCHES_ALL).find(xml)
        return m?.groupValues?.get(1) ?: error("$name missing in $path")
    }

    @Test
    fun englishFooterIsTheChronexaCredit() {
        assertEquals(expected, stringValue("src/main/res/values/strings.xml", "made_in_jharkhand"))
    }

    @Test
    fun germanFooterIsTheSameCredit() {
        assertEquals(expected, stringValue("src/main/res/values-de/strings.xml", "made_in_jharkhand"))
    }

    @Test
    fun oldFooterKeyIsGone() {
        for (lang in listOf("values", "values-de")) {
            val xml = File("src/main/res/$lang/strings.xml").readText()
            assertFalse("made_in_europe still defined in $lang", xml.contains("made_in_europe"))
        }
    }

    @Test
    fun noVisibleSourceOrResourceMentionsTheOldFooter() {
        // Source, resources, store listing and README. CHANGELOG is history and is excluded on purpose.
        val roots = listOf("src/main", "../fastlane", "../README.md")
        val offenders = mutableListOf<String>()
        for (root in roots) {
            val base = File(root)
            val files = if (base.isDirectory) base.walkTopDown().filter { it.isFile }.toList() else listOf(base)
            for (f in files) {
                if (!f.canRead() || f.length() > 2_000_000) continue
                val text = runCatching { f.readText() }.getOrNull() ?: continue
                for (phrase in oldPhrases) if (text.contains(phrase)) offenders += "${f.path}: $phrase"
            }
        }
        assertTrue("old footer still present: $offenders", offenders.isEmpty())
    }
}
