// Part of Chronexa, a derivative of reReminder 4.0.1 — GNU GPL v3. See NOTICE.
package com.olaf.rereminder.study

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.ZoneId

/**
 * The windows audio repeats across: overnight intervals, selected days, and the end time. The looping itself is
 * Android playback and is checked on a phone; these tests fix the times it is scheduled for.
 */
class TaskAudioLoopWindowTest {

    private val zone = ZoneId.of("Europe/Berlin")
    private val monday = LocalDate.of(2026, 10, 26)
    private val tuesday = LocalDate.of(2026, 10, 27)
    private fun at(date: LocalDate, hour: Int, minute: Int) =
        toEpochMillis(LocalDateTime.of(date, LocalTime.of(hour, minute)), zone)

    private fun audio(start: Int, end: Int, repeat: TaskRepeat = TaskRepeat.NONE, days: Set<DayOfWeek> = emptySet()) =
        StudyTask(id = 1, title = "Focus", firstDate = monday, startMinute = start, endMinute = end,
            repeat = repeat, weekdays = days, continuousAudio = true, taskAudioUri = "content://a/1", alarmSlot = 4)

    @Test
    fun anOvernightIntervalRunsFromElevenPmToOneAm() {
        val (start, end) = nextTaskAudioWindow(audio(23 * 60, 60), at(monday, 12, 0), zone)!!
        assertEquals(at(monday, 23, 0), start)
        assertEquals(at(monday.plusDays(1), 1, 0), end)
        assertEquals(120, taskDurationMinutes(audio(23 * 60, 60)))
    }

    @Test
    fun aSelectedDayRepeatPlaysOnlyOnItsDays() {
        // Tuesdays only. From Monday, the next window is Tuesday's, not Monday's.
        val tuesdaysOnly = audio(5 * 60, 5 * 60 + 24, TaskRepeat.WEEKLY, setOf(DayOfWeek.TUESDAY))
        val next = nextTaskAudioWindow(tuesdaysOnly, at(monday, 12, 0), zone)!!
        assertEquals(at(tuesday, 5, 0), next.first)
        assertEquals(at(tuesday, 5, 24), next.second)
    }

    @Test
    fun theWindowAfterTheCurrentEndIsTheNextOccurrence() {
        // A daily task whose window has ended must hand over to the next day, so no end or start repeats.
        val daily = audio(5 * 60, 5 * 60 + 24, TaskRepeat.DAILY)
        val first = nextTaskAudioWindow(daily, at(monday, 12, 0), zone)!!
        val after = nextTaskAudioWindow(daily, first.second, zone)!!
        assertEquals(at(tuesday, 5, 0), after.first)
    }

    @Test
    fun noWindowIsReturnedOncePastAOneOffTask() {
        // A one-off task is over once its window has passed: nothing else plays for it.
        val once = audio(5 * 60, 5 * 60 + 24)
        assertNull(nextTaskAudioWindow(once, at(tuesday, 12, 0), zone))
    }
}
