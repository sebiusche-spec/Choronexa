// Part of Chronexa, a derivative of reReminder 4.0.1 — GNU GPL v3. See NOTICE.
package com.olaf.rereminder.regression

import com.olaf.rereminder.study.ACTIVITY_CODE_BASE
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

/**
 * Guards the alarm decisions that are easy to undo by accident: the exact-alarm permission scope,
 * the private activity receiver, and the request-code ranges that keep reminders and snoozes safe.
 */
class AlarmRegressionTest {

    private val manifest = File("src/main/AndroidManifest.xml").readText()

    // Match the permission element itself, not the comment that also mentions it.
    private fun lineWith(text: String) = manifest.lines().first { it.contains("<uses-permission") && it.contains(text) }

    @Test
    fun useExactAlarmIsKeptForAllVersions() {
        assertFalse(lineWith("USE_EXACT_ALARM").contains("maxSdkVersion"))
    }

    @Test
    fun scheduleExactAlarmIsOnlyRequestedUpToAndroid12L() {
        assertTrue(lineWith("SCHEDULE_EXACT_ALARM").contains("android:maxSdkVersion=\"32\""))
    }

    @Test
    fun noInternetPermission() {
        assertFalse(manifest.contains("android.permission.INTERNET\""))
    }

    @Test
    fun activityReceiverIsPrivate() {
        val block = manifest.substringAfter("android:name=\".service.ActivityAlarmReceiver\"").substringBefore("/>")
        assertTrue(block.contains("android:exported=\"false\""))
    }

    @Test
    fun activityCodesDoNotOverlapExistingReminderRanges() {
        val scheduler = File("src/main/java/com/olaf/rereminder/service/ReminderScheduler.kt").readText()
        val helper = File("src/main/java/com/olaf/rereminder/utils/NotificationHelper.kt").readText()
        assertTrue(scheduler.contains("SNOOZE_REQUEST_BASE = 1_000_000"))
        assertTrue(helper.contains("NOTIFICATION_ID_BASE = 1000"))
        // Snooze codes end at 1 000 000 + 999 999, below the activity range.
        assertTrue(ACTIVITY_CODE_BASE > 1_000_000 + 999_999)
    }
}
