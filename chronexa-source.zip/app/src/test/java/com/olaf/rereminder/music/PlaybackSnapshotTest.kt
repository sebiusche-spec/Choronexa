// Part of Chronexa, a derivative of reReminder 4.0.1 — GNU GPL v3. See NOTICE.
package com.olaf.rereminder.music

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class PlaybackSnapshotTest {

    private val a = "content://media/audio/1"
    private val b = "content://media/audio/2"
    private val c = "content://media/audio/3"

    private fun snap(order: List<String> = listOf(a, b, c), index: Int = 1, position: Long = 42_000L) = PlaybackSnapshot(
        source = order, order = order, index = index, repeat = RepeatMode.ALL, shuffle = true,
        positionMs = position, scopeId = "physics",
    )

    @Test
    fun stateRoundTripsWithQueuePositionAndSettings() {
        val s = snap()
        val back = (PlaybackSnapshotCodec.decode(PlaybackSnapshotCodec.encode(s)) as PlaybackSnapshotCodec.Decoded.Ok).snapshot
        assertEquals(s, back)
    }

    @Test
    fun damagedTextIsInvalidNotACrash() {
        assertTrue(PlaybackSnapshotCodec.decode("{not json") is PlaybackSnapshotCodec.Decoded.Invalid)
    }

    @Test
    fun newerVersionIsReportedNotParsed() {
        val text = """{"schemaVersion":2,"order":[]}"""
        assertEquals(2, (PlaybackSnapshotCodec.decode(text) as PlaybackSnapshotCodec.Decoded.FutureVersion).version)
    }

    @Test
    fun outOfRangeIndexIsClampedWhenRead() {
        val text = """{"schemaVersion":1,"source":["$a"],"order":["$a"],"index":9,"positionMs":5}"""
        val s = (PlaybackSnapshotCodec.decode(text) as PlaybackSnapshotCodec.Decoded.Ok).snapshot
        assertEquals(0, s.index)
        assertEquals(a, s.order[s.index])
    }

    @Test
    fun unknownRepeatModeFallsBackToOff() {
        val text = """{"schemaVersion":1,"order":["$a"],"index":0,"repeat":"SOMETIMES"}"""
        assertEquals(RepeatMode.OFF, (PlaybackSnapshotCodec.decode(text) as PlaybackSnapshotCodec.Decoded.Ok).snapshot.repeat)
    }

    @Test
    fun aMissingSongIsDroppedAndTheCurrentSongStaysWithItsPosition() {
        // a cannot be opened; playback was on c.
        val r = restoreAccessible(snap(index = 2, position = 61_000L)) { it != a }!!
        assertEquals(listOf(b, c), r.snapshot.order)
        assertEquals(1, r.snapshot.index)
        assertEquals(c, r.snapshot.order[r.snapshot.index])
        assertEquals(61_000L, r.snapshot.positionMs)
        assertEquals(1, r.skipped)
    }

    @Test
    fun whenTheCurrentSongIsMissingPlaybackAdvancesToTheNextAvailableSong() {
        // b (the current song) cannot be opened. The next available song in queue order is c, the same
        // choice the service makes when it skips an unplayable track.
        val r = restoreAccessible(snap(index = 1, position = 30_000L)) { it != b }!!
        assertEquals(listOf(a, c), r.snapshot.order)
        assertEquals(c, r.snapshot.order[r.snapshot.index])
        assertEquals(0L, r.snapshot.positionMs)
    }

    @Test
    fun whenTheMissingSongIsLastPlaybackFallsBackToThePreviousAvailableSong() {
        // c (the last song, and the current one) cannot be opened, so the nearest available song before it is b.
        val r = restoreAccessible(snap(index = 2, position = 30_000L)) { it != c }!!
        assertEquals(listOf(a, b), r.snapshot.order)
        assertEquals(b, r.snapshot.order[r.snapshot.index])
        assertEquals(0L, r.snapshot.positionMs)
    }

    @Test
    fun ifNothingCanBeOpenedThereIsNothingToRestore() {
        assertNull(restoreAccessible(snap()) { false })
    }

    @Test
    fun anEmptyQueueHasNothingToRestore() {
        assertNull(restoreAccessible(snap(order = emptyList(), index = -1)) { true })
    }

    @Test
    fun aSnapshotIndexBeyondTheListIsClampedBeforeUse() {
        val r = restoreAccessible(snap(index = 99, position = 7_000L)) { true }!!
        assertEquals(2, r.snapshot.index)
        assertEquals(c, r.snapshot.order[r.snapshot.index])
    }

    @Test
    fun shuffleRepeatAndPlaylistSurviveRestore() {
        val r = restoreAccessible(snap()) { true }!!
        assertEquals(RepeatMode.ALL, r.snapshot.repeat)
        assertTrue(r.snapshot.shuffle)
        assertEquals("physics", r.snapshot.scopeId)
        assertEquals(0, r.skipped)
    }

    @Test
    fun theRestoredQueuePlaysTheSameTrack() {
        val s = snap(index = 2)
        assertEquals(c, s.toQueue().current)
    }
}
