// Part of Chronexa, a derivative of reReminder 4.0.1 — GNU GPL v3. See NOTICE.
package com.olaf.rereminder.study

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDateTime

class TimelineNowTest {

    private val day = LocalDateTime.of(2026, 10, 26, 0, 0)
    private fun at(h: Int, m: Int) = day.withHour(h).withMinute(m)

    private val starts = listOf(at(5, 0), at(5, 2), at(5, 10), at(5, 20))

    @Test
    fun theMarkerGoesBeforeTheFirstTaskThatHasNotStarted() {
        // 5:05 falls after 5:02 has started and before 5:10 starts: the marker sits before the 5:10 task (index 2).
        assertEquals(2, nowInsertIndex(starts, at(5, 5), isToday = true))
    }

    @Test
    fun theMarkerIsAtTheTopBeforeAnyTaskStarts() {
        assertEquals(0, nowInsertIndex(starts, at(4, 0), isToday = true))
    }

    @Test
    fun theMarkerIsAtTheEndAfterEveryTaskHasStarted() {
        assertEquals(4, nowInsertIndex(starts, at(23, 0), isToday = true))
    }

    @Test
    fun noMarkerOnOtherDays() {
        assertEquals(-1, nowInsertIndex(starts, at(5, 5), isToday = false))
    }

    @Test
    fun aDayWithNoTasksPutsTheMarkerAtZero() {
        assertEquals(0, nowInsertIndex(emptyList(), at(12, 0), isToday = true))
    }

    @Test
    fun aTaskIsHappeningFromItsStartUpToButNotIncludingItsEnd() {
        val start = at(5, 0)
        val end = at(5, 24)
        assertTrue(isHappeningNow(start, end, at(5, 0)))
        assertTrue(isHappeningNow(start, end, at(5, 23)))
        assertFalse(isHappeningNow(start, end, at(5, 24)))
        assertFalse(isHappeningNow(start, end, at(4, 59)))
    }

    @Test
    fun aMidnightCrossingTaskIsHappeningInTheMorningAfterMidnight() {
        // 10:45 PM to 5:00 AM next day: at 1:00 AM it is still happening.
        val start = at(22, 45)
        val end = day.plusDays(1).withHour(5).withMinute(0)
        assertTrue(isHappeningNow(start, end, day.plusDays(1).withHour(1)))
    }
}
