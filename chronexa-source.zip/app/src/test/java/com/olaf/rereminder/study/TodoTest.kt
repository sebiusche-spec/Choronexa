// Part of Chronexa, a derivative of reReminder 4.0.1 — GNU GPL v3. See NOTICE.
package com.olaf.rereminder.study

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDateTime

class TodoTest {

    private val now = LocalDateTime.of(2026, 10, 23, 12, 0)

    private fun todo(id: Long, due: LocalDateTime? = null, done: Boolean = false, title: String = "t$id") =
        TodoItem(id = id, title = title, dueAt = due, done = done)

    @Test
    fun pendingComesBeforeDoneAndDueSoonestFirst() {
        val items = listOf(
            todo(1, due = null),
            todo(2, due = now.plusDays(2), done = true),
            todo(3, due = now.plusDays(2)),
            todo(4, due = now.plusDays(1)),
        )
        assertEquals(listOf(4L, 3L, 1L, 2L), sortedTodos(items).map { it.id })
    }

    @Test
    fun ties_fallBackToIdSoOrderIsStable() {
        val due = now.plusDays(1)
        assertEquals(listOf(5L, 6L), sortedTodos(listOf(todo(6, due), todo(5, due))).map { it.id })
    }

    @Test
    fun overdueOnlyWhenNotDoneAndDuePassed() {
        assertTrue(todo(1, due = now.minusHours(1)).isOverdue(now))
        assertFalse(todo(2, due = now.minusHours(1), done = true).isOverdue(now))
        assertFalse(todo(3, due = now.plusHours(1)).isOverdue(now))
        assertFalse(todo(4, due = null).isOverdue(now))
    }

    @Test
    fun filtersSeparatePendingDoneAndAll() {
        val items = listOf(todo(1), todo(2, done = true))
        assertEquals(listOf(1L), filterTodos(items, TodoFilter.PENDING).map { it.id })
        assertEquals(listOf(2L), filterTodos(items, TodoFilter.DONE).map { it.id })
        assertEquals(2, filterTodos(items, TodoFilter.ALL).size)
    }

    @Test
    fun blankTitleIsRejectedAndTitledItemIsAccepted() {
        assertEquals("title_required", todo(1, title = "   ").validationError())
        assertNull(todo(2, title = "Email supervisor").validationError())
    }

    @Test
    fun emptyListStaysEmpty() {
        assertTrue(sortedTodos(emptyList()).isEmpty())
        assertTrue(filterTodos(emptyList(), TodoFilter.ALL).isEmpty())
    }
}
