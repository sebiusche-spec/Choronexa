// Part of Chronexa, a derivative of reReminder 4.0.1 — GNU GPL v3. See NOTICE.
package com.olaf.rereminder.study

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId

class FocusClockTest {

    private val minute = 60_000L
    private val t0 = 1_000_000_000L

    @Test
    fun countsDownWhileRunning() {
        val clock = FocusClock(plannedMillis = 25 * minute).start(t0)
        assertEquals(25 * minute, clock.remainingMillis(t0))
        assertEquals(20 * minute, clock.remainingMillis(t0 + 5 * minute))
    }

    @Test
    fun pausedTimeIsNotCounted() {
        val paused = FocusClock(plannedMillis = 10 * minute)
            .start(t0)
            .pause(t0 + 3 * minute)
        // Five minutes pass while paused.
        assertEquals(7 * minute, paused.remainingMillis(t0 + 8 * minute))
        assertEquals(FocusState.PAUSED, paused.state)
    }

    @Test
    fun resumeContinuesFromWhereItStopped() {
        val clock = FocusClock(plannedMillis = 10 * minute)
            .start(t0)
            .pause(t0 + 3 * minute)
            .resume(t0 + 20 * minute)
        assertEquals(7 * minute, clock.remainingMillis(t0 + 20 * minute))
        assertEquals(2 * minute, clock.remainingMillis(t0 + 25 * minute))
    }

    @Test
    fun answerIsTheSameNoMatterHowOftenItIsAsked() {
        // Simulates recreating the Activity: the clock is data, so reading it again gives the same answer.
        val clock = FocusClock(plannedMillis = 10 * minute).start(t0)
        val first = clock.remainingMillis(t0 + 4 * minute)
        val later = clock.remainingMillis(t0 + 4 * minute)
        assertEquals(first, later)
        assertEquals(6 * minute, first)
    }

    @Test
    fun completesExactlyWhenTimeIsUp() {
        val running = FocusClock(plannedMillis = 10 * minute).start(t0)
        val notYet = running.tick(t0 + 10 * minute - 1)
        assertEquals(FocusState.RUNNING, notYet.state)
        val done = notYet.tick(t0 + 10 * minute)
        assertEquals(FocusState.COMPLETED, done.state)
        assertTrue(done.completedBy(notYet))
    }

    @Test
    fun completionIsReportedOnlyOnce() {
        val done = FocusClock(plannedMillis = minute).start(t0).tick(t0 + minute)
        assertFalse(done.tick(t0 + 2 * minute).completedBy(done))
    }

    @Test
    fun pausedSessionNeverCompletesOnItsOwn() {
        val paused = FocusClock(plannedMillis = minute).start(t0).pause(t0 + 10)
        val later = paused.tick(t0 + 10 * minute)
        assertEquals(FocusState.PAUSED, later.state)
        assertFalse(later.completedBy(paused))
    }

    @Test
    fun resetAbandonsWithoutCompleting() {
        val reset = FocusClock(plannedMillis = 10 * minute).start(t0).reset()
        assertEquals(FocusState.IDLE, reset.state)
        assertEquals(10 * minute, reset.remainingMillis(t0 + 9 * minute))
    }

    @Test
    fun backwardsClockNeverProducesNegativeElapsed() {
        val clock = FocusClock(plannedMillis = 10 * minute).start(t0)
        assertEquals(0L, clock.elapsedMillis(t0 - 5 * minute))
    }

    @Test
    fun startingAgainAfterCompletionRestartsFromZero() {
        val done = FocusClock(plannedMillis = minute).start(t0).tick(t0 + minute)
        val again = done.start(t0 + 5 * minute)
        assertEquals(minute, again.remainingMillis(t0 + 5 * minute))
    }

    @Test
    fun focusSecondsCountByLocalDateInTheGivenZone() {
        val zone = ZoneId.of("Europe/Berlin")
        // 23:30 on 23 Oct local time, which is 21:30 UTC.
        val lateSession = Instant.parse("2026-10-23T21:30:00Z").toEpochMilli()
        val record = FocusRecord(1, null, "", plannedSeconds = 1500, startedAtMillis = lateSession - 1500_000,
            completedAtMillis = lateSession)
        assertEquals(1500L, focusSecondsOn(listOf(record), LocalDate.of(2026, 10, 23), zone))
        // 22:30 UTC is 00:30 in Berlin on the 24th, so this session belongs to the next day.
        val nextMorning = Instant.parse("2026-10-23T22:30:00Z").toEpochMilli()
        val after = record.copy(id = 2, completedAtMillis = nextMorning)
        assertEquals(1500L, focusSecondsOn(listOf(after), LocalDate.of(2026, 10, 24), zone))
    }

    @Test
    fun subjectTotalsGroupAndIncludeNoSubject() {
        val zone = ZoneId.of("UTC")
        val d = LocalDate.of(2026, 10, 23)
        val end = Instant.parse("2026-10-23T12:00:00Z").toEpochMilli()
        val records = listOf(
            FocusRecord(1, 1L, "", 1500, end - 1500_000, end),
            FocusRecord(2, 1L, "", 1500, end - 1500_000, end),
            FocusRecord(3, null, "", 600, end - 600_000, end),
        )
        val totals = focusSecondsBySubject(records, d, d, zone)
        assertEquals(3000L, totals[1L])
        assertEquals(600L, totals[null])
    }
}
