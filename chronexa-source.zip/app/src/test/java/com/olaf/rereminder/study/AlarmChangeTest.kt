// Part of Chronexa, a derivative of reReminder 4.0.1 — GNU GPL v3. See NOTICE.
package com.olaf.rereminder.study

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.ZoneId

/** Scheduling decisions for reminders and alarms: what is cancelled, what is set, and what is shown. */
class AlarmChangeTest {

    private val zone = ZoneId.of("Europe/Berlin")
    private val friday = LocalDate.of(2026, 10, 23)

    private fun at(date: LocalDate, hour: Int, minute: Int) = toEpochMillis(date.atTime(hour, minute), zone)

    private fun task(
        id: Long = 1,
        title: String = "Physics",
        start: Int = 7 * 60 + 30,
        end: Int = 9 * 60 + 30,
        date: LocalDate = friday,
        repeat: TaskRepeat = TaskRepeat.NONE,
        alert: Boolean = true,
        lead: Int = 5,
        alarm: Boolean = false,
        slot: Int = 3,
        custom: Long? = null,
    ) = StudyTask(
        id = id, title = title, firstDate = date, startMinute = start, endMinute = end, repeat = repeat,
        alert = alert, reminderLeadMinutes = lead, alarmAtStart = alarm, alarmSlot = slot, reminderCustomAt = custom,
    )

    private fun data(tasks: List<StudyTask> = emptyList(), todos: List<TodoItem> = emptyList()) = StudyData(
        subjects = emptyList(), tasks = tasks, completions = emptySet(), focusRecords = emptyList(),
        settings = StudySettings(), todos = todos, nextAlarmSlot = 20,
    )

    // --- Cancellation and replacement ----------------------------------------------------

    @Test
    fun deletingAnActivityCancelsItsAlarmsAndSchedulesNothing() {
        val plan = planAlarmChanges(data(listOf(task(slot = 3))), data())
        assertEquals(setOf(3), plan.cancelSlots)
        assertTrue(plan.scheduleTasks.isEmpty())
    }

    @Test
    fun disablingTheReminderCancelsItWithoutSettingAnything() {
        val plan = planAlarmChanges(data(listOf(task(slot = 3))), data(listOf(task(slot = 3, alert = false))))
        assertEquals(setOf(3), plan.cancelSlots)
        assertTrue(plan.scheduleTasks.isEmpty())
    }

    @Test
    fun movingAnActivityCancelsTheOldAlarmAndSetsTheNewOne() {
        val moved = task(slot = 3, start = 8 * 60, end = 10 * 60)
        val plan = planAlarmChanges(data(listOf(task(slot = 3))), data(listOf(moved)))
        assertEquals(setOf(3), plan.cancelSlots)
        assertEquals(listOf(moved), plan.scheduleTasks)
    }

    @Test
    fun renamingDoesNotTouchAnyAlarm() {
        val plan = planAlarmChanges(data(listOf(task(title = "Physics"))), data(listOf(task(title = "Physics II"))))
        assertTrue(plan.cancelSlots.isEmpty())
        assertTrue(plan.scheduleTasks.isEmpty())
    }

    @Test
    fun editingOneActivityLeavesAnotherActivitysAlarmAlone() {
        val a = task(id = 1, slot = 3)
        val b = task(id = 2, title = "Chemistry", start = 9 * 60 + 45, end = 11 * 60 + 45, slot = 4)
        val movedA = a.copy(startMinute = 8 * 60, endMinute = 10 * 60)
        val plan = planAlarmChanges(data(listOf(a, b)), data(listOf(movedA, b)))
        assertEquals(setOf(3), plan.cancelSlots)
        assertEquals(listOf(movedA), plan.scheduleTasks)
    }

    @Test
    fun aNewAlarmActivityIsScheduled() {
        val fresh = task(id = 9, slot = 5)
        val plan = planAlarmChanges(data(), data(listOf(fresh)))
        assertTrue(plan.cancelSlots.isEmpty())
        assertEquals(listOf(fresh), plan.scheduleTasks)
    }

    @Test
    fun aDoneTodoCancelsItsAlarm() {
        val open = TodoItem(id = 5, title = "Fees", dueAt = friday.atTime(10, 0), alert = true, alarmSlot = 6)
        val plan = planAlarmChanges(data(todos = listOf(open)), data(todos = listOf(open.copy(done = true))))
        assertEquals(setOf(6), plan.cancelSlots)
    }

    // --- Duplicate prevention ----------------------------------------------------------------

    @Test
    fun repeatingTheSameSaveCancelsAndSetsNothing() {
        val current = data(listOf(task(slot = 3)))
        val plan = planAlarmChanges(current, current)
        assertTrue(plan.cancelSlots.isEmpty())
        assertTrue(plan.scheduleTasks.isEmpty())
    }

    @Test
    fun reminderAndAlarmOfOneActivityNeverShareARequestCode() {
        assertNotEquals(requestCodeFor(3, AlarmKind.REMINDER), requestCodeFor(3, AlarmKind.ALARM))
    }

    @Test
    fun oneReminderAndOneAlarmAtDifferentTimesFireSeparately() {
        val t = task(alarm = true, lead = 5)
        val reminder = nextActivityTrigger(t, AlarmKind.REMINDER, at(friday, 6, 0), zone)
        val alarm = nextActivityTrigger(t, AlarmKind.ALARM, at(friday, 6, 0), zone)
        assertEquals(at(friday, 7, 25), reminder)
        assertEquals(at(friday, 7, 30), alarm)
    }

    // --- Custom reminder date and time -----------------------------------------------------

    @Test
    fun customReminderFiresOnceAtTheChosenMoment() {
        val t = task(custom = at(friday, 9, 0))
        assertEquals(at(friday, 9, 0), nextActivityTrigger(t, AlarmKind.REMINDER, at(friday, 8, 0), zone))
        assertNull(nextActivityTrigger(t, AlarmKind.REMINDER, at(friday, 9, 0), zone))
    }

    @Test
    fun customReminderIgnoresTheLeadTime() {
        val t = task(lead = 30, custom = at(friday, 9, 0))
        assertEquals(at(friday, 9, 0), nextActivityTrigger(t, AlarmKind.REMINDER, at(friday, 8, 0), zone))
    }

    @Test
    fun customReminderShowsOnlyOnItsOwnDate() {
        val t = task(custom = at(friday, 9, 0))
        val onFriday = reminderMomentFor(t, friday, zone)
        assertEquals(LocalDateTime.of(friday, java.time.LocalTime.of(9, 0)), onFriday)
        assertNull(reminderMomentFor(t, friday.plusDays(1), zone))
    }

    @Test
    fun customReminderWorksWithAStartAlarmAndIsNotSuppressed() {
        // With a lead of zero, the reminder would normally be dropped in favour of the alarm.
        // A custom reminder time is a different choice, so it stays.
        val t = task(lead = 0, alarm = true, custom = at(friday, 7, 0))
        assertEquals(at(friday, 7, 0), nextActivityTrigger(t, AlarmKind.REMINDER, at(friday, 6, 0), zone))
        assertEquals(at(friday, 7, 30), nextActivityTrigger(t, AlarmKind.ALARM, at(friday, 6, 0), zone))
    }

    // --- What each row shows -------------------------------------------------------------

    @Test
    fun defaultReminderShowsFiveMinutesBeforeTheStart() {
        assertEquals(LocalDateTime.of(friday, java.time.LocalTime.of(7, 25)), reminderMomentFor(task(), friday, zone))
    }

    @Test
    fun noReminderShowsNothing() {
        assertNull(reminderMomentFor(task(alert = false), friday, zone))
    }

    @Test
    fun alarmShowsTheStartTime() {
        assertEquals(LocalDateTime.of(friday, java.time.LocalTime.of(7, 30)), alarmMomentFor(task(alarm = true), friday))
        assertNull(alarmMomentFor(task(alarm = false), friday))
    }

    @Test
    fun todoRowShowsTheReminderBeforeItsDueTime() {
        val item = TodoItem(id = 2, title = "Fees", dueAt = friday.atTime(10, 0), alert = true, reminderLeadMinutes = 5)
        assertEquals(friday.atTime(9, 55), todoReminderMoment(item, zone))
        assertNull(todoReminderMoment(item.copy(done = true), zone))
    }

    @Test
    fun todoCustomReminderIsShownAsChosen() {
        val moment = at(friday, 8, 15)
        val item = TodoItem(id = 2, title = "Fees", dueAt = friday.atTime(10, 0), alert = true, reminderCustomAt = moment)
        assertEquals(friday.atTime(8, 15), todoReminderMoment(item, zone))
    }

    @Test
    fun weekdayRepeatStillSkipsTheWeekendForAlarms() {
        val t = task(repeat = TaskRepeat.WEEKDAYS, alarm = true, alert = false)
        assertEquals(LocalDate.of(2026, 10, 26), // Monday
            nextActivityTrigger(t, AlarmKind.ALARM, at(friday, 8, 0), zone)?.let {
                java.time.Instant.ofEpochMilli(it).atZone(zone).toLocalDate()
            })
        assertEquals(DayOfWeek.MONDAY, LocalDate.of(2026, 10, 26).dayOfWeek)
    }
}
