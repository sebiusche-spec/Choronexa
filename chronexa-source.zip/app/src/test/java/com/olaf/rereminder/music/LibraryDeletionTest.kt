// Part of Chronexa, a derivative of reReminder 4.0.1 — GNU GPL v3. See NOTICE.
package com.olaf.rereminder.music

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Removing a song from one playlist and deleting it from the whole library are different actions. Both are tested
 * here for a song that sits in several playlists and in Favorites.
 */
class LibraryDeletionTest {

    private val song = Track("content://media/audio/1", "Quadratics", "Ms Lee")
    private val other = Track("content://media/audio/2", "Forces", "Mr Shaw")

    /** A library where [song] is in Mathematics, Physics and Favorites, and [other] only in Physics. */
    private fun library(): MusicLibrary = MusicLibrary.initial()
        .addTrackTo("mathematics", song)
        .addTrackTo("physics", song)
        .addTrackTo(PLAYLIST_FAVORITES, song)
        .addTrackTo("physics", other)

    private fun members(lib: MusicLibrary, id: String) = lib.playlists.first { it.id == id }.trackUris

    @Test
    fun removingFromOnePlaylistLeavesTheSongEverywhereElse() {
        val after = library().removeFromPlaylist("physics", song.uri)
        assertFalse(song.uri in members(after, "physics"))
        assertTrue(song.uri in members(after, "mathematics"))
        assertTrue(song.uri in members(after, PLAYLIST_FAVORITES))
        assertTrue(after.tracks.any { it.uri == song.uri })
    }

    @Test
    fun removingFromFavoritesLeavesThePlaylistsAlone() {
        val after = library().removeFromPlaylist(PLAYLIST_FAVORITES, song.uri)
        assertFalse(song.uri in members(after, PLAYLIST_FAVORITES))
        assertTrue(song.uri in members(after, "mathematics"))
        assertTrue(song.uri in members(after, "physics"))
    }

    @Test
    fun deletingFromTheLibraryRemovesEveryPlaylistAndFavorites() {
        val after = library().deleteTrackFromLibrary(song.uri)
        assertFalse(after.tracks.any { it.uri == song.uri })
        assertFalse(song.uri in members(after, "mathematics"))
        assertFalse(song.uri in members(after, "physics"))
        assertFalse(song.uri in members(after, PLAYLIST_FAVORITES))
    }

    @Test
    fun deletingKeepsEveryOtherSongAndPlaylist() {
        val before = library()
        val after = before.deleteTrackFromLibrary(song.uri)
        assertEquals(listOf(other), after.tracks)
        assertEquals(listOf(other.uri), members(after, "physics"))
        assertEquals(before.playlists.map { it.id }, after.playlists.map { it.id })
        assertEquals(before.playlists.map { it.name }, after.playlists.map { it.name })
    }

    @Test
    fun builtInPlaylistsRemainEvenWhenTheyBecomeEmpty() {
        val after = library().deleteTrackFromLibrary(song.uri).deleteTrackFromLibrary(other.uri)
        assertEquals(7, after.playlists.size)
        assertTrue(after.playlists.all { it.builtIn })
        assertTrue(after.playlists.all { it.trackUris.isEmpty() })
    }

    @Test
    fun deletingAnUnknownSongChangesNothing() {
        val lib = library()
        assertEquals(lib, lib.deleteTrackFromLibrary("content://media/audio/404"))
    }

    @Test
    fun aDeletedSongIsNotLeftInTheQueueAfterwards() {
        // The queue rule is the same one used for playlist removal: the song is taken out wherever it sits.
        val queue = PlaybackQueue(source = listOf(song.uri, other.uri), order = listOf(song.uri, other.uri), index = 0)
        val after = queue.withoutTrack(song.uri)
        assertEquals(listOf(other.uri), after.order)
        assertEquals(other.uri, after.current)
    }
}
