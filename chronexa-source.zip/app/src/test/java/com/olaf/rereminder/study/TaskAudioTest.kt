// Part of Chronexa, a derivative of reReminder 4.0.1 — GNU GPL v3. See NOTICE.
package com.olaf.rereminder.study

import com.olaf.rereminder.music.MusicPlaybackService
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.Instant
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.ZoneId

class TaskAudioTest {

    private val zone = ZoneId.of("Europe/Berlin")
    private val day = LocalDate.of(2026, 10, 26)
    private val file = "content://media/audio/42"

    private fun at(date: LocalDate, hour: Int, minute: Int) =
        toEpochMillis(LocalDateTime.of(date, LocalTime.of(hour, minute)), zone)

    private fun audio(start: Int, end: Int, repeat: TaskRepeat = TaskRepeat.NONE, on: Boolean = true, uri: String = file) =
        StudyTask(
            id = 1, title = "Breathing", firstDate = day, startMinute = start, endMinute = end,
            repeat = repeat, continuousAudio = on, taskAudioUri = uri, alarmSlot = 3,
        )

    private fun data(vararg tasks: StudyTask) =
        StudyData.initial().copy(tasks = tasks.toList())

    @Test
    fun aFiveToTwentyFourTaskPlaysFromFiveToTwentyFour() {
        val (start, end) = nextTaskAudioWindow(audio(300, 324), at(day.minusDays(1), 12, 0), zone)!!
        assertEquals(at(day, 5, 0), start)
        assertEquals(at(day, 5, 24), end)
    }

    @Test
    fun durationIsTheTaskIntervalNotTheRingLength() {
        assertEquals(24, taskDurationMinutes(audio(300, 324)))
        assertEquals(60, taskDurationMinutes(audio(540, 600)))
    }

    @Test
    fun anIntervalCrossingMidnightHasTheRightDuration() {
        // 10:45 PM to 5:00 AM: 75 minutes to midnight plus 300 after it.
        assertEquals(375, taskDurationMinutes(audio(22 * 60 + 45, 300)))
    }

    @Test
    fun aZeroLengthTaskHasNoAudioWindow() {
        assertEquals(0, taskDurationMinutes(audio(300, 300)))
        assertNull(nextTaskAudioWindow(audio(300, 300), at(day.minusDays(1), 12, 0), zone))
    }

    @Test
    fun noWindowWhenTheAudioIsOffOrNoFileIsChosen() {
        assertNull(nextTaskAudioWindow(audio(300, 324, on = false), at(day.minusDays(1), 12, 0), zone))
        assertNull(nextTaskAudioWindow(audio(300, 324, uri = ""), at(day.minusDays(1), 12, 0), zone))
    }

    @Test
    fun aDailyTaskHasOneWindowPerDayAndNeverRepeatsTheSameOne() {
        val t = audio(300, 324, repeat = TaskRepeat.DAILY)
        val first = nextTaskAudioWindow(t, at(day.minusDays(1), 12, 0), zone)!!
        val second = nextTaskAudioWindow(t, first.first, zone)!!
        assertEquals(at(day, 5, 0), first.first)
        assertEquals(at(day.plusDays(1), 5, 0), second.first)
        assertNotEquals(first, second)
    }

    @Test
    fun aChangedStartTimeGivesANewWindow() {
        val before = nextTaskAudioWindow(audio(300, 324), at(day.minusDays(1), 12, 0), zone)
        val after = nextTaskAudioWindow(audio(360, 384), at(day.minusDays(1), 12, 0), zone)
        assertNotEquals(before, after)
        assertEquals(at(day, 6, 0), after!!.first)
    }

    @Test
    fun changingTheAudioReschedulesAndKeepsTheSlot() {
        val before = audio(300, 324)
        val after = before.copy(taskAudioUri = "content://media/audio/99")
        val plan = planAlarmChanges(data(before), data(after))
        assertEquals(setOf(3), plan.cancelSlots)
        assertEquals(listOf(after), plan.scheduleTasks)
    }

    @Test
    fun removingTheTaskCancelsItsSlot() {
        val plan = planAlarmChanges(data(audio(300, 324)), StudyData.initial())
        assertEquals(setOf(3), plan.cancelSlots)
        assertTrue(plan.scheduleTasks.isEmpty())
    }

    @Test
    fun aTaskWithOnlyContinuousAudioStillGetsAnAlarmSlot() {
        val t = StudyTask(id = 2, title = "Stretch", firstDate = day, startMinute = 330, endMinute = 345,
            continuousAudio = true, taskAudioUri = file)
        val assigned = assignAlarmSlots(StudyData.initial().copy(tasks = listOf(t))).tasks.single()
        assertTrue(assigned.alarmSlot > 0)
    }

    @Test
    fun taskAudioCodesDoNotCollideWithAlarmSnoozeOrMusicCodes() {
        val slots = (1..10_000).toList()
        val audioCodes = slots.map { taskAudioStartCodeFor(it) } + slots.map { taskAudioEndCodeFor(it) }
        val others = slots.map { requestCodeFor(it, AlarmKind.ALARM) } + slots.map { requestCodeFor(it, AlarmKind.REMINDER) } +
            slots.map { snoozeCodeFor(it) } + listOf(MusicPlaybackService.NOTIFICATION_ID)
        assertTrue(audioCodes.none { it in others.toSet() })
        assertEquals(audioCodes.size, audioCodes.toSet().size)
    }

    @Test
    fun aWindowAlreadyStartedIsNotScheduledAgainAsTheNextOne() {
        // Asking from the instant a window starts must give the following window, so no start fires twice.
        val t = audio(300, 324, repeat = TaskRepeat.DAILY)
        val started = at(day, 5, 0)
        val next = nextTaskAudioWindow(t, started, zone)!!
        assertTrue(next.first > started)
        assertFalse(next.first == started)
    }

    @Test
    fun stoppingTaskAudioUsesOnlyItsOwnCodes() {
        // The stop for a task's audio is an end code in the task-audio range; the music service's notification is
        // a different id, so stopping task audio cannot be mistaken for stopping the music.
        assertNotEquals(taskAudioEndCodeFor(3), MusicPlaybackService.NOTIFICATION_ID)
        assertNotEquals(taskAudioStartCodeFor(3), taskAudioEndCodeFor(3))
    }
}
