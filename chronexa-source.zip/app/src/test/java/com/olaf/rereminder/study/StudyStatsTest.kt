// Part of Chronexa, a derivative of reReminder 4.0.1 — GNU GPL v3. See NOTICE.
package com.olaf.rereminder.study

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId

class StudyStatsTest {

    private val zone = ZoneId.of("UTC")
    private val monday = LocalDate.of(2026, 10, 19)
    private val today = monday.plusDays(2)

    private fun task(id: Long, subject: Long?, date: LocalDate = monday) = StudyTask(
        id = id, title = "t$id", subjectId = subject, firstDate = date,
        startMinute = 540, endMinute = 600, repeat = TaskRepeat.DAILY,
    )

    private fun data(
        tasks: List<StudyTask>,
        completions: Set<Completion> = emptySet(),
        focus: List<FocusRecord> = emptyList(),
    ) = StudyData(
        subjects = listOf(Subject(1L, "Physics", 0), Subject(2L, "Maths", 1)),
        tasks = tasks,
        completions = completions,
        focusRecords = focus,
        settings = StudySettings(),
    )

    @Test
    fun completionOfAnUnrelatedDateIsNotCounted() {
        val d = data(listOf(task(1, 1L)), setOf(Completion(1, monday.minusDays(3))))
        assertEquals(0, completedCountBetween(d, monday.minusDays(10), today))
    }

    @Test
    fun staleCompletionForDeletedTaskIsIgnored() {
        val d = data(emptyList(), setOf(Completion(99, monday)))
        assertEquals(0, completedCountBetween(d, monday, today))
    }

    @Test
    fun completionsAreCountedPerDay() {
        val d = data(
            listOf(task(1, 1L)),
            setOf(Completion(1, monday), Completion(1, today)),
        )
        assertEquals(2, completedCountBetween(d, monday, today))
    }

    @Test
    fun subjectStatsCombineTasksAndFocusTime() {
        val end = Instant.parse("2026-10-20T12:00:00Z").toEpochMilli()
        val d = data(
            listOf(task(1, 1L), task(2, 2L)),
            setOf(Completion(1, monday)),
            listOf(FocusRecord(1, 1L, "", 1500, end - 1500_000, end)),
        )
        val stats = subjectStats(d, LocalDate.of(1970, 1, 1), today, zone)
        val physics = stats.first { it.subjectId == 1L }
        assertEquals(1, physics.completedTasks)
        assertEquals(1500L, physics.focusSeconds)
        assertEquals(0, stats.first { it.subjectId == 2L }.completedTasks)
    }

    @Test
    fun focusOfADeletedSubjectGroupsUnderNoSubject() {
        val end = Instant.parse("2026-10-20T12:00:00Z").toEpochMilli()
        val d = data(emptyList(), focus = listOf(FocusRecord(1, 77L, "", 600, end - 600_000, end)))
        val other = subjectStats(d, LocalDate.of(1970, 1, 1), today, zone).first { it.subjectId == null }
        assertEquals(600L, other.focusSeconds)
    }

    @Test
    fun streakUsesTheSameRuleAsTheStreakFunction() {
        val d = data(
            listOf(task(1, 1L)),
            setOf(Completion(1, monday), Completion(1, monday.plusDays(1)), Completion(1, today)),
        )
        assertEquals(3, bestStreak(d, today))
        assertEquals(3, currentStreak(d, today))
    }

    @Test
    fun badgesReflectRealCountsAndNeverExceedTarget() {
        val d = data(listOf(task(1, 1L)), setOf(Completion(1, monday)))
        val list = badges(d, today, zone)
        val first = list.first { it.id == "first_task" }
        assertTrue(first.earned)
        assertEquals(1, first.progress)
        assertFalse(list.first { it.id == "week_streak" }.earned)
        assertTrue(list.all { it.progress <= it.target })
    }

    @Test
    fun emptyDataHasNoBadgesEarnedAndNoStreak() {
        val d = data(emptyList())
        assertEquals(0, currentStreak(d, today))
        assertEquals(0, bestStreak(d, today))
        assertTrue(badges(d, today, zone).none { it.earned })
    }
}
