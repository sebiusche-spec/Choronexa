// Part of Chronexa, a derivative of reReminder 4.0.1 — GNU GPL v3. See NOTICE.
package com.olaf.rereminder.study

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDate
import java.time.LocalDateTime

class ActivityPlanningTest {

    private val day = LocalDate.of(2026, 10, 23)

    private fun at(h: Int, m: Int, date: LocalDate = day) = date.atTime(h, m)

    private fun task(
        id: Long,
        name: String,
        start: Int,
        end: Int,
        date: LocalDate = day,
        repeat: TaskRepeat = TaskRepeat.NONE,
    ) = StudyTask(id = id, title = name, firstDate = date, startMinute = start, endMinute = end, repeat = repeat)

    // --- Animation choice ---------------------------------------------------------------

    @Test
    fun keywordsDecideTheAnimationFirst() {
        assertEquals("wake", chooseAnimation("Wake up", "routine", "auto"))
        assertEquals("brush", chooseAnimation("Brush teeth", "routine", "auto"))
        assertEquals("physics", chooseAnimation("Physics", "study", "auto"))
        assertEquals("chemistry", chooseAnimation("Chemistry", "study", "auto"))
        assertEquals("food", chooseAnimation("Lunch", "routine", "auto"))
        assertEquals("break", chooseAnimation("Walk", "other", "auto"))
    }

    @Test
    fun earlierKeywordWinsWhenTwoMatch() {
        // "morning" (wake) is checked before "run" (exercise).
        assertEquals("wake", chooseAnimation("Morning run", "exercise", "auto"))
    }

    @Test
    fun categoryIsUsedWhenNoKeywordMatches() {
        assertEquals("study", chooseAnimation("Essay", "study", "auto"))
        assertEquals("sleep", chooseAnimation("Downtime", "sleep", "auto"))
        assertEquals("calm", chooseAnimation("Zzz", "other", "auto"))
        assertEquals("calm", chooseAnimation("Choir", "Music club", "auto"))
    }

    @Test
    fun manualChoiceBeatsKeywordsAndNoneSwitchesOff() {
        assertEquals("sleep", chooseAnimation("Physics", "study", "sleep"))
        assertEquals("none", chooseAnimation("Physics", "study", "none"))
    }

    @Test
    fun keywordsMatchWholeWordsOnly() {
        // "wakeboarding" must not match the "wake" keyword.
        assertEquals("calm", chooseAnimation("Wakeboarding", "other", "auto"))
    }

    // --- Categories ----------------------------------------------------------------------

    @Test
    fun allCategoriesAddsCustomOnesOnceWithoutBuiltInRepeats() {
        val data = StudyData(
            subjects = emptyList(), tasks = emptyList(), completions = emptySet(),
            focusRecords = emptyList(), settings = StudySettings(),
            categories = listOf("Gaming", "routine", "Gaming", "  ", "Choir"),
        )
        assertEquals(BUILT_IN_CATEGORIES + listOf("Gaming", "Choir"), allCategories(data))
    }

    // --- Current and next activity -----------------------------------------------------

    @Test
    fun currentAndNextWithRemainingMinutes() {
        val tasks = listOf(task(1, "Brush", 302, 310), task(2, "Bath", 310, 330))
        val s = dayNow(tasks, at(5, 5))
        assertEquals("Brush", s.current!!.task.title)
        assertEquals(5L, s.minutesLeft)
        assertEquals("Bath", s.next!!.task.title)
        assertEquals(5L, s.minutesUntilNext)
    }

    @Test
    fun aGapHasNoCurrentActivityButHasANext() {
        val tasks = listOf(task(1, "Brush", 302, 310), task(2, "Bath", 320, 330))
        val s = dayNow(tasks, at(5, 15))
        assertNull(s.current)
        assertNull(s.minutesLeft)
        assertEquals("Bath", s.next!!.task.title)
        assertEquals(5L, s.minutesUntilNext)
    }

    @Test
    fun overnightActivityFromYesterdayIsCurrentInTheEarlyMorning() {
        // Sleep: 23:00 yesterday to 06:00 today.
        val sleep = task(1, "Sleep", 1380, 360, date = day.minusDays(1))
        val s = dayNow(listOf(sleep), at(2, 0))
        assertEquals("Sleep", s.current!!.task.title)
        assertEquals(240L, s.minutesLeft)
    }

    @Test
    fun afterTheLastActivityThereIsNoNext() {
        val s = dayNow(listOf(task(1, "Brush", 302, 310)), at(10, 0))
        assertNull(s.current)
        assertNull(s.next)
        assertNull(s.minutesUntilNext)
    }

    // --- Copying a day ------------------------------------------------------------------

    @Test
    fun copyMakesOneOffCopiesAndSkipsWhatIsAlreadyThere() {
        val tomorrow = day.plusDays(1)
        val tasks = listOf(
            task(1, "Brush", 302, 310),                              // once, today only
            task(2, "Bath", 310, 330, repeat = TaskRepeat.DAILY),    // occurs tomorrow too
        )
        var next = 100L
        val result = copyDay(tasks, day, tomorrow) { next++ }
        assertEquals(1, result.created.size)
        assertEquals(1, result.skipped)              // the daily Bath already occurs tomorrow
        val brush = result.created.single()
        assertEquals("Brush", brush.title)
        assertEquals(tomorrow, brush.firstDate)
        assertEquals(TaskRepeat.NONE, brush.repeat)
        assertEquals(100L, brush.id)
    }

    @Test
    fun copyingTheSameDayTwiceCreatesNothingTheSecondTime() {
        val tomorrow = day.plusDays(1)
        val tasks = listOf(task(1, "Brush", 302, 310))
        val first = copyDay(tasks, day, tomorrow) { 50L }
        val second = copyDay(tasks + first.created, day, tomorrow) { 60L }
        assertTrue(second.created.isEmpty())
        assertEquals(1, second.skipped)
    }

    @Test
    fun copyToTheSameDayDoesNothing() {
        val result = copyDay(listOf(task(1, "Brush", 302, 310)), day, day) { 1L }
        assertTrue(result.created.isEmpty())
        assertEquals(0, result.skipped)
    }

    // --- Rescheduling -------------------------------------------------------------------

    @Test
    fun rescheduleKeepsTheLength() {
        val brush = task(1, "Brush", 302, 310)
        val moved = brush.rescheduledTo(1410)!!
        assertEquals(1410, moved.startMinute)
        assertEquals(1418, moved.endMinute)
        assertEquals(8, moved.durationMinutes)
    }

    @Test
    fun rescheduleWrapsAnOvernightActivityPastMidnight() {
        val sleep = task(1, "Sleep", 1380, 360) // 7 hours
        val moved = sleep.rescheduledTo(1410)!!  // 23:30 start
        assertEquals(390, moved.endMinute)       // 06:30 next morning
        assertEquals(420, moved.durationMinutes)
    }

    @Test
    fun aWholeDayActivityCanOnlyStartAtMidnight() {
        val whole = task(1, "Holiday", 0, MINUTES_PER_DAY)
        assertNull(whole.rescheduledTo(100))
        assertEquals(MINUTES_PER_DAY, whole.rescheduledTo(0)!!.endMinute)
    }

    @Test
    fun rescheduleRejectsAStartOutsideTheDay() {
        assertNull(task(1, "Brush", 302, 310).rescheduledTo(MINUTES_PER_DAY))
        assertNull(task(1, "Brush", 302, 310).rescheduledTo(-1))
    }
}
