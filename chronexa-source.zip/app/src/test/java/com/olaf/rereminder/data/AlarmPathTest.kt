// Part of Chronexa, a derivative of reReminder 4.0.1 — GNU GPL v3. See NOTICE.
package com.olaf.rereminder.data

import org.junit.Assert.assertEquals
import org.junit.Test

/** The path a video alarm takes when Android may or may not let the ringing service start from the background. */
class AlarmPathTest {

    @Test
    fun aVideoAlarmRingsThroughTheServiceWhenItCanStart() {
        assertEquals(AlarmPath.RINGING_SERVICE, alarmPathFor(routedAsAlarm = true, serviceStarted = true, fullScreenPosted = true))
    }

    @Test
    fun aRefusedStartFallsBackToTheFullScreenAlarmNotNotTheOrdinaryOne() {
        assertEquals(AlarmPath.FULL_SCREEN_NOTIFICATION, alarmPathFor(routedAsAlarm = true, serviceStarted = false, fullScreenPosted = true))
    }

    @Test
    fun onlyWhenNothingElseWorksDoesAnAlarmBecomeAnOrdinaryNotification() {
        assertEquals(AlarmPath.ORDINARY_NOTIFICATION, alarmPathFor(routedAsAlarm = true, serviceStarted = false, fullScreenPosted = false))
    }

    @Test
    fun anEarlyReminderIsAlwaysAnOrdinaryNotification() {
        assertEquals(AlarmPath.ORDINARY_NOTIFICATION, alarmPathFor(routedAsAlarm = false, serviceStarted = false, fullScreenPosted = true))
    }
}
