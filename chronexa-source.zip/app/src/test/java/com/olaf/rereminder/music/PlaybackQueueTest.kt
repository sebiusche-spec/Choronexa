// Part of Chronexa, a derivative of reReminder 4.0.1 — GNU GPL v3. See NOTICE.
package com.olaf.rereminder.music

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.random.Random

class PlaybackQueueTest {

    private val songs = listOf("a", "b", "c")

    @Test
    fun playingFromATrackStartsThereInOrder() {
        val q = PlaybackQueue.buildQueue(songs, startUri = "b", shuffle = false)
        assertEquals("b", q.current)
        assertEquals(songs, q.order)
    }

    @Test
    fun nextAndPreviousStopAtTheEdgesWithRepeatOff() {
        assertNull(PlaybackQueue.buildQueue(songs, "c", shuffle = false).next())
        assertNull(PlaybackQueue.buildQueue(songs, "a", shuffle = false).previous())
        assertEquals("b", PlaybackQueue.buildQueue(songs, "a", shuffle = false).next()!!.current)
    }

    @Test
    fun repeatAllWrapsAround() {
        assertEquals("a", PlaybackQueue.buildQueue(songs, "c", shuffle = false, repeat = RepeatMode.ALL).next()!!.current)
        assertEquals("c", PlaybackQueue.buildQueue(songs, "a", shuffle = false, repeat = RepeatMode.ALL).previous()!!.current)
    }

    @Test
    fun repeatOneKeepsTheSameTrackWhenItEnds() {
        val q = PlaybackQueue.buildQueue(songs, "b", shuffle = false, repeat = RepeatMode.ONE)
        assertEquals("b", q.afterTrackEnded()!!.current)
    }

    @Test
    fun repeatCycleGoesOffAllOneOff() {
        val q = PlaybackQueue.buildQueue(songs, "a", shuffle = false)
        assertEquals(RepeatMode.ALL, q.cycleRepeat().repeat)
        assertEquals(RepeatMode.ONE, q.cycleRepeat().cycleRepeat().repeat)
        assertEquals(RepeatMode.OFF, q.cycleRepeat().cycleRepeat().cycleRepeat().repeat)
    }

    @Test
    fun shuffleKeepsEverySongOnceAndStartsWithTheChosenOne() {
        val q = PlaybackQueue.buildQueue(songs, "b", shuffle = true, random = Random(7))
        assertEquals("b", q.current)
        assertEquals(songs.sorted(), q.order.sorted())
    }

    @Test
    fun turningShuffleOnKeepsTheCurrentTrackPlaying() {
        val shuffled = PlaybackQueue.buildQueue(songs, "c", shuffle = false).withShuffle(true, Random(3))
        assertEquals("c", shuffled.current)
        assertTrue(shuffled.shuffle)
        assertEquals(songs.sorted(), shuffled.order.sorted())
    }

    @Test
    fun anEmptyQueueHasNothingToPlay() {
        val q = PlaybackQueue.buildQueue(emptyList(), null, shuffle = true)
        assertNull(q.current)
        assertNull(q.next())
        assertNull(q.previous())
    }
}
