// Part of Chronexa, a derivative of reReminder 4.0.1 — GNU GPL v3. See NOTICE.
package com.olaf.rereminder.study

import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDate

class PlaylistAlarmIsolationTest {

    private val day = LocalDate.of(2026, 10, 23)

    private fun data(task: StudyTask) = StudyData(subjects = emptyList(), tasks = listOf(task), completions = emptySet(),
        focusRecords = emptyList(), settings = StudySettings(), nextAlarmSlot = 9)

    @Test
    fun linkingAPlaylistDoesNotTouchTheAlarm() {
        val before = StudyTask(1, "Physics", firstDate = day, startMinute = 450, endMinute = 570,
            alert = true, alarmAtStart = true, alarmSlot = 4)
        val after = before.copy(playlistId = "physics", playOnStart = true)
        val plan = planAlarmChanges(data(before), data(after))
        assertTrue(plan.cancelSlots.isEmpty())
        assertTrue(plan.scheduleTasks.isEmpty())
    }

    @Test
    fun changingTheAlarmStillReschedulesWhilePlaylistIsKept() {
        val before = StudyTask(1, "Physics", firstDate = day, startMinute = 450, endMinute = 570,
            alarmAtStart = true, alarmSlot = 4, playlistId = "physics")
        val after = before.copy(startMinute = 480, endMinute = 600)
        val plan = planAlarmChanges(data(before), data(after))
        assertTrue(plan.scheduleTasks.single().playlistId == "physics")
    }
}
