// Part of Chronexa, a derivative of reReminder 4.0.1 — GNU GPL v3. See NOTICE.
package com.olaf.rereminder.music

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class MusicCodecTest {

    private val a = Track("content://media/audio/1", "Quadratics", "Ms Lee", 185_000L)

    @Test
    fun libraryRoundTripsWithPlaylistMembership() {
        val lib = MusicLibrary.initial().addTrackTo("mathematics", a).addTrackTo(PLAYLIST_FAVORITES, a)
            .createPlaylist("Exam week")
        val back = (MusicCodec.decode(MusicCodec.encode(lib)) as MusicCodec.DecodeResult.Ok).library
        assertEquals(lib, back)
    }

    @Test
    fun unknownFieldsAreIgnored() {
        val text = """{"schemaVersion":1,"futureThing":[1],"tracks":[],"playlists":[],"nextPlaylistNumber":3}"""
        val ok = MusicCodec.decode(text) as MusicCodec.DecodeResult.Ok
        assertEquals(3, ok.library.nextPlaylistNumber)
    }

    @Test
    fun newerVersionIsReportedNotParsed() {
        val result = MusicCodec.decode("""{"schemaVersion":2,"tracks":[]}""")
        assertEquals(2, (result as MusicCodec.DecodeResult.FutureVersion).version)
    }

    @Test
    fun damagedDataIsReportedNotDropped() {
        assertTrue(MusicCodec.decode("not json") is MusicCodec.DecodeResult.Invalid)
    }

    @Test
    fun removingAFileFromAPlaylistSurvivesSaveAndLoad() {
        val lib = MusicLibrary.initial().addTrackTo("physics", a).removeFromPlaylist("physics", a.uri)
        val back = (MusicCodec.decode(MusicCodec.encode(lib)) as MusicCodec.DecodeResult.Ok).library
        assertTrue(back.playlists.first { it.id == "physics" }.trackUris.isEmpty())
        assertEquals(listOf(a), back.tracks)
    }
}
