// Part of Chronexa, a derivative of reReminder 4.0.1 — GNU GPL v3. See NOTICE.
package com.olaf.rereminder.study

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * The rules behind Snooze. Cancelling and scheduling real alarms needs a device; these tests cover the request
 * codes and timing that those calls depend on.
 */
class AlarmSnoozeTest {

    @Test
    fun snoozeCodesNeverCollideWithAnyAlarmCode() {
        val alarmCodes = (1..10_000).map { requestCodeFor(it, AlarmKind.ALARM) } + (1..10_000).map { requestCodeFor(it, AlarmKind.REMINDER) }
        val snoozeCodes = (1..10_000).map { snoozeCodeFor(it) }
        assertTrue(alarmCodes.none { it in snoozeCodes.toSet() })
    }

    @Test
    fun aRepeatedSnoozeUsesTheSamePendingCode() {
        // The same code means the system replaces the pending snooze rather than adding a second one.
        assertEquals(snoozeCodeFor(7), snoozeCodeFor(7))
        assertFalse(snoozeCodeFor(7) == snoozeCodeFor(8))
    }

    @Test
    fun anAlarmCodeMapsBackToItsSlot() {
        assertEquals(42, slotForAlarmCode(requestCodeFor(42, AlarmKind.ALARM)))
    }

    @Test
    fun remindersSnoozesAndUnknownCodesAreNotActivityAlarms() {
        assertNull(slotForAlarmCode(requestCodeFor(42, AlarmKind.REMINDER)))
        assertNull(slotForAlarmCode(snoozeCodeFor(42)))
        assertNull(slotForAlarmCode(5))
    }

    @Test
    fun snoozeRingsAfterTheChosenMinutes() {
        val now = 1_000_000L
        assertEquals(now + 5 * 60_000L, snoozeTrigger(now, 5))
        assertEquals(now + 30 * 60_000L, snoozeTrigger(now, 30))
    }

    @Test
    fun snoozeLengthIsKeptWithinAnHour() {
        val now = 0L
        assertEquals(SNOOZE_MIN_MINUTES * 60_000L, snoozeTrigger(now, 0))
        assertEquals(SNOOZE_MAX_MINUTES * 60_000L, snoozeTrigger(now, 500))
    }
}
