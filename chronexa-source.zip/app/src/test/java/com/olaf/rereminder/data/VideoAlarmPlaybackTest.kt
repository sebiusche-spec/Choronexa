// Part of Chronexa, a derivative of reReminder 4.0.1 — GNU GPL v3. See NOTICE.
package com.olaf.rereminder.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/** Which sounds an alarm plays when a video is involved, and what happens when the video cannot play. */
class VideoAlarmPlaybackTest {

    private val video = VideoChoice(uri = "content://media/video/7", name = "Sunrise.mp4")

    @Test
    fun aVideoAloneKeepsTheRingtoneOff() {
        // Video audio only: the video's sound is the alarm sound, so the ringtone must not also play.
        val playback = resolveVideoPlayback(video.copy(audio = VideoAudioMode.VIDEO_AUDIO), canOpen = true)
        assertFalse(playback.ringtoneAllowed())
        assertTrue(playback.videoAudioAllowed())
    }

    @Test
    fun theRingtoneOnlyModeKeepsTheVideoSilent() {
        val playback = resolveVideoPlayback(video.copy(audio = VideoAudioMode.RINGTONE), canOpen = true)
        assertTrue(playback.ringtoneAllowed())
        assertFalse(playback.videoAudioAllowed())
    }

    @Test
    fun bothPlayTogether() {
        val playback = resolveVideoPlayback(video.copy(audio = VideoAudioMode.BOTH), canOpen = true)
        assertTrue(playback.ringtoneAllowed())
        assertTrue(playback.videoAudioAllowed())
    }

    @Test
    fun aVideoThatCannotBeOpenedStillRingsTheRingtone() {
        // Missing, moved or unreadable: the alarm must still ring, and it must not be silent.
        val playback = resolveVideoPlayback(video.copy(audio = VideoAudioMode.VIDEO_AUDIO), canOpen = false)
        assertEquals(VideoPlayback.FallbackToRingtone, playback)
        assertTrue(playback.ringtoneAllowed())
        assertFalse(playback.videoAudioAllowed())
    }

    @Test
    fun anAlarmWithNoVideoRingsItsNormalSound() {
        assertTrue(VideoPlayback.None.ringtoneAllowed())
        assertFalse(VideoPlayback.None.videoAudioAllowed())
    }

    @Test
    fun aMutedPhoneSilencesTheVideosAudioButKeepsItsPicture() {
        val played = resolveVideoPlayback(video.copy(audio = VideoAudioMode.BOTH, loop = false), canOpen = true)
        val silenced = played.silencedFor(audible = false) as VideoPlayback.Play
        assertFalse(silenced.playVideoAudio)
        assertFalse(silenced.playRingtone)
        assertEquals(video.uri, silenced.uri)
        assertFalse(silenced.loop)
    }

    @Test
    fun anAudibleAlarmIsLeftUnchanged() {
        val played = resolveVideoPlayback(video.copy(audio = VideoAudioMode.BOTH), canOpen = true)
        assertEquals(played, played.silencedFor(audible = true))
    }

    @Test
    fun silencingNeverChangesAlarmsWithoutAVideo() {
        assertEquals(VideoPlayback.None, VideoPlayback.None.silencedFor(audible = false))
        assertEquals(VideoPlayback.FallbackToRingtone, VideoPlayback.FallbackToRingtone.silencedFor(audible = false))
    }
}
