// Part of Chronexa, a derivative of reReminder 4.0.1 — GNU GPL v3. See NOTICE.
package com.olaf.rereminder.study

import org.junit.Assert.assertEquals
import org.junit.Test
import java.time.LocalDate

class StreaksTest {

    private val today = LocalDate.of(2026, 10, 23)

    /** A day summary lookup from explicit per-day results. Missing days have no tasks. */
    private fun lookup(days: Map<LocalDate, Pair<Int, Int>>): (LocalDate) -> DaySummary = { d ->
        val (total, done) = days[d] ?: (0 to 0)
        DaySummary(d, total, done)
    }

    private fun fullyDone(vararg offsets: Int): Map<LocalDate, Pair<Int, Int>> =
        offsets.associate { today.minusDays(it.toLong()) to (2 to 2) }

    @Test
    fun currentStreakCountsConsecutiveCompletedDays() {
        val map = fullyDone(0, 1, 2)
        assertEquals(3, Streaks.current(today, lookup(map)))
    }

    @Test
    fun todayInProgressDoesNotBreakTheStreak() {
        val map = fullyDone(1, 2) + mapOf(today to (3 to 1))
        assertEquals(2, Streaks.current(today, lookup(map)))
    }

    @Test
    fun todayCompletedAddsToTheStreak() {
        val map = fullyDone(0, 1)
        assertEquals(2, Streaks.current(today, lookup(map)))
    }

    @Test
    fun aMissedDayEndsTheCurrentStreak() {
        // Today done, yesterday had an unfinished task, the two days before were done.
        val map = fullyDone(0, 2, 3) + mapOf(today.minusDays(1) to (2 to 1))
        assertEquals(1, Streaks.current(today, lookup(map)))
    }

    @Test
    fun aDayWithNothingScheduledBreaksTheStreak() {
        val map = fullyDone(0, 2, 3) // yesterday has no tasks at all
        assertEquals(1, Streaks.current(today, lookup(map)))
    }

    @Test
    fun noHistoryGivesZero() {
        assertEquals(0, Streaks.current(today, lookup(emptyMap())))
        assertEquals(0, Streaks.best(null, today, lookup(emptyMap())))
    }

    @Test
    fun bestStreakFindsTheLongestRunAnywhere() {
        val start = today.minusDays(9)
        // Days -9..-5 done (5 days), gap, days -3..-2 done, today in progress.
        val map = mutableMapOf<LocalDate, Pair<Int, Int>>()
        for (i in 9 downTo 5) map[today.minusDays(i.toLong())] = 1 to 1
        for (i in 3 downTo 2) map[today.minusDays(i.toLong())] = 1 to 1
        map[today] = 2 to 1
        assertEquals(5, Streaks.best(start, today, lookup(map)))
    }

    @Test
    fun bestStreakIgnoresTodayWhileItIsInProgress() {
        val start = today.minusDays(2)
        val map = mapOf(
            today.minusDays(2) to (1 to 1),
            today.minusDays(1) to (1 to 1),
            today to (2 to 0),
        )
        assertEquals(2, Streaks.best(start, today, lookup(map)))
    }

    @Test
    fun streakAcrossAMonthBoundaryStaysConsecutive() {
        val end = LocalDate.of(2026, 11, 2)
        val map = mapOf(
            LocalDate.of(2026, 10, 31) to (1 to 1),
            LocalDate.of(2026, 11, 1) to (1 to 1),
            LocalDate.of(2026, 11, 2) to (1 to 1),
        )
        assertEquals(3, Streaks.best(LocalDate.of(2026, 10, 31), end, lookup(map)))
    }
}
