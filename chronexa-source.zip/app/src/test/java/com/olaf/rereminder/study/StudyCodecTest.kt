// Part of Chronexa, a derivative of reReminder 4.0.1 — GNU GPL v3. See NOTICE.
package com.olaf.rereminder.study

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.DayOfWeek
import java.time.LocalDate

class StudyCodecTest {

    private fun sample() = StudyData(
        subjects = defaultSubjects(),
        tasks = listOf(
            StudyTask(1, "Brush", "", null, LocalDate.of(2026, 10, 19), 300, 310, TaskRepeat.DAILY),
            StudyTask(2, "Physics", "Chapter 4", 1L, LocalDate.of(2026, 10, 20), 450, 570,
                TaskRepeat.WEEKLY, setOf(DayOfWeek.TUESDAY, DayOfWeek.THURSDAY), LocalDate.of(2026, 12, 31)),
        ),
        completions = setOf(Completion(1, LocalDate.of(2026, 10, 19))),
        focusRecords = listOf(FocusRecord(1, 1L, "deep work", 1500, 1_000L, 2_500_000L)),
        settings = StudySettings(focusMinutes = 50, firstDayOfWeek = DayOfWeek.SUNDAY),
    )

    @Test
    fun roundTripPreservesEverything() {
        val original = sample()
        val text = StudyCodec.encode(original)
        val back = StudyCodec.decode(text) as StudyCodec.DecodeResult.Ok
        assertEquals(original, back.data)
    }

    @Test
    fun unknownFieldsFromNewerMinorChangesAreIgnored() {
        val text = """{"schemaVersion":1,"futureField":[1,2],"subjects":[],"tasks":[],""" +
            """"completions":[],"focusRecords":[],"settings":{"focusMinutes":30,"mystery":true}}"""
        val ok = StudyCodec.decode(text) as StudyCodec.DecodeResult.Ok
        assertEquals(30, ok.data.settings.focusMinutes)
    }

    @Test
    fun newerSchemaIsReportedAndNeverParsedAsCurrent() {
        val text = """{"schemaVersion":3,"subjects":[]}"""
        val result = StudyCodec.decode(text)
        assertEquals(3, (result as StudyCodec.DecodeResult.FutureVersion).version)
    }

    @Test
    fun unreadableFileIsInvalidNotSilentlyEmpty() {
        assertTrue(StudyCodec.decode("not json at all") is StudyCodec.DecodeResult.Invalid)
        assertTrue(StudyCodec.decode("""{"tasks":[{"id":1,"title":"x","firstDate":"2026-13-40","startMinute":0,"endMinute":1}]}""")
            is StudyCodec.DecodeResult.Invalid)
    }

    @Test
    fun unknownRepeatTextFallsBackToNone() {
        val text = """{"schemaVersion":1,"tasks":[{"id":5,"title":"x","firstDate":"2026-10-19",""" +
            """"startMinute":60,"endMinute":120,"repeat":"BIWEEKLY"}]}"""
        val ok = StudyCodec.decode(text) as StudyCodec.DecodeResult.Ok
        assertEquals(TaskRepeat.NONE, ok.data.tasks.single().repeat)
    }

    @Test
    fun badFirstDayFallsBackToMonday() {
        val text = """{"schemaVersion":1,"settings":{"firstDayOfWeek":9}}"""
        val ok = StudyCodec.decode(text) as StudyCodec.DecodeResult.Ok
        assertEquals(DayOfWeek.MONDAY, ok.data.settings.firstDayOfWeek)
    }

    @Test
    fun emptyObjectGivesEmptyDataWithDefaultSettings() {
        val ok = StudyCodec.decode("{}") as StudyCodec.DecodeResult.Ok
        assertTrue(ok.data.tasks.isEmpty())
        assertEquals(StudySettings(), ok.data.settings)
    }

    @Test
    fun outOfRangeSettingsAreClampedNotRejected() {
        val text = """{"schemaVersion":1,"settings":{"focusMinutes":0,"sessionsBeforeLongBreak":99}}"""
        val ok = StudyCodec.decode(text) as StudyCodec.DecodeResult.Ok
        assertEquals(1, ok.data.settings.focusMinutes)
        assertEquals(12, ok.data.settings.sessionsBeforeLongBreak)
    }

    @Test
    fun schemaOneFileReadsWithAnEmptyTodoList() {
        // A file written before to-dos existed must still load, with nothing lost.
        val text = """{"schemaVersion":1,"subjects":[{"id":1,"name":"Physics"}],"settings":{"focusMinutes":30}}"""
        val ok = StudyCodec.decode(text) as StudyCodec.DecodeResult.Ok
        assertTrue(ok.data.todos.isEmpty())
        assertEquals("Physics", ok.data.subjects.single().name)
        assertEquals(30, ok.data.settings.focusMinutes)
    }

    @Test
    fun todosRoundTripIncludingDueMomentAndDoneFlag() {
        val data = StudyData(
            subjects = emptyList(),
            tasks = emptyList(),
            completions = emptySet(),
            focusRecords = emptyList(),
            settings = StudySettings(),
            todos = listOf(
                TodoItem(1, "Submit lab report", "Section 3", 2L, java.time.LocalDateTime.of(2026, 10, 25, 17, 30), done = true),
                TodoItem(2, "Buy pens"),
            ),
        )
        val back = (StudyCodec.decode(StudyCodec.encode(data)) as StudyCodec.DecodeResult.Ok).data
        assertEquals(data.todos, back.todos)
    }

    @Test
    fun savedFileIsWrittenAsTheCurrentSchema() {
        val text = StudyCodec.encode(StudyData.initial())
        assertTrue(text.contains("\"schemaVersion\":${StudyCodec.CURRENT_SCHEMA_VERSION}"))
    }
}
