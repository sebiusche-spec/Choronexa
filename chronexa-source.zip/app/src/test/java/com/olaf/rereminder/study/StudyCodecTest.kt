// Part of Chronexa, a derivative of reReminder 4.0.1 — GNU GPL v3. See NOTICE.
package com.olaf.rereminder.study

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.DayOfWeek
import java.time.LocalDate

class StudyCodecTest {

    private fun sample() = StudyData(
        subjects = defaultSubjects(),
        tasks = listOf(
            StudyTask(1, "Brush", "", null, LocalDate.of(2026, 10, 19), 300, 310, TaskRepeat.DAILY),
            StudyTask(2, "Physics", "Chapter 4", 1L, LocalDate.of(2026, 10, 20), 450, 570,
                TaskRepeat.WEEKLY, setOf(DayOfWeek.TUESDAY, DayOfWeek.THURSDAY), LocalDate.of(2026, 12, 31)),
        ),
        completions = setOf(Completion(1, LocalDate.of(2026, 10, 19))),
        focusRecords = listOf(FocusRecord(1, 1L, "deep work", 1500, 1_000L, 2_500_000L)),
        settings = StudySettings(focusMinutes = 50, firstDayOfWeek = DayOfWeek.SUNDAY),
    )

    @Test
    fun roundTripPreservesEverything() {
        val original = sample()
        val text = StudyCodec.encode(original)
        val back = StudyCodec.decode(text) as StudyCodec.DecodeResult.Ok
        assertEquals(original, back.data)
    }

    @Test
    fun unknownFieldsFromNewerMinorChangesAreIgnored() {
        val text = """{"schemaVersion":1,"futureField":[1,2],"subjects":[],"tasks":[],""" +
            """"completions":[],"focusRecords":[],"settings":{"focusMinutes":30,"mystery":true}}"""
        val ok = StudyCodec.decode(text) as StudyCodec.DecodeResult.Ok
        assertEquals(30, ok.data.settings.focusMinutes)
    }

    @Test
    fun newerSchemaIsReportedAndNeverParsedAsCurrent() {
        val text = """{"schemaVersion":9,"subjects":[]}"""
        val result = StudyCodec.decode(text)
        assertEquals(9, (result as StudyCodec.DecodeResult.FutureVersion).version)
    }

    @Test
    fun unreadableFileIsInvalidNotSilentlyEmpty() {
        assertTrue(StudyCodec.decode("not json at all") is StudyCodec.DecodeResult.Invalid)
        assertTrue(StudyCodec.decode("""{"tasks":[{"id":1,"title":"x","firstDate":"2026-13-40","startMinute":0,"endMinute":1}]}""")
            is StudyCodec.DecodeResult.Invalid)
    }

    @Test
    fun unknownRepeatTextFallsBackToNone() {
        val text = """{"schemaVersion":1,"tasks":[{"id":5,"title":"x","firstDate":"2026-10-19",""" +
            """"startMinute":60,"endMinute":120,"repeat":"BIWEEKLY"}]}"""
        val ok = StudyCodec.decode(text) as StudyCodec.DecodeResult.Ok
        assertEquals(TaskRepeat.NONE, ok.data.tasks.single().repeat)
    }

    @Test
    fun badFirstDayFallsBackToMonday() {
        val text = """{"schemaVersion":1,"settings":{"firstDayOfWeek":9}}"""
        val ok = StudyCodec.decode(text) as StudyCodec.DecodeResult.Ok
        assertEquals(DayOfWeek.MONDAY, ok.data.settings.firstDayOfWeek)
    }

    @Test
    fun emptyObjectGivesEmptyDataWithDefaultSettings() {
        val ok = StudyCodec.decode("{}") as StudyCodec.DecodeResult.Ok
        assertTrue(ok.data.tasks.isEmpty())
        assertEquals(StudySettings(), ok.data.settings)
    }

    @Test
    fun outOfRangeSettingsAreClampedNotRejected() {
        val text = """{"schemaVersion":1,"settings":{"focusMinutes":0,"sessionsBeforeLongBreak":99}}"""
        val ok = StudyCodec.decode(text) as StudyCodec.DecodeResult.Ok
        assertEquals(1, ok.data.settings.focusMinutes)
        assertEquals(12, ok.data.settings.sessionsBeforeLongBreak)
    }

    @Test
    fun schemaOneFileReadsWithAnEmptyTodoList() {
        // A file written before to-dos existed must still load, with nothing lost.
        val text = """{"schemaVersion":1,"subjects":[{"id":1,"name":"Physics"}],"settings":{"focusMinutes":30}}"""
        val ok = StudyCodec.decode(text) as StudyCodec.DecodeResult.Ok
        assertTrue(ok.data.todos.isEmpty())
        assertEquals("Physics", ok.data.subjects.single().name)
        assertEquals(30, ok.data.settings.focusMinutes)
    }

    @Test
    fun todosRoundTripIncludingDueMomentAndDoneFlag() {
        val data = StudyData(
            subjects = emptyList(),
            tasks = emptyList(),
            completions = emptySet(),
            focusRecords = emptyList(),
            settings = StudySettings(),
            todos = listOf(
                TodoItem(1, "Submit lab report", "Section 3", 2L, java.time.LocalDateTime.of(2026, 10, 25, 17, 30), done = true),
                TodoItem(2, "Buy pens"),
            ),
        )
        val back = (StudyCodec.decode(StudyCodec.encode(data)) as StudyCodec.DecodeResult.Ok).data
        assertEquals(data.todos, back.todos)
    }

    @Test
    fun savedFileIsWrittenAsTheCurrentSchema() {
        val text = StudyCodec.encode(StudyData.initial())
        assertTrue(text.contains("\"schemaVersion\":${StudyCodec.CURRENT_SCHEMA_VERSION}"))
    }

    @Test
    fun schemaTwoFileReadsWithPlannerDefaults() {
        val text = """{"schemaVersion":2,"tasks":[{"id":7,"title":"Brush","firstDate":"2026-10-23",""" +
            """"startMinute":302,"endMinute":310}]}"""
        val ok = StudyCodec.decode(text) as StudyCodec.DecodeResult.Ok
        val task = ok.data.tasks.single()
        assertEquals("other", task.category)
        assertEquals("auto", task.animation)
        assertFalse(task.alert)
        assertTrue(ok.data.categories.isEmpty())
    }

    @Test
    fun plannerFieldsAndCustomCategoriesRoundTrip() {
        val data = StudyData(
            subjects = emptyList(), tasks = listOf(
                StudyTask(3, "Bath", firstDate = java.time.LocalDate.of(2026, 10, 23), startMinute = 310,
                    endMinute = 330, category = "routine", animation = "bath", alert = true),
            ),
            completions = emptySet(), focusRecords = emptyList(), settings = StudySettings(),
            categories = listOf("Gaming"),
        )
        val back = (StudyCodec.decode(StudyCodec.encode(data)) as StudyCodec.DecodeResult.Ok).data
        assertEquals(data.tasks, back.tasks)
        assertEquals(listOf("Gaming"), back.categories)
    }

    @Test
    fun schemaThreeFileReadsWithNoAlarmsScheduled() {
        val text = """{"schemaVersion":3,"tasks":[{"id":2,"title":"Physics","firstDate":"2026-10-23",""" +
            """"startMinute":450,"endMinute":570,"alert":true}]}"""
        val ok = StudyCodec.decode(text) as StudyCodec.DecodeResult.Ok
        val task = ok.data.tasks.single()
        assertEquals(5, task.reminderLeadMinutes)
        assertFalse(task.alarmAtStart)
        assertEquals("default", task.sound)
        assertEquals(0, task.alarmSlot)
        assertEquals(1, ok.data.nextAlarmSlot)
    }

    @Test
    fun alarmFieldsRoundTrip() {
        val data = StudyData(
            subjects = emptyList(),
            tasks = listOf(StudyTask(4, "Physics", firstDate = java.time.LocalDate.of(2026, 10, 23),
                startMinute = 450, endMinute = 570, alert = true, reminderLeadMinutes = 10,
                alarmAtStart = true, alarmSlot = 7)),
            completions = emptySet(), focusRecords = emptyList(), settings = StudySettings(),
            todos = listOf(TodoItem(9, "Pay fees", dueAt = java.time.LocalDateTime.of(2026, 10, 24, 9, 0),
                alert = true, reminderLeadMinutes = 15, alarmAtDue = true, alarmSlot = 8)),
            nextAlarmSlot = 9,
        )
        val back = (StudyCodec.decode(StudyCodec.encode(data)) as StudyCodec.DecodeResult.Ok).data
        assertEquals(data.tasks, back.tasks)
        assertEquals(data.todos, back.todos)
        assertEquals(9, back.nextAlarmSlot)
    }

    @Test
    fun customReminderMomentRoundTrips() {
        val data = StudyData(
            subjects = emptyList(),
            tasks = listOf(StudyTask(6, "Chemistry", firstDate = java.time.LocalDate.of(2026, 10, 23),
                startMinute = 840, endMinute = 960, alert = true, reminderCustomAt = 1_800_000_000_000L, alarmSlot = 2)),
            completions = emptySet(), focusRecords = emptyList(), settings = StudySettings(),
            todos = listOf(TodoItem(7, "Forms", dueAt = java.time.LocalDateTime.of(2026, 10, 25, 9, 0),
                alert = true, reminderCustomAt = 1_800_100_000_000L, alarmSlot = 3)),
            nextAlarmSlot = 4,
        )
        val back = (StudyCodec.decode(StudyCodec.encode(data)) as StudyCodec.DecodeResult.Ok).data
        assertEquals(data.tasks, back.tasks)
        assertEquals(data.todos, back.todos)
    }

    @Test
    fun schemaFourFileHasNoCustomReminder() {
        val text = """{"schemaVersion":4,"tasks":[{"id":3,"title":"Bath","firstDate":"2026-10-23",""" +
            """"startMinute":310,"endMinute":330,"alert":true}]}"""
        val ok = StudyCodec.decode(text) as StudyCodec.DecodeResult.Ok
        assertEquals(null, ok.data.tasks.single().reminderCustomAt)
    }

    @Test
    fun alarmSoundRoundTripsWithItsSwitchAndName() {
        val task = StudyTask(8, "Physics", firstDate = java.time.LocalDate.of(2026, 10, 23),
            startMinute = 450, endMinute = 570, alarmAtStart = true,
            sound = "content://com.android.providers.media.documents/document/audio%3A42",
            alarmSoundOn = false, soundName = "Focus bell.mp3")
        val data = StudyData(subjects = emptyList(), tasks = listOf(task), completions = emptySet(),
            focusRecords = emptyList(), settings = StudySettings())
        val back = (StudyCodec.decode(StudyCodec.encode(data)) as StudyCodec.DecodeResult.Ok).data
        assertEquals(task, back.tasks.single())
    }

    @Test
    fun schemaFiveFileUsesTheDefaultAlarmSound() {
        val text = """{"schemaVersion":5,"tasks":[{"id":9,"title":"Bath","firstDate":"2026-10-23",""" +
            """"startMinute":310,"endMinute":330,"alarmAtStart":true}]}"""
        val task = (StudyCodec.decode(text) as StudyCodec.DecodeResult.Ok).data.tasks.single()
        assertEquals("default", task.sound)
        assertEquals(true, task.alarmSoundOn)
        assertEquals("", task.soundName)
    }

    @Test
    fun playlistAssociationRoundTripsAndOldTasksHaveNone() {
        val linked = StudyTask(11, "Physics", firstDate = java.time.LocalDate.of(2026, 10, 23),
            startMinute = 450, endMinute = 570, playlistId = "physics", playOnStart = true)
        val data = StudyData(subjects = emptyList(), tasks = listOf(linked), completions = emptySet(),
            focusRecords = emptyList(), settings = StudySettings())
        assertEquals(linked, (StudyCodec.decode(StudyCodec.encode(data)) as StudyCodec.DecodeResult.Ok).data.tasks.single())

        val old = """{"schemaVersion":6,"tasks":[{"id":12,"title":"Old","firstDate":"2026-10-23","startMinute":310,"endMinute":330}]}"""
        val task = (StudyCodec.decode(old) as StudyCodec.DecodeResult.Ok).data.tasks.single()
        assertEquals("", task.playlistId)
        assertEquals(false, task.playOnStart)
    }
}
