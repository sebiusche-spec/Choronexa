// Part of Chronexa, a derivative of reReminder 4.0.1 — GNU GPL v3. See NOTICE.
package com.olaf.rereminder.study.routine

import com.olaf.rereminder.study.StudyData
import com.olaf.rereminder.study.TaskRepeat
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDate

class RoutineTemplateTest {

    private val day = LocalDate.of(2026, 10, 25)

    @Test
    fun theRoutineHasEveryRowFromTheChart() {
        assertEquals(21, CLASS_12_DAILY_ROUTINE.size)
        assertEquals("Wake Up", CLASS_12_DAILY_ROUTINE.first().title)
        assertEquals("Sleep", CLASS_12_DAILY_ROUTINE.last().title)
    }

    @Test
    fun theRoutineHasNoOverlaps() {
        assertNull(findRoutineOverlap(CLASS_12_DAILY_ROUTINE))
    }

    @Test
    fun anOverlapIsFoundWhenRowsShareAMinute() {
        val bad = listOf(
            RoutineItem("A", 300, 400, "x"),
            RoutineItem("B", 390, 450, "x"),
        )
        assertTrue(findRoutineOverlap(bad) != null)
    }

    @Test
    fun theSleepRowRunsOvernight() {
        val sleep = CLASS_12_DAILY_ROUTINE.last()
        assertTrue(sleep.coveredMinutes().contains(0))
        assertTrue(sleep.coveredMinutes().contains(1439))
        assertTrue(!sleep.coveredMinutes().contains(300))
    }

    @Test
    fun addingTheRoutineCreatesDailyActivitiesWithAlarmsOff() {
        val (data, added) = StudyData.initial().withRoutine(day)
        assertEquals(21, added)
        assertTrue(data.tasks.all { it.repeat == TaskRepeat.DAILY && !it.alert && !it.alarmAtStart && it.alarmSlot == 0 })
    }

    @Test
    fun applyingTheRoutineTwiceAddsNothingTheSecondTime() {
        val (once, _) = StudyData.initial().withRoutine(day)
        val (twice, added) = once.withRoutine(day)
        assertEquals(0, added)
        assertEquals(once.tasks.size, twice.tasks.size)
    }

    @Test
    fun theUsersOwnActivitiesAreKeptAndNotDuplicated() {
        val base = StudyData.initial()
        val (withRoutine, _) = base.withRoutine(day)
        val mine = withRoutine.tasks.first().copy(title = "Yoga class")
        val edited = withRoutine.copy(tasks = withRoutine.tasks.map { if (it.id == withRoutine.tasks.first().id) mine else it })
        val (again, added) = edited.withRoutine(day)
        // The row the user renamed no longer matches, so the chart's row comes back once; nothing else is duplicated.
        assertEquals(1, added)
        assertTrue(again.tasks.any { it.title == "Yoga class" })
    }

    @Test
    fun newIdsAreUniqueAndAfterTheExistingOnes() {
        val (data, _) = StudyData.initial().withRoutine(day)
        assertEquals(data.tasks.size, data.tasks.map { it.id }.toSet().size)
    }
}
