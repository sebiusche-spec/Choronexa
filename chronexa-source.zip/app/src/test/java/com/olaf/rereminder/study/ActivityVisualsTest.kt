// Part of Chronexa, a derivative of reReminder 4.0.1 — GNU GPL v3. See NOTICE.
package com.olaf.rereminder.study

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDate

class ActivityVisualsTest {

    private val day = LocalDate.of(2026, 10, 26)

    private fun task(title: String, animation: String = "auto", category: String = "other") = StudyTask(
        id = 1, title = title, firstDate = day, startMinute = 420, endMinute = 450,
        category = category, animation = animation,
    )

    @Test
    fun everyRuleOutputIsAVisualTheAppCanDraw() {
        val names = listOf("Wake up", "Brush teeth", "Bath", "Prayer", "Physics", "Chemistry", "Math", "Coding",
            "Essay", "Gym", "Lunch", "Walk", "Sleep", "Downtime", "Zzz", "Choir", "Chill music")
        for (name in names) {
            val key = chooseAnimation(name, "other", "auto")
            assertTrue("$name -> $key", resolveVisual(key) == key)
            assertTrue(resolveVisual(key) in VISUAL_CHOICES)
        }
    }

    @Test
    fun keywordsPickTheirPicture() {
        assertEquals("wake", visualFor(task("Wake up")))
        assertEquals("brush", visualFor(task("Brush teeth")))
        assertEquals("maths", visualFor(task("Math revision")))
        assertEquals("physics", visualFor(task("Physics")))
        assertEquals("chemistry", visualFor(task("Chemistry")))
        assertEquals("sleep", visualFor(task("Downtime", category = "sleep")))
        assertEquals("meditate", visualFor(task("Prayer / Meditation")))
        assertEquals("music", visualFor(task("Chill / Music / Relax")))
    }

    @Test
    fun aManualChoiceAlwaysWins() {
        assertEquals("maths", chooseAnimation("Wake up", "routine", "maths"))
        assertEquals("none", visualFor(task("Physics", animation = "none")))
    }

    @Test
    fun aManualChoiceIsKeptWhenTheTaskIsRenamed() {
        assertEquals("physics", visualFor(task("Brush teeth", animation = "physics")))
    }

    @Test
    fun anAutomaticTaskFollowsItsNewName() {
        assertEquals("wake", visualFor(task("Wake up")))
        assertEquals("brush", visualFor(task("Brush teeth")))
    }

    @Test
    fun unknownKeysFallBackToCalmNotBlank() {
        assertEquals("calm", resolveVisual("something-old"))
        assertEquals("none", resolveVisual("none"))
    }

    @Test
    fun theChosenPictureSurvivesASaveAndLoad() {
        val data = StudyData.initial().copy(tasks = listOf(task("Essay", animation = "meditate")))
        val back = (StudyCodec.decode(StudyCodec.encode(data)) as StudyCodec.DecodeResult.Ok).data.tasks.single()
        assertEquals("meditate", back.animation)
        assertEquals("meditate", visualFor(back))
    }

    @Test
    fun aTaskSavedBeforeTheChoiceExistedStillLoadsAsAutomatic() {
        val text = """{"schemaVersion":9,"tasks":[{"id":5,"title":"Wake up","firstDate":"2026-10-26","startMinute":300,"endMinute":320}]}"""
        val task = (StudyCodec.decode(text) as StudyCodec.DecodeResult.Ok).data.tasks.single()
        assertEquals("auto", task.animation)
        assertEquals("wake", visualFor(task))
    }
}
