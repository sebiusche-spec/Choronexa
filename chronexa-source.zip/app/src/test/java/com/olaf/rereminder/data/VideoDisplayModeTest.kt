// Part of Chronexa, a derivative of reReminder 4.0.1 — GNU GPL v3. See NOTICE.
package com.olaf.rereminder.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/** Display modes: saved per alarm, read from older saves, and never cropping in FIT or FILL_NO_CROP. */
class VideoDisplayModeTest {

    private val tolerance = 0.01f
    private fun sx(p: Pair<Float, Float>) = p.first
    private fun sy(p: Pair<Float, Float>) = p.second

    // --- Saving and reading the mode ----------------------------------------------------------

    @Test
    fun aNewChoiceDefaultsToFit() {
        assertEquals(VideoDisplayMode.FIT, VideoChoice(uri = "content://media/video/1").effectiveMode())
    }

    @Test
    fun anOlderSaveWithTheFillFlagReadsAsFillCrop() {
        assertEquals(VideoDisplayMode.FILL_CROP, VideoChoice(uri = "content://media/video/1", fill = true).effectiveMode())
    }

    @Test
    fun aChosenModeIsNotOverriddenByAnOldFlag() {
        assertEquals(VideoDisplayMode.FILL_NO_CROP, VideoChoice(uri = "u", displayMode = VideoDisplayMode.FILL_NO_CROP).effectiveMode())
    }

    @Test
    fun choosingAModeKeepsTheOldFlagInStep() {
        val choice = VideoChoice(uri = "u", fill = true)
        assertFalse(choice.withDisplayMode(VideoDisplayMode.FIT).fill)
        assertFalse(choice.withDisplayMode(VideoDisplayMode.FILL_NO_CROP).fill)
        assertTrue(choice.withDisplayMode(VideoDisplayMode.FILL_CROP).fill)
    }

    @Test
    fun theModeIsSavedAndReloadedForEachAlarmSeparately() {
        val first = Reminder(id = 1, name = "Wake").withVideo(VideoChoice(uri = "content://media/video/1").withDisplayMode(VideoDisplayMode.FILL_NO_CROP))
        val second = Reminder(id = 2, name = "Sleep").withVideo(VideoChoice(uri = "content://media/video/2").withDisplayMode(VideoDisplayMode.FILL_CROP))
        val back = ReminderCodec.decode(ReminderCodec.encode(listOf(first, second)), nowMillis = 0L)
        assertEquals(VideoDisplayMode.FILL_NO_CROP, back[0].video!!.effectiveMode())
        assertEquals(VideoDisplayMode.FILL_CROP, back[1].video!!.effectiveMode())
    }

    @Test
    fun thePreviewAndTheAlarmUseTheSameMode() {
        for (mode in VideoDisplayMode.values()) {
            val choice = VideoChoice(uri = "u").withDisplayMode(mode)
            val play = resolveVideoPlayback(choice, canOpen = true) as VideoPlayback.Play
            assertEquals(mode, play.displayMode)
        }
    }

    // --- No cropping in FIT or FILL_NO_CROP ------------------------------------------------------

    @Test
    fun aLandscapeVideoOnAPortraitScreenIsNeverCroppedInEitherNoCropMode() {
        for (mode in listOf(VideoDisplayMode.FIT, VideoDisplayMode.FILL_NO_CROP)) {
            val scale = videoScaleFor(1080, 2400, 1920, 1080, mode)
            assertTrue(sx(scale) <= 1f + tolerance)
            assertTrue(sy(scale) <= 1f + tolerance)
        }
    }

    @Test
    fun aPortraitVideoOnALandscapeScreenIsNeverCroppedInEitherNoCropMode() {
        for (mode in listOf(VideoDisplayMode.FIT, VideoDisplayMode.FILL_NO_CROP)) {
            val scale = videoScaleFor(2400, 1080, 1080, 1920, mode)
            assertTrue(sx(scale) <= 1f + tolerance)
            assertTrue(sy(scale) <= 1f + tolerance)
        }
    }

    @Test
    fun fillNoCropDrawsTheSameSizeAsFit() {
        val fit = videoScaleFor(1080, 2400, 1920, 1080, VideoDisplayMode.FIT)
        val noCrop = videoScaleFor(1080, 2400, 1920, 1080, VideoDisplayMode.FILL_NO_CROP)
        assertEquals(sx(fit), sx(noCrop), tolerance)
        assertEquals(sy(fit), sy(noCrop), tolerance)
    }

    @Test
    fun fillCropDoesCropTheEdges() {
        val crop = videoScaleFor(1080, 2400, 1920, 1080, VideoDisplayMode.FILL_CROP)
        assertTrue(sx(crop) > 1f)
    }

    @Test
    fun aVideoWithTheSameAspectRatioIsDrawnUnchangedInEveryMode() {
        for (mode in VideoDisplayMode.values()) {
            val scale = videoScaleFor(1080, 1920, 1080, 1920, mode)
            assertEquals(1f, sx(scale), tolerance)
            assertEquals(1f, sy(scale), tolerance)
        }
    }
}
