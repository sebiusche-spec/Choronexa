// Part of Chronexa, a derivative of reReminder 4.0.1 — GNU GPL v3. See NOTICE.
package com.olaf.rereminder.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.IBinder
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.olaf.rereminder.R
import com.olaf.rereminder.study.taskAudioEndCodeFor

/**
 * Plays one task's audio from its start to its end. It loops the file for the whole window and releases the
 * player when stopped.
 *
 * One task audio plays at a time: if a new window starts while another is playing, the new one replaces it.
 * Audio focus is requested as transient-with-ducking, so unrelated music is lowered, not stopped. The Music
 * Studio player is a separate service and is never stopped from here.
 */
class TaskAudioService : Service(), AudioManager.OnAudioFocusChangeListener {

    private var player: MediaPlayer? = null
    private var activeSlot = 0
    private var focusRequest: AudioFocusRequest? = null
    private var resumeAfterTransient = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        getSystemService(NotificationManager::class.java)?.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, getString(R.string.task_audio_channel), NotificationManager.IMPORTANCE_LOW),
        )
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val slot = intent?.getIntExtra(EXTRA_SLOT, 0) ?: 0
        when (intent?.action) {
            ACTION_PLAY -> {
                // Promote first: the system requires a foreground service to say so promptly.
                promote(slot, intent.getStringExtra(EXTRA_TITLE).orEmpty())
                start(slot, intent.getStringExtra(EXTRA_URI).orEmpty())
            }
            ACTION_STOP -> if (slot == activeSlot) stopAll() else if (player == null) stopSelf()
            else -> if (player == null) stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun start(slot: Int, uriString: String) {
        // Same window started again: it is already playing, so do not start a second copy.
        if (player != null && activeSlot == slot) return
        releasePlayer()
        activeSlot = slot
        val uri = Uri.parse(uriString)
        if (uriString.isBlank() || !canRead(uri)) {
            // A missing or unreadable file must not play anything; the window simply ends silently.
            Log.w(TAG, "The task audio file cannot be opened; nothing plays for this window")
            stopAll()
            return
        }
        requestFocus()
        val media = MediaPlayer()
        player = media
        try {
            media.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build(),
            )
            media.setDataSource(this, uri)
            media.isLooping = true
            // The player can be released between prepare and start (a stop or a newer window); start only the current one.
            media.setOnPreparedListener { if (player === it) runCatching { it.start() } }
            media.setOnErrorListener { _, _, _ ->
                Log.w(TAG, "Task audio playback error")
                stopAll()
                true
            }
            media.prepareAsync()
        } catch (e: Exception) {
            Log.w(TAG, "Could not play task audio", e)
            stopAll()
        }
    }

    private fun canRead(uri: Uri): Boolean = runCatching {
        contentResolver.openInputStream(uri)?.use { it.read() >= -1 } ?: false
    }.getOrDefault(false)

    private fun requestFocus() {
        val manager = getSystemService(AudioManager::class.java) ?: return
        val request = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build(),
            )
            .setOnAudioFocusChangeListener(this)
            .build()
        focusRequest = request
        manager.requestAudioFocus(request)
    }

    private fun abandonFocus() {
        val manager = getSystemService(AudioManager::class.java)
        focusRequest?.let { manager?.abandonAudioFocusRequest(it) }
        focusRequest = null
    }

    override fun onAudioFocusChange(focusChange: Int) {
        when (focusChange) {
            AudioManager.AUDIOFOCUS_LOSS -> stopAll()
            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT -> {
                resumeAfterTransient = player?.isPlaying == true
                runCatching { player?.pause() }
            }
            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK -> player?.setVolume(DUCK_VOLUME, DUCK_VOLUME)
            AudioManager.AUDIOFOCUS_GAIN -> {
                player?.setVolume(1f, 1f)
                if (resumeAfterTransient) {
                    resumeAfterTransient = false
                    runCatching { player?.start() }
                }
            }
        }
    }

    private fun stopAll() {
        releasePlayer()
        abandonFocus()
        activeSlot = 0
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun releasePlayer() {
        player?.let {
            runCatching { it.stop() }
            runCatching { it.release() }
        }
        player = null
    }

    private fun promote(slot: Int, title: String) {
        val stop = PendingIntent.getService(
            this,
            taskAudioEndCodeFor(slot),
            Intent(this, TaskAudioService::class.java).setAction(ACTION_STOP).putExtra(EXTRA_SLOT, slot),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
        val notification: Notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(getString(R.string.task_audio_running, title.ifEmpty { getString(R.string.app_name) }))
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .addAction(0, getString(R.string.alarm_stop), stop)
            .build()
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
            } else {
                startForeground(NOTIFICATION_ID, notification)
            }
        } catch (e: RuntimeException) {
            // Android refused foreground status. Playback may then be stopped by the system; it is not guaranteed.
            Log.w(TAG, "Could not start task audio in the foreground", e)
        }
    }

    override fun onDestroy() {
        releasePlayer()
        abandonFocus()
        super.onDestroy()
    }

    companion object {
        private const val TAG = "TaskAudioService"
        const val ACTION_PLAY = "com.olaf.rereminder.action.TASK_AUDIO_PLAY"
        const val ACTION_STOP = "com.olaf.rereminder.action.TASK_AUDIO_STOP"
        const val EXTRA_SLOT = "slot"
        const val EXTRA_URI = "uri"
        const val EXTRA_TITLE = "title"
        const val CHANNEL_ID = "task_audio"
        /** Kept clear of the alarm, reminder, snooze and music notification ids. */
        const val NOTIFICATION_ID = 3_600_001
        private const val DUCK_VOLUME = 0.3f

        /** Starts playback of a task's audio. Android may refuse the start; then nothing plays, and that is logged. */
        fun play(context: Context, slot: Int, uri: String, title: String) {
            val intent = Intent(context, TaskAudioService::class.java)
                .setAction(ACTION_PLAY)
                .putExtra(EXTRA_SLOT, slot)
                .putExtra(EXTRA_URI, uri)
                .putExtra(EXTRA_TITLE, title)
            runCatching { ContextCompat.startForegroundService(context, intent) }
                .onFailure { Log.w(TAG, "Task audio could not be started", it) }
        }

        /** Stops a slot's audio if it is the one playing. Harmless when nothing is playing. */
        fun stop(context: Context, slot: Int) {
            val intent = Intent(context, TaskAudioService::class.java)
                .setAction(ACTION_STOP)
                .putExtra(EXTRA_SLOT, slot)
            runCatching { context.startService(intent) }
        }
    }
}
