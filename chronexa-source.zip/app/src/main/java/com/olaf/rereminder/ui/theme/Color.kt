// Modified for Chronexa (Stage A) from reReminder 4.0.1 — GNU GPL v3. See NOTICE.
package com.olaf.rereminder.ui.theme

import androidx.compose.ui.graphics.Color

/**
 * Chronexa palette: deep navy-black surfaces with cyan and violet accents.
 *
 * Dark is the signature look. Light is a clean counterpart that keeps the same accents, so the
 * brand reads the same whichever theme the phone is using.
 */

/** Brand accents, used for glows and gradients rather than for body text. */
val ChronexaCyan = Color(0xFF00E5FF)
val ChronexaViolet = Color(0xFF8B5CF6)
val ChronexaNavy = Color(0xFF050508)

// --- Light ---------------------------------------------------------------
val LightPrimary = Color(0xFF0E7490)
val LightOnPrimary = Color(0xFFFFFFFF)
val LightPrimaryContainer = Color(0xFFCCF3FB)
val LightOnPrimaryContainer = Color(0xFF001F28)

val LightSecondary = Color(0xFF6D4AC9)
val LightOnSecondary = Color(0xFFFFFFFF)
val LightSecondaryContainer = Color(0xFFE6DCFF)
val LightOnSecondaryContainer = Color(0xFF240055)

val LightTertiary = Color(0xFF3B6FB6)
val LightOnTertiary = Color(0xFFFFFFFF)
val LightTertiaryContainer = Color(0xFFD6E4FF)
val LightOnTertiaryContainer = Color(0xFF001B3D)

val LightError = Color(0xFFBA1A1A)
val LightOnError = Color(0xFFFFFFFF)
val LightErrorContainer = Color(0xFFFFDAD6)
val LightOnErrorContainer = Color(0xFF410002)

val LightBackground = Color(0xFFF6F8FD)
val LightOnBackground = Color(0xFF121A2B)
val LightSurface = Color(0xFFF6F8FD)
val LightOnSurface = Color(0xFF121A2B)
val LightSurfaceVariant = Color(0xFFDDE3F1)
val LightOnSurfaceVariant = Color(0xFF434B5E)

val LightSurfaceContainerLowest = Color(0xFFFFFFFF)
val LightSurfaceContainerLow = Color(0xFFF0F4FD)
val LightSurfaceContainer = Color(0xFFEAF0FB)
val LightSurfaceContainerHigh = Color(0xFFE2E9F7)
val LightSurfaceContainerHighest = Color(0xFFDAE2F2)

val LightOutline = Color(0xFF737B90)
val LightOutlineVariant = Color(0xFFC3CADB)
val LightInverseSurface = Color(0xFF2B3347)
val LightInverseOnSurface = Color(0xFFEEF2FB)
val LightInversePrimary = Color(0xFF7FE5FF)
val LightScrim = Color(0xFF000000)

// --- Dark (Chronexa Night) -----------------------------------------------
val DarkPrimary = Color(0xFF00E5FF)
val DarkOnPrimary = Color(0xFF001F26)
val DarkPrimaryContainer = Color(0xFF00343D)
val DarkOnPrimaryContainer = Color(0xFFB8F5FF)

val DarkSecondary = Color(0xFFB9A2FF)
val DarkOnSecondary = Color(0xFF2A1861)
val DarkSecondaryContainer = Color(0xFF3B2A7A)
val DarkOnSecondaryContainer = Color(0xFFEDE5FF)

val DarkTertiary = Color(0xFF8AB4FF)
val DarkOnTertiary = Color(0xFF0B2B5C)
val DarkTertiaryContainer = Color(0xFF1F3F7A)
val DarkOnTertiaryContainer = Color(0xFFD8E2FF)

val DarkError = Color(0xFFFFB4AB)
val DarkOnError = Color(0xFF690005)
val DarkErrorContainer = Color(0xFF93000A)
val DarkOnErrorContainer = Color(0xFFFFDAD6)

val DarkBackground = Color(0xFF050508)
val DarkOnBackground = Color(0xFFF5F5FF)
val DarkSurface = Color(0xFF08080F)
val DarkOnSurface = Color(0xFFF5F5FF)
val DarkSurfaceVariant = Color(0xFF1A1A2A)
val DarkOnSurfaceVariant = Color(0xFF9292A8)

val DarkSurfaceContainerLowest = Color(0xFF020204)
val DarkSurfaceContainerLow = Color(0xFF08080F)
val DarkSurfaceContainer = Color(0xFF0B0B13)
val DarkSurfaceContainerHigh = Color(0xFF10101B)
val DarkSurfaceContainerHighest = Color(0xFF171726)

val DarkOutline = Color(0xFF5F6073)
val DarkOutlineVariant = Color(0xFF24243A)
val DarkInverseSurface = Color(0xFFE6EAF5)
val DarkInverseOnSurface = Color(0xFF1B2132)
val DarkInversePrimary = Color(0xFF006878)
val DarkScrim = Color(0xFF000000)
