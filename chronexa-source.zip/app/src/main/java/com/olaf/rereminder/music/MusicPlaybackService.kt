// Part of Chronexa, a derivative of reReminder 4.0.1 — GNU GPL v3. See NOTICE.
package com.olaf.rereminder.music

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.media.MediaMetadata
import android.media.MediaPlayer
import android.media.session.MediaSession
import android.media.session.PlaybackState
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.Log
import androidx.core.content.ContextCompat
import com.olaf.rereminder.R

/**
 * Plays the music library as a foreground media service, so playback can continue when the user moves
 * between screens or locks the phone, within Android's own limits.
 *
 * Audio focus: a call or another app taking audio pauses playback; a brief interruption pauses and then
 * resumes it; a short notification sound only lowers the volume. Unplugging headphones pauses at once.
 * There is one MediaPlayer, released when playback stops or the service ends.
 *
 * Alarm audio is separate: ActivityAlarmService never shares this player, so neither can stop the other.
 */
class MusicPlaybackService : Service(), AudioManager.OnAudioFocusChangeListener {

    private var player: MediaPlayer? = null
    private var queue = PlaybackQueue()
    private var session: MediaSession? = null
    private var focusRequest: AudioFocusRequest? = null
    private var resumeAfterTransient = false
    private val handler = Handler(Looper.getMainLooper())

    private val progress = object : Runnable {
        override fun run() {
            publish(notify = false)
            if (MusicPlayback.state.value.playing) handler.postDelayed(this, PROGRESS_MILLIS)
        }
    }

    private val noisy = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            if (intent.action == AudioManager.ACTION_AUDIO_BECOMING_NOISY) pause()
        }
    }

    override fun onCreate() {
        super.onCreate()
        createChannel()
        session = MediaSession(this, "ChronexaMusic").also { s ->
            s.setCallback(object : MediaSession.Callback() {
                override fun onPlay() = play()
                override fun onPause() = pause()
                override fun onSkipToNext() = next()
                override fun onSkipToPrevious() = previous()
                override fun onStop() = stopAll()
                override fun onSeekTo(pos: Long) = seek(pos)
            })
            s.isActive = true
        }
        ContextCompat.registerReceiver(
            this,
            noisy,
            IntentFilter(AudioManager.ACTION_AUDIO_BECOMING_NOISY),
            ContextCompat.RECEIVER_NOT_EXPORTED,
        )
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // Promote first: Android requires a foreground service to be promoted promptly.
        promote()
        when (intent?.action) {
            ACTION_PLAY_QUEUE -> {
                val uris = intent.getStringArrayListExtra(EXTRA_URIS).orEmpty()
                val start = intent.getStringExtra(EXTRA_START_URI)
                val shuffle = intent.getBooleanExtra(EXTRA_SHUFFLE, false)
                queue = PlaybackQueue.buildQueue(uris, start, shuffle, repeat = queue.repeat)
                loadCurrent(autoStart = true)
            }
            ACTION_PLAY_PLAYLIST -> {
                val id = intent.getStringExtra(EXTRA_PLAYLIST_ID).orEmpty()
                val uris = MusicRepository.get(this).library.value.contentsOf(id).tracks.map { it.uri }
                if (uris.isEmpty()) {
                    MusicPlayback.publish(PlaybackUi(problem = getString(R.string.music_playlist_empty)))
                    stopForeground(STOP_FOREGROUND_REMOVE)
                    stopSelf()
                } else {
                    queue = PlaybackQueue.buildQueue(uris, null, shuffle = false, repeat = queue.repeat)
                    loadCurrent(autoStart = true)
                }
            }
            ACTION_TOGGLE -> if (MusicPlayback.state.value.playing) pause() else play()
            ACTION_NEXT -> next()
            ACTION_PREVIOUS -> previous()
            ACTION_STOP -> stopAll()
            ACTION_SHUFFLE -> {
                queue = queue.withShuffle(!queue.shuffle)
                publish()
            }
            ACTION_REPEAT -> {
                queue = queue.cycleRepeat()
                publish()
            }
            ACTION_SEEK -> seek(intent.getLongExtra(EXTRA_POSITION, 0L))
            else -> if (queue.current == null) stopAll()
        }
        return START_NOT_STICKY
    }

    private fun loadCurrent(autoStart: Boolean) {
        val uri = queue.current
        releasePlayer()
        if (uri == null) {
            stopAll()
            return
        }
        val media = MediaPlayer()
        player = media
        try {
            media.setAudioAttributes(musicAttributes())
            media.setDataSource(this, Uri.parse(uri))
            media.setOnPreparedListener { if (autoStart) play() else publish() }
            media.setOnCompletionListener { onTrackEnded() }
            media.setOnErrorListener { _, _, _ ->
                skipUnplayable()
                true
            }
            media.prepareAsync()
        } catch (e: Exception) {
            // Moved, deleted, or its permission has lapsed: skip it and say so, rather than crash.
            Log.w(TAG, "Could not open a track", e)
            skipUnplayable()
        }
    }

    /** Moves past a file that cannot be played. Stops when there is nothing after it. */
    private fun skipUnplayable() {
        releasePlayer()
        val after = queue.next()
        if (after == null) {
            MusicPlayback.publish(PlaybackUi(problem = getString(R.string.music_track_unavailable)))
            stopAll(keepProblem = true)
        } else {
            queue = after
            publish(problem = getString(R.string.music_track_unavailable))
            loadCurrent(autoStart = true)
        }
    }

    private fun play() {
        val media = player ?: return
        if (!requestFocus()) {
            publish(problem = getString(R.string.music_focus_denied))
            return
        }
        runCatching { media.start() }
        publish()
        handler.removeCallbacks(progress)
        handler.post(progress)
    }

    private fun pause() {
        resumeAfterTransient = false
        runCatching { player?.pause() }
        handler.removeCallbacks(progress)
        publish()
    }

    private fun next() {
        val moved = queue.next()
        if (moved == null) {
            stopAll()
        } else {
            queue = moved
            loadCurrent(autoStart = true)
        }
    }

    private fun previous() {
        // Within the first few seconds, "previous" restarts the track, as music apps do.
        if ((player?.currentPosition ?: 0) > RESTART_THRESHOLD_MS) {
            seek(0L)
            return
        }
        val moved = queue.previous()
        if (moved == null) {
            seek(0L)
        } else {
            queue = moved
            loadCurrent(autoStart = true)
        }
    }

    private fun seek(positionMs: Long) {
        runCatching { player?.seekTo(positionMs.coerceAtLeast(0L).toInt()) }
        publish()
    }

    private fun onTrackEnded() {
        val repeatOne = queue.repeat == RepeatMode.ONE
        val moved = queue.afterTrackEnded()
        when {
            moved == null -> stopAll()
            repeatOne -> {
                runCatching { player?.seekTo(0) }
                play()
            }
            else -> {
                queue = moved
                loadCurrent(autoStart = true)
            }
        }
    }

    private fun musicAttributes(): AudioAttributes = AudioAttributes.Builder()
        .setUsage(AudioAttributes.USAGE_MEDIA)
        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
        .build()

    private fun requestFocus(): Boolean {
        val manager = getSystemService(AudioManager::class.java) ?: return false
        val request = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
            .setAudioAttributes(musicAttributes())
            .setOnAudioFocusChangeListener(this)
            .build()
        focusRequest = request
        return manager.requestAudioFocus(request) == AudioManager.AUDIOFOCUS_REQUEST_GRANTED
    }

    private fun abandonFocus() {
        val manager = getSystemService(AudioManager::class.java)
        focusRequest?.let { manager?.abandonAudioFocusRequest(it) }
        focusRequest = null
    }

    override fun onAudioFocusChange(focusChange: Int) {
        when (focusChange) {
            AudioManager.AUDIOFOCUS_LOSS -> {
                pause()
                abandonFocus()
            }
            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT -> {
                resumeAfterTransient = MusicPlayback.state.value.playing
                pause()
            }
            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK -> player?.setVolume(DUCK_VOLUME, DUCK_VOLUME)
            AudioManager.AUDIOFOCUS_GAIN -> {
                player?.setVolume(1f, 1f)
                if (resumeAfterTransient) {
                    resumeAfterTransient = false
                    play()
                }
            }
        }
    }

    /** Stops playback and the service. The queue's settings (repeat, shuffle) are kept for next time. */
    private fun stopAll(keepProblem: Boolean = false) {
        releasePlayer()
        queue = PlaybackQueue(source = queue.source, repeat = queue.repeat, shuffle = queue.shuffle)
        abandonFocus()
        if (keepProblem) {
            MusicPlayback.publish(MusicPlayback.state.value.copy(queue = queue, playing = false))
        } else {
            publish()
        }
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun releasePlayer() {
        handler.removeCallbacks(progress)
        player?.let {
            runCatching { it.stop() }
            runCatching { it.release() }
        }
        player = null
    }

    /**
     * Publishes the state to the Music Studio and the lock-screen session. The notification is rebuilt only
     * when [notify] is set, so the twice-a-second progress tick does not rebuild it.
     */
    private fun publish(problem: String? = null, notify: Boolean = true) {
        val media = player
        val track = queue.current?.let { uri ->
            MusicRepository.get(this).library.value.tracks.firstOrNull { it.uri == uri }
        }
        val state = PlaybackUi(
            queue = queue,
            playing = media?.let { runCatching { it.isPlaying }.getOrDefault(false) } ?: false,
            positionMs = media?.let { runCatching { it.currentPosition.toLong() }.getOrDefault(0L) } ?: 0L,
            durationMs = media?.let { runCatching { it.duration.toLong().coerceAtLeast(0L) }.getOrDefault(0L) } ?: 0L,
            title = track?.title.orEmpty(),
            artist = track?.artist.orEmpty(),
            problem = problem ?: MusicPlayback.state.value.problem.takeIf { queue.current != null },
        )
        MusicPlayback.publish(state)
        session?.let { s ->
            s.setPlaybackState(
                PlaybackState.Builder()
                    .setActions(
                        PlaybackState.ACTION_PLAY or PlaybackState.ACTION_PAUSE or PlaybackState.ACTION_PLAY_PAUSE or
                            PlaybackState.ACTION_SKIP_TO_NEXT or PlaybackState.ACTION_SKIP_TO_PREVIOUS or
                            PlaybackState.ACTION_STOP or PlaybackState.ACTION_SEEK_TO,
                    )
                    .setState(
                        if (state.playing) PlaybackState.STATE_PLAYING else PlaybackState.STATE_PAUSED,
                        state.positionMs,
                        1f,
                    )
                    .build(),
            )
            s.setMetadata(
                MediaMetadata.Builder()
                    .putString(MediaMetadata.METADATA_KEY_TITLE, state.title)
                    .putString(MediaMetadata.METADATA_KEY_ARTIST, state.artist)
                    .putLong(MediaMetadata.METADATA_KEY_DURATION, state.durationMs)
                    .build(),
            )
        }
        if (notify && queue.current != null) {
            getSystemService(NotificationManager::class.java)?.notify(NOTIFICATION_ID, buildNotification(state))
        }
    }

    private fun promote() {
        val notification = buildNotification(MusicPlayback.state.value)
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
            } else {
                startForeground(NOTIFICATION_ID, notification)
            }
        } catch (e: RuntimeException) {
            Log.w(TAG, "Could not start in the foreground", e)
        }
    }

    private fun buildNotification(state: PlaybackUi): Notification {
        val title = state.title.ifEmpty { getString(R.string.music_now_playing) }
        val builder = Notification.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(title)
            .setContentText(state.artist)
            .setVisibility(Notification.VISIBILITY_PUBLIC)
            .setOngoing(state.playing)
            .setOnlyAlertOnce(true)
        builder.addAction(action(android.R.drawable.ic_media_previous, R.string.music_previous, ACTION_PREVIOUS, 1))
        if (state.playing) {
            builder.addAction(action(android.R.drawable.ic_media_pause, R.string.music_pause, ACTION_TOGGLE, 2))
        } else {
            builder.addAction(action(android.R.drawable.ic_media_play, R.string.music_play, ACTION_TOGGLE, 2))
        }
        builder.addAction(action(android.R.drawable.ic_media_next, R.string.music_next, ACTION_NEXT, 3))
        builder.addAction(action(android.R.drawable.ic_menu_close_clear_cancel, R.string.music_stop, ACTION_STOP, 4))
        val style = Notification.MediaStyle().setShowActionsInCompactView(0, 1, 2)
        session?.sessionToken?.let { style.setMediaSession(it) }
        builder.setStyle(style)
        return builder.build()
    }

    private fun action(icon: Int, label: Int, command: String, requestCode: Int): Notification.Action {
        val pending = PendingIntent.getService(
            this,
            requestCode + ACTION_REQUEST_BASE,
            Intent(this, MusicPlaybackService::class.java).setAction(command),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
        return Notification.Action.Builder(Icon.createWithResource(this, icon), getString(label), pending).build()
    }

    private fun createChannel() {
        getSystemService(NotificationManager::class.java)?.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, getString(R.string.music_channel_name), NotificationManager.IMPORTANCE_LOW),
        )
    }

    override fun onDestroy() {
        runCatching { unregisterReceiver(noisy) }
        releasePlayer()
        abandonFocus()
        session?.isActive = false
        session?.release()
        session = null
        MusicPlayback.publish(PlaybackUi())
        super.onDestroy()
    }

    companion object {
        private const val TAG = "MusicPlaybackService"
        const val CHANNEL_ID = "music_playback"
        /** Kept clear of the reminder (small ids), snooze and activity-alarm ranges. */
        const val NOTIFICATION_ID = 3_500_000
        private const val ACTION_REQUEST_BASE = 3_500_100
        const val ACTION_PLAY_QUEUE = "com.olaf.rereminder.music.PLAY_QUEUE"
        const val ACTION_PLAY_PLAYLIST = "com.olaf.rereminder.music.PLAY_PLAYLIST"
        const val ACTION_TOGGLE = "com.olaf.rereminder.music.TOGGLE"
        const val ACTION_NEXT = "com.olaf.rereminder.music.NEXT"
        const val ACTION_PREVIOUS = "com.olaf.rereminder.music.PREVIOUS"
        const val ACTION_STOP = "com.olaf.rereminder.music.STOP"
        const val ACTION_SHUFFLE = "com.olaf.rereminder.music.SHUFFLE"
        const val ACTION_REPEAT = "com.olaf.rereminder.music.REPEAT"
        const val ACTION_SEEK = "com.olaf.rereminder.music.SEEK"
        const val EXTRA_URIS = "uris"
        const val EXTRA_START_URI = "startUri"
        const val EXTRA_SHUFFLE = "shuffle"
        const val EXTRA_PLAYLIST_ID = "playlistId"
        const val EXTRA_POSITION = "position"
        private const val PROGRESS_MILLIS = 500L
        private const val RESTART_THRESHOLD_MS = 3_000
        private const val DUCK_VOLUME = 0.2f

        /** Sends a command to the service. Returns false if Android refuses to start it. */
        fun send(context: Context, intent: Intent): Boolean =
            runCatching { ContextCompat.startForegroundService(context, intent) }.isSuccess
    }
}
