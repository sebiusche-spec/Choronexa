// Part of Chronexa, a derivative of reReminder 4.0.1 — GNU GPL v3. See NOTICE.
package com.olaf.rereminder.study

import java.time.DayOfWeek
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.temporal.TemporalAdjusters

/** One task on one date, with its real start and end as local wall-clock times. */
data class Occurrence(
    val task: StudyTask,
    val date: LocalDate,
    val startAt: LocalDateTime,
    val endAt: LocalDateTime,
)

private val WEEKDAYS = setOf(
    DayOfWeek.MONDAY, DayOfWeek.TUESDAY, DayOfWeek.WEDNESDAY, DayOfWeek.THURSDAY, DayOfWeek.FRIDAY,
)

/** Whether this task has an occurrence that starts on [date]. */
fun StudyTask.occursOn(date: LocalDate): Boolean {
    if (date.isBefore(firstDate)) return false
    if (lastDate != null && date.isAfter(lastDate)) return false
    return when (repeat) {
        TaskRepeat.NONE -> date == firstDate
        TaskRepeat.DAILY -> true
        TaskRepeat.WEEKDAYS -> date.dayOfWeek in WEEKDAYS
        TaskRepeat.WEEKLY -> {
            val days = if (weekdays.isEmpty()) setOf(firstDate.dayOfWeek) else weekdays
            date.dayOfWeek in days
        }
        // Every N days from the first day. The count is kept at least 2; every day is the Daily choice.
        TaskRepeat.EVERY_N_DAYS -> !date.isBefore(firstDate) &&
            (date.toEpochDay() - firstDate.toEpochDay()) % repeatEvery.coerceAtLeast(2) == 0L
    }
}

/** The occurrence that starts on [date]. Uses wall-clock arithmetic, so daylight-saving changes do not shift it. */
fun StudyTask.occurrenceOn(date: LocalDate): Occurrence {
    val midnight = date.atStartOfDay()
    val start = midnight.plusMinutes(startMinute.toLong())
    val end = midnight.plusMinutes(endMinute.toLong()).let { if (crossesMidnight) it.plusDays(1) else it }
    return Occurrence(this, date, start, end)
}

/** Occurrences that start on [date], in time order. */
fun occurrencesStartingOn(tasks: List<StudyTask>, date: LocalDate): List<Occurrence> =
    tasks.filter { it.occursOn(date) }
        .map { it.occurrenceOn(date) }
        .sortedWith(compareBy<Occurrence> { it.startAt }.thenBy { it.task.id })

/**
 * Everything that is active on [date]: tasks starting that day, plus overnight tasks that started
 * the day before and are still running at the start of [date]. Overlap checks need both, or a
 * 23:00–07:00 task would look free at 06:30.
 */
fun occurrencesTouching(tasks: List<StudyTask>, date: LocalDate): List<Occurrence> {
    val dayStart = date.atStartOfDay()
    val fromYesterday = occurrencesStartingOn(tasks, date.minusDays(1))
        .filter { it.endAt.isAfter(dayStart) }
    return (fromYesterday + occurrencesStartingOn(tasks, date))
        .sortedWith(compareBy<Occurrence> { it.startAt }.thenBy { it.task.id })
}

/** True when two occurrences share any time. Tasks that merely touch (09:00–10:00 then 10:00–11:00) do not overlap. */
fun Occurrence.overlaps(other: Occurrence): Boolean =
    startAt.isBefore(other.endAt) && other.startAt.isBefore(endAt)

/** Every overlapping pair in [occurrences]. Reports only; it never changes any schedule. */
fun findOverlaps(occurrences: List<Occurrence>): List<Pair<Occurrence, Occurrence>> {
    val sorted = occurrences.sortedBy { it.startAt }
    val pairs = mutableListOf<Pair<Occurrence, Occurrence>>()
    for (i in sorted.indices) {
        for (j in i + 1 until sorted.size) {
            // Sorted by start: once a later task starts at or after this one ends, none after it can overlap.
            if (!sorted[j].startAt.isBefore(sorted[i].endAt)) break
            pairs += sorted[i] to sorted[j]
        }
    }
    return pairs
}

/**
 * Occurrences on [date] that would overlap a candidate task being saved. [candidate] is excluded
 * from [existing] by id, so editing a task does not conflict with its own previous version.
 */
fun conflictsFor(candidate: StudyTask, date: LocalDate, existing: List<StudyTask>): List<Occurrence> {
    val others = existing.filter { it.id != candidate.id }
    val mine = candidate.occurrenceOn(date)
    return occurrencesTouching(others, date).filter { it.overlaps(mine) }
}

/** A task is overdue when it is not done and its end has passed. */
fun isOverdue(occurrence: Occurrence, completed: Boolean, now: LocalDateTime): Boolean =
    !completed && occurrence.endAt.isBefore(now)

/** Completion for one day. Percent rounds down, so 2 of 3 is 66, never 67. */
data class DaySummary(val date: LocalDate, val total: Int, val completed: Int) {
    val percent: Int get() = if (total == 0) 0 else completed * 100 / total
    val allDone: Boolean get() = total > 0 && completed == total
}

fun summarizeDay(tasks: List<StudyTask>, completions: Set<Completion>, date: LocalDate): DaySummary {
    val occurrences = occurrencesStartingOn(tasks, date)
    val done = occurrences.count { Completion(it.task.id, date) in completions }
    return DaySummary(date, occurrences.size, done)
}

/** The first day of the week that contains [date], for the user's chosen first day. */
fun weekStart(date: LocalDate, firstDay: DayOfWeek): LocalDate =
    date.with(TemporalAdjusters.previousOrSame(firstDay))

/** Seven day summaries starting at [weekStart]. */
fun weekSummaries(
    tasks: List<StudyTask>,
    completions: Set<Completion>,
    weekStart: LocalDate,
): List<DaySummary> = (0L..6L).map { summarizeDay(tasks, completions, weekStart.plusDays(it)) }
