// Part of Chronexa, a derivative of reReminder 4.0.1 — GNU GPL v3. See NOTICE.
package com.olaf.rereminder.music

import kotlin.random.Random

enum class RepeatMode { OFF, ALL, ONE }

/**
 * The order tracks will play in, and where playback is in it. [source] is the list as the user chose
 * it, so turning shuffle on or off can rebuild the order without losing the original.
 *
 * Track identities are URIs. An empty queue has no current track.
 */
data class PlaybackQueue(
    val source: List<String> = emptyList(),
    val order: List<String> = emptyList(),
    val index: Int = -1,
    val repeat: RepeatMode = RepeatMode.OFF,
    val shuffle: Boolean = false,
) {
    val current: String? get() = order.getOrNull(index)

    /** The track after this one, or null when playback should stop. */
    fun next(): PlaybackQueue? = when {
        order.isEmpty() -> null
        index + 1 < order.size -> copy(index = index + 1)
        repeat == RepeatMode.ALL -> copy(index = 0)
        else -> null
    }

    /** The track before this one, or null when there is none to go back to. */
    fun previous(): PlaybackQueue? = when {
        order.isEmpty() -> null
        index > 0 -> copy(index = index - 1)
        repeat == RepeatMode.ALL -> copy(index = order.size - 1)
        else -> null
    }

    /** What happens when a track finishes on its own: repeat one stays put, otherwise move on. */
    fun afterTrackEnded(): PlaybackQueue? = if (repeat == RepeatMode.ONE) this else next()

    /** Off, then all, then one, then off again. */
    fun cycleRepeat(): PlaybackQueue = copy(
        repeat = when (repeat) {
            RepeatMode.OFF -> RepeatMode.ALL
            RepeatMode.ALL -> RepeatMode.ONE
            RepeatMode.ONE -> RepeatMode.OFF
        },
    )

    /** Turns shuffle on or off. The current track keeps playing and stays current. */
    fun withShuffle(on: Boolean, random: Random = Random.Default): PlaybackQueue {
        val now = current
        return buildQueue(source, startUri = now, shuffle = on, repeat = repeat, random = random)
    }

    companion object {
        /**
         * Builds a queue from the chosen list. With shuffle, the chosen track (if any) plays first and the rest
         * follow in a random order. Every track appears exactly once.
         */
        fun buildQueue(
            source: List<String>,
            startUri: String?,
            shuffle: Boolean,
            repeat: RepeatMode = RepeatMode.OFF,
            random: Random = Random.Default,
        ): PlaybackQueue {
            if (source.isEmpty()) return PlaybackQueue(repeat = repeat, shuffle = shuffle)
            val startAt = startUri?.let { source.indexOf(it) }?.takeIf { it >= 0 } ?: 0
            return if (shuffle) {
                val first = source[startAt]
                val rest = source.filterIndexed { i, _ -> i != startAt }.shuffled(random)
                PlaybackQueue(source, listOf(first) + rest, 0, repeat, shuffle = true)
            } else {
                PlaybackQueue(source, source, startAt, repeat, shuffle = false)
            }
        }
    }
}
