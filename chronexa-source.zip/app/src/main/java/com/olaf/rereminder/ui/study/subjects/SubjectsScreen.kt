// Part of Chronexa, a derivative of reReminder 4.0.1 — GNU GPL v3. See NOTICE.
package com.olaf.rereminder.ui.study.subjects

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.olaf.rereminder.R
import com.olaf.rereminder.study.StudyData
import com.olaf.rereminder.study.Subject
import com.olaf.rereminder.study.SubjectStat
import com.olaf.rereminder.study.subjectStats
import com.olaf.rereminder.ui.components.GlowCard
import com.olaf.rereminder.ui.components.revealOnEnter
import com.olaf.rereminder.ui.study.EmptyState
import com.olaf.rereminder.ui.study.StudyStatusBanner
import com.olaf.rereminder.ui.study.StudyViewModel
import com.olaf.rereminder.ui.study.accentFor
import com.olaf.rereminder.ui.study.minutesLabel
import com.olaf.rereminder.ui.theme.ReminderAccents
import java.time.LocalDate
import java.time.ZoneId

@Composable
fun SubjectsRoute(viewModel: StudyViewModel = viewModel()) {
    val data by viewModel.data.collectAsStateWithLifecycle()
    val status by viewModel.status.collectAsStateWithLifecycle()
    var addOpen by remember { mutableStateOf(false) }
    var renaming by remember { mutableStateOf<Subject?>(null) }
    var deleting by remember { mutableStateOf<Subject?>(null) }

    val today = LocalDate.now()
    val zone = ZoneId.systemDefault()
    val stats = subjectStats(data, LocalDate.of(1970, 1, 1), today, zone)
    val maxCompleted = (stats.maxOfOrNull { it.completedTasks } ?: 0).coerceAtLeast(1)

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item(key = "header") {
            Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = stringResource(R.string.subjects_title),
                    style = MaterialTheme.typography.headlineMedium,
                    color = MaterialTheme.colorScheme.onBackground,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.weight(1f),
                )
                IconButton(onClick = { addOpen = true }) {
                    Icon(Icons.Rounded.Add, contentDescription = stringResource(R.string.subjects_add))
                }
            }
        }

        if (status !is com.olaf.rereminder.study.StudyStatus.Ready) {
            item(key = "status") { StudyStatusBanner(status) }
        }

        val realSubjects = stats.filter { it.subjectId != null }
        if (realSubjects.isEmpty()) {
            item(key = "empty") {
                EmptyState(
                    title = stringResource(R.string.subjects_empty_title),
                    body = stringResource(R.string.subjects_empty_body),
                )
            }
        }

        items(realSubjects, key = { it.subjectId ?: -1L }) { stat ->
            val subject = data.subjects.first { it.id == stat.subjectId }
            SubjectCard(
                stat = stat,
                maxCompleted = maxCompleted,
                onRename = { renaming = subject },
                onDelete = { deleting = subject },
            )
        }

        val other = stats.firstOrNull { it.subjectId == null }
        if (other != null && (other.completedTasks > 0 || other.focusSeconds > 0L)) {
            item(key = "other") {
                GlowCard(glow = ReminderAccents[0], modifier = Modifier.revealOnEnter()) {
                    Text(
                        text = stringResource(R.string.subjects_no_subject),
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onSurface,
                    )
                    Text(
                        text = stringResource(
                            R.string.subjects_stat_line,
                            other.completedTasks,
                            minutesLabel(other.focusSeconds / 60),
                        ),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        }
    }

    if (addOpen) {
        NameDialog(
            title = stringResource(R.string.subjects_add),
            initial = "",
            confirm = stringResource(R.string.common_save),
            onDismiss = { addOpen = false },
            onConfirm = { name ->
                if (viewModel.addSubject(name, colorIndex = data.subjects.size)) addOpen = false
            },
        )
    }
    renaming?.let { subject ->
        NameDialog(
            title = stringResource(R.string.subjects_rename),
            initial = subject.name,
            confirm = stringResource(R.string.common_save),
            onDismiss = { renaming = null },
            onConfirm = { name ->
                if (viewModel.renameSubject(subject.id, name)) renaming = null
            },
        )
    }
    deleting?.let { subject ->
        AlertDialog(
            onDismissRequest = { deleting = null },
            title = { Text(stringResource(R.string.subjects_delete_title, subject.name)) },
            text = { Text(stringResource(R.string.subjects_delete_body)) },
            confirmButton = {
                TextButton(onClick = {
                    viewModel.deleteSubject(subject.id)
                    deleting = null
                }) { Text(stringResource(R.string.common_delete)) }
            },
            dismissButton = {
                TextButton(onClick = { deleting = null }) { Text(stringResource(R.string.common_cancel)) }
            },
        )
    }
}

@Composable
private fun SubjectCard(
    stat: SubjectStat,
    maxCompleted: Int,
    onRename: () -> Unit,
    onDelete: () -> Unit,
) {
    val accent = accentFor(stat.colorIndex)
    GlowCard(glow = accent, modifier = Modifier.revealOnEnter()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(
                    text = stat.name,
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onSurface,
                    fontWeight = FontWeight.SemiBold,
                )
                Text(
                    text = stringResource(
                        R.string.subjects_stat_line,
                        stat.completedTasks,
                        minutesLabel(stat.focusSeconds / 60),
                    ),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                // Bar length is relative to the subject with the most completed tasks, so it shows
                // real comparison only. It never implies a target that does not exist.
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(6.dp)
                        .clip(androidx.compose.foundation.shape.RoundedCornerShape(3.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant),
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth(stat.completedTasks.toFloat() / maxCompleted)
                            .height(6.dp)
                            .clip(androidx.compose.foundation.shape.RoundedCornerShape(3.dp))
                            .background(accent),
                    )
                }
            }
            IconButton(onClick = onRename) {
                Icon(Icons.Rounded.Edit, contentDescription = stringResource(R.string.subjects_rename))
            }
            IconButton(onClick = onDelete) {
                Icon(Icons.Rounded.Delete, contentDescription = stringResource(R.string.common_delete))
            }
        }
    }
}

@Composable
private fun NameDialog(
    title: String,
    initial: String,
    confirm: String,
    onDismiss: () -> Unit,
    onConfirm: (String) -> Unit,
) {
    var text by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            OutlinedTextField(
                value = text,
                onValueChange = { text = it.take(40) },
                singleLine = true,
                label = { Text(stringResource(R.string.subjects_name_label)) },
            )
        },
        confirmButton = {
            Button(onClick = { onConfirm(text) }, enabled = text.isNotBlank()) { Text(confirm) }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text(stringResource(R.string.common_cancel)) }
        },
    )
}
