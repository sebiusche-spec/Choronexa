// Part of Chronexa, a derivative of reReminder 4.0.1 — GNU GPL v3. See NOTICE.
package com.olaf.rereminder.study

/**
 * The visuals a task can show, in the order the chooser lists them. "auto" follows the task's name and category;
 * the others are fixed choices. "none" shows nothing.
 */
val VISUAL_CHOICES: List<String> = listOf(
    "auto", "wake", "brush", "bath", "meditate", "food", "maths", "physics", "chemistry", "computing",
    "study", "music", "exercise", "break", "sleep", "calm", "none",
)

/** Keys the drawing code knows. Anything else is drawn as the calm visual rather than as nothing. */
private val DRAWN_VISUALS = setOf(
    "wake", "brush", "bath", "meditate", "maths", "physics", "chemistry", "computing",
    "study", "music", "exercise", "food", "break", "sleep", "calm",
)

/** The key to draw for a stored or chosen value. Unknown values fall back to calm; "none" stays none. */
fun resolveVisual(key: String): String = when {
    key == "none" -> "none"
    key in DRAWN_VISUALS -> key
    else -> "calm"
}

/**
 * The visual for a task. A manual choice always wins and is never overwritten by a rename. "auto" follows the
 * task's current name and category, so renaming an automatic task changes its visual, as intended.
 */
fun visualFor(task: StudyTask): String = resolveVisual(chooseAnimation(task.title, task.category, task.animation))
