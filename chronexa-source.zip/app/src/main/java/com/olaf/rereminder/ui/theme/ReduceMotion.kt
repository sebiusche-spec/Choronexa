// Part of Chronexa, a derivative of reReminder 4.0.1 — GNU GPL v3. See NOTICE.
package com.olaf.rereminder.ui.theme

import android.provider.Settings
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.platform.LocalContext
import com.olaf.rereminder.utils.MotionMode
import com.olaf.rereminder.utils.PreferenceHelper

/**
 * True when decorative motion should be off. The in-app choice wins; SYSTEM falls back to
 * Android's "Remove animations" setting (animator duration scale of zero).
 */
@Composable
fun rememberReduceMotion(): Boolean {
    val context = LocalContext.current
    return remember(context) {
        when (PreferenceHelper(context).getMotionMode()) {
            MotionMode.REDUCED -> true
            MotionMode.FULL -> false
            MotionMode.SYSTEM -> runCatching {
                Settings.Global.getFloat(
                    context.contentResolver,
                    Settings.Global.ANIMATOR_DURATION_SCALE,
                    1f,
                ) == 0f
            }.getOrDefault(false)
        }
    }
}
