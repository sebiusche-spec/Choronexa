// Part of Chronexa, a derivative of reReminder 4.0.1 — GNU GPL v3. See NOTICE.
package com.olaf.rereminder.study.routine

import com.olaf.rereminder.study.StudyData
import com.olaf.rereminder.study.StudyTask
import com.olaf.rereminder.study.TaskRepeat
import com.olaf.rereminder.study.assignAlarmSlots
import java.time.LocalDate

/**
 * One row of the routine: a title, a time range in minutes of the day, and a category. The routine is a
 * template: adding it creates ordinary schedule activities, which can then be edited, moved or deleted in the
 * Schedule like any other activity. Nothing is forced; no alarm is switched on.
 */
data class RoutineItem(
    val title: String,
    val startMinute: Int,
    val endMinute: Int,
    val category: String,
    val notes: String = "",
)

private fun hm(hour24: Int, minute: Int) = hour24 * 60 + minute

/**
 * The daily routine from the user's reference chart, as written there. Study sessions name the subject; the
 * Sleep row runs overnight, ending at 5:00 AM the next day.
 */
val CLASS_12_DAILY_ROUTINE: List<RoutineItem> = listOf(
    RoutineItem("Wake Up", hm(5, 0), hm(5, 20), "routine", "Freshen up, drink water, gratitude"),
    RoutineItem("Meditation & Prayer", hm(5, 20), hm(5, 50), "routine", "Deep breathing, prayer"),
    RoutineItem("Workout / Gym", hm(5, 50), hm(6, 40), "fitness", "Strength training, cardio, stretching"),
    RoutineItem("Bath & Get Ready", hm(6, 40), hm(7, 10), "routine", "Freshen up, take bath, get ready for study"),
    RoutineItem("Healthy Breakfast", hm(7, 10), hm(7, 30), "meal", "Eat healthy and nutritious food"),
    RoutineItem("Study Session 1 · Physics", hm(7, 30), hm(9, 30), "study", "Complete 1 chapter: understand → notes → examples → PYQ"),
    RoutineItem("Short Break", hm(9, 30), hm(9, 45), "break", "Rest, walk, deep breath"),
    RoutineItem("Study Session 2 · Chemistry", hm(9, 45), hm(11, 45), "study", "Complete 1 chapter: NCERT → concepts → practice questions"),
    RoutineItem("Short Break", hm(11, 45), hm(12, 0), "break", "Hydrate, relax, stretch"),
    RoutineItem("Study Session 3 · Mathematics", hm(12, 0), hm(14, 0), "study", "Complete 1 chapter: formula sheet → question practice"),
    RoutineItem("Lunch", hm(14, 0), hm(14, 45), "meal", "Balanced meal and rest"),
    RoutineItem("Power Nap / Rest", hm(14, 45), hm(15, 30), "rest", "Short nap (20–30 min) or relax"),
    RoutineItem("Study Session 4 · Computer Science", hm(15, 30), hm(17, 0), "study", "Complete 1 chapter: code + concepts → write programs"),
    RoutineItem("Short Break", hm(17, 0), hm(17, 20), "break", "Snack, walk, relax"),
    RoutineItem("English Session", hm(17, 20), hm(18, 20), "study", "Complete 1 chapter: read → understand → write → practice"),
    RoutineItem("Revision Time", hm(18, 20), hm(19, 0), "revision", "Revise all subjects: quick notes and formulas"),
    RoutineItem("Dinner & Family Time", hm(19, 0), hm(20, 0), "meal", "Talk to family, have dinner"),
    RoutineItem("Study Session 5 · PYQ / Sample Paper", hm(20, 0), hm(22, 0), "study", "PYQ, sample paper, problem solving"),
    RoutineItem("Day Review", hm(22, 0), hm(22, 20), "routine", "What did I learn today? Plan for tomorrow"),
    RoutineItem("Read / Relax", hm(22, 20), hm(22, 45), "rest", "Read a book or listen to calm music"),
    RoutineItem("Sleep", hm(22, 45), hm(5, 0), "sleep", "Sound sleep (7–7.5 hours)"),
)

/** The minutes of the day an item covers, handling the overnight case where the end is earlier than the start. */
fun RoutineItem.coveredMinutes(): Set<Int> {
    val minutes = mutableSetOf<Int>()
    var m = startMinute
    while (m != endMinute) {
        minutes += m
        m = (m + 1) % 1440
    }
    return minutes
}

/** The first pair of routine items that share a minute, or null when the routine has no overlaps. */
fun findRoutineOverlap(items: List<RoutineItem>): Pair<RoutineItem, RoutineItem>? {
    for (i in items.indices) {
        val a = items[i].coveredMinutes()
        for (j in i + 1 until items.size) {
            if (a.any { it in items[j].coveredMinutes() }) return items[i] to items[j]
        }
    }
    return null
}

/** Whether the schedule already has this routine row, with the same title, times and a daily repeat. */
private fun StudyTask.matches(item: RoutineItem): Boolean =
    title == item.title && startMinute == item.startMinute && endMinute == item.endMinute &&
        repeat == TaskRepeat.DAILY && lastDate == null

/**
 * Adds the routine rows the schedule does not already have. Rows that match an existing daily activity are
 * skipped, so applying the routine twice never duplicates anything, and the user's own activities are kept.
 * Returns the new data and how many rows were added.
 */
fun StudyData.withRoutine(firstDate: LocalDate, items: List<RoutineItem> = CLASS_12_DAILY_ROUTINE): Pair<StudyData, Int> {
    val missing = items.filter { item -> tasks.none { it.matches(item) } }
    if (missing.isEmpty()) return this to 0
    var nextId = (tasks.maxOfOrNull { it.id } ?: 0L) + 1
    val added = missing.map { item ->
        StudyTask(
            id = nextId++,
            title = item.title,
            notes = item.notes,
            firstDate = firstDate,
            startMinute = item.startMinute,
            endMinute = item.endMinute,
            repeat = TaskRepeat.DAILY,
            category = item.category,
        )
    }
    return assignAlarmSlots(copy(tasks = tasks + added)) to added.size
}
