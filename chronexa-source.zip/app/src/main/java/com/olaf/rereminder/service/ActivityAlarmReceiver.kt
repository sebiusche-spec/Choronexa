// Part of Chronexa, a derivative of reReminder 4.0.1 — GNU GPL v3. See NOTICE.
package com.olaf.rereminder.service

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log

/** Receives activity and to-do alarms fired by AlarmManager. Not exported: only the app schedules them. */
class ActivityAlarmReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != ActivityAlarms.ACTION_FIRE) return
        val item = intent.getStringExtra(ActivityAlarms.EXTRA_ITEM) ?: return
        val kind = intent.getStringExtra(ActivityAlarms.EXTRA_KIND) ?: return
        val id = intent.getLongExtra(ActivityAlarms.EXTRA_ID, -1L)
        val trigger = intent.getLongExtra(ActivityAlarms.EXTRA_TRIGGER, 0L)
        val snooze = intent.getBooleanExtra(ActivityAlarms.EXTRA_SNOOZE, false)
        try {
            ActivityAlarms.handleFire(context, item, id, kind, trigger, snooze)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to handle an activity alarm", e)
        }
    }

    private companion object {
        const val TAG = "ActivityAlarmReceiver"
    }
}
