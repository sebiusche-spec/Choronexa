// Part of Chronexa, a derivative of reReminder 4.0.1 — GNU GPL v3. See NOTICE.
package com.olaf.rereminder.music

/**
 * A song the user has added. [uri] is the audio file's content URI and is its identity: the same file
 * added twice is one track. The file itself is never copied or deleted by the playlists.
 */
data class Track(
    val uri: String,
    val title: String,
    val artist: String = "",
    val durationMs: Long = 0L,
)

/**
 * A named list of track URIs. Membership is per playlist: removing a URI from one playlist leaves
 * every other playlist and the library untouched.
 */
data class Playlist(
    val id: String,
    val name: String,
    val builtIn: Boolean,
    val trackUris: List<String> = emptyList(),
)

data class MusicLibrary(
    val tracks: List<Track>,
    val playlists: List<Playlist>,
    /** Counter for custom playlist ids. It only goes up, so an id is never reused. */
    val nextPlaylistNumber: Int = 1,
) {
    companion object {
        fun initial(): MusicLibrary = MusicLibrary(tracks = emptyList(), playlists = defaultPlaylists())
    }
}

const val PLAYLIST_FAVORITES = "favorites"

/**
 * The playlists every library starts with. "All Songs" is not stored: it is simply every track in the
 * library, so it can never fall out of step with the library.
 */
fun defaultPlaylists(): List<Playlist> = listOf(
    Playlist("mathematics", "Mathematics", builtIn = true),
    Playlist("physics", "Physics", builtIn = true),
    Playlist("chemistry", "Chemistry", builtIn = true),
    Playlist("computer_science", "Computer Science", builtIn = true),
    Playlist("english", "English", builtIn = true),
    Playlist("relaxation", "Relaxation", builtIn = true),
    Playlist(PLAYLIST_FAVORITES, "Favorites", builtIn = true),
)
