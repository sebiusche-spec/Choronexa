// Part of Chronexa, a derivative of reReminder 4.0.1 — GNU GPL v3. See NOTICE.
package com.olaf.rereminder.study

import java.time.Instant
import java.time.ZoneId

/**
 * Continuous task audio: a task's own track plays from its start to its end. It is planned here as plain
 * times. It is independent of the alarm ring, which keeps its own short duration, and of the music player.
 *
 * Request codes sit in ranges that do not overlap the alarm, snooze, reminder, or music notification ranges.
 */
const val TASK_AUDIO_START_BASE = 1_950_000_000
const val TASK_AUDIO_END_BASE = 1_960_000_000

private const val DAY_MINUTES = 1440
private const val SEARCH_DAYS = 400L

fun taskAudioStartCodeFor(slot: Int): Int = TASK_AUDIO_START_BASE + slot

fun taskAudioEndCodeFor(slot: Int): Int = TASK_AUDIO_END_BASE + slot

/**
 * The task's duration in minutes, handling intervals that cross midnight (10:45 PM to 5:00 AM is 375 minutes).
 * A task whose start equals its end has no duration and cannot have continuous audio.
 */
fun taskDurationMinutes(task: StudyTask): Int =
    ((task.endMinute - task.startMinute) % DAY_MINUTES + DAY_MINUTES) % DAY_MINUTES

/** Whether continuous audio applies: switched on, a file chosen, and a real duration. */
fun hasTaskAudio(task: StudyTask): Boolean =
    task.continuousAudio && task.taskAudioUri.isNotBlank() && taskDurationMinutes(task) > 0

/**
 * The next interval in which the task's audio should play, as (start, end) epoch millis, strictly after
 * [afterMillis]. Null when continuous audio does not apply or no occurrence is found.
 */
fun nextTaskAudioWindow(task: StudyTask, afterMillis: Long, zone: ZoneId): Pair<Long, Long>? {
    if (!hasTaskAudio(task)) return null
    val firstDay = Instant.ofEpochMilli(afterMillis).atZone(zone).toLocalDate().minusDays(2)
    for (offset in 0L..SEARCH_DAYS) {
        val day = firstDay.plusDays(offset)
        if (!task.occursOn(day)) continue
        val occurrence = task.occurrenceOn(day)
        val start = toEpochMillis(occurrence.startAt, zone)
        val end = toEpochMillis(occurrence.endAt, zone)
        if (start > afterMillis) return start to end
    }
    return null
}

/**
 * The window that starts at exactly [triggerMillis], or null when the task's audio no longer starts then. A
 * start that fires after the task was edited, disabled or deleted is therefore ignored.
 */
fun taskAudioWindowStartingAt(task: StudyTask, triggerMillis: Long, zone: ZoneId): Pair<Long, Long>? {
    val window = nextTaskAudioWindow(task, triggerMillis - 1, zone) ?: return null
    return if (window.first == triggerMillis) window else null
}
