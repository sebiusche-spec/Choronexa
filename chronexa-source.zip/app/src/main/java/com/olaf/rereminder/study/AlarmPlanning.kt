// Part of Chronexa, a derivative of reReminder 4.0.1 — GNU GPL v3. See NOTICE.
package com.olaf.rereminder.study

import java.time.Instant
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.ZoneId

/**
 * Identifiers for activity alarms. These are pure rules; the Android side turns them into
 * AlarmManager calls.
 *
 * Request-code map (all disjoint):
 *   small ids        reminders (existing)
 *   1 000 000 + id   reminder snoozes (existing)
 *   2 000 000 + ...  activity and to-do alarms (this file)
 */
const val ACTIVITY_CODE_BASE = 2_000_000
const val DEFAULT_LEAD_MINUTES = 5
const val MAX_LEAD_MINUTES = 1440
private const val SEARCH_DAYS = 400L

/** A reminder that fires before the start, or an alarm that fires at the start. */
enum class AlarmKind(val offset: Int) { REMINDER(0), ALARM(1) }

/** Which list an alarm belongs to. Activities and to-dos never share a slot. */
enum class ItemKind { ACTIVITY, TODO }

fun clampLead(minutes: Int): Int = minutes.coerceIn(0, MAX_LEAD_MINUTES)

/** Each slot has two codes: one for the reminder and one for the alarm. */
fun requestCodeFor(slot: Int, kind: AlarmKind): Int = ACTIVITY_CODE_BASE + slot * 2 + kind.offset

private fun leadFor(kind: AlarmKind, lead: Int): Int = if (kind == AlarmKind.REMINDER) clampLead(lead) else 0

/**
 * Whether [kind] should be scheduled. A reminder at the start is dropped when an alarm already fires
 * at the start, so the user gets one notification, not two.
 */
fun isKindActive(
    alert: Boolean,
    alarmAtStart: Boolean,
    lead: Int,
    kind: AlarmKind,
    customAt: Long? = null,
): Boolean = when (kind) {
    AlarmKind.REMINDER -> alert && !(alarmAtStart && customAt == null && clampLead(lead) == 0)
    AlarmKind.ALARM -> alarmAtStart
}

fun toEpochMillis(local: LocalDateTime, zone: ZoneId): Long = local.atZone(zone).toInstant().toEpochMilli()

/**
 * The next time an activity's [kind] should fire, strictly after [afterMillis]. Null when nothing is
 * scheduled. Handles repeats, weekdays and activities that cross midnight.
 */
fun nextActivityTrigger(task: StudyTask, kind: AlarmKind, afterMillis: Long, zone: ZoneId): Long? {
    if (!isKindActive(task.alert, task.alarmAtStart, task.reminderLeadMinutes, kind, task.reminderCustomAt)) return null
    // A chosen reminder time fires once, at that moment, whatever the lead time says.
    if (kind == AlarmKind.REMINDER && task.reminderCustomAt != null) {
        val custom = task.reminderCustomAt ?: return null
        return if (custom > afterMillis) custom else null
    }
    val lead = leadFor(kind, task.reminderLeadMinutes).toLong()
    val firstDay = Instant.ofEpochMilli(afterMillis).atZone(zone).toLocalDate().minusDays(2)
    for (offset in 0L..SEARCH_DAYS) {
        val day = firstDay.plusDays(offset)
        if (!task.occursOn(day)) continue
        val start = task.occurrenceOn(day).startAt
        val trigger = toEpochMillis(start.minusMinutes(lead), zone)
        if (trigger > afterMillis) return trigger
    }
    return null
}

/** The next time a to-do's [kind] should fire. A done to-do or one without a due time has none. */
fun nextTodoTrigger(item: TodoItem, kind: AlarmKind, afterMillis: Long, zone: ZoneId): Long? {
    if (item.done) return null
    val due = item.dueAt ?: return null
    if (!isKindActive(item.alert, item.alarmAtDue, item.reminderLeadMinutes, kind, item.reminderCustomAt)) return null
    if (kind == AlarmKind.REMINDER && item.reminderCustomAt != null) {
        val custom = item.reminderCustomAt ?: return null
        return if (custom > afterMillis) custom else null
    }
    val trigger = toEpochMillis(due.minusMinutes(leadFor(kind, item.reminderLeadMinutes).toLong()), zone)
    return if (trigger > afterMillis) trigger else null
}

/**
 * The date of the occurrence a fired reminder belongs to. Used to skip a reminder for an activity
 * that was already ticked off for that day.
 */
fun occurrenceDateOf(triggerMillis: Long, leadMinutes: Int, zone: ZoneId): LocalDate =
    Instant.ofEpochMilli(triggerMillis + leadMinutes * 60_000L).atZone(zone).toLocalDate()

/**
 * Everything that changes what gets scheduled. Completing an activity is not in here, because a
 * completed occurrence is checked when its reminder fires. Changing a title is not in here either.
 */
fun StudyTask.alarmFingerprint(): String = listOf(
    firstDate, startMinute, endMinute, repeat, weekdays.map { it.value }.sorted(), lastDate,
    alert, clampLead(reminderLeadMinutes), alarmAtStart, sound, alarmSlot, reminderCustomAt,
).joinToString("|")

fun TodoItem.alarmFingerprint(): String = listOf(
    dueAt, done, alert, clampLead(reminderLeadMinutes), alarmAtDue, sound, alarmSlot, reminderCustomAt,
).joinToString("|")

/**
 * Gives every activity or to-do that needs an alarm a slot, once. Slots are taken from a counter that
 * only moves forward, so a slot is never reused and an old alarm cannot be inherited by a new item.
 */
fun assignAlarmSlots(data: StudyData): StudyData {
    var next = data.nextAlarmSlot.coerceAtLeast(1)
    val tasks = data.tasks.map { t ->
        if ((t.alert || t.alarmAtStart) && t.alarmSlot == 0) t.copy(alarmSlot = next++) else t
    }
    val todos = data.todos.map { item ->
        if ((item.alert || item.alarmAtDue) && item.alarmSlot == 0) item.copy(alarmSlot = next++) else item
    }
    return data.copy(tasks = tasks, todos = todos, nextAlarmSlot = next)
}

/**
 * The reminder time shown for one occurrence of an activity, or null when no reminder applies to it.
 * A custom reminder only applies on its own date.
 */
fun reminderMomentFor(task: StudyTask, occurrenceDate: LocalDate, zone: ZoneId): LocalDateTime? {
    if (!isKindActive(task.alert, task.alarmAtStart, task.reminderLeadMinutes, AlarmKind.REMINDER, task.reminderCustomAt)) {
        return null
    }
    val custom = task.reminderCustomAt
    if (custom != null) {
        val local = Instant.ofEpochMilli(custom).atZone(zone).toLocalDateTime()
        return if (local.toLocalDate() == occurrenceDate) local else null
    }
    if (!task.occursOn(occurrenceDate)) return null
    return task.occurrenceOn(occurrenceDate).startAt.minusMinutes(clampLead(task.reminderLeadMinutes).toLong())
}

/** The alarm time shown for one occurrence: the activity's start, when the start alarm is on. */
fun alarmMomentFor(task: StudyTask, occurrenceDate: LocalDate): LocalDateTime? {
    if (!task.alarmAtStart || !task.occursOn(occurrenceDate)) return null
    return task.occurrenceOn(occurrenceDate).startAt
}

/** The reminder time shown for a to-do, or null when none applies. */
fun todoReminderMoment(item: TodoItem, zone: ZoneId): LocalDateTime? {
    if (item.done) return null
    if (!isKindActive(item.alert, item.alarmAtDue, item.reminderLeadMinutes, AlarmKind.REMINDER, item.reminderCustomAt)) {
        return null
    }
    item.reminderCustomAt?.let { return Instant.ofEpochMilli(it).atZone(zone).toLocalDateTime() }
    val due = item.dueAt ?: return null
    return due.minusMinutes(leadFor(AlarmKind.REMINDER, item.reminderLeadMinutes).toLong())
}

/** The alarm time shown for a to-do: its due time, when the alarm is on. */
fun todoAlarmMoment(item: TodoItem): LocalDateTime? =
    if (!item.done && item.alarmAtDue) item.dueAt else null

/** Whether a task still has a reminder or an alarm that could fire. */
private fun StudyTask.needsAlarms(): Boolean = alert || alarmAtStart

/** Whether a to-do still has a reminder or an alarm that could fire: it must be open and switched on. */
private fun TodoItem.needsAlarms(): Boolean = !done && (alert || alarmAtDue)

/** What the alarm service has to do after a change to the data. */
data class AlarmPlan(
    val cancelSlots: Set<Int>,
    val scheduleTasks: List<StudyTask>,
    val scheduleTodos: List<TodoItem>,
)

/**
 * Works out what to cancel and what to set after a change.
 *
 * An item that was deleted, or whose alarm settings changed, has its old slot cancelled, and is set
 * again if it still exists and needs alarms. An item whose alarm settings are unchanged is not touched,
 * so an edit to one activity never touches another activity's alarms.
 */
fun planAlarmChanges(old: StudyData, new: StudyData): AlarmPlan {
    val cancel = mutableSetOf<Int>()
    val tasks = mutableListOf<StudyTask>()
    val todos = mutableListOf<TodoItem>()

    val oldTasks = old.tasks.associateBy { it.id }
    val newTasks = new.tasks.associateBy { it.id }
    for ((id, before) in oldTasks) {
        val after = newTasks[id]
        if (after == null || after.alarmFingerprint() != before.alarmFingerprint() || after.alarmSlot != before.alarmSlot) {
            if (before.alarmSlot > 0) cancel += before.alarmSlot
        }
    }
    for ((id, after) in newTasks) {
        val before = oldTasks[id]
        if ((before == null || before.alarmFingerprint() != after.alarmFingerprint()) && after.needsAlarms()) tasks += after
    }

    val oldTodos = old.todos.associateBy { it.id }
    val newTodos = new.todos.associateBy { it.id }
    for ((id, before) in oldTodos) {
        val after = newTodos[id]
        if (after == null || after.alarmFingerprint() != before.alarmFingerprint() || after.alarmSlot != before.alarmSlot) {
            if (before.alarmSlot > 0) cancel += before.alarmSlot
        }
    }
    for ((id, after) in newTodos) {
        val before = oldTodos[id]
        if ((before == null || before.alarmFingerprint() != after.alarmFingerprint()) && after.needsAlarms()) todos += after
    }
    return AlarmPlan(cancel, tasks, todos)
}
