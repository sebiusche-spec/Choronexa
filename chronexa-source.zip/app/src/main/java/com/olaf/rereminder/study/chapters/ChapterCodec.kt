// Part of Chronexa, a derivative of reReminder 4.0.1 — GNU GPL v3. See NOTICE.
package com.olaf.rereminder.study.chapters

import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json

/**
 * The chapter master as JSON. Same rules as the other stores: unknown fields ignored, a newer version is
 * reported and never overwritten, and unreadable data is reported rather than discarded.
 */
object ChapterCodec {

    const val CURRENT_SCHEMA_VERSION = 1

    private val json = Json {
        ignoreUnknownKeys = true
        encodeDefaults = true
    }

    sealed interface Decoded {
        data class Ok(val master: ChapterMaster) : Decoded
        data class FutureVersion(val version: Int) : Decoded
        data object Invalid : Decoded
    }

    fun encode(master: ChapterMaster): String = json.encodeToString(FileDto.serializer(), master.toDto())

    fun decode(text: String): Decoded = try {
        val dto = json.decodeFromString(FileDto.serializer(), text)
        when {
            dto.schemaVersion > CURRENT_SCHEMA_VERSION -> Decoded.FutureVersion(dto.schemaVersion)
            dto.schemaVersion < 1 -> Decoded.Invalid
            else -> Decoded.Ok(dto.toDomain())
        }
    } catch (e: Exception) {
        Decoded.Invalid
    }

    @Serializable
    private data class FileDto(
        val schemaVersion: Int = CURRENT_SCHEMA_VERSION,
        val chapters: List<ChapterDto> = emptyList(),
    )

    @Serializable
    private data class ChapterDto(
        val id: String,
        val subject: String,
        val number: Int,
        val name: String,
        val status: String = ChapterStatus.UNCERTAIN.name,
        val steps: List<String> = emptyList(),
    )

    private fun ChapterMaster.toDto() = FileDto(
        chapters = chapters.map {
            ChapterDto(it.id, it.subject.name, it.number, it.name, it.status.name, it.steps.map { s -> s.name })
        },
    )

    /**
     * Reads defensively: an unknown subject, status or step name is dropped rather than failing the whole file,
     * and an unknown status falls back to UNCERTAIN, so nothing is silently counted as included.
     */
    private fun FileDto.toDomain(): ChapterMaster = ChapterMaster(
        chapters.mapNotNull { dto ->
            val subject = runCatching { Subject.valueOf(dto.subject) }.getOrNull() ?: return@mapNotNull null
            Chapter(
                id = dto.id,
                subject = subject,
                number = dto.number,
                name = dto.name,
                status = runCatching { ChapterStatus.valueOf(dto.status) }.getOrDefault(ChapterStatus.UNCERTAIN),
                steps = dto.steps.mapNotNull { runCatching { ChapterStep.valueOf(it) }.getOrNull() }.toSet(),
            )
        },
    )
}
