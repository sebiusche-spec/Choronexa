// Part of Chronexa, a derivative of reReminder 4.0.1 — GNU GPL v3. See NOTICE.
package com.olaf.rereminder.study

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/** Whether the saved study data can be changed right now. */
sealed interface StudyStatus {
    data object Ready : StudyStatus
    /** The previous file was unreadable and was kept as [preservedAs]. Data starts fresh. */
    data class Recovered(val preservedAs: String) : StudyStatus
    /** Written by a newer app version. Shown, never overwritten. */
    data class ReadOnly(val version: Int) : StudyStatus
    /** A save or load failed. Changes are not kept. */
    data class Unavailable(val message: String) : StudyStatus
}

enum class FocusMode { FOCUS, SHORT_BREAK, LONG_BREAK }

/**
 * The focus timer as the UI sees it. It is held in memory, so it survives Activity recreation but
 * not the app being killed by the system. Completed focus sessions are written to disk; an
 * unfinished one is lost on process death and is never recorded.
 */
data class FocusSession(
    val mode: FocusMode = FocusMode.FOCUS,
    val clock: FocusClock = FocusClock(plannedMillis = 25L * 60_000L),
    val subjectId: Long? = null,
    val label: String = "",
    val startedAtMillis: Long = 0L,
    val focusCompletedThisCycle: Int = 0,
)

/**
 * Single source of truth for the study planner. Screens observe [data] and [session]; every change
 * goes through [update], which saves before publishing, so the screen never shows data that is not
 * on disk.
 */
class StudyRepository private constructor(context: Context) {

    private val store = StudyStore.forContext(context)
    private val lock = Any()

    private val _data = MutableStateFlow(StudyData.initial())
    val data: StateFlow<StudyData> = _data.asStateFlow()

    private val _status = MutableStateFlow<StudyStatus>(StudyStatus.Ready)
    val status: StateFlow<StudyStatus> = _status.asStateFlow()

    private val _session = MutableStateFlow(FocusSession())
    val session: StateFlow<FocusSession> = _session.asStateFlow()

    init {
        load()
    }

    private fun load() = synchronized(lock) {
        when (val result = store.load()) {
            is StudyStore.LoadResult.Loaded -> {
                _data.value = result.data
                _status.value = result.recoveredFrom?.let { StudyStatus.Recovered(it) } ?: StudyStatus.Ready
                _session.value = FocusSession(
                    clock = FocusClock(plannedMillis = result.data.settings.focusMinutes * 60_000L),
                )
            }

            is StudyStore.LoadResult.ReadOnly -> {
                _data.value = StudyData.initial()
                _status.value = StudyStatus.ReadOnly(result.version)
            }

            is StudyStore.LoadResult.Unreadable -> {
                _data.value = StudyData.initial()
                _status.value = StudyStatus.Unavailable(result.message)
            }
        }
    }

    /**
     * Applies [transform], saves, and publishes the result only if the save succeeded.
     * Returns false when nothing changed on disk.
     */
    fun update(transform: (StudyData) -> StudyData): Boolean = synchronized(lock) {
        val next = transform(_data.value)
        if (store.save(next)) {
            _data.value = next
            true
        } else {
            _status.value = StudyStatus.Unavailable("Could not save the change.")
            false
        }
    }

    /** A new id larger than any existing one. Ids are never reused. */
    fun <T> nextId(items: Iterable<T>, idOf: (T) -> Long): Long =
        (items.maxOfOrNull(idOf) ?: 0L) + 1L

    // --- Focus timer -----------------------------------------------------------------

    fun updateSession(transform: (FocusSession) -> FocusSession) {
        synchronized(lock) { _session.value = transform(_session.value) }
    }

    /**
     * Advances the timer to [now]. When a focus session finishes, it is written to disk. Breaks are
     * not recorded as focus time.
     */
    fun tickFocus(now: Long) = synchronized(lock) {
        val before = _session.value
        if (before.clock.state != FocusState.RUNNING) return@synchronized
        val afterClock = before.clock.tick(now)
        if (afterClock == before.clock) return@synchronized

        var after = before.copy(clock = afterClock)
        if (afterClock.completedBy(before.clock) && before.mode == FocusMode.FOCUS) {
            val saved = update { data ->
                data.copy(
                    focusRecords = data.focusRecords + FocusRecord(
                        id = nextId(data.focusRecords) { it.id },
                        subjectId = before.subjectId,
                        label = before.label,
                        plannedSeconds = (before.clock.plannedMillis / 1000L).toInt(),
                        startedAtMillis = before.startedAtMillis,
                        // The moment the countdown reached zero, not when the app noticed it.
                        completedAtMillis = before.clock.runStartedAtMillis +
                            (before.clock.plannedMillis - before.clock.bankedMillis),
                    ),
                )
            }
            if (saved) {
                after = after.copy(focusCompletedThisCycle = before.focusCompletedThisCycle + 1)
            }
        }
        _session.value = after
    }

    companion object {
        @Volatile
        private var instance: StudyRepository? = null

        fun get(context: Context): StudyRepository =
            instance ?: synchronized(this) {
                instance ?: StudyRepository(context.applicationContext).also { instance = it }
            }
    }
}
