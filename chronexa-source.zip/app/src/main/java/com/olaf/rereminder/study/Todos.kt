// Part of Chronexa, a derivative of reReminder 4.0.1 — GNU GPL v3. See NOTICE.
package com.olaf.rereminder.study

import java.time.LocalDateTime

/** Which to-dos the list shows. */
enum class TodoFilter { PENDING, DONE, ALL }

/** A to-do is overdue when it is not done and its due moment has passed. */
fun TodoItem.isOverdue(now: LocalDateTime): Boolean =
    !done && dueAt != null && dueAt.isBefore(now)

/** Why a to-do cannot be saved, or null. Returned as a key so the UI can localise it. */
fun TodoItem.validationError(): String? = if (title.isBlank()) "title_required" else null

/**
 * Pending to-dos first, then done ones. Within each group: items with a due moment come first,
 * soonest first; items without one follow. Ties fall back to id, so the order is stable.
 */
fun sortedTodos(items: List<TodoItem>): List<TodoItem> =
    items.sortedWith(compareBy<TodoItem>({ it.done }, { it.dueAt == null }, { it.dueAt }, { it.id }))

fun filterTodos(items: List<TodoItem>, filter: TodoFilter): List<TodoItem> = when (filter) {
    TodoFilter.PENDING -> items.filter { !it.done }
    TodoFilter.DONE -> items.filter { it.done }
    TodoFilter.ALL -> items
}
