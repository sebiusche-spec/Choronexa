// Part of Chronexa, a derivative of reReminder 4.0.1 — GNU GPL v3. See NOTICE.
package com.olaf.rereminder.ui.study.achievements

import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.olaf.rereminder.R
import com.olaf.rereminder.study.StudyStatus
import com.olaf.rereminder.study.badges
import com.olaf.rereminder.study.bestStreak
import com.olaf.rereminder.study.completedCountBetween
import com.olaf.rereminder.study.currentStreak
import com.olaf.rereminder.study.focusSecondsBetween
import com.olaf.rereminder.study.focusSecondsOn
import com.olaf.rereminder.study.summarizeDay
import com.olaf.rereminder.study.subjectStats
import com.olaf.rereminder.study.weekStart
import com.olaf.rereminder.study.weekSummaries
import com.olaf.rereminder.study.Badge
import com.olaf.rereminder.study.DaySummary
import com.olaf.rereminder.study.StudyData
import com.olaf.rereminder.ui.components.GlowCard
import com.olaf.rereminder.ui.components.revealOnEnter
import com.olaf.rereminder.ui.study.EmptyState
import com.olaf.rereminder.ui.study.StudyStatusBanner
import com.olaf.rereminder.ui.study.StudyViewModel
import com.olaf.rereminder.ui.study.accentFor
import com.olaf.rereminder.ui.study.minutesLabel
import com.olaf.rereminder.ui.theme.ChronexaCyan
import com.olaf.rereminder.ui.theme.ChronexaViolet
import com.olaf.rereminder.ui.theme.Motion
import java.time.LocalDate
import java.time.ZoneId
import java.time.DayOfWeek
import java.time.format.TextStyle
import java.util.Locale

@Composable
fun AchievementsRoute(viewModel: StudyViewModel = viewModel()) {
    val data by viewModel.data.collectAsStateWithLifecycle()
    val status by viewModel.status.collectAsStateWithLifecycle()
    AchievementsScreen(data, status)
}

@Composable
fun AchievementsScreen(data: StudyData, status: StudyStatus) {
    val zone = ZoneId.systemDefault()
    val today = LocalDate.now()
    val weekFrom = weekStart(today, data.settings.firstDayOfWeek)
    val hasHistory = data.tasks.isNotEmpty() || data.focusRecords.isNotEmpty()

    val completedToday = completedCountBetween(data, today, today)
    val completedWeek = completedCountBetween(data, weekFrom, today)
    val focusToday = focusSecondsOn(data.focusRecords, today, zone)
    val focusWeek = focusSecondsBetween(data.focusRecords, weekFrom, today, zone)
    val current = currentStreak(data, today)
    val best = bestStreak(data, today)
    val week = weekSummaries(data.tasks, data.completions, weekFrom)
    val subjects = subjectStats(data, LocalDate.of(1970, 1, 1), today, zone)
    val maxCompleted = (subjects.maxOfOrNull { it.completedTasks } ?: 0).coerceAtLeast(1)
    val badgeList = badges(data, today, zone)

    LazyColumn(
        modifier = Modifier.fillMaxWidth(),
        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        item(key = "title") {
            Text(
                text = stringResource(R.string.achievements_title),
                style = MaterialTheme.typography.headlineMedium,
                color = MaterialTheme.colorScheme.onBackground,
                fontWeight = FontWeight.SemiBold,
            )
        }

        if (status !is StudyStatus.Ready) item(key = "status") { StudyStatusBanner(status) }

        if (!hasHistory) {
            item(key = "empty") {
                EmptyState(
                    title = stringResource(R.string.achievements_empty_title),
                    body = stringResource(R.string.achievements_empty_body),
                )
            }
            return@LazyColumn
        }

        item(key = "stats") {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    StatCard(
                        label = stringResource(R.string.achievements_done_today),
                        value = completedToday.toString(),
                        accent = ChronexaCyan,
                        modifier = Modifier.weight(1f),
                    )
                    StatCard(
                        label = stringResource(R.string.achievements_done_week),
                        value = completedWeek.toString(),
                        accent = ChronexaCyan,
                        modifier = Modifier.weight(1f),
                    )
                }
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    StatCard(
                        label = stringResource(R.string.achievements_focus_today),
                        value = minutesLabel(focusToday / 60),
                        accent = ChronexaViolet,
                        modifier = Modifier.weight(1f),
                    )
                    StatCard(
                        label = stringResource(R.string.achievements_focus_week),
                        value = minutesLabel(focusWeek / 60),
                        accent = ChronexaViolet,
                        modifier = Modifier.weight(1f),
                    )
                }
            }
        }

        item(key = "streak") {
            GlowCard(glow = ChronexaCyan, modifier = Modifier.revealOnEnter()) {
                Text(
                    text = stringResource(R.string.achievements_streak_title),
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.secondary,
                    fontWeight = FontWeight.SemiBold,
                )
                Row(verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.spacedBy(20.dp)) {
                    Column {
                        Text(
                            text = current.toString(),
                            style = MaterialTheme.typography.displaySmall,
                            color = MaterialTheme.colorScheme.onSurface,
                            fontWeight = FontWeight.Light,
                        )
                        Text(
                            text = stringResource(R.string.achievements_streak_current),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    Column {
                        Text(
                            text = best.toString(),
                            style = MaterialTheme.typography.titleLarge,
                            color = MaterialTheme.colorScheme.onSurface,
                            fontWeight = FontWeight.SemiBold,
                        )
                        Text(
                            text = stringResource(R.string.achievements_streak_best),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
                Text(
                    text = stringResource(R.string.achievements_streak_rule),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }

        item(key = "week_title") {
            Text(
                text = stringResource(R.string.achievements_week_title),
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onBackground,
                fontWeight = FontWeight.SemiBold,
            )
        }
        item(key = "week") {
            WeekBars(week)
        }

        item(key = "subjects_title") {
            Text(
                text = stringResource(R.string.achievements_subjects_title),
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onBackground,
                fontWeight = FontWeight.SemiBold,
            )
        }
        items(subjects.filter { it.completedTasks > 0 || it.focusSeconds > 0L }, key = { it.subjectId ?: -1L }) { s ->
            val accent = accentFor(s.colorIndex)
            GlowCard(glow = accent, modifier = Modifier.revealOnEnter()) {
                Text(
                    text = s.name,
                    style = MaterialTheme.typography.titleSmall,
                    color = MaterialTheme.colorScheme.onSurface,
                    fontWeight = FontWeight.SemiBold,
                )
                Text(
                    text = stringResource(R.string.subjects_stat_line, s.completedTasks, minutesLabel(s.focusSeconds / 60)),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Spacer8()
                LinearProgressIndicator(
                    progress = { s.completedTasks.toFloat() / maxCompleted },
                    modifier = Modifier.fillMaxWidth(),
                    color = accent,
                    trackColor = MaterialTheme.colorScheme.surfaceVariant,
                )
            }
        }

        item(key = "badges_title") {
            Text(
                text = stringResource(R.string.achievements_badges_title),
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onBackground,
                fontWeight = FontWeight.SemiBold,
            )
        }
        items(badgeList, key = { it.id }) { badge ->
            BadgeRow(badge)
        }
    }
}

@Composable
private fun Spacer8() {
    Box(Modifier.height(8.dp))
}

@Composable
private fun StatCard(
    label: String,
    value: String,
    accent: androidx.compose.ui.graphics.Color,
    modifier: Modifier = Modifier,
) {
    GlowCard(glow = accent, modifier = modifier.revealOnEnter()) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Text(
            text = value,
            style = MaterialTheme.typography.titleLarge,
            color = MaterialTheme.colorScheme.onSurface,
            fontWeight = FontWeight.SemiBold,
        )
    }
}

/** Seven bars for the current week. Each height is the real completion percentage for that day. */
@Composable
private fun WeekBars(week: List<DaySummary>) {
    GlowCard(glow = ChronexaCyan, modifier = Modifier.revealOnEnter()) {
        Row(
            modifier = Modifier.fillMaxWidth().height(120.dp),
            verticalAlignment = Alignment.Bottom,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            week.forEach { day ->
                val target = if (day.total == 0) 0.dp else (day.percent * 0.9f).dp
                val animated by animateDpAsState(
                    targetValue = target,
                    animationSpec = Motion.spatial(),
                    label = "weekBar",
                )
                Column(
                    modifier = Modifier.weight(1f),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Bottom,
                ) {
                    Text(
                        text = if (day.total == 0) "–" else "${day.percent}%",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Box(
                        modifier = Modifier
                            .fillMaxWidth(0.7f)
                            .height(animated.coerceAtLeast(2.dp))
                            .clip(RoundedCornerShape(6.dp))
                            .background(
                                if (day.allDone) ChronexaCyan else ChronexaViolet.copy(alpha = 0.5f),
                            ),
                    )
                    Text(
                        text = day.date.dayOfWeek.getDisplayName(TextStyle.NARROW, Locale.getDefault()),
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        }
    }
}

@Composable
private fun BadgeRow(badge: Badge) {
    val name = when (badge.id) {
        "first_task" -> stringResource(R.string.badge_first_task)
        "three_day_streak" -> stringResource(R.string.badge_three_day_streak)
        "week_streak" -> stringResource(R.string.badge_week_streak)
        "ten_sessions" -> stringResource(R.string.badge_ten_sessions)
        "five_hours" -> stringResource(R.string.badge_five_hours)
        else -> badge.id
    }
    GlowCard(glow = if (badge.earned) ChronexaCyan else ChronexaViolet, modifier = Modifier.revealOnEnter()) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Icon(
                imageVector = Icons.Rounded.CheckCircle,
                contentDescription = null,
                tint = if (badge.earned) ChronexaCyan else MaterialTheme.colorScheme.outline,
                modifier = Modifier.size(24.dp),
            )
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = name,
                    style = MaterialTheme.typography.titleSmall,
                    color = if (badge.earned) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant,
                    fontWeight = FontWeight.SemiBold,
                )
                Text(
                    text = stringResource(R.string.achievements_badge_progress, badge.progress, badge.target),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
    }
}
