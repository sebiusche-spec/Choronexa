// Part of Chronexa, a derivative of reReminder 4.0.1 — GNU GPL v3. See NOTICE.
package com.olaf.rereminder.service

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log

/** Receives task audio starts and ends fired by AlarmManager. Not exported: only the app schedules them. */
class TaskAudioReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val slot = intent.getIntExtra(TaskAudioEngine.EXTRA_SLOT, 0)
        try {
            when (intent.action) {
                TaskAudioEngine.ACTION_START -> TaskAudioEngine.onStart(
                    context,
                    intent.getLongExtra(TaskAudioEngine.EXTRA_TASK_ID, -1L),
                    slot,
                    intent.getLongExtra(TaskAudioEngine.EXTRA_TRIGGER, 0L),
                )
                TaskAudioEngine.ACTION_END -> TaskAudioEngine.onEnd(context, slot)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Task audio event failed", e)
        }
    }

    private companion object {
        const val TAG = "TaskAudioReceiver"
    }
}
