// Part of Chronexa, a derivative of reReminder 4.0.1 — GNU GPL v3. See NOTICE.
package com.olaf.rereminder.service

import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.net.Uri
import android.os.Build
import android.os.IBinder
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.olaf.rereminder.R
import com.olaf.rereminder.study.AlarmSoundRef
import com.olaf.rereminder.study.parseSoundRef
import com.olaf.rereminder.study.shouldStartPlayback
import com.olaf.rereminder.utils.AlertPlayer
import com.olaf.rereminder.utils.PreferenceHelper
import com.olaf.rereminder.study.slotForAlarmCode
import com.olaf.rereminder.study.snoozeTrigger
import com.olaf.rereminder.utils.AlertSound
import com.olaf.rereminder.utils.NotificationHelper

/**
 * Plays a task's alarm sound until it is stopped.
 *
 * It runs as a foreground service because Android mutes audio that starts from the background. It
 * plays the task's chosen file, or the default alarm sound when the file can't be opened. A code that
 * is already ringing never starts a second copy. The service stops itself once nothing is ringing.
 */
class ActivityAlarmService : Service() {

    private var player: AlertPlayer? = null
    private val ringing = mutableSetOf<Int>()

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> startRinging(intent)
            ACTION_STOP -> {
                val code = intent.getIntExtra(EXTRA_CODE, 0)
                // Stop silences this alarm and cancels its pending snooze, so it cannot ring again.
                slotForAlarmCode(code)?.let { ActivityAlarms.cancelSnooze(this, it) }
                stopOne(code)
            }
            ACTION_SNOOZE -> snooze(
                code = intent.getIntExtra(EXTRA_CODE, 0),
                taskId = intent.getLongExtra(EXTRA_ITEM_ID, 0L),
            )
            else -> if (ringing.isEmpty()) stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun startRinging(intent: Intent) {
        val code = intent.getIntExtra(EXTRA_CODE, 0)
        val title = intent.getStringExtra(EXTRA_TITLE).orEmpty()
        val startMinute = intent.getIntExtra(EXTRA_START_MINUTE, 0)
        // Promote to the foreground first, whatever happens next: Android requires it promptly.
        val taskId = intent.getLongExtra(EXTRA_ITEM_ID, 0L)
        promote(code, title, startMinute, intent.getStringExtra(EXTRA_PLAYLIST_ID).orEmpty(), taskId)
        if (!shouldStartPlayback(ringing, code)) return
        ringing += code
        if (player == null) play(intent.getStringExtra(EXTRA_SOUND))
    }

    private fun play(raw: String?) {
        val alert: AlertSound = when (val choice = parseSoundRef(raw)) {
            AlarmSoundRef.Silent -> AlertSound.Silent
            AlarmSoundRef.DefaultTone -> AlertSound.Tone(null)
            is AlarmSoundRef.Custom -> {
                val uri = Uri.parse(choice.uri)
                if (canRead(uri)) {
                    AlertSound.Tone(uri)
                } else {
                    // The file was moved, deleted, or its permission lapsed: play the default instead.
                    Log.w(TAG, "The chosen alarm file can't be opened; playing the default sound")
                    AlertSound.Tone(null)
                }
            }
        }
        val alarmPlayer = AlertPlayer(this, AudioAttributes.USAGE_ALARM, loop = true)
        player = alarmPlayer
        alarmPlayer.play(alert, VIBRATION) { stopAll() }
    }

    private fun canRead(uri: Uri): Boolean = runCatching {
        contentResolver.openInputStream(uri)?.use { it.read() >= -1 } ?: false
    }.getOrDefault(false)

    /**
     * Snooze: silence this alarm and schedule its one follow-up. The follow-up uses the slot's snooze code, so
     * tapping Snooze again only moves the same pending alarm. Music is never started here.
     */
    private fun snooze(code: Int, taskId: Long) {
        val slot = slotForAlarmCode(code) ?: return
        if (taskId > 0L) {
            val minutes = PreferenceHelper(this).getSnoozeMinutes()
            val trigger = snoozeTrigger(System.currentTimeMillis(), minutes)
            if (!ActivityAlarms.scheduleSnooze(this, slot, taskId, trigger)) {
                Log.w(TAG, "The snooze could not be scheduled; the alarm is silenced anyway")
            }
        }
        stopOne(code)
    }

    private fun stopOne(code: Int) {
        ringing.remove(code)
        if (ringing.isEmpty()) stopAll()
    }

    private fun stopAll() {
        player?.stop()
        player = null
        ringing.clear()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun promote(code: Int, title: String, startMinute: Int, playlistId: String, taskId: Long) {
        val notification = buildNotification(code, title, startMinute, playlistId, taskId)
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                startForeground(code, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SYSTEM_EXEMPTED)
            } else {
                startForeground(code, notification)
            }
        } catch (e: RuntimeException) {
            // Android refused foreground status (for example, a restricted background start). Playback
            // is then not guaranteed; the alarm notification is still posted by the caller's fallback.
            Log.w(TAG, "Could not start in the foreground", e)
        }
    }

    private fun buildNotification(code: Int, title: String, startMinute: Int, playlistId: String, taskId: Long): Notification {
        val stop = PendingIntent.getService(
            this,
            code,
            Intent(this, ActivityAlarmService::class.java).setAction(ACTION_STOP).putExtra(EXTRA_CODE, code),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
        val clock = com.olaf.rereminder.study.clock12Hour(startMinute)
        return NotificationCompat.Builder(this, NotificationHelper.CHANNEL_ALARMS)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(title.ifEmpty { getString(R.string.app_name) })
            .setContentText(getString(R.string.activity_alarm_running, clock))
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .addAction(0, getString(R.string.alarm_snooze), snoozePending(code, taskId))
            .addAction(0, getString(R.string.alarm_stop), stop)
            .also { b -> if (playlistId.isNotEmpty()) b.addAction(0, getString(R.string.alarm_play_playlist), playPending(playlistId)) }
            .build()
    }

    /** The Snooze button. Explicit intent to this service, with the alarm's code and task id. */
    private fun snoozePending(code: Int, taskId: Long): PendingIntent = PendingIntent.getService(
        this,
        code,
        Intent(this, ActivityAlarmService::class.java)
            .setAction(ACTION_SNOOZE)
            .putExtra(EXTRA_CODE, code)
            .putExtra(EXTRA_ITEM_ID, taskId),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
    )

    /** Starts the chosen playlist, only when the user taps the button on this notification. */
    private fun playPending(playlistId: String): PendingIntent = PendingIntent.getService(
        this,
        playlistId.hashCode(),
        Intent(this, com.olaf.rereminder.music.MusicPlaybackService::class.java)
            .setAction(com.olaf.rereminder.music.MusicPlaybackService.ACTION_PLAY_PLAYLIST)
            .putExtra(com.olaf.rereminder.music.MusicPlaybackService.EXTRA_PLAYLIST_ID, playlistId),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
    )

    override fun onDestroy() {
        player?.stop()
        player = null
        super.onDestroy()
    }

    companion object {
        const val ACTION_START = "com.olaf.rereminder.action.ALARM_START"
        const val ACTION_STOP = "com.olaf.rereminder.action.ALARM_STOP"
        const val ACTION_SNOOZE = "com.olaf.rereminder.action.ALARM_SNOOZE"
        const val EXTRA_ITEM_ID = "itemId"
        const val EXTRA_CODE = "code"
        const val EXTRA_TITLE = "title"
        const val EXTRA_START_MINUTE = "startMinute"
        const val EXTRA_SOUND = "sound"
        private const val TAG = "ActivityAlarmService"
        private const val EXTRA_PLAYLIST_ID = "playlistId"
        private val VIBRATION = longArrayOf(0L, 800L, 600L)

        /** Starts the service. Returns false if Android refuses, so the caller can fall back to a notification. */
        fun start(
            context: Context,
            code: Int,
            title: String,
            startMinute: Int,
            sound: String,
            playlistId: String = "",
            taskId: Long = 0L,
        ): Boolean {
            val intent = Intent(context, ActivityAlarmService::class.java)
                .setAction(ACTION_START)
                .putExtra(EXTRA_CODE, code)
                .putExtra(EXTRA_TITLE, title)
                .putExtra(EXTRA_START_MINUTE, startMinute)
                .putExtra(EXTRA_SOUND, sound)
                .putExtra(EXTRA_PLAYLIST_ID, playlistId)
                .putExtra(EXTRA_ITEM_ID, taskId)
            return runCatching { ContextCompat.startForegroundService(context, intent) }.isSuccess
        }
    }
}
