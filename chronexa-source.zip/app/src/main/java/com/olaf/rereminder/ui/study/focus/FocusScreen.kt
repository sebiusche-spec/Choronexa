// Part of Chronexa, a derivative of reReminder 4.0.1 — GNU GPL v3. See NOTICE.
package com.olaf.rereminder.ui.study.focus

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.olaf.rereminder.R
import com.olaf.rereminder.study.FocusMode
import com.olaf.rereminder.study.FocusRecord
import com.olaf.rereminder.study.FocusState
import com.olaf.rereminder.study.focusSecondsBetween
import com.olaf.rereminder.study.focusSecondsOn
import com.olaf.rereminder.study.weekStart
import com.olaf.rereminder.ui.components.GlowCard
import com.olaf.rereminder.ui.components.revealOnEnter
import com.olaf.rereminder.ui.format.formatCountdown
import com.olaf.rereminder.ui.study.EmptyState
import com.olaf.rereminder.ui.study.ProgressRing
import com.olaf.rereminder.ui.study.StudyStatusBanner
import com.olaf.rereminder.ui.study.StudyViewModel
import com.olaf.rereminder.ui.study.accentFor
import com.olaf.rereminder.ui.study.minutesLabel
import com.olaf.rereminder.ui.theme.ChronexaCyan
import com.olaf.rereminder.ui.theme.ChronexaViolet
import com.olaf.rereminder.ui.theme.rememberReduceMotion
import kotlinx.coroutines.delay
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.time.format.FormatStyle

@Composable
fun FocusRoute(viewModel: StudyViewModel = viewModel()) {
    val data by viewModel.data.collectAsStateWithLifecycle()
    val status by viewModel.status.collectAsStateWithLifecycle()
    val session by viewModel.session.collectAsStateWithLifecycle()
    val clock = session.clock
    val running = clock.state == FocusState.RUNNING
    val editable = clock.state == FocusState.IDLE || clock.state == FocusState.COMPLETED
    val reduceMotion = rememberReduceMotion()

    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }

    // Advances the timer only while it is running and this screen is visible. The loop is cancelled
    // when the state changes or the screen leaves composition, so nothing runs in the background.
    LaunchedEffect(clock.state) {
        while (true) {
            viewModel.focusTick()
            now = System.currentTimeMillis()
            if (clock.state != FocusState.RUNNING) break
            delay(250L)
        }
    }

    val zone = ZoneId.systemDefault()
    val today = LocalDate.now()
    val weekFrom = weekStart(today, data.settings.firstDayOfWeek)
    val todaySeconds = focusSecondsOn(data.focusRecords, today, zone)
    val weekSeconds = focusSecondsBetween(data.focusRecords, weekFrom, today, zone)
    val history = data.focusRecords.sortedByDescending { it.completedAtMillis }.take(15)

    val remaining = clock.remainingMillis(now)
    val planned = clock.plannedMillis.coerceAtLeast(1L)
    val progress = 1f - remaining.toFloat() / planned.toFloat()
    val ringColor = if (session.mode == FocusMode.FOCUS) ChronexaCyan else ChronexaViolet

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        item(key = "title") {
            Text(
                text = stringResource(R.string.focus_title),
                style = MaterialTheme.typography.headlineMedium,
                color = MaterialTheme.colorScheme.onBackground,
                fontWeight = FontWeight.SemiBold,
            )
        }

        if (status !is com.olaf.rereminder.study.StudyStatus.Ready) {
            item(key = "status") { StudyStatusBanner(status) }
        }

        item(key = "ring") {
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                val ringContent: @Composable () -> Unit = {
                    ProgressRing(
                        progress = progress,
                        modifier = Modifier.size(260.dp),
                        strokeWidth = 14.dp,
                        color = ringColor,
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = formatCountdown(remaining),
                                style = MaterialTheme.typography.displayLarge,
                                fontWeight = FontWeight.Light,
                                color = MaterialTheme.colorScheme.onSurface,
                            )
                            Text(
                                text = modeLabel(session.mode),
                                style = MaterialTheme.typography.labelLarge,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    }
                }
                // The pulse is only composed while a session runs, so an idle screen animates nothing.
                if (running && !reduceMotion) PulsingGlow(content = ringContent) else ringContent()

                Text(
                    text = stateLabel(clock.state),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center,
                )
            }
        }

        item(key = "controls") {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp, Alignment.CenterHorizontally),
            ) {
                when (clock.state) {
                    FocusState.IDLE, FocusState.COMPLETED -> Button(onClick = { viewModel.focusStart() }) {
                        Text(stringResource(R.string.focus_start))
                    }
                    FocusState.RUNNING -> Button(onClick = { viewModel.focusPause() }) {
                        Text(stringResource(R.string.focus_pause))
                    }
                    FocusState.PAUSED -> Button(onClick = { viewModel.focusResume() }) {
                        Text(stringResource(R.string.focus_resume))
                    }
                }
                OutlinedButton(
                    onClick = { viewModel.focusReset() },
                    enabled = clock.state != FocusState.IDLE,
                ) {
                    Text(stringResource(R.string.focus_reset))
                }
            }
        }

        item(key = "modes") {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ModeChip(FocusMode.FOCUS, R.string.focus_mode_focus, session.mode, editable) { viewModel.selectMode(it) }
                    ModeChip(FocusMode.SHORT_BREAK, R.string.focus_mode_short, session.mode, editable) { viewModel.selectMode(it) }
                    ModeChip(FocusMode.LONG_BREAK, R.string.focus_mode_long, session.mode, editable) { viewModel.selectMode(it) }
                }
                if (session.mode == FocusMode.FOCUS) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(
                            selected = session.subjectId == null,
                            onClick = { if (editable) viewModel.selectSubject(null) },
                            label = { Text(stringResource(R.string.editor_subject_none)) },
                        )
                        data.subjects.forEach { s ->
                            FilterChip(
                                selected = session.subjectId == s.id,
                                onClick = { if (editable) viewModel.selectSubject(s.id) },
                                label = { Text(s.name) },
                            )
                        }
                    }
                    OutlinedTextField(
                        value = session.label,
                        onValueChange = { if (editable) viewModel.setLabel(it) },
                        label = { Text(stringResource(R.string.focus_label)) },
                        singleLine = true,
                        enabled = editable,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Text),
                        modifier = Modifier.fillMaxWidth(),
                    )
                }
            }
        }

        item(key = "totals") {
            GlowCard(glow = ChronexaCyan, modifier = Modifier.revealOnEnter()) {
                Row(horizontalArrangement = Arrangement.spacedBy(24.dp)) {
                    TotalCell(stringResource(R.string.focus_today), minutesLabel(todaySeconds / 60))
                    TotalCell(stringResource(R.string.focus_this_week), minutesLabel(weekSeconds / 60))
                }
            }
        }

        item(key = "history_title") {
            Text(
                text = stringResource(R.string.focus_history_title),
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onSurface,
                fontWeight = FontWeight.SemiBold,
            )
        }

        if (history.isEmpty()) {
            item(key = "history_empty") {
                EmptyState(
                    title = stringResource(R.string.focus_history_empty_title),
                    body = stringResource(R.string.focus_history_empty_body),
                )
            }
        } else {
            items(history, key = { it.id }) { record ->
                HistoryRow(record, data.subjects.firstOrNull { it.id == record.subjectId }, zone)
            }
        }
    }
}

private fun modeLabel(mode: FocusMode): String = when (mode) {
    FocusMode.FOCUS -> "FOCUS"
    FocusMode.SHORT_BREAK -> "SHORT BREAK"
    FocusMode.LONG_BREAK -> "LONG BREAK"
}

@Composable
private fun stateLabel(state: FocusState): String = when (state) {
    FocusState.IDLE -> stringResource(R.string.focus_state_idle)
    FocusState.RUNNING -> stringResource(R.string.focus_state_running)
    FocusState.PAUSED -> stringResource(R.string.focus_state_paused)
    FocusState.COMPLETED -> stringResource(R.string.focus_state_completed)
}

@Composable
private fun ModeChip(
    value: FocusMode,
    labelRes: Int,
    selected: FocusMode,
    enabled: Boolean,
    onSelect: (FocusMode) -> Unit,
) {
    FilterChip(
        selected = selected == value,
        onClick = { if (enabled) onSelect(value) },
        label = { Text(stringResource(labelRes)) },
    )
}

/** A soft glow behind the ring that breathes slowly. Composed only while a session is running. */
@Composable
private fun PulsingGlow(content: @Composable () -> Unit) {
    val transition = rememberInfiniteTransition(label = "focusGlow")
    val pulse by transition.animateFloat(
        initialValue = 0.94f,
        targetValue = 1.02f,
        animationSpec = infiniteRepeatable(tween(durationMillis = 2000, easing = LinearEasing), RepeatMode.Reverse),
        label = "pulse",
    )
    Box(
        modifier = Modifier
            .graphicsLayer {
                scaleX = pulse
                scaleY = pulse
            }
            .drawBehind {
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(ChronexaCyan.copy(alpha = 0.22f), Color.Transparent),
                        center = Offset(size.width / 2f, size.height / 2f),
                        radius = size.minDimension * 0.7f,
                    ),
                )
            },
        contentAlignment = Alignment.Center,
    ) {
        content()
    }
}

@Composable
private fun TotalCell(label: String, value: String) {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Text(
            text = value,
            style = MaterialTheme.typography.titleLarge,
            color = MaterialTheme.colorScheme.onSurface,
            fontWeight = FontWeight.SemiBold,
        )
    }
}

@Composable
private fun HistoryRow(record: FocusRecord, subject: com.olaf.rereminder.study.Subject?, zone: ZoneId) {
    val formatter = DateTimeFormatter.ofLocalizedDateTime(FormatStyle.MEDIUM, FormatStyle.SHORT).withZone(zone)
    val when_ = formatter.format(Instant.ofEpochMilli(record.completedAtMillis))
    val details = listOfNotNull(
        subject?.name ?: stringResource(R.string.subjects_no_subject),
        record.label.takeIf { it.isNotBlank() },
    ).joinToString(" · ")
    GlowCard(
        glow = subject?.let { accentFor(it.colorIndex) } ?: ChronexaCyan,
        modifier = Modifier.revealOnEnter(),
    ) {
        Text(
            text = minutesLabel(record.plannedSeconds / 60L),
            style = MaterialTheme.typography.titleMedium,
            color = MaterialTheme.colorScheme.onSurface,
            fontWeight = FontWeight.SemiBold,
        )
        Text(
            text = "$when_  ·  $details",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}
