// Part of Chronexa, a derivative of reReminder 4.0.1 — GNU GPL v3. See NOTICE.
package com.olaf.rereminder.music

import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json

/**
 * The music library as JSON. Same rules as the study file: unknown fields are ignored, a newer version
 * is reported and never overwritten, and unreadable data is reported rather than discarded.
 */
object MusicCodec {

    const val CURRENT_SCHEMA_VERSION = 1

    private val json = Json {
        ignoreUnknownKeys = true
        encodeDefaults = true
    }

    sealed interface DecodeResult {
        data class Ok(val library: MusicLibrary) : DecodeResult
        data class FutureVersion(val version: Int) : DecodeResult
        data class Invalid(val reason: String) : DecodeResult
    }

    fun encode(library: MusicLibrary): String = json.encodeToString(MusicFileDto.serializer(), library.toDto())

    fun decode(text: String): DecodeResult = try {
        val dto = json.decodeFromString(MusicFileDto.serializer(), text)
        when {
            dto.schemaVersion > CURRENT_SCHEMA_VERSION -> DecodeResult.FutureVersion(dto.schemaVersion)
            dto.schemaVersion < 1 -> DecodeResult.Invalid("schemaVersion ${dto.schemaVersion}")
            else -> DecodeResult.Ok(dto.toDomain())
        }
    } catch (e: Exception) {
        DecodeResult.Invalid(e.message ?: e::class.java.simpleName)
    }

    @Serializable
    private data class MusicFileDto(
        val schemaVersion: Int = CURRENT_SCHEMA_VERSION,
        val tracks: List<TrackDto> = emptyList(),
        val playlists: List<PlaylistDto> = emptyList(),
        val nextPlaylistNumber: Int = 1,
    )

    @Serializable
    private data class TrackDto(val uri: String, val title: String, val artist: String = "", val durationMs: Long = 0L)

    @Serializable
    private data class PlaylistDto(
        val id: String,
        val name: String,
        val builtIn: Boolean = false,
        val trackUris: List<String> = emptyList(),
    )

    private fun MusicLibrary.toDto() = MusicFileDto(
        schemaVersion = CURRENT_SCHEMA_VERSION,
        tracks = tracks.map { TrackDto(it.uri, it.title, it.artist, it.durationMs) },
        playlists = playlists.map { PlaylistDto(it.id, it.name, it.builtIn, it.trackUris) },
        nextPlaylistNumber = nextPlaylistNumber,
    )

    private fun MusicFileDto.toDomain() = MusicLibrary(
        tracks = tracks.map { Track(it.uri, it.title, it.artist, it.durationMs) },
        playlists = playlists.map { Playlist(it.id, it.name, it.builtIn, it.trackUris) },
        nextPlaylistNumber = nextPlaylistNumber.coerceAtLeast(1),
    )
}
