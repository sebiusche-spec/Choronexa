// Part of Chronexa, a derivative of reReminder 4.0.1 — GNU GPL v3. See NOTICE.
package com.olaf.rereminder.music

import android.content.Context
import android.content.Intent
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.OpenableColumns

/**
 * Reads what the library needs from a file the user picked: its name, artist and length. The file is
 * referenced by its URI and kept readable with a persistable permission. Nothing is copied.
 */
object MusicImport {

    fun track(context: Context, uri: Uri): Track {
        val name = displayName(context, uri)
        val (artist, durationMs) = metadata(context, uri)
        return Track(
            uri = uri.toString(),
            title = name.substringBeforeLast('.').ifBlank { name },
            artist = artist,
            durationMs = durationMs,
        )
    }

    /** Asks the system to keep read access across restarts. Some providers refuse; the file then works until it moves. */
    fun keepAccess(context: Context, uri: Uri) {
        runCatching {
            context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
    }

    private fun displayName(context: Context, uri: Uri): String = runCatching {
        context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) cursor.getString(0) else null
        }
    }.getOrNull() ?: uri.lastPathSegment.orEmpty()

    private fun metadata(context: Context, uri: Uri): Pair<String, Long> {
        val retriever = MediaMetadataRetriever()
        return try {
            retriever.setDataSource(context, uri)
            val artist = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST).orEmpty()
            val duration = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            artist to duration
        } catch (e: Exception) {
            "" to 0L
        } finally {
            runCatching { retriever.release() }
        }
    }
}
