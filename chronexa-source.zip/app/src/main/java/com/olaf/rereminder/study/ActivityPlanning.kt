// Part of Chronexa, a derivative of reReminder 4.0.1 — GNU GPL v3. See NOTICE.
package com.olaf.rereminder.study

import java.time.Duration
import java.time.LocalDate
import java.time.LocalDateTime

/** Built-in categories. The id is what is stored; the screen shows the label. */
val BUILT_IN_CATEGORIES: List<String> = listOf("routine", "study", "exercise", "food", "break", "sleep", "other")

/** Built-in categories first, then the user's own, without repeats. */
fun allCategories(data: StudyData): List<String> =
    BUILT_IN_CATEGORIES + data.categories.map { it.trim() }.filter { it.isNotEmpty() && it !in BUILT_IN_CATEGORIES }.distinct()

// --- Animation choice ------------------------------------------------------------------

/** Keyword rules checked in order. The first match wins, so specific words come first. */
private val KEYWORD_RULES: List<Pair<Regex, String>> = listOf(
    Regex("""\b(wake|sunrise|morning|alarm)\b""", RegexOption.IGNORE_CASE) to "wake",
    Regex("""\b(brush|teeth|dental|floss)\b""", RegexOption.IGNORE_CASE) to "brush",
    Regex("""\b(bath|shower|wash)\b""", RegexOption.IGNORE_CASE) to "bath",
    Regex("""\b(physics|mechanics|kinematics|optics)\b""", RegexOption.IGNORE_CASE) to "physics",
    Regex("""\b(chemistry|chem|molecule|reaction|organic)\b""", RegexOption.IGNORE_CASE) to "chemistry",
    Regex("""\b(math|maths|mathematics|algebra|calculus|geometry|equation)\b""", RegexOption.IGNORE_CASE) to "maths",
    Regex("""\b(code|coding|computer|programming|algorithm|python|javascript)\b""", RegexOption.IGNORE_CASE) to "computing",
    Regex("""\b(study|revision|revise|read|reading|homework|notes|english)\b""", RegexOption.IGNORE_CASE) to "study",
    Regex("""\b(gym|exercise|workout|run|running|yoga|stretch|push-?ups?)\b""", RegexOption.IGNORE_CASE) to "exercise",
    Regex("""\b(lunch|dinner|breakfast|meal|eat|eating|snack|food|coffee|tea)\b""", RegexOption.IGNORE_CASE) to "food",
    Regex("""\b(break|rest|pause|walk|recharge)\b""", RegexOption.IGNORE_CASE) to "break",
    Regex("""\b(meditation|meditate|prayer|pray|mindfulness)\b""", RegexOption.IGNORE_CASE) to "meditate",
    Regex("""\b(music|songs?|guitar|piano|chill)\b""", RegexOption.IGNORE_CASE) to "music",
    Regex("""\b(sleep|bed|nap|night)\b""", RegexOption.IGNORE_CASE) to "sleep",
)

private val CATEGORY_ANIMATION: Map<String, String> = mapOf(
    "routine" to "calm", "study" to "study", "exercise" to "exercise", "food" to "food",
    "break" to "break", "sleep" to "sleep", "other" to "calm",
)

/**
 * The animation for an activity. A manual choice always wins, and "none" turns animation off.
 * Otherwise the name's keywords decide, then the category, then a calm default. Visual only.
 */
fun chooseAnimation(name: String, category: String, animation: String): String {
    if (animation != "auto") return animation
    for ((pattern, key) in KEYWORD_RULES) {
        if (pattern.containsMatchIn(name)) return key
    }
    return CATEGORY_ANIMATION[category] ?: "calm"
}

// --- What is happening now ---------------------------------------------------------------

/**
 * The state of the day at [now]. Overnight activities that began yesterday and are still running
 * count as current. "Next" looks only at activities starting later today.
 */
data class DayNow(
    val current: Occurrence?,
    val minutesLeft: Long?,
    val next: Occurrence?,
    val minutesUntilNext: Long?,
)

fun dayNow(tasks: List<StudyTask>, now: LocalDateTime): DayNow {
    val today = now.toLocalDate()
    val candidates = occurrencesStartingOn(tasks, today) + occurrencesStartingOn(tasks, today.minusDays(1))
    val current = candidates
        .filter { !it.startAt.isAfter(now) && now.isBefore(it.endAt) }
        .maxByOrNull { it.startAt }
    val next = occurrencesStartingOn(tasks, today)
        .filter { it.startAt.isAfter(now) }
        .minByOrNull { it.startAt }
    return DayNow(
        current = current,
        minutesLeft = current?.let { Duration.between(now, it.endAt).toMinutes() },
        next = next,
        minutesUntilNext = next?.let { Duration.between(now, it.startAt).toMinutes() },
    )
}

// --- Copying and rescheduling -------------------------------------------------------------

data class CopyResult(val created: List<StudyTask>, val skipped: Int)

/** Same name (ignoring case and spaces) and the same times. Two such activities are the same activity. */
private fun signatureOf(task: StudyTask): Triple<String, Int, Int> =
    Triple(task.title.trim().lowercase(), task.startMinute, task.endMinute)

/**
 * Copies the activities of [from] to [to] as one-off activities. Anything already on [to] with the
 * same name and times is skipped, so copying twice creates nothing the second time. Completion
 * history is not copied: the new day starts unticked.
 */
fun copyDay(tasks: List<StudyTask>, from: LocalDate, to: LocalDate, nextId: () -> Long): CopyResult {
    if (from == to) return CopyResult(emptyList(), 0)
    val taken = occurrencesStartingOn(tasks, to).map { signatureOf(it.task) }.toMutableSet()
    val created = mutableListOf<StudyTask>()
    var skipped = 0
    for (occurrence in occurrencesStartingOn(tasks, from)) {
        val signature = signatureOf(occurrence.task)
        if (signature in taken) {
            skipped++
            continue
        }
        taken += signature
        created += occurrence.task.copy(
            id = nextId(),
            firstDate = to,
            repeat = TaskRepeat.NONE,
            weekdays = emptySet(),
            lastDate = null,
        )
    }
    return CopyResult(created, skipped)
}

/**
 * The same activity moved to [newStartMinute], keeping its length and wrapping past midnight.
 * Returns null when the move can't be represented: a whole-day activity can only start at midnight.
 */
fun StudyTask.rescheduledTo(newStartMinute: Int): StudyTask? {
    if (newStartMinute !in 0 until MINUTES_PER_DAY) return null
    val length = durationMinutes
    if (length >= MINUTES_PER_DAY) {
        return if (newStartMinute == 0) copy(startMinute = 0, endMinute = MINUTES_PER_DAY) else null
    }
    val raw = newStartMinute + length
    val end = if (raw > MINUTES_PER_DAY) raw - MINUTES_PER_DAY else raw
    return copy(startMinute = newStartMinute, endMinute = end)
}
