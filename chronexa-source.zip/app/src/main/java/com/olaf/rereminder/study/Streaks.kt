// Part of Chronexa, a derivative of reReminder 4.0.1 — GNU GPL v3. See NOTICE.
package com.olaf.rereminder.study

import java.time.LocalDate

/**
 * Streak rule, stated once so the UI can explain it:
 *
 * A day counts toward a streak when every task scheduled for that day is completed (and there is
 * at least one). A day with nothing scheduled, or with an unfinished task, breaks the streak.
 *
 * Today is special: while it is still in progress it neither counts nor breaks. Once today is
 * fully completed it counts.
 */
object Streaks {

    /** Consecutive completed days that end yesterday, or today if today is already complete. */
    fun current(
        today: LocalDate,
        summaryOn: (LocalDate) -> DaySummary,
        maxLookbackDays: Int = 3650,
    ): Int {
        var count = if (summaryOn(today).allDone) 1 else 0
        var day = today.minusDays(1)
        var steps = 0
        while (steps < maxLookbackDays && summaryOn(day).allDone) {
            count++
            day = day.minusDays(1)
            steps++
        }
        return count
    }

    /**
     * The longest run of completed days from [firstDay] through [today]. Pass the earliest date
     * with any scheduled task, or null when nothing has ever been scheduled.
     */
    fun best(
        firstDay: LocalDate?,
        today: LocalDate,
        summaryOn: (LocalDate) -> DaySummary,
    ): Int {
        // Null means nothing has ever been scheduled, so there is no run to measure.
        val start: LocalDate = firstDay ?: return 0
        var best = 0
        var run = 0
        var day: LocalDate = start
        while (!day.isAfter(today)) {
            if (summaryOn(day).allDone) {
                run++
                if (run > best) best = run
            } else if (day != today) {
                run = 0
            }
            day = day.plusDays(1)
        }
        return best
    }
}
