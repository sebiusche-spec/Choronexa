// Part of Chronexa, a derivative of reReminder 4.0.1 — GNU GPL v3. See NOTICE.
package com.olaf.rereminder.music

import android.content.Context
import com.olaf.rereminder.data.Storage
import java.io.File
import java.io.IOException
import java.nio.file.AtomicMoveNotSupportedException
import java.nio.file.Files
import java.nio.file.StandardCopyOption

/**
 * Reads and writes the music library in its own file, separate from the study and reminder data.
 * Same safety rules as the study store: atomic writes, a newer file is read-only, an unreadable file is
 * moved aside rather than deleted, and nothing is written before a successful load.
 */
class MusicStore(private val file: File) {

    sealed interface LoadResult {
        data class Loaded(val library: MusicLibrary, val recoveredFrom: String?) : LoadResult
        data class ReadOnly(val version: Int) : LoadResult
        data class Unreadable(val message: String) : LoadResult
    }

    private var writable = false

    @Synchronized
    fun load(nowMillis: Long = System.currentTimeMillis()): LoadResult {
        writable = false
        if (!file.exists()) {
            writable = true
            return LoadResult.Loaded(MusicLibrary.initial(), recoveredFrom = null)
        }
        val text = try {
            file.readText(Charsets.UTF_8)
        } catch (e: IOException) {
            return LoadResult.Unreadable(e.message ?: "read failed")
        }
        return when (val decoded = MusicCodec.decode(text)) {
            is MusicCodec.DecodeResult.Ok -> {
                writable = true
                LoadResult.Loaded(decoded.library, recoveredFrom = null)
            }
            is MusicCodec.DecodeResult.FutureVersion -> LoadResult.ReadOnly(decoded.version)
            is MusicCodec.DecodeResult.Invalid -> {
                val preserved = File(file.parentFile, "music.unreadable-$nowMillis.json")
                try {
                    Files.move(file.toPath(), preserved.toPath())
                } catch (e: IOException) {
                    return LoadResult.Unreadable("could not preserve the unreadable file: ${e.message}")
                }
                writable = true
                LoadResult.Loaded(MusicLibrary.initial(), recoveredFrom = preserved.name)
            }
        }
    }

    /** Returns false if nothing was written: no successful load yet, a read-only file, or an I/O error. */
    @Synchronized
    fun save(library: MusicLibrary): Boolean {
        if (!writable) return false
        val temp = File(file.parentFile, file.name + ".tmp")
        return try {
            temp.writeText(MusicCodec.encode(library), Charsets.UTF_8)
            try {
                Files.move(temp.toPath(), file.toPath(), StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING)
            } catch (e: AtomicMoveNotSupportedException) {
                Files.move(temp.toPath(), file.toPath(), StandardCopyOption.REPLACE_EXISTING)
            }
            true
        } catch (e: IOException) {
            temp.delete()
            false
        }
    }

    companion object {
        const val FILE_NAME = "music.json"

        fun forContext(context: Context): MusicStore = MusicStore(File(Storage.filesDir(context), FILE_NAME))
    }
}
