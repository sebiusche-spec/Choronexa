// Part of Chronexa, a derivative of reReminder 4.0.1 — GNU GPL v3. See NOTICE.
package com.olaf.rereminder.ui.home

import com.olaf.rereminder.data.Reminder

/** Which greeting fits the time of day. */
enum class DayPart { MORNING, AFTERNOON, EVENING }

/** Morning from 05:00, afternoon from 12:00, evening from 18:00 and through the night. */
fun dayPartFor(hour: Int): DayPart = when (hour) {
    in 5..11 -> DayPart.MORNING
    in 12..17 -> DayPart.AFTERNOON
    else -> DayPart.EVENING
}

/** The reminder that fires soonest, with its display name resolved. */
data class NextAlarm(val name: String, val atMillis: Long)

/**
 * The soonest upcoming alert among enabled reminders.
 *
 * Returns null while everything is paused, and ignores any reminder whose time has already
 * passed: a stale value must never be shown as "next".
 */
fun nextAlarmFrom(
    reminders: List<Reminder>,
    masterEnabled: Boolean,
    now: Long,
    nameOf: (Reminder) -> String,
): NextAlarm? {
    if (!masterEnabled) return null
    val next = reminders
        .filter { it.enabled && it.nextTriggerAt > now }
        .minByOrNull { it.nextTriggerAt }
        ?: return null
    return NextAlarm(nameOf(next), next.nextTriggerAt)
}
