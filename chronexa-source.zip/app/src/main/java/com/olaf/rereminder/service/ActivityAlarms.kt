// Part of Chronexa, a derivative of reReminder 4.0.1 — GNU GPL v3. See NOTICE.
package com.olaf.rereminder.service

import com.olaf.rereminder.study.snoozeCodeFor
import com.olaf.rereminder.study.snoozeTrigger

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.olaf.rereminder.R
import com.olaf.rereminder.study.AlarmKind
import com.olaf.rereminder.study.Completion
import com.olaf.rereminder.study.ItemKind
import com.olaf.rereminder.study.StudyData
import com.olaf.rereminder.study.StudyRepository
import com.olaf.rereminder.study.StudyTask
import com.olaf.rereminder.study.TodoItem
import com.olaf.rereminder.study.alarmFingerprint
import com.olaf.rereminder.study.nextActivityTrigger
import com.olaf.rereminder.study.planAlarmChanges
import com.olaf.rereminder.study.nextTodoTrigger
import com.olaf.rereminder.study.occurrenceDateOf
import com.olaf.rereminder.study.requestCodeFor
import com.olaf.rereminder.utils.NotificationHelper
import java.time.ZoneId

/**
 * Schedules, cancels and fires alarms for study activities and to-dos.
 *
 * Reminders and snoozes from the original app are not touched. Activity alarms use their own
 * request-code range (see AlarmPlanning.kt). Every scheduled event is identified by its item's
 * slot, so cancelling an item cancels exactly its own alarms.
 *
 * Exact timing: on Android 12 and later [canScheduleExact] is checked first. When exact alarms are
 * not allowed, the alarm is still set but as an inexact one, and the result says so. Nothing here
 * claims a time will be met exactly.
 */
object ActivityAlarms {

    const val ACTION_FIRE = "com.olaf.rereminder.action.ACTIVITY_ALARM"
    const val EXTRA_ITEM = "item"
    const val EXTRA_ID = "id"
    const val EXTRA_KIND = "kind"
    const val EXTRA_TRIGGER = "trigger"
    const val EXTRA_SNOOZE = "snooze"
    private const val TAG = "ActivityAlarms"

    /** The outcome of scheduling one event, shown in the editor so the user can see it worked. */
    data class Entry(
        val item: ItemKind,
        val itemId: Long,
        val kind: AlarmKind,
        val triggerAtMillis: Long,
        val scheduled: Boolean,
        val exact: Boolean,
    )

    fun canScheduleExact(context: Context): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return true
        val manager = context.getSystemService(AlarmManager::class.java) ?: return false
        return manager.canScheduleExactAlarms()
    }

    private fun intentFor(
        context: Context,
        code: Int,
        item: ItemKind,
        id: Long,
        kind: AlarmKind,
        trigger: Long,
    ): PendingIntent {
        val intent = Intent(context, ActivityAlarmReceiver::class.java)
            .setAction(ACTION_FIRE)
            .putExtra(EXTRA_ITEM, item.name)
            .putExtra(EXTRA_ID, id)
            .putExtra(EXTRA_KIND, kind.name)
            .putExtra(EXTRA_TRIGGER, trigger)
        return PendingIntent.getBroadcast(
            context,
            code,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
    }

    /** Sets one alarm. Falls back to an inexact alarm when exact scheduling is refused. */
    private fun schedule(
        context: Context,
        code: Int,
        item: ItemKind,
        id: Long,
        kind: AlarmKind,
        trigger: Long,
    ): Entry {
        val manager = context.getSystemService(AlarmManager::class.java)
            ?: return Entry(item, id, kind, trigger, scheduled = false, exact = false)
        val pending = intentFor(context, code, item, id, kind, trigger)
        val exactAllowed = canScheduleExact(context)
        return try {
            if (exactAllowed) {
                manager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, trigger, pending)
            } else {
                manager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, trigger, pending)
            }
            Entry(item, id, kind, trigger, scheduled = true, exact = exactAllowed)
        } catch (e: SecurityException) {
            Log.w(TAG, "Exact alarm refused; setting an inexact one", e)
            try {
                manager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, trigger, pending)
                Entry(item, id, kind, trigger, scheduled = true, exact = false)
            } catch (e2: SecurityException) {
                Log.e(TAG, "Could not schedule the alarm", e2)
                Entry(item, id, kind, trigger, scheduled = false, exact = false)
            }
        }
    }

    /** Cancels both alarms of a slot. Safe to call when nothing is scheduled. */
    fun cancelSlot(context: Context, slot: Int) {
        if (slot <= 0) return
        val manager = context.getSystemService(AlarmManager::class.java) ?: return
        for (kind in AlarmKind.values()) {
            // Cancelling matches on action and request code, so the extras here do not matter.
            manager.cancel(intentFor(context, requestCodeFor(slot, kind), ItemKind.ACTIVITY, 0L, kind, 0L))
        }
        cancelSnooze(context, slot)
    }

    /** Cancels the pending snooze of a slot, if any. Safe to call when there is none. */
    fun cancelSnooze(context: Context, slot: Int) {
        if (slot <= 0) return
        val manager = context.getSystemService(AlarmManager::class.java) ?: return
        manager.cancel(snoozeIntent(context, snoozeCodeFor(slot), 0L, 0L))
    }

    /**
     * Schedules the one snooze of a slot. Using the same request code each time means a repeated snooze
     * replaces the pending one. Returns false only if Android refused to schedule it at all.
     */
    fun scheduleSnooze(context: Context, slot: Int, taskId: Long, trigger: Long): Boolean {
        if (slot <= 0 || taskId <= 0L) return false
        val manager = context.getSystemService(AlarmManager::class.java) ?: return false
        val pending = snoozeIntent(context, snoozeCodeFor(slot), taskId, trigger)
        return try {
            manager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, trigger, pending)
            true
        } catch (e: SecurityException) {
            Log.w(TAG, "Exact snooze refused; setting an inexact one", e)
            try {
                manager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, trigger, pending)
                true
            } catch (e2: SecurityException) {
                Log.e(TAG, "Could not schedule the snooze", e2)
                false
            }
        }
    }

    /** The receiver intent for a snooze. Marked with the snooze extra so it does not reschedule the repeat. */
    private fun snoozeIntent(context: Context, code: Int, id: Long, trigger: Long): PendingIntent {
        val intent = Intent(context, ActivityAlarmReceiver::class.java)
            .setAction(ACTION_FIRE)
            .putExtra(EXTRA_ITEM, ItemKind.ACTIVITY.name)
            .putExtra(EXTRA_KIND, AlarmKind.ALARM.name)
            .putExtra(EXTRA_ID, id)
            .putExtra(EXTRA_TRIGGER, trigger)
            .putExtra(EXTRA_SNOOZE, true)
        return PendingIntent.getBroadcast(
            context,
            code,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
    }

    /**
     * A snoozed alarm rings again. It rings only if the task still exists, still has a start alarm, and the
     * day's occurrence is not already done. It never reschedules the repeat, which is already armed.
     */
    private fun handleSnoozeFire(
        context: Context,
        task: StudyTask,
        data: StudyData,
        trigger: Long,
        zone: ZoneId,
    ) {
        if (!task.alarmAtStart || task.alarmSlot <= 0) return
        val date = occurrenceDateOf(trigger, 0, zone)
        if (Completion(task.id, date) in data.completions) return
        val code = requestCodeFor(task.alarmSlot, AlarmKind.ALARM)
        val sound = if (task.alarmSoundOn) task.sound else "silent"
        val offered = if (task.playOnStart) task.playlistId else ""
        if (!ActivityAlarmService.start(context, code, task.title, task.startMinute, sound, offered, task.id)) {
            post(context, AlarmKind.ALARM, task.title, task.startMinute, code)
        }
    }

    private fun scheduleTask(context: Context, task: StudyTask, now: Long, zone: ZoneId): List<Entry> {
        if (task.alarmSlot <= 0) return emptyList()
        return AlarmKind.values().mapNotNull { kind ->
            nextActivityTrigger(task, kind, now, zone)?.let { trigger ->
                schedule(context, requestCodeFor(task.alarmSlot, kind), ItemKind.ACTIVITY, task.id, kind, trigger)
            }
        }
    }

    private fun scheduleTodo(context: Context, item: TodoItem, now: Long, zone: ZoneId): List<Entry> {
        if (item.alarmSlot <= 0) return emptyList()
        return AlarmKind.values().mapNotNull { kind ->
            nextTodoTrigger(item, kind, now, zone)?.let { trigger ->
                schedule(context, requestCodeFor(item.alarmSlot, kind), ItemKind.TODO, item.id, kind, trigger)
            }
        }
    }

    /**
     * Brings the alarms in line with a change to the data. Anything deleted, disabled, moved or
     * edited is cancelled first, then its new alarms are set. Items whose alarm settings did not
     * change are left alone, so an unrelated edit never touches another activity's alarm.
     */
    fun applyChange(
        context: Context,
        old: StudyData,
        new: StudyData,
        nowMillis: Long = System.currentTimeMillis(),
    ): List<Entry> {
        val zone = ZoneId.systemDefault()
        val plan = planAlarmChanges(old, new)
        plan.cancelSlots.forEach { cancelSlot(context, it) }
        val results = plan.scheduleTasks.flatMap { scheduleTask(context, it, nowMillis, zone) } +
            plan.scheduleTodos.flatMap { scheduleTodo(context, it, nowMillis, zone) }
        return results
    }

    /**
     * Re-sets every activity and to-do alarm. Used after a reboot, a clock or timezone change, or an
     * app update, because Android drops pending alarms in those cases. Each slot is cancelled before
     * it is set again, so running this twice does not create duplicates.
     */
    fun resyncAll(context: Context, data: StudyData, nowMillis: Long = System.currentTimeMillis()): List<Entry> {
        val zone = ZoneId.systemDefault()
        (data.tasks.map { it.alarmSlot } + data.todos.map { it.alarmSlot })
            .filter { it > 0 }
            .distinct()
            .forEach { cancelSlot(context, it) }
        return data.tasks.flatMap { scheduleTask(context, it, nowMillis, zone) } +
            data.todos.flatMap { scheduleTodo(context, it, nowMillis, zone) }
    }

    /**
     * Called when an alarm fires. The alarm only proceeds if it is still the current one for that
     * item, so a deleted, disabled or edited activity cannot ring from an old alarm. A reminder
     * for an occurrence already ticked off is skipped. The next occurrence is armed either way.
     */
    fun handleFire(
        context: Context,
        itemName: String,
        id: Long,
        kindName: String,
        expectedTrigger: Long,
        snooze: Boolean = false,
    ) {
        val kind = runCatching { AlarmKind.valueOf(kindName) }.getOrNull() ?: return
        val item = runCatching { ItemKind.valueOf(itemName) }.getOrNull() ?: return
        NotificationHelper.createNotificationChannels(context)
        val data = StudyRepository.get(context).data.value
        val zone = ZoneId.systemDefault()

        when (item) {
            ItemKind.ACTIVITY -> {
                val task = data.tasks.firstOrNull { it.id == id } ?: return
                if (snooze) {
                    handleSnoozeFire(context, task, data, expectedTrigger, zone)
                    return
                }
                if (nextActivityTrigger(task, kind, expectedTrigger - 1, zone) != expectedTrigger) return
                val lead = if (kind == AlarmKind.REMINDER && task.reminderCustomAt == null) task.reminderLeadMinutes else 0
                val date = occurrenceDateOf(expectedTrigger, lead, zone)
                if (Completion(task.id, date) !in data.completions) {
                    val code = requestCodeFor(task.alarmSlot, kind)
                    if (kind == AlarmKind.ALARM) {
                        // The task's own sound plays from the service. If Android refuses to start it,
                        // fall back to a notification with the channel sound, so the alarm still shows.
                        val sound = if (task.alarmSoundOn) task.sound else "silent"
                        val offered = if (task.playOnStart) task.playlistId else ""
                        if (!ActivityAlarmService.start(context, code, task.title, task.startMinute, sound, offered, task.id)) {
                            post(context, kind, task.title, task.startMinute, code)
                        }
                    } else {
                        post(context, kind, task.title, task.startMinute, code)
                    }
                }
                nextActivityTrigger(task, kind, expectedTrigger, zone)?.let { next ->
                    schedule(context, requestCodeFor(task.alarmSlot, kind), ItemKind.ACTIVITY, task.id, kind, next)
                }
            }
            ItemKind.TODO -> {
                val todo = data.todos.firstOrNull { it.id == id } ?: return
                if (nextTodoTrigger(todo, kind, expectedTrigger - 1, zone) != expectedTrigger) return
                if (!todo.done) {
                    val due = todo.dueAt?.let { it.hour * 60 + it.minute } ?: 0
                    post(context, kind, todo.title, due, requestCodeFor(todo.alarmSlot, kind))
                }
                nextTodoTrigger(todo, kind, expectedTrigger, zone)?.let { next ->
                    schedule(context, requestCodeFor(todo.alarmSlot, kind), ItemKind.TODO, todo.id, kind, next)
                }
            }
        }
    }

    /**
     * Shows the notification. The id is the alarm's request code, so a second firing for the same
     * item replaces the first notification instead of stacking a duplicate.
     */
    private fun post(context: Context, kind: AlarmKind, title: String, startMinute: Int, code: Int) {
        val channel = if (kind == AlarmKind.ALARM) NotificationHelper.CHANNEL_ALARMS else NotificationHelper.CHANNEL_REMINDERS
        if (!NotificationHelper.canPost(context, channel)) {
            Log.w(TAG, "Notifications are off for $channel; nothing shown")
            return
        }
        val clock = com.olaf.rereminder.study.clock12Hour(startMinute)
        val text = if (kind == AlarmKind.ALARM) {
            context.getString(R.string.activity_alarm_text)
        } else {
            context.getString(R.string.activity_reminder_text, clock)
        }
        val notification = NotificationCompat.Builder(context, channel)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(title)
            .setContentText(text)
            .setCategory(if (kind == AlarmKind.ALARM) NotificationCompat.CATEGORY_ALARM else NotificationCompat.CATEGORY_REMINDER)
            .setPriority(if (kind == AlarmKind.ALARM) NotificationCompat.PRIORITY_HIGH else NotificationCompat.PRIORITY_DEFAULT)
            .setAutoCancel(true)
            .setOnlyAlertOnce(true)
            .build()
        try {
            NotificationManagerCompat.from(context).notify(code, notification)
        } catch (e: SecurityException) {
            Log.w(TAG, "Notification permission missing", e)
        }
    }
}
