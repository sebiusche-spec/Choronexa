// Part of Chronexa, a derivative of reReminder 4.0.1 — GNU GPL v3. See NOTICE.
package com.olaf.rereminder.ui.theme

import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import com.olaf.rereminder.R

/**
 * Outfit, bundled in res/font (SIL Open Font License, see assets/licenses/OFL-Outfit.txt). Bundled rather
 * than fetched, so the app never loads a font over the network. Outfit ships in Regular and Bold; other
 * weights resolve to the nearest of the two.
 */
val OutfitFamily: FontFamily = FontFamily(
    Font(R.font.outfit_regular, FontWeight.Normal),
    Font(R.font.outfit_bold, FontWeight.Bold),
)
