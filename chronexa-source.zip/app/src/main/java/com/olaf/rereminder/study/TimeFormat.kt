// Part of Chronexa, a derivative of reReminder 4.0.1 — GNU GPL v3. See NOTICE.
package com.olaf.rereminder.study

import java.util.Locale

/**
 * 12-hour clock text for a minute of the day: "5:20 AM", "12:00 PM", "12:00 AM".
 *
 * This is display only. Stored times stay as minutes of the day, so changing how a time is shown never
 * changes when anything is scheduled. Midnight (0 and 1440) reads as 12:00 AM and noon as 12:00 PM.
 */
fun clock12Hour(minuteOfDay: Int): String {
    val minute = ((minuteOfDay % MINUTES_PER_DAY) + MINUTES_PER_DAY) % MINUTES_PER_DAY
    val hour24 = minute / 60
    val hour12 = if (hour24 % 12 == 0) 12 else hour24 % 12
    val period = if (hour24 < 12) "AM" else "PM"
    return String.format(Locale.ROOT, "%d:%02d %s", hour12, minute % 60, period)
}
