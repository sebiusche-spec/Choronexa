// Part of Chronexa, a derivative of reReminder 4.0.1 — GNU GPL v3. See NOTICE.
package com.olaf.rereminder.music

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/** What the Music Studio shows about playback. Only [MusicPlaybackService] writes it. */
data class PlaybackUi(
    val queue: PlaybackQueue = PlaybackQueue(),
    val playing: Boolean = false,
    val positionMs: Long = 0L,
    val durationMs: Long = 0L,
    val title: String = "",
    val artist: String = "",
    /** A short message when a file could not be played. Null otherwise. */
    val problem: String? = null,
)

object MusicPlayback {
    private val stateFlow = MutableStateFlow(PlaybackUi())
    val state: StateFlow<PlaybackUi> = stateFlow.asStateFlow()

    internal fun publish(value: PlaybackUi) {
        stateFlow.value = value
    }
}
