// Part of Chronexa, a derivative of reReminder 4.0.1 — GNU GPL v3. See NOTICE.
package com.olaf.rereminder.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.ScrollState
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.TileMode
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.util.lerp
import com.olaf.rereminder.ui.theme.Motion
import com.olaf.rereminder.ui.theme.rememberReduceMotion

private val ExpandedHeight = 118.dp
private val CollapsedHeight = 62.dp
private val ActionRowHeight = 56.dp

/** Reference palette stops for the animated title: white, lavender, purple, cyan, white. */
private val TitleStops = listOf(
    Color(0xFFFFFFFF),
    Color(0xFFD8C7FF),
    Color(0xFF8B5CF6),
    Color(0xFF00E5FF),
    Color(0xFFFFFFFF),
)

/** Reference neon line: transparent, purple, cyan, pink, transparent. */
private val NeonLineStops = listOf(
    Color.Transparent,
    Color(0xFF8B5CF6),
    Color(0xFF00E5FF),
    Color(0xFFFF2D95),
    Color.Transparent,
)

/** How far the shimmer travels per cycle, and how wide one gradient sweep is, in pixels. */
private const val TITLE_TRAVEL_PX = 600f
private const val TITLE_SPAN_PX = 600f
private const val LINE_TRAVEL_PX = 900f
private const val LINE_SPAN_PX = 900f

/**
 * The app's header: a dark glass bar with a gradient brand title, an optional tagline, and a neon line along
 * its lower edge. The bar collapses with the scroll, and the title scales from the left so it stays anchored.
 *
 * The title shimmer and the neon line move only while reduce-motion is off; otherwise they are static.
 */
@Composable
fun CollapsingHeader(
    title: String,
    progress: Float,
    modifier: Modifier = Modifier,
    subtitle: String? = null,
    navigationIcon: @Composable (() -> Unit)? = null,
    actions: @Composable RowScope.() -> Unit = {},
) {
    val p = progress.coerceIn(0f, 1f)
    val height = lerp(ExpandedHeight, CollapsedHeight, p)

    // Once collapsed the title has to clear the navigation icon; expanded it starts at the margin.
    val startPadding = if (navigationIcon != null) lerp(20.dp, 52.dp, p) else 20.dp
    val titleScale = lerp(1f, 0.64f, p)

    val containerColor by animateColorAsState(
        targetValue = if (p > 0.02f) {
            MaterialTheme.colorScheme.surfaceContainer
        } else {
            Color.Transparent
        },
        animationSpec = Motion.fade(),
        label = "headerContainer",
    )

    // The header always reserves its expanded height, however far it has collapsed, and the bar is drawn
    // inside that space. If the reserved height followed the collapse, the Scaffold would hand the content a
    // different top padding on every frame, and the collapse would never settle. The unused part takes no
    // touches, so content scrolls up behind it.
    Box(modifier = modifier.fillMaxWidth()) {
        Spacer(
            Modifier
                .statusBarsPadding()
                .height(ExpandedHeight),
        )
        CollapsingBar(
            title = title,
            subtitle = subtitle,
            progress = p,
            height = height,
            startPadding = startPadding,
            titleScale = titleScale,
            containerColor = containerColor,
            navigationIcon = navigationIcon,
            actions = actions,
        )
    }
}

@Composable
private fun CollapsingBar(
    title: String,
    subtitle: String?,
    progress: Float,
    height: Dp,
    startPadding: Dp,
    titleScale: Float,
    containerColor: Color,
    navigationIcon: @Composable (() -> Unit)?,
    actions: @Composable RowScope.() -> Unit,
) {
    val p = progress
    val shift = neonShift(rememberReduceMotion())
    Box(
        modifier = Modifier
            .fillMaxWidth()
            // Fill first, inset second: the container colour runs behind the status bar while the
            // title and actions sit below it.
            .background(containerColor)
            .statusBarsPadding()
            .height(height),
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(ActionRowHeight)
                .padding(horizontal = 4.dp)
                .align(Alignment.TopStart),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.End,
        ) {
            navigationIcon?.invoke()
            Box(Modifier.weight(1f))
            actions()
        }

        // Tagline: visible when expanded, gone once collapsed. Sits above the title.
        if (subtitle != null) {
            Text(
                text = subtitle.uppercase(),
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                fontWeight = FontWeight.Bold,
                letterSpacing = 3.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .padding(start = startPadding, end = 20.dp, bottom = 62.dp)
                    .graphicsLayer { alpha = 1f - p },
            )
        }

        Text(
            text = title,
            style = MaterialTheme.typography.headlineLarge.merge(TextStyle(brush = titleBrush(shift))),
            fontWeight = FontWeight.Bold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier
                .align(Alignment.BottomStart)
                .padding(start = startPadding, end = 20.dp, bottom = lerp(18.dp, 16.dp, p))
                .graphicsLayer {
                    // Scaling from the left edge keeps the first letter anchored, so the title
                    // shrinks in place instead of drifting sideways.
                    transformOrigin = TransformOrigin(0f, 0.5f)
                    scaleX = titleScale
                    scaleY = titleScale
                },
        )

        // Neon line along the lower edge: the reference's purple, cyan and pink sweep. It stays faintly
        // visible when expanded and brightens as the bar collapses.
        Box(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .height(2.dp)
                .graphicsLayer { alpha = 0.6f + 0.4f * p }
                .drawBehind {
                    drawRect(
                        brush = neonLineBrush(shift),
                        topLeft = Offset.Zero,
                        size = Size(size.width, size.height),
                    )
                },
        )
    }
}

/** A 0..1 position that loops while motion is on, and stays at 0 otherwise. Costs nothing when reduced. */
@Composable
private fun neonShift(reduce: Boolean): Float {
    if (reduce) return 0f
    val transition = rememberInfiniteTransition(label = "neon")
    val value by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(durationMillis = 4000, easing = LinearEasing), RepeatMode.Restart),
        label = "neonShift",
    )
    return value
}

private fun titleBrush(shift: Float): Brush = Brush.linearGradient(
    colors = TitleStops,
    start = Offset(shift * TITLE_TRAVEL_PX, 0f),
    end = Offset(shift * TITLE_TRAVEL_PX + TITLE_SPAN_PX, 0f),
    tileMode = TileMode.Mirror,
)

private fun neonLineBrush(shift: Float): Brush = Brush.linearGradient(
    colors = NeonLineStops,
    start = Offset(shift * LINE_TRAVEL_PX, 0f),
    end = Offset(shift * LINE_TRAVEL_PX + LINE_SPAN_PX, 0f),
    tileMode = TileMode.Mirror,
)

/**
 * How far the header has collapsed, 0f expanded to 1f collapsed.
 *
 * Read from the raw scroll offset rather than an animation, so the header tracks the finger frame for frame.
 */
@Composable
fun rememberCollapseProgress(
    listState: LazyListState,
    distance: Dp = ExpandedHeight - CollapsedHeight,
): State<Float> {
    val distancePx = with(LocalDensity.current) { distance.toPx() }
    return remember(listState, distancePx) {
        derivedStateOf {
            if (listState.firstVisibleItemIndex > 0) {
                1f
            } else {
                (listState.firstVisibleItemScrollOffset / distancePx).coerceIn(0f, 1f)
            }
        }
    }
}

@Composable
fun rememberCollapseProgress(
    scrollState: ScrollState,
    distance: Dp = ExpandedHeight - CollapsedHeight,
): State<Float> {
    val distancePx = with(LocalDensity.current) { distance.toPx() }
    return remember(scrollState, distancePx) {
        derivedStateOf { (scrollState.value / distancePx).coerceIn(0f, 1f) }
    }
}
