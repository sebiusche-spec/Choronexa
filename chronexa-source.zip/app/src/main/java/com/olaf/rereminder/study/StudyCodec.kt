// Part of Chronexa, a derivative of reReminder 4.0.1 — GNU GPL v3. See NOTICE.
package com.olaf.rereminder.study

import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.LocalDateTime

/**
 * Converts [StudyData] to and from JSON.
 *
 * The file carries a [CURRENT_SCHEMA_VERSION]. Rules:
 * - Unknown fields are ignored, so a file written by a newer minor change still reads.
 * - A file with a *higher* schema version is reported as [DecodeResult.FutureVersion] and must never
 *   be overwritten by this build, or a newer build's data would be lost.
 * - Anything unreadable is reported as [DecodeResult.Invalid]. The caller keeps the bytes; nothing is
 *   silently discarded.
 * - Enum-like values are stored as text, and unknown text falls back to a safe default.
 */
object StudyCodec {

    const val CURRENT_SCHEMA_VERSION = 5

    private val json = Json {
        ignoreUnknownKeys = true
        encodeDefaults = true
    }

    sealed interface DecodeResult {
        data class Ok(val data: StudyData) : DecodeResult
        data class FutureVersion(val version: Int) : DecodeResult
        data class Invalid(val reason: String) : DecodeResult
    }

    fun encode(data: StudyData): String =
        json.encodeToString(StudyFileDto.serializer(), data.toDto())

    fun decode(text: String): DecodeResult = try {
        val dto = json.decodeFromString(StudyFileDto.serializer(), text)
        when {
            dto.schemaVersion > CURRENT_SCHEMA_VERSION -> DecodeResult.FutureVersion(dto.schemaVersion)
            dto.schemaVersion < 1 -> DecodeResult.Invalid("schemaVersion ${dto.schemaVersion}")
            else -> DecodeResult.Ok(dto.toDomain())
        }
    } catch (e: Exception) {
        DecodeResult.Invalid(e.message ?: e::class.java.simpleName)
    }

    // --- Persistence shape. Dates are ISO text, weekdays are ISO numbers (1 = Monday). ---

    @Serializable
    private data class StudyFileDto(
        val schemaVersion: Int = CURRENT_SCHEMA_VERSION,
        val subjects: List<SubjectDto> = emptyList(),
        val tasks: List<TaskDto> = emptyList(),
        val completions: List<CompletionDto> = emptyList(),
        val focusRecords: List<FocusRecordDto> = emptyList(),
        val settings: SettingsDto = SettingsDto(),
        val todos: List<TodoDto> = emptyList(),
        val categories: List<String> = emptyList(),
        val nextAlarmSlot: Int = 1,
    )

    @Serializable
    private data class TodoDto(
        val id: Long,
        val title: String,
        val notes: String = "",
        val subjectId: Long? = null,
        val dueAt: String? = null,
        val done: Boolean = false,
        val alert: Boolean = false,
        val reminderLeadMinutes: Int = 5,
        val alarmAtDue: Boolean = false,
        val sound: String = "default",
        val alarmSlot: Int = 0,
        val reminderCustomAt: Long? = null,
    )

    @Serializable
    private data class SubjectDto(val id: Long, val name: String, val colorIndex: Int = 0)

    @Serializable
    private data class TaskDto(
        val id: Long,
        val title: String,
        val notes: String = "",
        val subjectId: Long? = null,
        val firstDate: String,
        val startMinute: Int,
        val endMinute: Int,
        val repeat: String = "NONE",
        val weekdays: List<Int> = emptyList(),
        val lastDate: String? = null,
        val category: String = "other",
        val animation: String = "auto",
        val alert: Boolean = false,
        val reminderLeadMinutes: Int = 5,
        val alarmAtStart: Boolean = false,
        val sound: String = "default",
        val alarmSlot: Int = 0,
        val reminderCustomAt: Long? = null,
    )

    @Serializable
    private data class CompletionDto(val taskId: Long, val date: String)

    @Serializable
    private data class FocusRecordDto(
        val id: Long,
        val subjectId: Long? = null,
        val label: String = "",
        val plannedSeconds: Int,
        val startedAtMillis: Long,
        val completedAtMillis: Long,
    )

    @Serializable
    private data class SettingsDto(
        val focusMinutes: Int = 25,
        val shortBreakMinutes: Int = 5,
        val longBreakMinutes: Int = 15,
        val sessionsBeforeLongBreak: Int = 4,
        val firstDayOfWeek: Int = 1,
    )

    private fun StudyData.toDto() = StudyFileDto(
        schemaVersion = CURRENT_SCHEMA_VERSION,
        subjects = subjects.map { SubjectDto(it.id, it.name, it.colorIndex) },
        tasks = tasks.map { t ->
            TaskDto(
                id = t.id,
                title = t.title,
                notes = t.notes,
                subjectId = t.subjectId,
                firstDate = t.firstDate.toString(),
                startMinute = t.startMinute,
                endMinute = t.endMinute,
                repeat = t.repeat.name,
                weekdays = t.weekdays.map { it.value }.sorted(),
                lastDate = t.lastDate?.toString(),
                category = t.category,
                animation = t.animation,
                alert = t.alert,
                reminderLeadMinutes = t.reminderLeadMinutes,
                alarmAtStart = t.alarmAtStart,
                sound = t.sound,
                alarmSlot = t.alarmSlot,
                reminderCustomAt = t.reminderCustomAt,
            )
        },
        categories = categories,
        nextAlarmSlot = nextAlarmSlot,
        completions = completions.map { CompletionDto(it.taskId, it.date.toString()) },
        focusRecords = focusRecords.map {
            FocusRecordDto(
                id = it.id,
                subjectId = it.subjectId,
                label = it.label,
                plannedSeconds = it.plannedSeconds,
                startedAtMillis = it.startedAtMillis,
                completedAtMillis = it.completedAtMillis,
            )
        },
        todos = todos.map {
            TodoDto(
                id = it.id,
                title = it.title,
                notes = it.notes,
                subjectId = it.subjectId,
                dueAt = it.dueAt?.toString(),
                done = it.done,
                alert = it.alert,
                reminderLeadMinutes = it.reminderLeadMinutes,
                alarmAtDue = it.alarmAtDue,
                sound = it.sound,
                alarmSlot = it.alarmSlot,
                reminderCustomAt = it.reminderCustomAt,
            )
        },
        settings = SettingsDto(
            focusMinutes = settings.focusMinutes,
            shortBreakMinutes = settings.shortBreakMinutes,
            longBreakMinutes = settings.longBreakMinutes,
            sessionsBeforeLongBreak = settings.sessionsBeforeLongBreak,
            firstDayOfWeek = settings.firstDayOfWeek.value,
        ),
    )

    private fun StudyFileDto.toDomain() = StudyData(
        subjects = subjects.map { Subject(it.id, it.name, it.colorIndex) },
        tasks = tasks.map { t ->
            StudyTask(
                id = t.id,
                title = t.title,
                notes = t.notes,
                subjectId = t.subjectId,
                firstDate = LocalDate.parse(t.firstDate),
                startMinute = t.startMinute,
                endMinute = t.endMinute,
                repeat = runCatching { TaskRepeat.valueOf(t.repeat) }.getOrDefault(TaskRepeat.NONE),
                weekdays = t.weekdays.mapNotNull { runCatching { DayOfWeek.of(it) }.getOrNull() }.toSet(),
                lastDate = t.lastDate?.let { LocalDate.parse(it) },
                category = t.category,
                animation = t.animation,
                alert = t.alert,
                reminderLeadMinutes = t.reminderLeadMinutes,
                alarmAtStart = t.alarmAtStart,
                sound = t.sound,
                alarmSlot = t.alarmSlot,
                reminderCustomAt = t.reminderCustomAt,
            )
        },
        categories = categories,
        nextAlarmSlot = nextAlarmSlot,
        completions = completions.map { Completion(it.taskId, LocalDate.parse(it.date)) }.toSet(),
        focusRecords = focusRecords.map {
            FocusRecord(
                id = it.id,
                subjectId = it.subjectId,
                label = it.label,
                plannedSeconds = it.plannedSeconds,
                startedAtMillis = it.startedAtMillis,
                completedAtMillis = it.completedAtMillis,
            )
        },
        todos = todos.map {
            TodoItem(
                id = it.id,
                title = it.title,
                notes = it.notes,
                subjectId = it.subjectId,
                dueAt = it.dueAt?.let { text -> LocalDateTime.parse(text) },
                done = it.done,
                alert = it.alert,
                reminderLeadMinutes = it.reminderLeadMinutes,
                alarmAtDue = it.alarmAtDue,
                sound = it.sound,
                alarmSlot = it.alarmSlot,
                reminderCustomAt = it.reminderCustomAt,
            )
        },
        settings = StudySettings(
            focusMinutes = settings.focusMinutes,
            shortBreakMinutes = settings.shortBreakMinutes,
            longBreakMinutes = settings.longBreakMinutes,
            sessionsBeforeLongBreak = settings.sessionsBeforeLongBreak,
            firstDayOfWeek = runCatching { DayOfWeek.of(settings.firstDayOfWeek) }
                .getOrDefault(DayOfWeek.MONDAY),
        ).clamped(),
    )
}
