// Part of Chronexa, a derivative of reReminder 4.0.1 — GNU GPL v3. See NOTICE.
package com.olaf.rereminder.ui.study.schedule

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Alarm
import androidx.compose.material.icons.rounded.ChevronLeft
import androidx.compose.material.icons.rounded.ChevronRight
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.olaf.rereminder.R
import com.olaf.rereminder.study.Completion
import com.olaf.rereminder.study.DaySummary
import com.olaf.rereminder.study.MINUTES_PER_DAY
import com.olaf.rereminder.study.Occurrence
import com.olaf.rereminder.study.StudyData
import com.olaf.rereminder.study.StudyStatus
import com.olaf.rereminder.study.StudyTask
import com.olaf.rereminder.study.Subject
import com.olaf.rereminder.study.TaskRepeat
import com.olaf.rereminder.study.conflictsFor
import com.olaf.rereminder.study.findOverlaps
import com.olaf.rereminder.study.isOverdue
import com.olaf.rereminder.study.occurrencesStartingOn
import com.olaf.rereminder.study.occurrencesTouching
import com.olaf.rereminder.study.summarizeDay
import com.olaf.rereminder.study.validationError
import com.olaf.rereminder.study.weekStart
import com.olaf.rereminder.ui.components.GlowCard
import com.olaf.rereminder.ui.components.revealOnEnter
import com.olaf.rereminder.ui.study.AnimatedCheckbox
import com.olaf.rereminder.ui.study.EmptyState
import com.olaf.rereminder.ui.study.ProgressRing
import com.olaf.rereminder.ui.study.StudyStatusBanner
import com.olaf.rereminder.ui.study.StudyViewModel
import com.olaf.rereminder.ui.study.StudyWarning
import com.olaf.rereminder.ui.study.SubjectTag
import com.olaf.rereminder.ui.study.accentFor
import com.olaf.rereminder.ui.study.clockLabel
import com.olaf.rereminder.ui.theme.Motion
import com.olaf.rereminder.ui.theme.pressScale
import com.olaf.rereminder.ui.study.pickers.DatePickerSheet
import com.olaf.rereminder.ui.study.pickers.PickerField
import com.olaf.rereminder.ui.study.pickers.TimePickerSheet
import com.olaf.rereminder.ui.study.pickers.formatPickedDate
import com.olaf.rereminder.ui.study.alarms.ReminderSection
import com.olaf.rereminder.ui.study.alarms.AlarmSoundSection
import com.olaf.rereminder.ui.study.alarms.shortMoment
import com.olaf.rereminder.study.reminderMomentFor
import com.olaf.rereminder.study.alarmMomentFor
import com.olaf.rereminder.ui.theme.ChronexaCyan
import com.olaf.rereminder.ui.theme.ChronexaViolet
import com.olaf.rereminder.service.ActivityAlarms
import com.olaf.rereminder.study.AlarmKind
import com.olaf.rereminder.study.DEFAULT_LEAD_MINUTES
import com.olaf.rereminder.study.nextActivityTrigger
import java.time.ZoneId
import com.olaf.rereminder.study.endMinuteFromPicker
import com.olaf.rereminder.study.endsNextDay
import com.olaf.rereminder.study.lengthMinutes
import com.olaf.rereminder.study.timeRangeIssue
import com.olaf.rereminder.ui.study.minutesLabel
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.format.TextStyle
import java.util.Locale

/**
 * Parses "HH:mm" into a minute of the day. For an end time, "00:00" means the end of the day, so a
 * task from 22:00 to 00:00 runs to midnight. Returns null for anything that is not a valid time.
 */
fun parseClock(text: String, isEnd: Boolean): Int? {
    val match = Regex("""(\d{1,2}):(\d{2})""").matchEntire(text.trim()) ?: return null
    val hours = match.groupValues[1].toInt()
    val minutes = match.groupValues[2].toInt()
    if (minutes !in 0..59 || hours !in 0..24) return null
    if (hours == 24 && minutes != 0) return null
    val total = hours * 60 + minutes
    return when {
        isEnd && total == 0 -> MINUTES_PER_DAY
        total >= MINUTES_PER_DAY && !(isEnd && total == MINUTES_PER_DAY) -> null
        else -> total
    }
}

private fun dayShort(day: DayOfWeek): String = day.getDisplayName(TextStyle.SHORT, Locale.getDefault())

@Composable
fun ScheduleRoute(
    onOpenAlarms: () -> Unit,
    viewModel: StudyViewModel = viewModel(),
) {
    val data by viewModel.data.collectAsStateWithLifecycle()
    val status by viewModel.status.collectAsStateWithLifecycle()
    val alarmReport by viewModel.alarmReport.collectAsStateWithLifecycle()
    var selected by remember { mutableStateOf(LocalDate.now()) }
    var editing by remember { mutableStateOf<StudyTask?>(null) }
    var showEditor by remember { mutableStateOf(false) }

    BackHandler(enabled = showEditor) { showEditor = false }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        floatingActionButton = {
            if (!showEditor) {
                ExtendedFloatingActionButton(
                    onClick = {
                        editing = null
                        showEditor = true
                    },
                    icon = { Icon(Icons.Rounded.Add, contentDescription = null) },
                    text = { Text(stringResource(R.string.schedule_add_task)) },
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = MaterialTheme.colorScheme.onPrimary,
                )
            }
        },
    ) { padding ->
        Box(modifier = Modifier.fillMaxSize().padding(padding)) {
            AnimatedVisibility(
                visible = !showEditor,
                enter = fadeIn(Motion.fade()),
                exit = fadeOut(Motion.fade()),
            ) {
                DayView(
                    data = data,
                    status = status,
                    date = selected,
                    onDateChange = { selected = it },
                    onOpenAlarms = onOpenAlarms,
                    onToggle = { task, day -> viewModel.toggleCompletion(task.id, day) },
                    onOpenTask = { task ->
                        editing = task
                        showEditor = true
                    },
                )
            }
            AnimatedVisibility(
                visible = showEditor,
                enter = fadeIn(Motion.screenEnter()) + slideInVertically(Motion.screenEnter()) { it / 6 },
                exit = fadeOut(Motion.screenExit()) + slideOutVertically(Motion.screenExit()) { it / 6 },
            ) {
                TaskEditor(
                    initial = editing,
                    initialDate = selected,
                    data = data,
                    report = alarmReport,
                    onSave = { task ->
                        val ok = viewModel.saveTask(task)
                        if (ok) showEditor = false
                        ok
                    },
                    onDelete = { id ->
                        viewModel.deleteTask(id)
                        showEditor = false
                    },
                    onClose = { showEditor = false },
                )
            }
        }
    }
}

@Composable
private fun DayView(
    data: StudyData,
    status: StudyStatus,
    date: LocalDate,
    onDateChange: (LocalDate) -> Unit,
    onOpenAlarms: () -> Unit,
    onToggle: (StudyTask, LocalDate) -> Unit,
    onOpenTask: (StudyTask) -> Unit,
) {
    val now = LocalDateTime.now()
    val starting = occurrencesStartingOn(data.tasks, date)
    val overlappingIds = findOverlaps(occurrencesTouching(data.tasks, date))
        .flatMap { listOf(it.first.task.id, it.second.task.id) }
        .toSet()
    val summary = summarizeDay(data.tasks, data.completions, date)

    LazyColumn(
        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        modifier = Modifier.fillMaxSize(),
    ) {
        item(key = "header") {
            Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = stringResource(R.string.schedule_title),
                    style = MaterialTheme.typography.headlineMedium,
                    color = MaterialTheme.colorScheme.onBackground,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.weight(1f),
                )
                IconButton(onClick = onOpenAlarms) {
                    Icon(
                        Icons.Rounded.Alarm,
                        contentDescription = stringResource(R.string.schedule_alarms_button),
                        tint = MaterialTheme.colorScheme.secondary,
                    )
                }
            }
        }

        if (status !is StudyStatus.Ready) {
            item(key = "status") { StudyStatusBanner(status) }
        }

        item(key = "week") {
            WeekStrip(selected = date, firstDay = data.settings.firstDayOfWeek, onSelect = onDateChange)
        }

        item(key = "summary") {
            SummaryCard(summary = summary, date = date)
        }

        if (starting.isEmpty()) {
            item(key = "empty") {
                EmptyState(
                    title = stringResource(R.string.schedule_empty_title),
                    body = stringResource(R.string.schedule_empty_body),
                )
            }
        } else {
            items(starting, key = { "${it.task.id}-${it.startAt}" }) { occurrence ->
                val completed = Completion(occurrence.task.id, date) in data.completions
                val subject = data.subjects.firstOrNull { it.id == occurrence.task.subjectId }
                val zone = ZoneId.systemDefault()
                val reminderLine = reminderMomentFor(occurrence.task, date, zone)
                    ?.let { stringResource(R.string.index_reminder, shortMoment(it)) }
                val alarmLine = alarmMomentFor(occurrence.task, date)
                    ?.let { stringResource(R.string.index_alarm, shortMoment(it)) }
                TaskRow(
                    reminderLine = reminderLine,
                    alarmLine = alarmLine,
                    occurrence = occurrence,
                    subject = subject,
                    completed = completed,
                    overlapping = occurrence.task.id in overlappingIds,
                    overdue = isOverdue(occurrence, completed, now),
                    onToggle = { onToggle(occurrence.task, date) },
                    onClick = { onOpenTask(occurrence.task) },
                )
            }
        }
    }
}

@Composable
private fun WeekStrip(selected: LocalDate, firstDay: DayOfWeek, onSelect: (LocalDate) -> Unit) {
    val start = weekStart(selected, firstDay)
    val today = LocalDate.now()
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(2.dp),
    ) {
        IconButton(onClick = { onSelect(selected.minusDays(7)) }) {
            Icon(Icons.Rounded.ChevronLeft, contentDescription = stringResource(R.string.schedule_previous_week))
        }
        for (offset in 0L..6L) {
            val day = start.plusDays(offset)
            DayChip(
                day = day,
                selected = day == selected,
                isToday = day == today,
                onClick = { onSelect(day) },
                modifier = Modifier.weight(1f),
            )
        }
        IconButton(onClick = { onSelect(selected.plusDays(7)) }) {
            Icon(Icons.Rounded.ChevronRight, contentDescription = stringResource(R.string.schedule_next_week))
        }
    }
}

@Composable
private fun DayChip(
    day: LocalDate,
    selected: Boolean,
    isToday: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val interaction = remember { MutableInteractionSource() }
    val background by animateColorAsState(
        targetValue = if (selected) MaterialTheme.colorScheme.primaryContainer else Color.Transparent,
        animationSpec = Motion.fade(),
        label = "dayBackground",
    )
    Column(
        modifier = modifier
            .pressScale(interaction, pressedScale = 0.92f)
            .clip(RoundedCornerShape(14.dp))
            .background(background)
            .clickable(interactionSource = interaction, indication = null, onClick = onClick)
            .padding(vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(
            text = dayShort(day.dayOfWeek),
            style = MaterialTheme.typography.labelSmall,
            color = if (isToday) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Text(
            text = day.dayOfMonth.toString(),
            style = MaterialTheme.typography.titleMedium,
            color = if (selected) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurface,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
        )
    }
}

@Composable
private fun SummaryCard(summary: DaySummary, date: LocalDate) {
    GlowCard(glow = MaterialTheme.colorScheme.primary, modifier = Modifier.revealOnEnter()) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(16.dp)) {
            ProgressRing(
                progress = summary.percent / 100f,
                modifier = Modifier.size(72.dp),
                strokeWidth = 7.dp,
                color = MaterialTheme.colorScheme.primary,
            ) {
                Text(
                    text = "${summary.percent}%",
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.onSurface,
                    fontWeight = FontWeight.SemiBold,
                )
            }
            Column {
                Text(
                    text = stringResource(R.string.schedule_done_summary, summary.completed, summary.total),
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onSurface,
                )
                Text(
                    text = date.toString(),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
    }
}

@Composable
private fun TaskRow(
    reminderLine: String?,
    alarmLine: String?,
    occurrence: Occurrence,
    subject: Subject?,
    completed: Boolean,
    overlapping: Boolean,
    overdue: Boolean,
    onToggle: () -> Unit,
    onClick: () -> Unit,
) {
    val task = occurrence.task
    val accent = subject?.let { accentFor(it.colorIndex) } ?: MaterialTheme.colorScheme.primary
    val timeText = "${clockLabel(task.startMinute)} – ${clockLabel(task.endMinute)}" +
        if (task.crossesMidnight) " " + stringResource(R.string.schedule_next_day) else ""
    GlowCard(glow = accent, onClick = onClick, modifier = Modifier.revealOnEnter()) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            AnimatedCheckbox(
                checked = completed,
                onCheckedChange = { onToggle() },
                description = stringResource(R.string.schedule_complete_description, task.title),
                accent = accent,
            )
            Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(
                    text = timeText,
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.secondary,
                    fontWeight = FontWeight.SemiBold,
                )
                Text(
                    text = task.title,
                    style = MaterialTheme.typography.titleMedium,
                    color = if (completed) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.onSurface,
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    if (subject != null) SubjectTag(subject.name, accent)
                    if (overdue) {
                        Text(
                            text = stringResource(R.string.schedule_overdue),
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.error,
                        )
                    }
                }
                if (reminderLine != null) {
                    Text(text = reminderLine, style = MaterialTheme.typography.bodySmall, color = ChronexaCyan)
                }
                if (alarmLine != null) {
                    Text(text = alarmLine, style = MaterialTheme.typography.bodySmall, color = ChronexaViolet)
                }
                if (overlapping) {
                    Text(
                        text = stringResource(R.string.schedule_overlap_warning),
                        style = MaterialTheme.typography.labelSmall,
                        color = StudyWarning,
                    )
                }
            }
        }
    }
}

private enum class EditorPicker { DATE, START, END, UNTIL }

/**
 * Create, edit, reschedule or delete one task. Dates and times come from pickers, so a bad value
 * cannot be typed. Overlaps only warn; nothing is moved or blocked because of them.
 */
@Composable
private fun TaskEditor(
    initial: StudyTask?,
    initialDate: LocalDate,
    data: StudyData,
    report: List<ActivityAlarms.Entry>,
    onSave: (StudyTask) -> Boolean,
    onDelete: (Long) -> Unit,
    onClose: () -> Unit,
) {
    var title by remember(initial) { mutableStateOf(initial?.title ?: "") }
    var notes by remember(initial) { mutableStateOf(initial?.notes ?: "") }
    var subjectId by remember(initial) { mutableStateOf(initial?.subjectId) }
    var date by remember(initial) { mutableStateOf(initial?.firstDate ?: initialDate) }
    var startMinute by remember(initial) { mutableStateOf(initial?.startMinute ?: 9 * 60) }
    // The picker shows 00:00–23:59. A stored end of 1440 (midnight) is shown as 00:00.
    var pickedEnd by remember(initial) {
        mutableStateOf(initial?.endMinute?.let { if (it >= MINUTES_PER_DAY) 0 else it } ?: 10 * 60)
    }
    var repeat by remember(initial) { mutableStateOf(initial?.repeat ?: TaskRepeat.NONE) }
    var weekdays by remember(initial) { mutableStateOf(initial?.weekdays ?: emptySet()) }
    var untilDate by remember(initial) { mutableStateOf(initial?.lastDate) }
    var remind by remember(initial) { mutableStateOf(initial?.alert ?: false) }
    var leadMinutes by remember(initial) { mutableStateOf(initial?.reminderLeadMinutes ?: DEFAULT_LEAD_MINUTES) }
    var alarmOn by remember(initial) { mutableStateOf(initial?.alarmAtStart ?: false) }
    var customAt by remember(initial) { mutableStateOf(initial?.reminderCustomAt) }
    var soundOn by remember(initial) { mutableStateOf(initial?.alarmSoundOn ?: true) }
    var soundRef by remember(initial) { mutableStateOf(initial?.sound ?: "default") }
    var soundName by remember(initial) { mutableStateOf(initial?.soundName ?: "") }
    var confirmDelete by remember { mutableStateOf(false) }
    var picker by remember { mutableStateOf<EditorPicker?>(null) }

    val timeIssue = timeRangeIssue(startMinute, pickedEnd)
    val endMinute = endMinuteFromPicker(pickedEnd, startMinute)
    val candidate: StudyTask? = if (timeIssue == null) {
        StudyTask(
            id = initial?.id ?: 0L,
            title = title.trim(),
            notes = notes.trim(),
            subjectId = subjectId,
            firstDate = date,
            startMinute = startMinute,
            endMinute = endMinute,
            repeat = repeat,
            weekdays = if (repeat == TaskRepeat.WEEKLY) weekdays else emptySet(),
            lastDate = if (repeat == TaskRepeat.NONE) null else untilDate,
            alert = remind,
            reminderLeadMinutes = leadMinutes,
            alarmAtStart = alarmOn,
            alarmSlot = initial?.alarmSlot ?: 0,
            reminderCustomAt = customAt,
            alarmSoundOn = soundOn,
            sound = soundRef,
            soundName = soundName,
        )
    } else {
        null
    }
    val errorKey: String? = timeIssue ?: candidate?.validationError()
    val conflicts = if (candidate != null && errorKey == null) {
        conflictsFor(candidate, date, data.tasks)
    } else {
        emptyList()
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onClose) {
                Icon(Icons.Rounded.Close, contentDescription = stringResource(R.string.editor_close))
            }
            Text(
                text = stringResource(if (initial == null) R.string.task_new_title else R.string.task_edit_title),
                style = MaterialTheme.typography.headlineSmall,
                color = MaterialTheme.colorScheme.onBackground,
                fontWeight = FontWeight.SemiBold,
            )
        }

        OutlinedTextField(
            value = title,
            onValueChange = { title = it.take(80) },
            label = { Text(stringResource(R.string.editor_title_label)) },
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
        )
        OutlinedTextField(
            value = notes,
            onValueChange = { notes = it.take(500) },
            label = { Text(stringResource(R.string.editor_notes_label)) },
            minLines = 2,
            modifier = Modifier.fillMaxWidth(),
        )

        Text(
            text = stringResource(R.string.editor_subject_label),
            style = MaterialTheme.typography.labelLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(
                selected = subjectId == null,
                onClick = { subjectId = null },
                label = { Text(stringResource(R.string.editor_subject_none)) },
            )
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            data.subjects.forEach { s ->
                FilterChip(
                    selected = subjectId == s.id,
                    onClick = { subjectId = s.id },
                    label = { Text(s.name) },
                )
            }
        }

        Text(
            text = stringResource(R.string.picker_when_heading),
            style = MaterialTheme.typography.labelLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            PickerField(
                label = stringResource(R.string.picker_date_label),
                value = formatPickedDate(date),
                onClick = { picker = EditorPicker.DATE },
                modifier = Modifier.weight(1f),
            )
            OutlinedButton(onClick = { date = LocalDate.now() }) {
                Text(stringResource(R.string.editor_today))
            }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            PickerField(
                label = stringResource(R.string.picker_start_label),
                value = clockLabel(startMinute),
                onClick = { picker = EditorPicker.START },
                modifier = Modifier.weight(1f),
            )
            PickerField(
                label = stringResource(R.string.picker_end_label),
                value = clockLabel(pickedEnd),
                onClick = { picker = EditorPicker.END },
                isError = timeIssue != null,
                modifier = Modifier.weight(1f),
            )
        }
        when {
            timeIssue != null -> Text(
                text = stringResource(errorMessageRes(timeIssue)),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.error,
            )
            else -> {
                val length = lengthMinutes(startMinute, endMinute)
                val lengthText = stringResource(R.string.picker_length, minutesLabel(length.toLong()))
                Text(
                    text = if (endsNextDay(startMinute, endMinute)) {
                        lengthText + " · " + stringResource(R.string.picker_next_day)
                    } else {
                        lengthText
                    },
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }

        AlarmSoundSection(
            soundOn = soundOn,
            onSoundOn = { soundOn = it },
            soundRef = soundRef,
            soundName = soundName,
            onChosen = { ref, name ->
                soundRef = ref
                soundName = name
            },
        )

        val repeatContent: @Composable () -> Unit = {
        Text(
            text = stringResource(R.string.editor_repeat_label),
            style = MaterialTheme.typography.labelLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            RepeatChip(TaskRepeat.NONE, R.string.editor_repeat_once, repeat) { repeat = it }
            RepeatChip(TaskRepeat.DAILY, R.string.editor_repeat_daily, repeat) { repeat = it }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            RepeatChip(TaskRepeat.WEEKDAYS, R.string.editor_repeat_weekdays, repeat) { repeat = it }
            RepeatChip(TaskRepeat.WEEKLY, R.string.editor_repeat_weekly, repeat) { repeat = it }
        }

        if (repeat == TaskRepeat.WEEKLY) {
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                DayOfWeek.values().forEach { day ->
                    FilterChip(
                        selected = day in weekdays,
                        onClick = {
                            weekdays = if (day in weekdays) weekdays - day else weekdays + day
                        },
                        label = { Text(dayShort(day)) },
                    )
                }
            }
        }

        if (repeat != TaskRepeat.NONE) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                PickerField(
                    label = stringResource(R.string.picker_until_label),
                    value = untilDate?.let { formatPickedDate(it) } ?: stringResource(R.string.picker_until_none),
                    onClick = { picker = EditorPicker.UNTIL },
                    modifier = Modifier.weight(1f),
                )
                if (untilDate != null) {
                    TextButton(onClick = { untilDate = null }) {
                        Text(stringResource(R.string.picker_clear))
                    }
                }
            }
        }
        }

        ReminderSection(
            hasTime = true,
            needsTimeText = stringResource(R.string.alarm_needs_time),
            remind = remind,
            onRemind = { remind = it },
            leadMinutes = leadMinutes,
            onLead = { leadMinutes = it },
            customAt = customAt,
            onCustomAt = { customAt = it },
            alarmOn = alarmOn,
            onAlarm = { alarmOn = it },
            startText = formatPickedDate(date) + " " + clockLabel(startMinute),
            previewReminder = candidate?.let { nextActivityTrigger(it, AlarmKind.REMINDER, System.currentTimeMillis(), ZoneId.systemDefault()) },
            previewAlarm = candidate?.let { nextActivityTrigger(it, AlarmKind.ALARM, System.currentTimeMillis(), ZoneId.systemDefault()) },
            repeatContent = repeatContent,
            report = report.filter { it.itemId == initial?.id && initial != null },
        )

        if (timeIssue == null && errorKey != null) {
            Text(
                text = stringResource(errorMessageRes(errorKey)),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.error,
            )
        }

        conflicts.forEach { c ->
            Text(
                text = stringResource(
                    R.string.editor_conflict_line,
                    c.task.title,
                    clockLabel(c.task.startMinute),
                    clockLabel(c.task.endMinute),
                ),
                style = MaterialTheme.typography.bodySmall,
                color = StudyWarning,
            )
        }

        Row(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
            androidx.compose.material3.Button(
                onClick = { candidate?.let { onSave(it) } },
                enabled = errorKey == null && candidate != null,
            ) {
                Text(stringResource(R.string.editor_save))
            }
            if (initial != null) {
                OutlinedButton(onClick = { confirmDelete = true }) {
                    Icon(Icons.Rounded.Delete, contentDescription = null, modifier = Modifier.size(18.dp))
                    Text(stringResource(R.string.task_delete))
                }
            }
        }
    }

    when (picker) {
        EditorPicker.DATE -> DatePickerSheet(
            initial = date,
            onConfirm = { date = it; picker = null },
            onDismiss = { picker = null },
        )
        EditorPicker.START -> TimePickerSheet(
            title = stringResource(R.string.picker_start_title),
            initialMinute = startMinute,
            onConfirm = { startMinute = it; picker = null },
            onDismiss = { picker = null },
        )
        EditorPicker.END -> TimePickerSheet(
            title = stringResource(R.string.picker_end_title),
            initialMinute = pickedEnd,
            onConfirm = { pickedEnd = it; picker = null },
            onDismiss = { picker = null },
        )
        EditorPicker.UNTIL -> DatePickerSheet(
            initial = untilDate ?: date,
            onConfirm = { untilDate = it; picker = null },
            onDismiss = { picker = null },
        )
        null -> Unit
    }

    if (confirmDelete && initial != null) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text(stringResource(R.string.task_delete_confirm_title)) },
            text = { Text(stringResource(R.string.editor_delete_confirm_body)) },
            confirmButton = {
                TextButton(onClick = {
                    confirmDelete = false
                    onDelete(initial.id)
                }) { Text(stringResource(R.string.common_delete)) }
            },
            dismissButton = {
                TextButton(onClick = { confirmDelete = false }) { Text(stringResource(R.string.common_cancel)) }
            },
        )
    }
}

@Composable
private fun RepeatChip(
    value: TaskRepeat,
    labelRes: Int,
    selected: TaskRepeat,
    onSelect: (TaskRepeat) -> Unit,
) {
    FilterChip(
        selected = selected == value,
        onClick = { onSelect(value) },
        label = { Text(stringResource(labelRes)) },
    )
}

private fun errorMessageRes(key: String): Int = when (key) {
    "title_required" -> R.string.error_title_required
    "zero_length" -> R.string.error_zero_length
    "weekday_required" -> R.string.error_weekday_required
    "last_before_first" -> R.string.error_last_before_first
    "invalid_date" -> R.string.error_invalid_date
    "invalid_time", "time_out_of_range" -> R.string.error_invalid_time
    else -> R.string.error_invalid_time
}
