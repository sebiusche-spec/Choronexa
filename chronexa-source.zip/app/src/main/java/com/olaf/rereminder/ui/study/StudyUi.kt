// Part of Chronexa, a derivative of reReminder 4.0.1 — GNU GPL v3. See NOTICE.
package com.olaf.rereminder.ui.study

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.role
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.olaf.rereminder.ui.theme.Motion
import com.olaf.rereminder.ui.theme.ReminderAccents
import com.olaf.rereminder.ui.theme.pressScale

/** "05:10" for a minute of the day. 1440 reads as "24:00", the end of a day. */
fun clockLabel(minute: Int): String = com.olaf.rereminder.study.clock12Hour(minute)

/** "25 min" or "1 h 05 min". */
fun minutesLabel(totalMinutes: Long): String {
    val h = totalMinutes / 60
    val m = totalMinutes % 60
    return if (h == 0L) "$m min" else String.format("%d h %02d min", h, m)
}

fun accentFor(index: Int): Color = ReminderAccents[index.mod(ReminderAccents.size)]

/** A circular progress ring. The sweep animates whenever [progress] changes. */
@Composable
fun ProgressRing(
    progress: Float,
    modifier: Modifier = Modifier,
    strokeWidth: Dp = 10.dp,
    color: Color = MaterialTheme.colorScheme.primary,
    trackColor: Color = MaterialTheme.colorScheme.surfaceVariant,
    content: @Composable () -> Unit = {},
) {
    val animated by animateFloatAsState(
        targetValue = progress.coerceIn(0f, 1f),
        animationSpec = Motion.spatial(),
        label = "ring",
    )
    Box(modifier = modifier, contentAlignment = Alignment.Center) {
        Canvas(modifier = Modifier.matchParentSize()) {
            val stroke = strokeWidth.toPx()
            val inset = stroke / 2f
            val arc = Size(size.width - stroke, size.height - stroke)
            drawArc(
                color = trackColor,
                startAngle = -90f,
                sweepAngle = 360f,
                useCenter = false,
                topLeft = Offset(inset, inset),
                size = arc,
                style = Stroke(width = stroke),
            )
            if (animated > 0f) {
                drawArc(
                    color = color,
                    startAngle = -90f,
                    sweepAngle = 360f * animated,
                    useCenter = false,
                    topLeft = Offset(inset, inset),
                    size = arc,
                    style = Stroke(width = stroke, cap = StrokeCap.Round),
                )
            }
        }
        content()
    }
}

/**
 * A completion checkbox. The box fills with the accent colour and a tick scales in. A press
 * shrinks it briefly. Nothing here waits on the database; the state comes from the caller.
 */
@Composable
fun AnimatedCheckbox(
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    description: String,
    accent: Color,
    modifier: Modifier = Modifier,
) {
    val interaction = remember { MutableInteractionSource() }
    val fill by animateColorAsState(
        targetValue = if (checked) accent else Color.Transparent,
        animationSpec = Motion.fade(),
        label = "checkFill",
    )
    val border by animateColorAsState(
        targetValue = if (checked) accent else MaterialTheme.colorScheme.outline,
        animationSpec = Motion.fade(),
        label = "checkBorder",
    )
    Box(
        modifier = modifier
            .size(32.dp)
            .pressScale(interaction, pressedScale = 0.86f)
            .clip(CircleShape)
            .background(fill)
            .border(2.dp, border, CircleShape)
            .clickable(
                interactionSource = interaction,
                indication = null,
                role = Role.Checkbox,
                onClick = { onCheckedChange(!checked) },
            )
            .semantics(mergeDescendants = true) {
                role = Role.Checkbox
                contentDescription = description
            },
        contentAlignment = Alignment.Center,
    ) {
        AnimatedVisibility(
            visible = checked,
            enter = scaleIn(Motion.expressive()) + fadeIn(Motion.fade()),
            exit = scaleOut(Motion.snappy()) + fadeOut(Motion.fade()),
        ) {
            Icon(
                imageVector = Icons.Rounded.Check,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.surface,
                modifier = Modifier.size(18.dp),
            )
        }
    }
}

@Composable
fun EmptyState(title: String, body: String, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier.fillMaxWidth().padding(vertical = 28.dp, horizontal = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        Text(
            text = title,
            style = MaterialTheme.typography.titleMedium,
            color = MaterialTheme.colorScheme.onSurface,
            fontWeight = FontWeight.SemiBold,
        )
        Text(
            text = body,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

/** A small rounded tag in a subject's accent colour. */
@Composable
fun SubjectTag(name: String, color: Color, modifier: Modifier = Modifier) {
    Row(
        modifier = modifier
            .clip(CircleShape)
            .background(color.copy(alpha = 0.16f))
            .padding(horizontal = 10.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        Box(Modifier.size(8.dp).clip(CircleShape).background(color))
        Text(
            text = name,
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurface,
            fontSize = 12.sp,
        )
    }
}

/** Amber for overlap and other "check this" notes. Never used for errors. */
val StudyWarning = androidx.compose.ui.graphics.Color(0xFFFFBF47)

/** Shown above study screens when data is read-only, recovered or could not be saved. */
@Composable
fun StudyStatusBanner(status: com.olaf.rereminder.study.StudyStatus) {
    val text = when (status) {
        is com.olaf.rereminder.study.StudyStatus.Ready -> return
        is com.olaf.rereminder.study.StudyStatus.ReadOnly ->
            androidx.compose.ui.res.stringResource(com.olaf.rereminder.R.string.study_status_readonly, status.version)
        is com.olaf.rereminder.study.StudyStatus.Recovered ->
            androidx.compose.ui.res.stringResource(com.olaf.rereminder.R.string.study_status_recovered, status.preservedAs)
        is com.olaf.rereminder.study.StudyStatus.Unavailable ->
            androidx.compose.ui.res.stringResource(com.olaf.rereminder.R.string.study_status_unavailable, status.message)
    }
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(androidx.compose.foundation.shape.RoundedCornerShape(14.dp))
            .background(StudyWarning.copy(alpha = 0.14f))
            .padding(horizontal = 14.dp, vertical = 10.dp),
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurface,
        )
    }
}
