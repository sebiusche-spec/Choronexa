// Part of Chronexa, a derivative of reReminder 4.0.1 — GNU GPL v3. See NOTICE.
package com.olaf.rereminder.ui.study.alarms

import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.net.Uri
import android.provider.OpenableColumns
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.olaf.rereminder.R
import com.olaf.rereminder.study.AlarmSoundRef
import com.olaf.rereminder.study.parseSoundRef
import com.olaf.rereminder.ui.components.GlowCard
import com.olaf.rereminder.ui.theme.ChronexaViolet
import com.olaf.rereminder.utils.AlertPlayer
import com.olaf.rereminder.utils.AlertSound

/** The audio file's name, from the system, or a plain fallback. */
private fun displayName(context: Context, uri: Uri): String = runCatching {
    context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
        if (cursor.moveToFirst()) cursor.getString(0) else null
    }
}.getOrNull() ?: uri.lastPathSegment.orEmpty()

/** Whether the app can still open a chosen file. A moved, deleted or de-permitted file cannot. */
private fun canOpen(context: Context, uri: Uri): Boolean = runCatching {
    context.contentResolver.openInputStream(uri)?.use { it.read() >= -1 } ?: false
}.getOrDefault(false)

/**
 * "🎵 Audio & Alarm Sound": the sound an activity's alarm plays. The chosen file is picked with the
 * system document picker, read in place (not copied), and kept with a read permission that survives
 * restarts. Anything unavailable falls back to the default alarm sound.
 *
 * [soundRef] is the stored sound text: "default", "silent", or a content URI. [onChosen] receives the
 * new URI (or "default" for a reset) and the file's name.
 */
@Composable
fun AlarmSoundSection(
    soundOn: Boolean,
    onSoundOn: (Boolean) -> Unit,
    soundRef: String,
    soundName: String,
    onChosen: (String, String) -> Unit,
) {
    val context = LocalContext.current
    val choice = parseSoundRef(soundRef)
    var previewing by remember { mutableStateOf(false) }
    var previewProblem by remember { mutableStateOf(false) }
    val player = remember(context) {
        AlertPlayer(context, AudioAttributes.USAGE_ALARM, loop = false, maxMillis = PREVIEW_MILLIS)
    }
    DisposableEffect(player) {
        onDispose { player.stop() }
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            // Keep read access across restarts. Some providers refuse; the file then falls back safely later.
            runCatching {
                context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            onChosen(uri.toString(), displayName(context, uri))
        }
    }

    GlowCard(glow = ChronexaViolet) {
        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text(
                text = stringResource(R.string.sound_section_title),
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onSurface,
                fontWeight = FontWeight.SemiBold,
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = stringResource(R.string.sound_enable),
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.weight(1f),
                )
                Switch(checked = soundOn, onCheckedChange = {
                    player.stop()
                    previewing = false
                    onSoundOn(it)
                })
            }

            Text(
                text = when (choice) {
                    is AlarmSoundRef.Custom -> stringResource(
                        R.string.sound_current_file,
                        soundName.ifEmpty { stringResource(R.string.sound_custom_unnamed) },
                    )
                    else -> stringResource(R.string.sound_current_default)
                },
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            if (previewProblem) {
                Text(
                    text = stringResource(R.string.sound_unavailable),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.error,
                )
            }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { picker.launch(arrayOf("audio/*")) }) {
                    Text(stringResource(R.string.sound_choose))
                }
                OutlinedButton(onClick = {
                    if (previewing) {
                        player.stop()
                        previewing = false
                    } else {
                        previewProblem = false
                        val sound = when (choice) {
                            AlarmSoundRef.Silent -> AlertSound.Silent
                            AlarmSoundRef.DefaultTone -> AlertSound.Tone(null)
                            is AlarmSoundRef.Custom -> {
                                val uri = Uri.parse(choice.uri)
                                if (canOpen(context, uri)) {
                                    AlertSound.Tone(uri)
                                } else {
                                    previewProblem = true
                                    AlertSound.Tone(null)
                                }
                            }
                        }
                        previewing = true
                        player.play(sound, null) { previewing = false }
                    }
                }) {
                    Text(
                        stringResource(
                            if (previewing) R.string.alarm_sound_preview_stop else R.string.alarm_sound_preview,
                        ),
                    )
                }
            }
            if (choice is AlarmSoundRef.Custom) {
                TextButton(onClick = {
                    player.stop()
                    previewing = false
                    onChosen("default", "")
                }) {
                    Text(stringResource(R.string.sound_reset))
                }
            }
            Text(
                text = stringResource(R.string.sound_note),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

private const val PREVIEW_MILLIS = 8_000L
