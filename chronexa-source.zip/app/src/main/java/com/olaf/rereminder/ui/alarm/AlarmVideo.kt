// Part of Chronexa, a derivative of reReminder 4.0.1 — GNU GPL v3. See NOTICE.
package com.olaf.rereminder.ui.alarm

import android.graphics.Matrix
import android.graphics.SurfaceTexture
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.net.Uri
import android.view.Surface
import android.view.TextureView
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import com.olaf.rereminder.data.VideoPlayback
import com.olaf.rereminder.data.videoScale
import com.olaf.rereminder.service.AlarmService

/**
 * The alarm's video, full-screen behind the alarm controls, with a dark scrim so the text stays readable.
 *
 * FIT shows the whole video and FILL covers the screen and crops; both keep the video's aspect ratio. The scale
 * is applied once the real video size is known and again whenever the view changes size.
 *
 * It plays once per alarm: the player is created the first time a surface exists, and released when this leaves
 * the screen (dismissed, snoozed, or failed). A failure is reported to the ringing service, which starts the
 * ringtone if the video was standing in for it, so the alarm still rings.
 */
@Composable
fun AlarmVideo(play: VideoPlayback.Play, alarmKey: Long, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    var surface by remember { mutableStateOf<Surface?>(null) }
    val player = remember { arrayOfNulls<MediaPlayer>(1) }
    val view = remember { arrayOfNulls<TextureView>(1) }
    val size = remember { IntArray(2) } // the video's width and height, once known

    fun applyScale() {
        val target = view[0] ?: return
        if (size[0] <= 0 || size[1] <= 0) return
        val (sx, sy) = videoScale(target.width, target.height, size[0], size[1], play.fill)
        val matrix = Matrix()
        matrix.setScale(sx, sy, target.width / 2f, target.height / 2f)
        target.setTransform(matrix)
    }

    AndroidView(
        modifier = modifier,
        factory = { ctx ->
            TextureView(ctx).also { textureView ->
                view[0] = textureView
                textureView.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ -> applyScale() }
                textureView.surfaceTextureListener = object : TextureView.SurfaceTextureListener {
                    override fun onSurfaceTextureAvailable(texture: SurfaceTexture, width: Int, height: Int) {
                        surface = Surface(texture)
                    }

                    override fun onSurfaceTextureSizeChanged(texture: SurfaceTexture, width: Int, height: Int) = Unit

                    override fun onSurfaceTextureDestroyed(texture: SurfaceTexture): Boolean {
                        surface?.release()
                        surface = null
                        return true
                    }

                    override fun onSurfaceTextureUpdated(texture: SurfaceTexture) = Unit
                }
            }
        },
    )

    // The display mode can change while the alarm is showing; reapply the scale straight away.
    LaunchedEffect(play.fill) { applyScale() }

    LaunchedEffect(surface, play, alarmKey) {
        val target = surface ?: return@LaunchedEffect
        // Once per alarm: a recomposition or a repeated delivery must not start a second player.
        if (player[0] != null) return@LaunchedEffect
        val media = MediaPlayer()
        player[0] = media
        val videoVolume = if (play.playVideoAudio) play.volumePercent / 100f else 0f
        try {
            media.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MOVIE)
                    .build(),
            )
            media.setDataSource(context, Uri.parse(play.uri))
            media.setSurface(target)
            media.isLooping = play.loop
            media.setVolume(videoVolume, videoVolume)
            media.setOnVideoSizeChangedListener { _, width, height ->
                size[0] = width
                size[1] = height
                applyScale()
            }
            media.setOnPreparedListener { it.start() }
            media.setOnErrorListener { _, _, _ ->
                AlarmService.reportVideoFailed(context)
                true
            }
            media.prepareAsync()
        } catch (e: Exception) {
            AlarmService.reportVideoFailed(context)
        }
    }

    // Release the player as soon as the video leaves the screen, so nothing keeps playing after dismiss or snooze.
    DisposableEffect(alarmKey) {
        onDispose {
            player[0]?.let {
                runCatching { it.stop() }
                runCatching { it.release() }
            }
            player[0] = null
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(listOf(Color.Black.copy(alpha = 0.08f), Color.Black.copy(alpha = 0.6f))),
            ),
    )
}
