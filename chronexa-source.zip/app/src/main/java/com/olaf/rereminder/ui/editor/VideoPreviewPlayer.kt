// Part of Chronexa, a derivative of reReminder 4.0.1 — GNU GPL v3. See NOTICE.
package com.olaf.rereminder.ui.editor

import android.graphics.Matrix
import android.graphics.SurfaceTexture
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.net.Uri
import android.util.Log
import android.view.Surface
import android.view.TextureView
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.olaf.rereminder.R
import com.olaf.rereminder.data.VideoDisplayMode
import com.olaf.rereminder.data.videoScaleFor

private const val PREVIEW_TAG = "VideoPreview"

/**
 * The alarm's video in the editor, shown as it will be shown when the alarm rings: the same display mode, the same
 * player and the same surface handling. While the video prepares, a loading indicator shows; if it cannot be read or
 * decoded, a readable message shows instead of a black area.
 */
@Composable
fun VideoPreviewPlayer(
    uri: String,
    loop: Boolean,
    mode: VideoDisplayMode,
    onError: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val context = LocalContext.current
    var surface by remember(uri) { mutableStateOf<Surface?>(null) }
    var ready by remember(uri) { mutableStateOf(false) }
    var failed by remember(uri) { mutableStateOf(false) }
    val player = remember(uri) { arrayOfNulls<MediaPlayer>(1) }
    val view = remember(uri) { arrayOfNulls<TextureView>(1) }
    val size = remember(uri) { IntArray(2) }

    fun applyScale() {
        val target = view[0] ?: return
        if (size[0] <= 0 || size[1] <= 0 || target.width <= 0 || target.height <= 0) return
        val (sx, sy) = videoScaleFor(target.width, target.height, size[0], size[1], mode)
        val matrix = Matrix()
        matrix.setScale(sx, sy, target.width / 2f, target.height / 2f)
        target.setTransform(matrix)
    }

    Box(modifier = modifier.background(Color.Black)) {
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { ctx ->
                TextureView(ctx).also { textureView ->
                    view[0] = textureView
                    textureView.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ -> applyScale() }
                    textureView.surfaceTextureListener = object : TextureView.SurfaceTextureListener {
                        override fun onSurfaceTextureAvailable(texture: SurfaceTexture, width: Int, height: Int) {
                            surface = Surface(texture)
                        }

                        override fun onSurfaceTextureSizeChanged(texture: SurfaceTexture, width: Int, height: Int) = Unit

                        override fun onSurfaceTextureDestroyed(texture: SurfaceTexture): Boolean {
                            surface?.release()
                            surface = null
                            return true
                        }

                        override fun onSurfaceTextureUpdated(texture: SurfaceTexture) = Unit
                    }
                }
            },
        )
        if (!ready && !failed) {
            CircularProgressIndicator(modifier = Modifier.align(Alignment.Center))
        }
        if (failed) {
            Text(
                text = stringResource(R.string.video_preview_error),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.error,
                modifier = Modifier.align(Alignment.Center).padding(16.dp),
            )
        }
    }

    LaunchedEffect(mode) { applyScale() }

    LaunchedEffect(surface, uri, loop) {
        val target = surface ?: return@LaunchedEffect
        if (player[0] != null) return@LaunchedEffect
        val media = MediaPlayer()
        player[0] = media
        try {
            media.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MOVIE)
                    .build(),
            )
            media.setDataSource(context, Uri.parse(uri))
            media.setSurface(target)
            media.isLooping = loop
            media.setOnVideoSizeChangedListener { _, width, height ->
                size[0] = width
                size[1] = height
                applyScale()
            }
            media.setOnPreparedListener {
                ready = true
                Log.i(PREVIEW_TAG, "Preview prepared; playing")
                it.start()
            }
            media.setOnErrorListener { _, what, _ ->
                // The URI is not logged: only the decoder's error code, which says nothing about the file's contents.
                Log.w(PREVIEW_TAG, "Preview playback failed (code $what)")
                failed = true
                onError()
                true
            }
            media.prepareAsync()
        } catch (e: Exception) {
            Log.w(PREVIEW_TAG, "Preview could not open the video: ${e.javaClass.simpleName}")
            failed = true
            onError()
        }
    }

    DisposableEffect(uri) {
        onDispose {
            player[0]?.let {
                runCatching { it.stop() }
                runCatching { it.release() }
            }
            player[0] = null
        }
    }
}
