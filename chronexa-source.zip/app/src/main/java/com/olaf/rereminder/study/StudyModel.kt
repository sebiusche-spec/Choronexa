// Part of Chronexa, a derivative of reReminder 4.0.1 — GNU GPL v3. See NOTICE.
package com.olaf.rereminder.study

import java.time.DayOfWeek
import java.time.LocalDate
import java.time.LocalDateTime

/** Minutes in a day. Times are stored as minutes from local midnight, so 05:10 is 310. */
const val MINUTES_PER_DAY = 24 * 60

data class Subject(val id: Long, val name: String, val colorIndex: Int)

private val DEFAULT_SUBJECT_NAMES = listOf("Physics", "Chemistry", "Mathematics", "Computer Science", "English")

fun defaultSubjects(): List<Subject> = DEFAULT_SUBJECT_NAMES.mapIndexed { index, name ->
    Subject(id = index + 1L, name = name, colorIndex = index)
}

enum class TaskRepeat { NONE, DAILY, WEEKDAYS, WEEKLY }

/**
 * A study task: a time slot on one date, optionally repeating.
 *
 * [startMinute] is inclusive and [endMinute] exclusive. If [endMinute] is not after [startMinute]
 * the task runs past midnight and ends on the following day. 1440 means "until midnight".
 */
data class StudyTask(
    val id: Long,
    val title: String,
    val notes: String = "",
    val subjectId: Long? = null,
    val firstDate: LocalDate,
    val startMinute: Int,
    val endMinute: Int,
    val repeat: TaskRepeat = TaskRepeat.NONE,
    /** Used by [TaskRepeat.WEEKLY] only. Empty means the weekday of [firstDate]. */
    val weekdays: Set<DayOfWeek> = emptySet(),
    /** Last date a repeating task may occur on. Null means it repeats indefinitely. */
    val lastDate: LocalDate? = null,
    /** Built-in category id (see [BUILT_IN_CATEGORIES]) or a custom category name. */
    val category: String = "other",
    /** "auto", "none", or an animation key. Visual only. */
    val animation: String = "auto",
    /**
     * Whether the user wants a reminder for this activity. Stored only in this stage; no alarm is
     * scheduled from it yet (see docs/ANDROID_INTEGRATION_PLAN.md, stage 4).
     */
    val alert: Boolean = false,
    /** Minutes before the start that the reminder fires. 0 means at the start. Used when [alert] is on. */
    val reminderLeadMinutes: Int = 5,
    /** An alarm at the start time, in addition to the reminder. */
    val alarmAtStart: Boolean = false,
    /** Notification sound. Only "default" is supported; reserved for per-activity sounds later. */
    val sound: String = "default",
    /** Stable number that identifies this activity's scheduled alarms. 0 means none allocated yet. */
    val alarmSlot: Int = 0,
    /** A chosen reminder date and time. When set, it replaces the lead time and fires once. */
    val reminderCustomAt: Long? = null,
    /** Whether the alarm plays a sound at all. Turning it off keeps the chosen file. */
    val alarmSoundOn: Boolean = true,
    /** The chosen audio file's name, shown to the user. Not used for playback. */
    val soundName: String = "",
    /** The playlist this task uses, or "" for none. Stored as a playlist id. */
    val playlistId: String = "",
    /** Offer the playlist when the task's alarm goes off. Never starts music by itself. */
    val playOnStart: Boolean = false,
    /** Play the task's own audio for the whole interval, from its start to its end. Separate from the alarm ring. */
    val continuousAudio: Boolean = false,
    /** The chosen audio file for continuous task audio, as a content URI. Empty when none. */
    val taskAudioUri: String = "",
    val taskAudioName: String = "",
) {
    val crossesMidnight: Boolean get() = endMinute <= startMinute

    val durationMinutes: Int
        get() = if (crossesMidnight) MINUTES_PER_DAY - startMinute + endMinute else endMinute - startMinute
}

/**
 * Why a task cannot be saved, or null when it can. Returned as a key so the UI can localise it.
 * Stored data is never validated on load: a record that is odd is kept, not dropped.
 */
fun StudyTask.validationError(): String? = when {
    title.isBlank() -> "title_required"
    startMinute !in 0 until MINUTES_PER_DAY -> "start_out_of_range"
    endMinute !in 1..MINUTES_PER_DAY -> "end_out_of_range"
    endMinute == startMinute -> "zero_length"
    repeat == TaskRepeat.WEEKLY && weekdays.isEmpty() -> "weekday_required"
    lastDate != null && lastDate.isBefore(firstDate) -> "last_before_first"
    else -> null
}

/**
 * A to-do: something to finish, with an optional due moment. Unlike a [StudyTask] it has no fixed
 * time slot and never repeats. Completing it does not affect any schedule or reminder.
 */
data class TodoItem(
    val id: Long,
    val title: String,
    val notes: String = "",
    val subjectId: Long? = null,
    /** Local wall-clock due moment. Null means there is no due date. */
    val dueAt: LocalDateTime? = null,
    val done: Boolean = false,
    /** Reminder before the due time. Only meaningful when [dueAt] is set. */
    val alert: Boolean = false,
    val reminderLeadMinutes: Int = 5,
    /** An alarm at the due time, in addition to the reminder. */
    val alarmAtDue: Boolean = false,
    val sound: String = "default",
    val alarmSlot: Int = 0,
    val reminderCustomAt: Long? = null,
)

/** Records that the user ticked a task off for one occurrence. The date is the occurrence's start date. */
data class Completion(val taskId: Long, val date: LocalDate)

/**
 * A finished focus session. Only sessions whose countdown reached zero are recorded here, so this
 * list is never inflated by sessions that were abandoned or reset.
 */
data class FocusRecord(
    val id: Long,
    val subjectId: Long?,
    val label: String,
    val plannedSeconds: Int,
    val startedAtMillis: Long,
    val completedAtMillis: Long,
)

data class StudySettings(
    val focusMinutes: Int = 25,
    val shortBreakMinutes: Int = 5,
    val longBreakMinutes: Int = 15,
    val sessionsBeforeLongBreak: Int = 4,
    val firstDayOfWeek: DayOfWeek = DayOfWeek.MONDAY,
) {
    /** Clamps values to sensible ranges, so a corrupted or hand-edited file cannot break the timer. */
    fun clamped(): StudySettings = copy(
        focusMinutes = focusMinutes.coerceIn(1, 180),
        shortBreakMinutes = shortBreakMinutes.coerceIn(1, 60),
        longBreakMinutes = longBreakMinutes.coerceIn(1, 120),
        sessionsBeforeLongBreak = sessionsBeforeLongBreak.coerceIn(2, 12),
    )
}

/** Everything the study planner persists. Reminders are stored separately and are not part of this. */
data class StudyData(
    val subjects: List<Subject>,
    val tasks: List<StudyTask>,
    val completions: Set<Completion>,
    val focusRecords: List<FocusRecord>,
    val settings: StudySettings,
    val todos: List<TodoItem> = emptyList(),
    /** Custom category names the user created. Built-in categories are not stored here. */
    val categories: List<String> = emptyList(),
    /** Next unused alarm slot. Increases only; a slot is never handed out twice. */
    val nextAlarmSlot: Int = 1,
) {
    companion object {
        fun initial(): StudyData = StudyData(
            subjects = defaultSubjects(),
            tasks = emptyList(),
            completions = emptySet(),
            focusRecords = emptyList(),
            settings = StudySettings(),
        )
    }
}
