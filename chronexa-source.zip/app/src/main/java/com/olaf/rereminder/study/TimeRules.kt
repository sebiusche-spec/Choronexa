// Part of Chronexa, a derivative of reReminder 4.0.1 — GNU GPL v3. See NOTICE.
package com.olaf.rereminder.study

import java.time.LocalDate
import java.time.LocalDateTime

/** Due time used for a to-do that has a date but no chosen time. Same default as before. */
const val DEFAULT_DUE_MINUTE = 9 * 60

/**
 * The end minute to store for a time the user picked as an end time.
 *
 * A picker can only show 00:00–23:59. Picking 00:00 as the end means the end of the day, so the
 * activity runs to midnight (stored as 1440). Exception: if the start is also 00:00 the activity
 * would be empty, so 0 is kept and the validation reports it.
 */
fun endMinuteFromPicker(pickedMinute: Int, startMinute: Int): Int =
    if (pickedMinute == 0 && startMinute != 0) MINUTES_PER_DAY else pickedMinute

/**
 * A problem with the start and picked end, before anything is stored, or null when the times are
 * usable. Overnight ranges (23:00 to 06:00) are valid and are not a problem.
 */
fun timeRangeIssue(startMinute: Int, pickedEndMinute: Int): String? = when {
    startMinute !in 0 until MINUTES_PER_DAY || pickedEndMinute !in 0 until MINUTES_PER_DAY -> "time_out_of_range"
    startMinute == pickedEndMinute -> "zero_length"
    else -> null
}

/** Minutes between start and stored end, allowing for ranges that cross midnight. */
fun lengthMinutes(startMinute: Int, endMinute: Int): Int =
    if (endMinute > startMinute) endMinute - startMinute else MINUTES_PER_DAY - startMinute + endMinute

/** True when a stored range finishes on the following day (not merely at midnight). */
fun endsNextDay(startMinute: Int, endMinute: Int): Boolean = endMinute <= startMinute && endMinute != MINUTES_PER_DAY

/**
 * The due moment for a to-do: a date with an optional time. Returns null when there is no date,
 * because a to-do cannot have a time without a date.
 */
fun todoDueMoment(date: LocalDate?, minuteOfDay: Int?): LocalDateTime? {
    if (date == null) return null
    val minute = minuteOfDay ?: DEFAULT_DUE_MINUTE
    return date.atTime(minute / 60, minute % 60)
}
