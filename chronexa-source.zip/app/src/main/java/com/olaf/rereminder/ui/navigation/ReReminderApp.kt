// Modified for Chronexa (Stage A) from reReminder 4.0.1 — GNU GPL v3. See NOTICE.
package com.olaf.rereminder.ui.navigation

import androidx.annotation.StringRes
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.EnterTransition
import androidx.compose.animation.ExitTransition
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.consumeWindowInsets
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CalendarMonth
import androidx.compose.material.icons.rounded.EmojiEvents
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.School
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Timer
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.olaf.rereminder.R
import com.olaf.rereminder.ui.editor.ReminderEditorRoute
import com.olaf.rereminder.ui.home.HomeRoute
import com.olaf.rereminder.ui.main.MainRoute
import com.olaf.rereminder.ui.study.achievements.AchievementsRoute
import com.olaf.rereminder.ui.study.focus.FocusRoute
import com.olaf.rereminder.ui.study.schedule.ScheduleRoute
import com.olaf.rereminder.ui.study.subjects.SubjectsRoute
import com.olaf.rereminder.ui.settings.SettingsRoute
import com.olaf.rereminder.ui.theme.Motion

object Routes {
    const val HOME = "home"
    const val SCHEDULE = "schedule"
    /** The alarm list. Reached from Schedule and Home; it is not a bottom tab. */
    const val ALARMS = "alarms"
    const val SUBJECTS = "subjects"
    const val FOCUS = "focus"
    const val ACHIEVEMENTS = "achievements"
    const val SETTINGS = "settings"
    const val EDITOR = "editor/{id}"
    const val ARG_ID = "id"

    fun editor(id: Int) = "editor/$id"
}

/**
 * The six top-level destinations, in bar order. Editing a reminder is a detail screen on top of
 * the Schedule tab, so it is not in this list and the bar hides while it is open.
 */
private enum class Tab(
    val route: String,
    @StringRes val label: Int,
    val icon: ImageVector,
) {
    HOME(Routes.HOME, R.string.nav_home, Icons.Rounded.Home),
    SCHEDULE(Routes.SCHEDULE, R.string.nav_schedule, Icons.Rounded.CalendarMonth),
    SUBJECTS(Routes.SUBJECTS, R.string.nav_subjects, Icons.Rounded.School),
    FOCUS(Routes.FOCUS, R.string.nav_focus, Icons.Rounded.Timer),
    ACHIEVEMENTS(Routes.ACHIEVEMENTS, R.string.nav_achievements, Icons.Rounded.EmojiEvents),
    SETTINGS(Routes.SETTINGS, R.string.settings_title, Icons.Rounded.Settings),
}

/**
 * The whole app in one navigation graph.
 *
 * Tabs switch with a short fade and keep their own state. The editor rises from below over the
 * Schedule tab, which settles back behind it, so reminders still feel like one surface moving in
 * front of another.
 */
@Composable
fun ReReminderApp() {
    val navController = rememberNavController()
    val currentRoute = navController.currentBackStackEntryAsState().value?.destination?.route
    val showBar = Tab.entries.any { it.route == currentRoute }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        // Each screen already pads itself for the status bar; this only reserves room for the bar.
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        bottomBar = {
            AnimatedVisibility(
                visible = showBar,
                enter = fadeIn(Motion.fade()) + slideInVertically { it / 2 },
                exit = fadeOut(Motion.fade()) + slideOutVertically { it / 2 },
            ) {
                ChronexaNavigationBar(
                    current = currentRoute,
                    onSelect = { navController.navigateTab(it) },
                )
            }
        },
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = Routes.HOME,
            modifier = Modifier
                .padding(innerPadding)
                .consumeWindowInsets(innerPadding),
        ) {
            composable(
                route = Routes.HOME,
                enterTransition = { tabEnter() },
                exitTransition = { tabExit() },
                popEnterTransition = { tabEnter() },
                popExitTransition = { tabExit() },
            ) {
                HomeRoute(
                    onOpenSchedule = { navController.navigateTab(Routes.SCHEDULE) },
                    onOpenFocus = { navController.navigateTab(Routes.FOCUS) },
                    onOpenAlarms = { navController.navigate(Routes.ALARMS) },
                )
            }

            composable(
                route = Routes.SCHEDULE,
                enterTransition = { tabEnter() },
                exitTransition = { tabExit() },
                popEnterTransition = { tabEnter() },
                popExitTransition = { tabExit() },
            ) {
                ScheduleRoute(onOpenAlarms = { navController.navigate(Routes.ALARMS) })
            }

            composable(
                route = Routes.ALARMS,
                enterTransition = { recedeIn() },
                exitTransition = { recedeOut() },
                popEnterTransition = { recedeIn() },
                popExitTransition = { recedeOut() },
            ) {
                MainRoute(
                    onEdit = { id -> navController.navigateFrom(Routes.ALARMS, Routes.editor(id)) },
                    onCreate = {
                        navController.navigateFrom(Routes.ALARMS, Routes.editor(NEW_REMINDER_ID))
                    },
                    onSettings = { navController.navigateTab(Routes.SETTINGS) },
                )
            }

            composable(
                route = Routes.EDITOR,
                arguments = listOf(
                    navArgument(Routes.ARG_ID) {
                        type = NavType.IntType
                        defaultValue = NEW_REMINDER_ID
                    }
                ),
                enterTransition = { riseIn() },
                popExitTransition = { sinkOut() },
            ) {
                // The id reaches the editor's ViewModel through its SavedStateHandle.
                ReminderEditorRoute(onClose = { navController.popFrom(Routes.EDITOR) })
            }

            composable(
                route = Routes.SUBJECTS,
                enterTransition = { tabEnter() },
                exitTransition = { tabExit() },
                popEnterTransition = { tabEnter() },
                popExitTransition = { tabExit() },
            ) {
                SubjectsRoute()
            }

            composable(
                route = Routes.FOCUS,
                enterTransition = { tabEnter() },
                exitTransition = { tabExit() },
                popEnterTransition = { tabEnter() },
                popExitTransition = { tabExit() },
            ) {
                FocusRoute()
            }

            composable(
                route = Routes.ACHIEVEMENTS,
                enterTransition = { tabEnter() },
                exitTransition = { tabExit() },
                popEnterTransition = { tabEnter() },
                popExitTransition = { tabExit() },
            ) {
                AchievementsRoute()
            }

            composable(
                route = Routes.SETTINGS,
                enterTransition = { tabEnter() },
                exitTransition = { tabExit() },
                popEnterTransition = { tabEnter() },
                popExitTransition = { tabExit() },
            ) {
                // A tab has no screen behind it to go back to, so it has no back arrow.
                SettingsRoute(onBack = null)
            }
        }
    }
}

@Composable
private fun ChronexaNavigationBar(current: String?, onSelect: (String) -> Unit) {
    NavigationBar(
        containerColor = MaterialTheme.colorScheme.surfaceContainerLow,
        tonalElevation = 0.dp,
    ) {
        Tab.entries.forEach { tab ->
            NavigationBarItem(
                selected = current == tab.route,
                onClick = { onSelect(tab.route) },
                icon = { Icon(imageVector = tab.icon, contentDescription = null) },
                label = {
                    Text(
                        text = stringResource(tab.label),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        style = MaterialTheme.typography.labelSmall,
                    )
                },
                colors = NavigationBarItemDefaults.colors(
                    indicatorColor = MaterialTheme.colorScheme.primaryContainer,
                ),
            )
        }
    }
}

private const val NEW_REMINDER_ID = 0

/**
 * Navigation guarded against double taps.
 *
 * A screen keeps receiving input while it animates out, so a second tap on the back arrow (or
 * back, then Save) used to pop again — taking the list with it and leaving an empty window — and
 * two quick taps on a card stacked two editors. Each action now only acts if the screen it came
 * from is still the one on top.
 */
private fun NavController.popFrom(route: String) {
    if (currentDestination?.route == route) popBackStack()
}

private fun NavController.navigateFrom(route: String, destination: String) {
    if (currentDestination?.route == route) navigate(destination)
}

/**
 * Moves between top-level tabs. Each tab keeps its own state, and the stack never grows past
 * Home plus the one tab shown, so back from any tab returns to Home.
 */
private fun NavController.navigateTab(route: String) {
    if (currentDestination?.route == route) return
    navigate(route) {
        popUpTo(Routes.HOME) { saveState = true }
        launchSingleTop = true
        restoreState = true
    }
}

// --- Transitions ----------------------------------------------------------
//
// All of these run on Motion.screenEnter/screenExit, never on springs, so predictive back can
// scrub them and every part of a transition ends on the same frame (see Motion).

/** A detail screen arriving: lifts up from below while growing to full size. */
private fun riseIn(): EnterTransition =
    slideInVertically(Motion.screenEnter()) { height -> height / 5 } +
        fadeIn(tween(Motion.SCREEN_ENTER_MILLIS, easing = LinearEasing)) +
        scaleIn(Motion.screenEnter(), initialScale = 0.92f)

/** The same screen leaving, by the back arrow, a save or the back gesture. */
private fun sinkOut(): ExitTransition =
    slideOutVertically(Motion.screenExit()) { height -> height / 5 } +
        fadeOut(tween(Motion.SCREEN_EXIT_MILLIS, easing = LinearEasing)) +
        scaleOut(Motion.screenExit(), targetScale = 0.92f)

/**
 * The list stepping back behind whatever opened on top of it.
 *
 * It only dims rather than fading out completely: it sits underneath the screen that is fading
 * in, and two half-transparent screens let the bare window background flash through.
 */
private fun recedeOut(): ExitTransition =
    fadeOut(tween(Motion.SCREEN_EXIT_MILLIS, easing = LinearEasing), targetAlpha = 0.4f) +
        scaleOut(Motion.screenExit(), targetScale = 0.96f)

private fun recedeIn(): EnterTransition =
    fadeIn(tween(Motion.SCREEN_ENTER_MILLIS, easing = LinearEasing), initialAlpha = 0.4f) +
        scaleIn(Motion.screenEnter(), initialScale = 0.96f)

/** Tabs cross-fade: they are peers, so neither should slide over the other. */
private fun tabEnter(): EnterTransition =
    fadeIn(tween(Motion.SCREEN_ENTER_MILLIS, easing = LinearEasing))

private fun tabExit(): ExitTransition =
    fadeOut(tween(Motion.SCREEN_EXIT_MILLIS, easing = LinearEasing))
