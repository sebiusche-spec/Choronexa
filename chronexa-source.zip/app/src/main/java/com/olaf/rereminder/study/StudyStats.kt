// Part of Chronexa, a derivative of reReminder 4.0.1 — GNU GPL v3. See NOTICE.
package com.olaf.rereminder.study

import java.time.LocalDate
import java.time.ZoneId

/**
 * Statistics computed only from stored data. Nothing here is estimated or filled in.
 */
data class SubjectStat(
    val subjectId: Long?,
    val name: String,
    val colorIndex: Int,
    val completedTasks: Int,
    val focusSeconds: Long,
)

data class Badge(val id: String, val target: Int, val progress: Int) {
    val earned: Boolean get() = progress >= target
}

/** Completions that point at a real occurrence. A stale completion for a deleted or rescheduled task is ignored. */
fun validCompletionsBetween(data: StudyData, from: LocalDate, to: LocalDate): List<Completion> {
    val tasksById = data.tasks.associateBy { it.id }
    return data.completions.filter { c ->
        !c.date.isBefore(from) && !c.date.isAfter(to) &&
            tasksById[c.taskId]?.occursOn(c.date) == true
    }
}

fun completedCountBetween(data: StudyData, from: LocalDate, to: LocalDate): Int =
    validCompletionsBetween(data, from, to).size

fun earliestScheduledDate(data: StudyData): LocalDate? = data.tasks.minOfOrNull { it.firstDate }

fun currentStreak(data: StudyData, today: LocalDate): Int =
    Streaks.current(today, { summarizeDay(data.tasks, data.completions, it) })

fun bestStreak(data: StudyData, today: LocalDate): Int =
    Streaks.best(earliestScheduledDate(data), today, { summarizeDay(data.tasks, data.completions, it) })

fun subjectStats(data: StudyData, from: LocalDate, to: LocalDate, zone: ZoneId): List<SubjectStat> {
    val tasksById = data.tasks.associateBy { it.id }
    val completionsBySubject = validCompletionsBetween(data, from, to)
        .groupingBy { tasksById[it.taskId]?.subjectId }
        .eachCount()
    val focusBySubject = focusSecondsBySubject(data.focusRecords, from, to, zone)

    val known = data.subjects.map { s ->
        SubjectStat(
            subjectId = s.id,
            name = s.name,
            colorIndex = s.colorIndex,
            completedTasks = completionsBySubject[s.id] ?: 0,
            focusSeconds = focusBySubject[s.id] ?: 0L,
        )
    }
    // Sessions or tasks that point at a deleted subject are grouped, not dropped.
    val knownIds = data.subjects.map { it.id }.toSet()
    val leftover = (completionsBySubject.keys + focusBySubject.keys)
        .filter { it == null || it !in knownIds }
    val other = if (leftover.isEmpty()) emptyList() else listOf(
        SubjectStat(
            subjectId = null,
            name = "No subject",
            colorIndex = 0,
            completedTasks = leftover.sumOf { completionsBySubject[it] ?: 0 },
            focusSeconds = leftover.sumOf { focusBySubject[it] ?: 0L },
        ),
    )
    return known + other
}

/** Milestones earned from real counts. Targets are fixed; progress is capped at the target. */
fun badges(data: StudyData, today: LocalDate, zone: ZoneId): List<Badge> {
    val allTimeFrom = earliestScheduledDate(data) ?: today
    val completedAll = completedCountBetween(data, allTimeFrom, today)
    val best = bestStreak(data, today)
    val sessions = data.focusRecords.size
    val focusHours = data.focusRecords.sumOf { it.plannedSeconds.toLong() } / 3600L
    return listOf(
        Badge("first_task", 1, completedAll),
        Badge("three_day_streak", 3, best),
        Badge("week_streak", 7, best),
        Badge("ten_sessions", 10, sessions),
        Badge("five_hours", 5, focusHours.toInt()),
    ).map { it.copy(progress = it.progress.coerceAtMost(it.target)) }
}
