// Part of Chronexa, a derivative of reReminder 4.0.1 — GNU GPL v3. See NOTICE.
package com.olaf.rereminder.study.chapters

/** Which syllabus statuses the list shows. ALL shows every chapter. */
enum class ChapterFilter(val status: ChapterStatus?) {
    ALL(null),
    INCLUDED(ChapterStatus.INCLUDED),
    EXCLUDED(ChapterStatus.EXCLUDED),
    UNCERTAIN(ChapterStatus.UNCERTAIN),
}

/**
 * The chapters a list should show: one subject, matching the search text, with the chosen status, in chapter
 * order. The search is case-insensitive and matches part of the chapter name. A blank search shows everything.
 */
fun ChapterMaster.visibleChapters(subject: Subject, query: String, filter: ChapterFilter): List<Chapter> {
    val needle = query.trim().lowercase()
    return chapters
        .filter { it.subject == subject }
        .filter { filter.status == null || it.status == filter.status }
        .filter { needle.isEmpty() || it.name.lowercase().contains(needle) }
        .sortedBy { it.number }
}
