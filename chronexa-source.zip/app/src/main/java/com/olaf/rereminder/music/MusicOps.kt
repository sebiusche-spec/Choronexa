// Part of Chronexa, a derivative of reReminder 4.0.1 — GNU GPL v3. See NOTICE.
package com.olaf.rereminder.music

/** Adds a track to the library and to one playlist. Adding the same file twice never duplicates it. */
fun MusicLibrary.addTrackTo(playlistId: String, track: Track): MusicLibrary {
    val known = tracks.any { it.uri == track.uri }
    return copy(
        tracks = if (known) tracks else tracks + track,
        playlists = playlists.map { p ->
            if (p.id == playlistId && track.uri !in p.trackUris) p.copy(trackUris = p.trackUris + track.uri) else p
        },
    )
}

/**
 * Removes a track from one playlist only. The track stays in the library, its file is not touched, and
 * every other playlist keeps it.
 */
fun MusicLibrary.removeFromPlaylist(playlistId: String, uri: String): MusicLibrary = copy(
    playlists = playlists.map { p ->
        if (p.id == playlistId) p.copy(trackUris = p.trackUris.filter { it != uri }) else p
    },
)

/** Favorites is an ordinary playlist: a track is a favourite while it is in it. */
fun MusicLibrary.toggleFavorite(uri: String): MusicLibrary {
    val inFavorites = playlists.firstOrNull { it.id == PLAYLIST_FAVORITES }?.trackUris?.contains(uri) == true
    return if (inFavorites) {
        removeFromPlaylist(PLAYLIST_FAVORITES, uri)
    } else {
        copy(playlists = playlists.map { p ->
            if (p.id == PLAYLIST_FAVORITES) p.copy(trackUris = p.trackUris + uri) else p
        })
    }
}

/** Creates a custom playlist. Returns the library unchanged if the name is blank. */
fun MusicLibrary.createPlaylist(name: String): MusicLibrary {
    val clean = name.trim().take(MAX_NAME)
    if (clean.isEmpty()) return this
    val id = "custom_$nextPlaylistNumber"
    return copy(
        playlists = playlists + Playlist(id, clean, builtIn = false),
        nextPlaylistNumber = nextPlaylistNumber + 1,
    )
}

/** Renames a playlist. A blank name is refused and the library is returned unchanged. */
fun MusicLibrary.renamePlaylist(playlistId: String, name: String): MusicLibrary {
    val clean = name.trim().take(MAX_NAME)
    if (clean.isEmpty()) return this
    return copy(playlists = playlists.map { if (it.id == playlistId) it.copy(name = clean) else it })
}

/**
 * Deletes a custom playlist. The tracks it listed stay in the library and in every other playlist, and
 * no audio file is touched. The built-in playlists cannot be deleted.
 */
fun MusicLibrary.deletePlaylist(playlistId: String): MusicLibrary {
    val target = playlists.firstOrNull { it.id == playlistId } ?: return this
    if (target.builtIn) return this
    return copy(playlists = playlists.filter { it.id != playlistId })
}

/** Moves a track within a playlist. Out-of-range indexes leave the playlist unchanged. */
fun MusicLibrary.reorder(playlistId: String, from: Int, to: Int): MusicLibrary = copy(
    playlists = playlists.map { p ->
        val list = p.trackUris
        if (p.id != playlistId || from !in list.indices || to !in list.indices || from == to) {
            p
        } else {
            val moved = list.toMutableList()
            val item = moved.removeAt(from)
            moved.add(to, item)
            p.copy(trackUris = moved)
        }
    },
)

/**
 * The tracks in a playlist, in playlist order. A URI with no matching track in the library is skipped, so
 * a damaged or stale reference never breaks the list. [missingCount] says how many were skipped.
 */
data class PlaylistContents(val tracks: List<Track>, val missingCount: Int)

fun MusicLibrary.contentsOf(playlistId: String): PlaylistContents {
    val list = playlists.firstOrNull { it.id == playlistId }?.trackUris.orEmpty()
    val byUri = tracks.associateBy { it.uri }
    val found = list.mapNotNull { byUri[it] }
    return PlaylistContents(found, list.size - found.size)
}

/** Every track in the library, in the order it was added. This is the "All Songs" view. */
fun MusicLibrary.allSongs(): List<Track> = tracks

/** Case-insensitive search over title and artist. A blank query returns everything. */
fun searchTracks(tracks: List<Track>, query: String): List<Track> {
    val q = query.trim().lowercase()
    if (q.isEmpty()) return tracks
    return tracks.filter { it.title.lowercase().contains(q) || it.artist.lowercase().contains(q) }
}

const val MAX_NAME = 40

/** Adds a track to the library without placing it in any playlist. Adding the same file twice is a no-op. */
fun MusicLibrary.addToLibrary(track: Track): MusicLibrary =
    if (tracks.any { it.uri == track.uri }) this else copy(tracks = tracks + track)
