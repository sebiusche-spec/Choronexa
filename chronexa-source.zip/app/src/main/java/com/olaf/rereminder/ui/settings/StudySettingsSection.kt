// Part of Chronexa, a derivative of reReminder 4.0.1 — GNU GPL v3. See NOTICE.
package com.olaf.rereminder.ui.settings

import android.app.Activity
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Remove
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.olaf.rereminder.R
import com.olaf.rereminder.study.StudySettings
import com.olaf.rereminder.ui.components.SectionCard
import com.olaf.rereminder.ui.study.StudyViewModel
import com.olaf.rereminder.utils.MotionMode
import com.olaf.rereminder.utils.PreferenceHelper
import com.olaf.rereminder.utils.ThemeMode
import java.time.DayOfWeek

/**
 * Settings for the study planner, appearance and motion, and an About card.
 *
 * Theme and motion changes recreate the activity so the whole app picks them up at once. Every
 * control here changes a stored value that something else reads; nothing is decorative.
 */
@Composable
fun StudySettingsSection(viewModel: StudyViewModel = viewModel()) {
    val data by viewModel.data.collectAsStateWithLifecycle()
    val settings = data.settings
    val context = LocalContext.current
    val prefs = remember(context) { PreferenceHelper(context) }
    var theme by remember(context) { mutableStateOf(prefs.getThemeMode()) }
    var motion by remember(context) { mutableStateOf(prefs.getMotionMode()) }
    val uriHandler = LocalUriHandler.current

    SectionCard(title = stringResource(R.string.settings_group_focus)) {
        Stepper(
            label = stringResource(R.string.settings_focus_minutes),
            value = settings.focusMinutes,
            unit = stringResource(R.string.settings_unit_minutes),
            step = 5,
            range = 1..180,
            onChange = { viewModel.saveSettings(settings.copy(focusMinutes = it)) },
        )
        Stepper(
            label = stringResource(R.string.settings_short_break),
            value = settings.shortBreakMinutes,
            unit = stringResource(R.string.settings_unit_minutes),
            step = 1,
            range = 1..60,
            onChange = { viewModel.saveSettings(settings.copy(shortBreakMinutes = it)) },
        )
        Stepper(
            label = stringResource(R.string.settings_long_break),
            value = settings.longBreakMinutes,
            unit = stringResource(R.string.settings_unit_minutes),
            step = 5,
            range = 1..120,
            onChange = { viewModel.saveSettings(settings.copy(longBreakMinutes = it)) },
        )
        Stepper(
            label = stringResource(R.string.settings_sessions_before_long),
            value = settings.sessionsBeforeLongBreak,
            unit = "",
            step = 1,
            range = 2..12,
            onChange = { viewModel.saveSettings(settings.copy(sessionsBeforeLongBreak = it)) },
        )
        Text(
            text = stringResource(R.string.settings_first_day),
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurface,
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(DayOfWeek.MONDAY, DayOfWeek.SUNDAY).forEach { day ->
                FilterChip(
                    selected = settings.firstDayOfWeek == day,
                    onClick = { viewModel.setFirstDayOfWeek(day) },
                    label = { Text(day.getDisplayName(java.time.format.TextStyle.FULL, java.util.Locale.getDefault())) },
                )
            }
        }
    }

    SectionCard(title = stringResource(R.string.settings_group_appearance)) {
        Text(
            text = stringResource(R.string.settings_theme),
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurface,
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ThemeMode.values().forEach { mode ->
                FilterChip(
                    selected = theme == mode,
                    onClick = {
                        prefs.setThemeMode(mode)
                        theme = mode
                        (context as? Activity)?.recreate()
                    },
                    label = { Text(stringResource(themeLabel(mode))) },
                )
            }
        }
        Text(
            text = stringResource(R.string.settings_motion),
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurface,
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            MotionMode.values().forEach { mode ->
                FilterChip(
                    selected = motion == mode,
                    onClick = {
                        prefs.setMotionMode(mode)
                        motion = mode
                        (context as? Activity)?.recreate()
                    },
                    label = { Text(stringResource(motionLabel(mode))) },
                )
            }
        }
        Text(
            text = stringResource(R.string.settings_motion_hint),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }

    SectionCard(title = stringResource(R.string.settings_group_about)) {
        Text(
            text = stringResource(R.string.about_body),
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        TextButton(onClick = { uriHandler.openUri(UPSTREAM_URL) }) {
            Text(stringResource(R.string.about_upstream))
        }
        TextButton(onClick = { uriHandler.openUri(LICENSE_URL) }) {
            Text(stringResource(R.string.about_license))
        }
    }
}

private const val UPSTREAM_URL = "https://github.com/ProfessorQuantumUniverse/reReminder"
private const val LICENSE_URL = "https://www.gnu.org/licenses/gpl-3.0.html"

private fun themeLabel(mode: ThemeMode): Int = when (mode) {
    ThemeMode.SYSTEM -> R.string.settings_theme_system
    ThemeMode.LIGHT -> R.string.settings_theme_light
    ThemeMode.DARK -> R.string.settings_theme_dark
}

private fun motionLabel(mode: MotionMode): Int = when (mode) {
    MotionMode.SYSTEM -> R.string.settings_motion_system
    MotionMode.REDUCED -> R.string.settings_motion_reduced
    MotionMode.FULL -> R.string.settings_motion_full
}

@Composable
private fun Stepper(
    label: String,
    value: Int,
    unit: String,
    step: Int,
    range: IntRange,
    onChange: (Int) -> Unit,
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurface,
            modifier = Modifier.weight(1f),
        )
        IconButton(
            onClick = { onChange((value - step).coerceIn(range)) },
            enabled = value > range.first,
        ) {
            Icon(Icons.Rounded.Remove, contentDescription = stringResource(R.string.settings_decrease))
        }
        Text(
            text = if (unit.isEmpty()) value.toString() else "$value $unit",
            style = MaterialTheme.typography.titleSmall,
            color = MaterialTheme.colorScheme.onSurface,
            modifier = Modifier.padding(horizontal = 6.dp),
        )
        IconButton(
            onClick = { onChange((value + step).coerceIn(range)) },
            enabled = value < range.last,
        ) {
            Icon(Icons.Rounded.Add, contentDescription = stringResource(R.string.settings_increase))
        }
    }
}
