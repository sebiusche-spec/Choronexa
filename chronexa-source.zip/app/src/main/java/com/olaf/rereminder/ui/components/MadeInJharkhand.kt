// Modified for Chronexa (footer) from reReminder 4.0.1 — GNU GPL v3. See NOTICE.
package com.olaf.rereminder.ui.components

import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.olaf.rereminder.R
import com.olaf.rereminder.ui.theme.ChronexaCyan
import com.olaf.rereminder.ui.theme.ReReminderTheme

/**
 * Developer credit shown on the start, setup and settings screens. The emojis carry the flag and
 * the leaf; the accent colour is the Chronexa cyan, kept quiet so it does not compete with content.
 */
@Composable
fun MadeInJharkhand(modifier: Modifier = Modifier) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            text = stringResource(R.string.made_in_jharkhand),
            modifier = Modifier.fillMaxWidth(),
            textAlign = TextAlign.Center,
            style = MaterialTheme.typography.bodySmall.copy(
                fontWeight = FontWeight.Medium,
                fontSize = 13.sp,
                letterSpacing = 0.3.sp,
            ),
            color = ChronexaCyan.copy(alpha = 0.85f),
        )
    }
}

@Preview(showBackground = true)
@Composable
private fun MadeInJharkhandPreview() {
    ReReminderTheme(dynamicColor = false) {
        MadeInJharkhand()
    }
}
