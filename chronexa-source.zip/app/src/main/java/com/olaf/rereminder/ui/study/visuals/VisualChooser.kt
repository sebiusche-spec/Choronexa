// Part of Chronexa, a derivative of reReminder 4.0.1 — GNU GPL v3. See NOTICE.
package com.olaf.rereminder.ui.study.visuals

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.olaf.rereminder.R
import com.olaf.rereminder.study.VISUAL_CHOICES

/** The visual chooser for a task: "Automatic" plus each fixed picture. The choice is saved with the task. */
@Composable
fun VisualChooser(selected: String, onSelect: (String) -> Unit, modifier: Modifier = Modifier) {
    LazyRow(modifier = modifier, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        items(VISUAL_CHOICES) { key ->
            FilterChip(
                selected = selected == key,
                onClick = { onSelect(key) },
                label = { Text(stringResource(visualLabel(key))) },
            )
        }
    }
}

private fun visualLabel(key: String): Int = when (key) {
    "wake" -> R.string.visual_wake
    "brush" -> R.string.visual_brush
    "bath" -> R.string.visual_bath
    "meditate" -> R.string.visual_meditate
    "music" -> R.string.visual_music
    "maths" -> R.string.visual_maths
    "physics" -> R.string.visual_physics
    "chemistry" -> R.string.visual_chemistry
    "computing" -> R.string.visual_computing
    "study" -> R.string.visual_study
    "exercise" -> R.string.visual_exercise
    "food" -> R.string.visual_food
    "break" -> R.string.visual_break
    "sleep" -> R.string.visual_sleep
    "calm" -> R.string.visual_calm
    "none" -> R.string.visual_none
    else -> R.string.visual_auto
}
