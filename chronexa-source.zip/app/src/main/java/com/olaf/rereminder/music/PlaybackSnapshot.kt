// Part of Chronexa, a derivative of reReminder 4.0.1 — GNU GPL v3. See NOTICE.
package com.olaf.rereminder.music

import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json

/**
 * The playback state saved for the next launch: the queue, where playback was, the playlist it came from,
 * and the shuffle and repeat settings. Track identities are content URIs.
 */
data class PlaybackSnapshot(
    val source: List<String>,
    val order: List<String>,
    val index: Int,
    val repeat: RepeatMode,
    val shuffle: Boolean,
    val positionMs: Long,
    val scopeId: String = "",
)

/** A snapshot with unopenable songs removed. [skipped] says how many were dropped. */
data class RestoredPlayback(val snapshot: PlaybackSnapshot, val skipped: Int)

fun PlaybackSnapshot.toQueue(): PlaybackQueue = PlaybackQueue(source, order, index, repeat, shuffle)

/**
 * Keeps only the songs that can still be opened and moves playback to a valid track.
 *
 * If the current song can still be opened, playback stays on it at the saved position. If it cannot, playback
 * moves to the nearest song that can, starting from the beginning. Returns null when nothing can be opened.
 * [canOpen] is asked once per URI.
 */
fun restoreAccessible(snapshot: PlaybackSnapshot, canOpen: (String) -> Boolean): RestoredPlayback? {
    if (snapshot.order.isEmpty()) return null
    val safeIndex = snapshot.index.coerceIn(0, snapshot.order.lastIndex)
    val openable = (snapshot.order + snapshot.source).distinct().associateWith { canOpen(it) }
    val keep = snapshot.order.map { openable[it] == true }
    val kept = snapshot.order.filterIndexed { i, _ -> keep[i] }
    if (kept.isEmpty()) return null
    // Where the current song lands among the kept songs: the count of kept songs before it, at most the last one.
    val newIndex = (0 until safeIndex).count { keep[it] }.coerceAtMost(kept.lastIndex)
    val currentKept = keep[safeIndex]
    val keptSource = snapshot.source.filter { openable[it] == true }
    val restored = snapshot.copy(
        source = keptSource,
        order = kept,
        index = newIndex,
        positionMs = if (currentKept) snapshot.positionMs.coerceAtLeast(0L) else 0L,
    )
    return RestoredPlayback(restored, skipped = snapshot.order.size - kept.size)
}

/** The saved state as JSON. Same safety rules as the other stores: unknown fields ignored, newer versions kept. */
object PlaybackSnapshotCodec {

    const val CURRENT_SCHEMA_VERSION = 1

    private val json = Json {
        ignoreUnknownKeys = true
        encodeDefaults = true
    }

    sealed interface Decoded {
        data class Ok(val snapshot: PlaybackSnapshot) : Decoded
        data class FutureVersion(val version: Int) : Decoded
        data object Invalid : Decoded
    }

    fun encode(snapshot: PlaybackSnapshot): String = json.encodeToString(Dto.serializer(), snapshot.toDto())

    fun decode(text: String): Decoded = try {
        val dto = json.decodeFromString(Dto.serializer(), text)
        when {
            dto.schemaVersion > CURRENT_SCHEMA_VERSION -> Decoded.FutureVersion(dto.schemaVersion)
            dto.schemaVersion < 1 -> Decoded.Invalid
            else -> Decoded.Ok(dto.toDomain())
        }
    } catch (e: Exception) {
        Decoded.Invalid
    }

    @Serializable
    private data class Dto(
        val schemaVersion: Int = CURRENT_SCHEMA_VERSION,
        val source: List<String> = emptyList(),
        val order: List<String> = emptyList(),
        val index: Int = -1,
        val repeat: String = RepeatMode.OFF.name,
        val shuffle: Boolean = false,
        val positionMs: Long = 0L,
        val scopeId: String = "",
    )

    private fun PlaybackSnapshot.toDto() = Dto(
        schemaVersion = CURRENT_SCHEMA_VERSION,
        source = source,
        order = order,
        index = index,
        repeat = repeat.name,
        shuffle = shuffle,
        positionMs = positionMs,
        scopeId = scopeId,
    )

    /** Reads the saved values defensively: an out-of-range index is clamped, and an unknown repeat mode is off. */
    private fun Dto.toDomain(): PlaybackSnapshot = PlaybackSnapshot(
        source = source,
        order = order,
        index = if (order.isEmpty()) -1 else index.coerceIn(0, order.lastIndex),
        repeat = runCatching { RepeatMode.valueOf(repeat) }.getOrDefault(RepeatMode.OFF),
        shuffle = shuffle,
        positionMs = positionMs.coerceAtLeast(0L),
        scopeId = scopeId,
    )
}
