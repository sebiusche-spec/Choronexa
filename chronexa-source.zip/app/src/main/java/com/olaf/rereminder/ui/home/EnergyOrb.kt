// Part of Chronexa, a derivative of reReminder 4.0.1 — GNU GPL v3. See NOTICE.
package com.olaf.rereminder.ui.home

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.olaf.rereminder.ui.theme.ChronexaCyan
import com.olaf.rereminder.ui.theme.ChronexaViolet
import com.olaf.rereminder.ui.theme.Motion
import com.olaf.rereminder.ui.theme.rememberReduceMotion

/**
 * A decorative energy core: layered glow, three rotating rings and a slow breath.
 *
 * It is visual only and does not represent any assistant. It is lightweight by design: a few
 * arcs and one radial gradient, no blur and no particles. Motion stops when reduce-motion is on,
 * and the animation is only composed while this screen is on screen.
 *
 * [energetic] speeds the rings up and brightens them, for example while a focus session runs.
 * A press briefly swells the core.
 */
@Composable
fun EnergyOrb(
    modifier: Modifier = Modifier,
    size: Dp = 200.dp,
    energetic: Boolean = false,
) {
    val reduce = rememberReduceMotion()
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val swell by animateFloatAsState(
        targetValue = if (pressed) 1.07f else 1f,
        animationSpec = Motion.snappy(),
        label = "orbSwell",
    )

    val transition = rememberInfiniteTransition(label = "orb")
    val spin by transition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = if (energetic) 7000 else 18000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart,
        ),
        label = "orbSpin",
    )
    val breath by transition.animateFloat(
        initialValue = 0.96f,
        targetValue = 1.03f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 3200, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse,
        ),
        label = "orbBreath",
    )
    val angle = if (reduce) 0f else spin
    val scale = if (reduce) 1f else breath

    Canvas(
        modifier = modifier
            .size(size)
            .graphicsLayer {
                scaleX = swell
                scaleY = swell
            }
            // Press feedback only. The orb does nothing when tapped; it just answers the touch.
            .clickable(interactionSource = interaction, indication = null, onClick = {}),
    ) {
        val c = Offset(this.size.width / 2f, this.size.height / 2f)
        val r = this.size.minDimension / 2f

        // Outer glow.
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(
                    ChronexaCyan.copy(alpha = if (energetic) 0.45f else 0.28f),
                    ChronexaViolet.copy(alpha = 0.14f),
                    Color.Transparent,
                ),
                center = c,
                radius = r * scale,
            ),
            radius = r * scale,
            center = c,
        )

        // Core.
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(
                    Color.White.copy(alpha = 0.85f),
                    ChronexaCyan.copy(alpha = 0.9f),
                    ChronexaViolet.copy(alpha = 0.6f),
                ),
                center = c,
                radius = r * 0.55f,
            ),
            radius = r * 0.55f * scale,
            center = c,
        )

        // Three rings, each turning at its own pace through a rotation of the whole canvas.
        val ringWidth = r * 0.035f
        drawRing(c, r * 0.80f, ChronexaCyan, 0.85f, 260f, angle, ringWidth)
        rotate(degrees = -angle * 0.6f, pivot = c) {
            drawRing(c, r * 0.66f, ChronexaViolet, 0.75f, 150f, 0f, ringWidth)
        }
        rotate(degrees = angle * 0.35f, pivot = c) {
            drawRing(c, r * 0.52f, Color.White, 0.35f, 90f, 0f, ringWidth * 0.8f)
        }
    }
}

/** One arc ring centred on [c]. */
private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawRing(
    c: Offset,
    radius: Float,
    color: Color,
    alpha: Float,
    sweep: Float,
    startDegrees: Float,
    width: Float,
) {
    rotate(degrees = startDegrees, pivot = c) {
        drawArc(
            color = color.copy(alpha = alpha),
            startAngle = 0f,
            sweepAngle = sweep,
            useCenter = false,
            topLeft = Offset(c.x - radius, c.y - radius),
            size = Size(radius * 2f, radius * 2f),
            style = Stroke(width = width, cap = StrokeCap.Round),
        )
    }
}
