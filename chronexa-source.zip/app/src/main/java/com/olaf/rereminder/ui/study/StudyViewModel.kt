// Part of Chronexa, a derivative of reReminder 4.0.1 — GNU GPL v3. See NOTICE.
package com.olaf.rereminder.ui.study

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import com.olaf.rereminder.study.Completion
import com.olaf.rereminder.study.FocusClock
import com.olaf.rereminder.study.FocusMode
import com.olaf.rereminder.study.FocusState
import com.olaf.rereminder.study.StudyRepository
import com.olaf.rereminder.study.StudySettings
import com.olaf.rereminder.study.StudyTask
import com.olaf.rereminder.study.Subject
import java.time.DayOfWeek
import java.time.LocalDate

/** Planned length of a focus session in milliseconds, from the user's settings. */
fun plannedMillisFor(mode: FocusMode, settings: StudySettings): Long {
    val minutes = when (mode) {
        FocusMode.FOCUS -> settings.focusMinutes
        FocusMode.SHORT_BREAK -> settings.shortBreakMinutes
        FocusMode.LONG_BREAK -> settings.longBreakMinutes
    }
    return minutes * 60_000L
}

/**
 * The actions the study screens can take. Each one goes through [StudyRepository], so the UI only
 * shows what was actually saved. Functions that save return false when the save failed.
 */
class StudyViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = StudyRepository.get(application)

    val data = repository.data
    val status = repository.status
    val session = repository.session

    // --- Tasks -----------------------------------------------------------------------

    /** Saves a new task (id 0) or replaces an existing one. */
    fun saveTask(task: StudyTask): Boolean = repository.update { d ->
        val id = if (task.id == 0L) repository.nextId(d.tasks) { it.id } else task.id
        d.copy(tasks = d.tasks.filter { it.id != id } + task.copy(id = id))
    }

    /** Deletes a task and its completions. Focus records are kept. */
    fun deleteTask(taskId: Long): Boolean = repository.update { d ->
        d.copy(
            tasks = d.tasks.filter { it.id != taskId },
            completions = d.completions.filterNot { it.taskId == taskId }.toSet(),
        )
    }

    /** Ticks a task off for one date, or clears the tick. */
    fun toggleCompletion(taskId: Long, date: LocalDate): Boolean = repository.update { d ->
        val c = Completion(taskId, date)
        d.copy(completions = if (c in d.completions) d.completions - c else d.completions + c)
    }

    // --- Subjects --------------------------------------------------------------------

    fun addSubject(name: String, colorIndex: Int): Boolean {
        val trimmed = name.trim()
        if (trimmed.isEmpty()) return false
        return repository.update { d ->
            val id = repository.nextId(d.subjects) { it.id }
            d.copy(subjects = d.subjects + Subject(id, trimmed, colorIndex))
        }
    }

    fun renameSubject(id: Long, name: String): Boolean {
        val trimmed = name.trim()
        if (trimmed.isEmpty()) return false
        return repository.update { d ->
            d.copy(subjects = d.subjects.map { if (it.id == id) it.copy(name = trimmed) else it })
        }
    }

    /**
     * Deletes a subject. Tasks and focus records that used it are kept and show as "No subject".
     * Removing a label must never remove study history.
     */
    fun deleteSubject(id: Long): Boolean = repository.update { d ->
        d.copy(
            subjects = d.subjects.filter { it.id != id },
            tasks = d.tasks.map { if (it.subjectId == id) it.copy(subjectId = null) else it },
            focusRecords = d.focusRecords.map { if (it.subjectId == id) it.copy(subjectId = null) else it },
        )
    }

    // --- Settings --------------------------------------------------------------------

    fun saveSettings(settings: StudySettings): Boolean {
        val clamped = settings.clamped()
        val saved = repository.update { d -> d.copy(settings = clamped) }
        if (saved) {
            // An idle timer should show the new length at once.
            repository.updateSession { s ->
                if (s.clock.state == FocusState.IDLE || s.clock.state == FocusState.COMPLETED) {
                    s.copy(clock = FocusClock(plannedMillisFor(s.mode, clamped)))
                } else {
                    s
                }
            }
        }
        return saved
    }

    fun setFirstDayOfWeek(day: DayOfWeek): Boolean =
        saveSettings(data.value.settings.copy(firstDayOfWeek = day))

    // --- Focus timer -----------------------------------------------------------------

    private fun isActive(state: FocusState) = state == FocusState.RUNNING || state == FocusState.PAUSED

    fun selectMode(mode: FocusMode) = repository.updateSession { s ->
        if (isActive(s.clock.state)) s
        else s.copy(mode = mode, clock = FocusClock(plannedMillisFor(mode, data.value.settings)))
    }

    fun selectSubject(subjectId: Long?) = repository.updateSession { s ->
        if (isActive(s.clock.state)) s else s.copy(subjectId = subjectId)
    }

    fun setLabel(label: String) = repository.updateSession { s ->
        if (isActive(s.clock.state)) s else s.copy(label = label.take(60))
    }

    fun focusStart() = repository.updateSession { s ->
        val now = System.currentTimeMillis()
        val fresh = s.clock.state == FocusState.IDLE || s.clock.state == FocusState.COMPLETED
        s.copy(
            clock = s.clock.start(now),
            startedAtMillis = if (fresh) now else s.startedAtMillis,
        )
    }

    fun focusPause() = repository.updateSession { s ->
        s.copy(clock = s.clock.pause(System.currentTimeMillis()))
    }

    fun focusResume() = repository.updateSession { s ->
        s.copy(clock = s.clock.resume(System.currentTimeMillis()))
    }

    fun focusReset() = repository.updateSession { s -> s.copy(clock = s.clock.reset()) }

    /** Called while the Focus screen is visible. A finished focus session is written to disk here. */
    fun focusTick() = repository.tickFocus(System.currentTimeMillis())
}
