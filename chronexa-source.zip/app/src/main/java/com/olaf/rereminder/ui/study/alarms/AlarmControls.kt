// Part of Chronexa, a derivative of reReminder 4.0.1 — GNU GPL v3. See NOTICE.
package com.olaf.rereminder.ui.study.alarms

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.olaf.rereminder.R
import com.olaf.rereminder.service.ActivityAlarms
import com.olaf.rereminder.study.AlarmKind
import com.olaf.rereminder.ui.components.GlowCard
import com.olaf.rereminder.ui.study.pickers.DatePickerSheet
import com.olaf.rereminder.ui.study.pickers.TimePickerSheet
import com.olaf.rereminder.ui.theme.ChronexaCyan
import com.olaf.rereminder.ui.theme.ChronexaViolet
import com.olaf.rereminder.utils.NotificationHelper
import java.time.Instant
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale

/** The reminder time choices offered as chips, in minutes before the start. */
private val LEAD_PRESETS = listOf(0, 5, 10, 15, 30, 60)

/** "Fri 23 Oct, 07:25" in the phone's language. */
fun formatMoment(local: LocalDateTime): String =
    DateTimeFormatter.ofPattern("EEE d MMM, HH:mm", Locale.getDefault()).format(local)

fun formatTrigger(millis: Long): String =
    formatMoment(Instant.ofEpochMilli(millis).atZone(ZoneId.systemDefault()).toLocalDateTime())

/** "07:25" when the moment is today, otherwise with the date. Used on activity rows. */
fun shortMoment(local: LocalDateTime): String {
    val today = LocalDate.now()
    return if (local.toLocalDate() == today) {
        String.format("%02d:%02d", local.hour, local.minute)
    } else {
        formatMoment(local)
    }
}

private fun notificationsGranted(context: Context): Boolean =
    Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU ||
        ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) ==
        PackageManager.PERMISSION_GRANTED

/**
 * "⏰ Reminders & Alarms": the reminder, the start alarm, the repeat choice and the sound, shared by
 * the Schedule and To-Do editors. Everything here is saved with the item and scheduled from it.
 */
@Composable
fun ReminderSection(
    hasTime: Boolean,
    needsTimeText: String,
    remind: Boolean,
    onRemind: (Boolean) -> Unit,
    leadMinutes: Int,
    onLead: (Int) -> Unit,
    customAt: Long?,
    onCustomAt: (Long?) -> Unit,
    alarmOn: Boolean,
    onAlarm: (Boolean) -> Unit,
    startText: String?,
    previewReminder: Long?,
    previewAlarm: Long?,
    repeatContent: (@Composable () -> Unit)?,
    report: List<ActivityAlarms.Entry>,
) {
    val context = LocalContext.current
    val exactAllowed = ActivityAlarms.canScheduleExact(context)
    val notificationsOn = NotificationHelper.canPost(context, NotificationHelper.CHANNEL_REMINDERS)
    var notifGranted by remember { mutableStateOf(notificationsGranted(context)) }
    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        notifGranted = granted
    }

    var customStep by remember { mutableStateOf(CustomStep.NONE) }
    var pickedDate by remember { mutableStateOf<LocalDate?>(null) }
    val zone = ZoneId.systemDefault()
    val customLocal = customAt?.let { Instant.ofEpochMilli(it).atZone(zone).toLocalDateTime() }
    val wantsAnything = (remind || alarmOn) && hasTime

    GlowCard(glow = ChronexaCyan) {
        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text(
                text = stringResource(R.string.reminders_title),
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onSurface,
                fontWeight = FontWeight.SemiBold,
            )
            if (!hasTime) {
                Text(
                    text = needsTimeText,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = stringResource(R.string.reminder_enable),
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.weight(1f),
                )
                Switch(checked = remind && hasTime, onCheckedChange = onRemind, enabled = hasTime)
            }

            if (remind && hasTime) {
                Text(
                    text = stringResource(R.string.reminder_time_label),
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Row(
                    modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    LEAD_PRESETS.forEach { minutes ->
                        FilterChip(
                            selected = customAt == null && leadMinutes == minutes,
                            onClick = {
                                onCustomAt(null)
                                onLead(minutes)
                            },
                            label = { Text(leadLabel(minutes)) },
                        )
                    }
                    FilterChip(
                        selected = customAt != null,
                        onClick = {
                            pickedDate = customLocal?.toLocalDate() ?: LocalDate.now()
                            customStep = CustomStep.DATE
                        },
                        label = {
                            Text(
                                customLocal?.let { formatMoment(it) }
                                    ?: stringResource(R.string.reminder_custom),
                            )
                        },
                    )
                }
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = stringResource(R.string.alarm_enable),
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.weight(1f),
                )
                Switch(checked = alarmOn && hasTime, onCheckedChange = onAlarm, enabled = hasTime)
            }
            if (alarmOn && hasTime) {
                Text(
                    text = stringResource(R.string.alarm_auto_start, startText ?: ""),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }

            if (repeatContent != null) {
                Text(
                    text = stringResource(R.string.repeat_label),
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                repeatContent()
            }

            Text(
                text = stringResource(R.string.sound_default),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )

            if (wantsAnything) {
                if (remind && previewReminder != null) {
                    Text(
                        text = stringResource(R.string.preview_reminder, formatTrigger(previewReminder)),
                        style = MaterialTheme.typography.bodyMedium,
                        color = ChronexaCyan,
                        fontWeight = FontWeight.SemiBold,
                    )
                } else if (remind && customAt != null) {
                    Text(
                        text = stringResource(R.string.preview_passed),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.error,
                    )
                }
                if (alarmOn && previewAlarm != null) {
                    Text(
                        text = stringResource(R.string.preview_alarm, formatTrigger(previewAlarm)),
                        style = MaterialTheme.typography.bodyMedium,
                        color = ChronexaViolet,
                        fontWeight = FontWeight.SemiBold,
                    )
                }
                if (!notifGranted && Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    Text(
                        text = stringResource(R.string.notifications_needed),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.error,
                    )
                    TextButton(onClick = {
                        permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                    }) {
                        Text(stringResource(R.string.notifications_allow))
                    }
                } else if (!notificationsOn) {
                    Text(
                        text = stringResource(R.string.alarm_notifications_off),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.error,
                    )
                }
                if (!exactAllowed) {
                    Text(
                        text = stringResource(R.string.alarm_exact_warning),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    TextButton(onClick = { openExactAlarmSettings(context) }) {
                        Text(stringResource(R.string.alarm_exact_allow))
                    }
                }
            }

            report.forEach { entry ->
                val label = if (entry.kind == AlarmKind.ALARM) {
                    stringResource(R.string.alarm_kind_alarm)
                } else {
                    stringResource(R.string.alarm_kind_reminder)
                }
                Text(
                    text = if (entry.scheduled) {
                        stringResource(R.string.alarm_status_set, label, formatTrigger(entry.triggerAtMillis))
                    } else {
                        stringResource(R.string.alarm_status_failed, label)
                    },
                    style = MaterialTheme.typography.bodySmall,
                    color = if (entry.scheduled) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.error,
                    fontWeight = FontWeight.Medium,
                )
            }
        }
    }

    // The custom reminder is chosen in two steps: date, then time. Both are real Android pickers.
    when (customStep) {
        CustomStep.NONE -> Unit
        CustomStep.DATE -> DatePickerSheet(
            initial = pickedDate ?: LocalDate.now(),
            onConfirm = {
                pickedDate = it
                customStep = CustomStep.TIME
            },
            onDismiss = { customStep = CustomStep.NONE },
        )
        CustomStep.TIME -> TimePickerSheet(
            title = stringResource(R.string.reminder_custom_time_title),
            initialMinute = customLocal?.let { it.hour * 60 + it.minute } ?: (LocalTime.now().hour * 60 + LocalTime.now().minute + 60) % 1440,
            onConfirm = { minute ->
                val date = pickedDate ?: LocalDate.now()
                val moment = LocalDateTime.of(date, LocalTime.of(minute / 60, minute % 60))
                onCustomAt(moment.atZone(zone).toInstant().toEpochMilli())
                customStep = CustomStep.NONE
            },
            onDismiss = { customStep = CustomStep.NONE },
        )
    }
}

private enum class CustomStep { NONE, DATE, TIME }

@Composable
private fun leadLabel(minutes: Int): String = when (minutes) {
    0 -> stringResource(R.string.reminder_at_start)
    5, 10, 15, 30 -> stringResource(R.string.reminder_minutes, minutes)
    else -> stringResource(R.string.reminder_hour)
}

/** Opens the system screen where exact alarms can be allowed. Only shown when they are not allowed. */
private fun openExactAlarmSettings(context: Context) {
    val intent = Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM)
        .setData(Uri.parse("package:${context.packageName}"))
    runCatching { context.startActivity(intent) }
}
