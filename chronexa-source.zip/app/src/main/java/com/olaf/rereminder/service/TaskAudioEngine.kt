// Part of Chronexa, a derivative of reReminder 4.0.1 — GNU GPL v3. See NOTICE.
package com.olaf.rereminder.service

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.util.Log
import com.olaf.rereminder.study.StudyRepository
import com.olaf.rereminder.study.StudyTask
import com.olaf.rereminder.study.hasTaskAudio
import com.olaf.rereminder.study.nextTaskAudioWindow
import com.olaf.rereminder.study.taskAudioEndCodeFor
import com.olaf.rereminder.study.taskAudioStartCodeFor
import com.olaf.rereminder.study.taskAudioWindowStartingAt
import java.time.ZoneId

/**
 * Schedules a task's audio: an exact start at the task's start time, and an exact end at its end time.
 *
 * Each start schedules the same window's end and the next window's start, so daily tasks repeat. Scheduling
 * replaces the previous request codes, so an edit cancels the old start and end before the new ones are set.
 * Nothing here touches the alarm ringtone or the Music Studio player.
 */
object TaskAudioEngine {

    const val ACTION_START = "com.olaf.rereminder.action.TASK_AUDIO_START"
    const val ACTION_END = "com.olaf.rereminder.action.TASK_AUDIO_END"
    const val EXTRA_TASK_ID = "taskId"
    const val EXTRA_SLOT = "slot"
    const val EXTRA_TRIGGER = "trigger"
    private const val TAG = "TaskAudioEngine"

    /** Cancels a slot's scheduled start and end, and stops its audio if it is playing. Safe with no slot. */
    fun cancel(context: Context, slot: Int) {
        if (slot <= 0) return
        val manager = context.getSystemService(AlarmManager::class.java)
        manager?.cancel(pendingFor(context, taskAudioStartCodeFor(slot), ACTION_START, 0L, slot, 0L))
        manager?.cancel(pendingFor(context, taskAudioEndCodeFor(slot), ACTION_END, 0L, slot, 0L))
        TaskAudioService.stop(context, slot)
    }

    /**
     * Schedules the next start for a task. The old start is cancelled first, so a repeated schedule never
     * leaves two. Returns true when a start was set.
     */
    fun schedule(context: Context, task: StudyTask, nowMillis: Long, zone: ZoneId): Boolean {
        if (task.alarmSlot <= 0) return false
        val manager = context.getSystemService(AlarmManager::class.java) ?: return false
        manager.cancel(pendingFor(context, taskAudioStartCodeFor(task.alarmSlot), ACTION_START, task.id, task.alarmSlot, 0L))
        if (!hasTaskAudio(task)) return false
        val (start, _) = nextTaskAudioWindow(task, nowMillis, zone) ?: return false
        return setExact(context, manager, taskAudioStartCodeFor(task.alarmSlot), ACTION_START, task.id, task.alarmSlot, start)
    }

    /**
     * A start fired. It plays only if the task still has audio and this start is still its current window. The
     * end is armed, and the next window is armed for repeating tasks.
     */
    fun onStart(context: Context, taskId: Long, slot: Int, trigger: Long, zone: ZoneId = ZoneId.systemDefault()) {
        val task = StudyRepository.get(context).data.value.tasks
            .firstOrNull { it.id == taskId && it.alarmSlot == slot } ?: return
        val window = taskAudioWindowStartingAt(task, trigger, zone) ?: run {
            Log.i(TAG, "Ignoring a task audio start that is no longer current")
            return
        }
        val manager = context.getSystemService(AlarmManager::class.java)
        if (manager != null) {
            setExact(context, manager, taskAudioEndCodeFor(slot), ACTION_END, taskId, slot, window.second)
            nextTaskAudioWindow(task, trigger, zone)?.let { (next, _) ->
                setExact(context, manager, taskAudioStartCodeFor(slot), ACTION_START, taskId, slot, next)
            }
        }
        TaskAudioService.play(context, slot, task.taskAudioUri, task.taskAudioName)
    }

    /** The end fired: stop this slot's audio. Another slot's audio is left alone. */
    fun onEnd(context: Context, slot: Int) {
        TaskAudioService.stop(context, slot)
    }

    private fun setExact(
        context: Context,
        manager: AlarmManager,
        code: Int,
        action: String,
        taskId: Long,
        slot: Int,
        trigger: Long,
    ): Boolean {
        val pending = pendingFor(context, code, action, taskId, slot, trigger)
        return try {
            manager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, trigger, pending)
            true
        } catch (e: SecurityException) {
            // Exact alarms are not allowed: the audio still starts, but possibly a little late.
            Log.w(TAG, "Exact task audio alarm refused; setting an inexact one", e)
            try {
                manager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, trigger, pending)
                true
            } catch (e2: SecurityException) {
                Log.e(TAG, "Could not schedule task audio", e2)
                false
            }
        }
    }

    private fun pendingFor(
        context: Context,
        code: Int,
        action: String,
        taskId: Long,
        slot: Int,
        trigger: Long,
    ): PendingIntent {
        val intent = Intent(context, TaskAudioReceiver::class.java)
            .setAction(action)
            .putExtra(EXTRA_TASK_ID, taskId)
            .putExtra(EXTRA_SLOT, slot)
            .putExtra(EXTRA_TRIGGER, trigger)
        return PendingIntent.getBroadcast(
            context,
            code,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
    }
}
