// Part of Chronexa, a derivative of reReminder 4.0.1 — GNU GPL v3. See NOTICE.
package com.olaf.rereminder.study

import android.content.Context
import com.olaf.rereminder.data.Storage
import java.io.File
import java.io.IOException
import java.nio.file.AtomicMoveNotSupportedException
import java.nio.file.Files
import java.nio.file.StandardCopyOption

/**
 * Reads and writes the study planner's data file, in device-protected storage next to the
 * reminders (so it is readable before the phone is unlocked after a reboot). Reminder preferences
 * are not touched.
 *
 * Safety rules:
 * - Writes go to a temporary file first and then replace the real one, so a crash cannot leave a
 *   half-written file.
 * - A file written by a *newer* version is opened read-only. It is never overwritten.
 * - A file that cannot be parsed is renamed aside, never deleted, and the app starts from defaults.
 * - Nothing is saved until a load has succeeded, so an unreadable file cannot be replaced by accident.
 */
class StudyStore(private val file: File) {

    sealed interface LoadResult {
        /** Data is ready. [recoveredFrom] names the preserved copy when the old file was unreadable. */
        data class Loaded(val data: StudyData, val recoveredFrom: String?) : LoadResult

        /** Written by a newer version of the app. Shown read-only. */
        data class ReadOnly(val version: Int) : LoadResult

        /** The file exists but could not be read or preserved. Nothing will be written over it. */
        data class Unreadable(val message: String) : LoadResult
    }

    private var writable = false

    @Synchronized
    fun load(nowMillis: Long = System.currentTimeMillis()): LoadResult {
        writable = false
        if (!file.exists()) {
            writable = true
            return LoadResult.Loaded(StudyData.initial(), recoveredFrom = null)
        }
        val text = try {
            file.readText(Charsets.UTF_8)
        } catch (e: IOException) {
            return LoadResult.Unreadable(e.message ?: "read failed")
        }
        return when (val decoded = StudyCodec.decode(text)) {
            is StudyCodec.DecodeResult.Ok -> {
                writable = true
                LoadResult.Loaded(decoded.data, recoveredFrom = null)
            }

            is StudyCodec.DecodeResult.FutureVersion -> LoadResult.ReadOnly(decoded.version)

            is StudyCodec.DecodeResult.Invalid -> {
                val preserved = File(file.parentFile, "study.unreadable-$nowMillis.json")
                try {
                    Files.move(file.toPath(), preserved.toPath())
                } catch (e: IOException) {
                    return LoadResult.Unreadable("could not preserve the unreadable file: ${e.message}")
                }
                writable = true
                LoadResult.Loaded(StudyData.initial(), recoveredFrom = preserved.name)
            }
        }
    }

    /** Returns false when nothing was written: no successful load yet, a read-only file, or an I/O error. */
    @Synchronized
    fun save(data: StudyData): Boolean {
        if (!writable) return false
        val temp = File(file.parentFile, file.name + ".tmp")
        return try {
            temp.writeText(StudyCodec.encode(data), Charsets.UTF_8)
            try {
                Files.move(
                    temp.toPath(),
                    file.toPath(),
                    StandardCopyOption.ATOMIC_MOVE,
                    StandardCopyOption.REPLACE_EXISTING,
                )
            } catch (e: AtomicMoveNotSupportedException) {
                Files.move(temp.toPath(), file.toPath(), StandardCopyOption.REPLACE_EXISTING)
            }
            true
        } catch (e: IOException) {
            temp.delete()
            false
        }
    }

    companion object {
        const val FILE_NAME = "study.json"

        fun forContext(context: Context): StudyStore =
            StudyStore(File(Storage.filesDir(context), FILE_NAME))
    }
}
