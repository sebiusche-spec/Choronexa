// Part of Chronexa, a derivative of reReminder 4.0.1 — GNU GPL v3. See NOTICE.
package com.olaf.rereminder.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.dp
import com.olaf.rereminder.ui.theme.ChronexaCyan
import com.olaf.rereminder.ui.theme.ChronexaViolet
import com.olaf.rereminder.ui.theme.Motion
import com.olaf.rereminder.ui.theme.pressScale
import com.olaf.rereminder.ui.theme.rememberReduceMotion
import kotlinx.coroutines.delay

/**
 * A surface card with a soft accent glow in its top corner and a fine gradient border.
 *
 * The glow is drawn once, statically. Nothing here loops or runs a frame clock while idle, so a
 * dashboard full of these costs no battery. Only press feedback animates, and only on tap.
 */
@Composable
fun GlowCard(
    modifier: Modifier = Modifier,
    glow: Color = ChronexaCyan,
    onClick: (() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit,
) {
    val shape = MaterialTheme.shapes.large
    val isDark = MaterialTheme.colorScheme.background.luminance() < 0.5f
    val glowAlpha = if (isDark) 0.20f else 0.08f
    val interaction = remember { MutableInteractionSource() }
    val press = if (onClick != null) {
        Modifier.pressScale(interaction, pressedScale = 0.98f)
    } else {
        Modifier
    }
    val tap = if (onClick != null) {
        Modifier.clickable(interactionSource = interaction, indication = null, onClick = onClick)
    } else {
        Modifier
    }

    Box(
        modifier = modifier
            .fillMaxWidth()
            .then(press)
            .clip(shape)
            .background(MaterialTheme.colorScheme.surfaceContainer)
            .border(
                width = 1.dp,
                brush = Brush.linearGradient(
                    colors = listOf(
                        glow.copy(alpha = 0.55f),
                        ChronexaViolet.copy(alpha = 0.22f),
                        Color.Transparent,
                    ),
                ),
                shape = shape,
            )
            .then(tap),
    ) {
        Box(
            modifier = Modifier
                .matchParentSize()
                .drawBehind {
                    drawRect(
                        brush = Brush.radialGradient(
                            colors = listOf(glow.copy(alpha = glowAlpha), Color.Transparent),
                            center = Offset(size.width, 0f),
                            radius = size.maxDimension * 0.7f,
                        ),
                    )
                },
        )
        Column(modifier = Modifier.padding(18.dp), content = content)
    }
}

/**
 * Fades a card in and lifts it 14dp into place once it first appears, staggered by [delayMillis]
 * so a column of cards arrives one after another. With reduce-motion on, cards simply appear.
 */
@Composable
fun Modifier.revealOnEnter(delayMillis: Long = 0L): Modifier {
    val reduce = rememberReduceMotion()
    var started by remember { mutableStateOf(reduce) }
    LaunchedEffect(Unit) {
        if (!reduce) {
            delay(delayMillis)
            started = true
        }
    }
    val progress by animateFloatAsState(
        targetValue = if (started) 1f else 0f,
        animationSpec = Motion.fade(),
        label = "reveal",
    )
    val density = LocalDensity.current
    val liftPx = with(density) { 14.dp.toPx() }
    return this.graphicsLayer {
        alpha = progress
        translationY = (1f - progress) * liftPx
    }
}
