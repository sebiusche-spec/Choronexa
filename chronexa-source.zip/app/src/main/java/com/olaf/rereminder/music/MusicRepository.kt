// Part of Chronexa, a derivative of reReminder 4.0.1 — GNU GPL v3. See NOTICE.
package com.olaf.rereminder.music

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/** The music library, loaded from [MusicStore] once and changed only through [update]. */
class MusicRepository private constructor(context: Context) {

    private val store = MusicStore.forContext(context)
    private val lock = Any()

    private val libraryFlow = MutableStateFlow(MusicLibrary.initial())
    val library: StateFlow<MusicLibrary> = libraryFlow.asStateFlow()

    /** A message when the saved file was newer or unreadable. Null when the library loaded normally. */
    var status: String? = null
        private set

    init {
        when (val result = store.load()) {
            is MusicStore.LoadResult.Loaded -> libraryFlow.value = result.library
            is MusicStore.LoadResult.ReadOnly ->
                status = "Your music library was saved by a newer Chronexa, so it is shown read-only."
            is MusicStore.LoadResult.Unreadable -> status = "Your music library could not be read: ${result.message}"
        }
    }

    /** Applies a change and saves it. Returns false, and changes nothing, when saving is not possible. */
    fun update(transform: (MusicLibrary) -> MusicLibrary): Boolean = synchronized(lock) {
        val next = transform(libraryFlow.value)
        if (store.save(next)) {
            libraryFlow.value = next
            true
        } else {
            false
        }
    }

    companion object {
        @Volatile
        private var instance: MusicRepository? = null

        fun get(context: Context): MusicRepository =
            instance ?: synchronized(this) {
                instance ?: MusicRepository(context.applicationContext).also { instance = it }
            }
    }
}
