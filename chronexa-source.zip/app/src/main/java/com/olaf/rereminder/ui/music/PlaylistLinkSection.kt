// Part of Chronexa, a derivative of reReminder 4.0.1 — GNU GPL v3. See NOTICE.
package com.olaf.rereminder.ui.music

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.olaf.rereminder.R
import com.olaf.rereminder.music.MusicRepository
import com.olaf.rereminder.ui.components.GlowCard
import com.olaf.rereminder.ui.theme.ChronexaCyan

/**
 * Chooses the playlist a task uses. The offer switch only decides whether the alarm notification shows a
 * "Play playlist" button. Music never starts by itself, and an empty or missing playlist is reported when
 * the user asks for it, not here.
 */
@Composable
fun PlaylistLinkSection(
    selectedId: String,
    onSelect: (String) -> Unit,
    offerOnStart: Boolean,
    onOffer: (Boolean) -> Unit,
) {
    val context = LocalContext.current
    val library by MusicRepository.get(context).library.collectAsStateWithLifecycle()
    GlowCard(glow = ChronexaCyan) {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(
                text = stringResource(R.string.playlist_link_title),
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onSurface,
                fontWeight = FontWeight.SemiBold,
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(
                    selected = selectedId.isEmpty(),
                    onClick = { onSelect("") },
                    label = { Text(stringResource(R.string.playlist_link_none)) },
                )
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                library.playlists.forEach { playlist ->
                    FilterChip(
                        selected = selectedId == playlist.id,
                        onClick = { onSelect(playlist.id) },
                        label = { Text("${playlist.name} (${playlist.trackUris.size})") },
                    )
                }
            }
            if (selectedId.isNotEmpty()) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = stringResource(R.string.playlist_offer_on_start),
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.weight(1f),
                    )
                    Switch(checked = offerOnStart, onCheckedChange = onOffer)
                }
                Text(
                    text = stringResource(R.string.playlist_offer_note),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.fillMaxWidth(),
                )
            }
        }
    }
}
