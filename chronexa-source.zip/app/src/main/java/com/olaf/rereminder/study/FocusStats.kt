// Part of Chronexa, a derivative of reReminder 4.0.1 — GNU GPL v3. See NOTICE.
package com.olaf.rereminder.study

import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId

private fun FocusRecord.dateIn(zone: ZoneId): LocalDate =
    Instant.ofEpochMilli(completedAtMillis).atZone(zone).toLocalDate()

/** Completed focus seconds on [date] in [zone]. Uses the time the session finished, so a session never counts twice. */
fun focusSecondsOn(records: List<FocusRecord>, date: LocalDate, zone: ZoneId): Long =
    records.filter { it.dateIn(zone) == date }.sumOf { it.plannedSeconds.toLong() }

/** Completed focus seconds from [from] through [to], both inclusive. */
fun focusSecondsBetween(
    records: List<FocusRecord>,
    from: LocalDate,
    to: LocalDate,
    zone: ZoneId,
): Long = records
    .filter { val d = it.dateIn(zone); !d.isBefore(from) && !d.isAfter(to) }
    .sumOf { it.plannedSeconds.toLong() }

/** Completed focus seconds per subject id. A null key collects sessions with no subject. */
fun focusSecondsBySubject(
    records: List<FocusRecord>,
    from: LocalDate,
    to: LocalDate,
    zone: ZoneId,
): Map<Long?, Long> = records
    .filter { val d = it.dateIn(zone); !d.isBefore(from) && !d.isAfter(to) }
    .groupBy { it.subjectId }
    .mapValues { (_, list) -> list.sumOf { it.plannedSeconds.toLong() } }
