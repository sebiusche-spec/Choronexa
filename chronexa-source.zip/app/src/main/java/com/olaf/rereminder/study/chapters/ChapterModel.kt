// Part of Chronexa, a derivative of reReminder 4.0.1 — GNU GPL v3. See NOTICE.
package com.olaf.rereminder.study.chapters

/** The three subjects from the reference chart. Custom subjects come later. */
enum class Subject(val label: String) {
    MATHEMATICS("Mathematics"),
    PHYSICS("Physics"),
    CHEMISTRY("Chemistry"),
}

/**
 * Whether a chapter is part of the syllabus being studied. Every chapter starts as UNCERTAIN: the chart
 * lists chapters, but it is not the official syllabus, so the user decides which ones count.
 */
enum class ChapterStatus { INCLUDED, EXCLUDED, UNCERTAIN }

/** The eight checklist items for each chapter, as on the reference chart. */
enum class ChapterStep {
    LEARN_CONCEPT,
    READ_NOTES,
    UNDERSTAND_FORMULAS,
    SOLVE_EXAMPLES,
    PRACTICE_QUESTIONS,
    REVIEW_MISTAKES,
    MARK_REVISION,
    MARK_COMPLETED,
}

data class Chapter(
    val id: String,
    val subject: Subject,
    val number: Int,
    val name: String,
    val status: ChapterStatus = ChapterStatus.UNCERTAIN,
    val steps: Set<ChapterStep> = emptySet(),
)

/** The chapter list. Progress is always derived from it, never stored separately, so it cannot drift. */
data class ChapterMaster(val chapters: List<Chapter>) {

    /** Sets whether a chapter counts. An unknown id is ignored. */
    fun withStatus(id: String, status: ChapterStatus): ChapterMaster =
        copy(chapters = chapters.map { if (it.id == id) it.copy(status = status) else it })

    /** Ticks a step off or on. Ticking the same step twice returns it to where it was. */
    fun toggleStep(id: String, step: ChapterStep): ChapterMaster = copy(
        chapters = chapters.map { c ->
            if (c.id != id) c else c.copy(steps = if (step in c.steps) c.steps - step else c.steps + step)
        },
    )

    /** Completion for one subject, 0–100, counting included chapters only. Null when none is included. */
    fun subjectPercent(subject: Subject): Int? = percentOf(chapters.filter { it.subject == subject })

    /** Completion across all included chapters, 0–100. Null when none is included. */
    fun overallPercent(): Int? = percentOf(chapters)

    /** Included chapters of one subject, in chapter order. */
    fun includedFor(subject: Subject): List<Chapter> =
        chapters.filter { it.subject == subject && it.status == ChapterStatus.INCLUDED }.sortedBy { it.number }

    private fun percentOf(scope: List<Chapter>): Int? {
        val included = scope.filter { it.status == ChapterStatus.INCLUDED }
        if (included.isEmpty()) return null
        val ticked = included.sumOf { it.steps.size }
        return ticked * 100 / (included.size * ChapterStep.entries.size)
    }

    companion object {
        /** The chart's chapters, in the order printed on it. Names are as written on the chart. */
        fun seeded(): ChapterMaster = ChapterMaster(
            listOf(
                *mathematics().toTypedArray(),
                *physics().toTypedArray(),
                *chemistry().toTypedArray(),
            ),
        )

        private fun mathematics() = listOf(
            "Relations & Functions", "Inverse Trigonometric Functions", "Matrices", "Determinants",
            "Continuity & Differentiability", "Application of Derivatives", "Integrals",
            "Application of Integrals", "Differential Equations", "Vector Algebra", "3D Geometry",
            "Linear Programming", "Probability",
        ).mapIndexed { i, name -> Chapter("math-%02d".format(i + 1), Subject.MATHEMATICS, i + 1, name) }

        private fun physics() = listOf(
            "Electric Charges & Fields", "Electrostatic Potential & Capacitance", "Current Electricity",
            "Moving Charges & Magnetism", "Magnetism & Matter", "Electromagnetic Induction",
            "Alternating Current", "Electromagnetic Waves", "Ray Optics & Optical Instruments",
            "Wave Optics", "Dual Nature of Radiation & Matter", "Atoms", "Nuclei",
            "Semiconductor Electronics",
        ).mapIndexed { i, name -> Chapter("phy-%02d".format(i + 1), Subject.PHYSICS, i + 1, name) }

        private fun chemistry() = listOf(
            "Solid State", "Solutions", "Electrochemistry", "Chemical Kinetics", "Surface Chemistry",
            "General Principles of Isolation", "p-Block Elements", "d & f Block Elements",
            "Coordination Compounds", "Haloalkanes & Haloarenes", "Alcohols, Phenols & Ethers",
            "Aldehydes, Ketones & Carboxylic Acids", "Amines", "Biomolecules", "Polymers",
            "Chemistry in Everyday Life",
        ).mapIndexed { i, name -> Chapter("chem-%02d".format(i + 1), Subject.CHEMISTRY, i + 1, name) }
    }
}
