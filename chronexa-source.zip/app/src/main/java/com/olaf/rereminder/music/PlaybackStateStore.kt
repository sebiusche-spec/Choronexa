// Part of Chronexa, a derivative of reReminder 4.0.1 — GNU GPL v3. See NOTICE.
package com.olaf.rereminder.music

import android.content.Context
import com.olaf.rereminder.data.Storage
import java.io.File
import java.io.IOException
import java.nio.file.AtomicMoveNotSupportedException
import java.nio.file.Files
import java.nio.file.StandardCopyOption

/**
 * Keeps the playback state in its own file, separate from the library. Saved with an atomic write, so a crash
 * mid-save leaves the previous state intact. Nothing here starts playback: the saved state is only offered.
 */
class PlaybackStateStore(private val file: File) {

    /** Writes the snapshot. A null snapshot is ignored, so a stop never erases the state the user may resume. */
    @Synchronized
    fun save(snapshot: PlaybackSnapshot?): Boolean {
        if (snapshot == null) return false
        val temp = File(file.parentFile, file.name + ".tmp")
        return try {
            temp.writeText(PlaybackSnapshotCodec.encode(snapshot), Charsets.UTF_8)
            try {
                Files.move(temp.toPath(), file.toPath(), StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING)
            } catch (e: AtomicMoveNotSupportedException) {
                Files.move(temp.toPath(), file.toPath(), StandardCopyOption.REPLACE_EXISTING)
            }
            true
        } catch (e: IOException) {
            temp.delete()
            false
        }
    }

    /** The saved state, or null when there is none or it cannot be read. */
    @Synchronized
    fun load(): PlaybackSnapshot? {
        if (!file.exists()) return null
        return try {
            when (val decoded = PlaybackSnapshotCodec.decode(file.readText(Charsets.UTF_8))) {
                is PlaybackSnapshotCodec.Decoded.Ok -> decoded.snapshot
                else -> null
            }
        } catch (e: IOException) {
            null
        }
    }

    companion object {
        const val FILE_NAME = "playback.json"

        fun forContext(context: Context): PlaybackStateStore =
            PlaybackStateStore(File(Storage.filesDir(context), FILE_NAME))
    }
}
