// Part of Chronexa, a derivative of reReminder 4.0.1 — GNU GPL v3. See NOTICE.
package com.olaf.rereminder.study.chapters

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * The chapter master, loaded once from [ChapterStore] and changed only through [update]. When the file cannot be
 * saved (newer version, unreadable, or a write failure) the list is shown but changes are refused, and the
 * screen says why.
 */
class ChapterMasterRepository private constructor(context: Context) {

    private val store = ChapterStore.forContext(context)
    private val lock = Any()

    private val masterFlow = MutableStateFlow(ChapterMaster.seeded())
    val master: StateFlow<ChapterMaster> = masterFlow.asStateFlow()

    private val readOnlyFlow = MutableStateFlow(false)
    val readOnly: StateFlow<Boolean> = readOnlyFlow.asStateFlow()

    private val messageFlow = MutableStateFlow<String?>(null)
    val message: StateFlow<String?> = messageFlow.asStateFlow()

    init {
        when (val result = store.load()) {
            is ChapterStore.LoadResult.Loaded -> {
                masterFlow.value = result.master
                readOnlyFlow.value = result.readOnly
                if (result.readOnly) {
                    messageFlow.value = "Your chapter list was saved by a newer Chronexa, so changes are not saved here."
                }
                result.recoveredFrom?.let {
                    messageFlow.value = "The saved chapter list could not be read. It was kept as $it and the chart was loaded again."
                }
            }
            is ChapterStore.LoadResult.Unreadable -> {
                readOnlyFlow.value = true
                messageFlow.value = "The chapter list could not be read: ${result.message}"
            }
        }
    }

    /** Applies a change and saves it. Returns false, and changes nothing, when saving is not allowed or fails. */
    fun update(transform: (ChapterMaster) -> ChapterMaster): Boolean = synchronized(lock) {
        if (readOnlyFlow.value) return false
        val next = transform(masterFlow.value)
        if (store.save(next, readOnly = false)) {
            masterFlow.value = next
            messageFlow.value = null
            true
        } else {
            messageFlow.value = "Could not save the chapter list. Your last change was not kept."
            false
        }
    }

    companion object {
        @Volatile
        private var instance: ChapterMasterRepository? = null

        fun get(context: Context): ChapterMasterRepository =
            instance ?: synchronized(this) {
                instance ?: ChapterMasterRepository(context.applicationContext).also { instance = it }
            }
    }
}
