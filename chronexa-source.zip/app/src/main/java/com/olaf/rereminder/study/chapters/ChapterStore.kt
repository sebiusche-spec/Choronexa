// Part of Chronexa, a derivative of reReminder 4.0.1 — GNU GPL v3. See NOTICE.
package com.olaf.rereminder.study.chapters

import android.content.Context
import com.olaf.rereminder.data.Storage
import java.io.File
import java.io.IOException
import java.nio.file.AtomicMoveNotSupportedException
import java.nio.file.Files
import java.nio.file.StandardCopyOption

/**
 * Keeps the chapter master in its own file. A newer file is read-only; an unreadable file is moved aside, not
 * deleted, before the chart is seeded again. Writes are atomic.
 */
class ChapterStore(private val file: File) {

    sealed interface LoadResult {
        data class Loaded(val master: ChapterMaster, val readOnly: Boolean, val recoveredFrom: String?) : LoadResult
        data class Unreadable(val message: String) : LoadResult
    }

    @Synchronized
    fun load(nowMillis: Long = System.currentTimeMillis()): LoadResult {
        if (!file.exists()) return LoadResult.Loaded(ChapterMaster.seeded(), readOnly = false, recoveredFrom = null)
        val text = try {
            file.readText(Charsets.UTF_8)
        } catch (e: IOException) {
            return LoadResult.Unreadable(e.message ?: "read failed")
        }
        return when (val decoded = ChapterCodec.decode(text)) {
            is ChapterCodec.Decoded.Ok -> LoadResult.Loaded(decoded.master, readOnly = false, recoveredFrom = null)
            is ChapterCodec.Decoded.FutureVersion -> LoadResult.Loaded(ChapterMaster.seeded(), readOnly = true, recoveredFrom = null)
            is ChapterCodec.Decoded.Invalid -> {
                val preserved = File(file.parentFile, "chapters.unreadable-$nowMillis.json")
                try {
                    Files.move(file.toPath(), preserved.toPath())
                } catch (e: IOException) {
                    return LoadResult.Unreadable("could not preserve the unreadable file: ${e.message}")
                }
                LoadResult.Loaded(ChapterMaster.seeded(), readOnly = false, recoveredFrom = preserved.name)
            }
        }
    }

    /** Returns false and writes nothing when the file is read-only or cannot be written. */
    @Synchronized
    fun save(master: ChapterMaster, readOnly: Boolean): Boolean {
        if (readOnly) return false
        val temp = File(file.parentFile, file.name + ".tmp")
        return try {
            temp.writeText(ChapterCodec.encode(master), Charsets.UTF_8)
            try {
                Files.move(temp.toPath(), file.toPath(), StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING)
            } catch (e: AtomicMoveNotSupportedException) {
                Files.move(temp.toPath(), file.toPath(), StandardCopyOption.REPLACE_EXISTING)
            }
            true
        } catch (e: IOException) {
            temp.delete()
            false
        }
    }

    companion object {
        const val FILE_NAME = "chapters.json"

        fun forContext(context: Context): ChapterStore = ChapterStore(File(Storage.filesDir(context), FILE_NAME))
    }
}
