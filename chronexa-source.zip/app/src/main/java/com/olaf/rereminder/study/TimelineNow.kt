// Part of Chronexa, a derivative of reReminder 4.0.1 — GNU GPL v3. See NOTICE.
package com.olaf.rereminder.study

import java.time.LocalDateTime

/**
 * Where the now marker sits among one day's tasks, given their start times in order. Returns the index of the
 * first task that has not started yet, or the number of tasks when every task has started. Returns -1 when the
 * day is not today, so no marker is shown on other days.
 */
fun nowInsertIndex(starts: List<LocalDateTime>, now: LocalDateTime, isToday: Boolean): Int {
    if (!isToday) return -1
    val first = starts.indexOfFirst { it.isAfter(now) }
    return if (first == -1) starts.size else first
}

/** Whether a task is happening at [now]: started, and not yet ended. */
fun isHappeningNow(start: LocalDateTime, end: LocalDateTime, now: LocalDateTime): Boolean =
    !now.isBefore(start) && now.isBefore(end)
