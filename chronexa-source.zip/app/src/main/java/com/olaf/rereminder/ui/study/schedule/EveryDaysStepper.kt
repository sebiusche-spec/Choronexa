// Part of Chronexa, a derivative of reReminder 4.0.1 — GNU GPL v3. See NOTICE.
package com.olaf.rereminder.ui.study.schedule

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Remove
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.olaf.rereminder.R

/** The smallest and largest "every N days" a task can use. Every day is the Daily choice instead. */
const val EVERY_DAYS_MIN = 2
const val EVERY_DAYS_MAX = 60

/** Clamps a requested count into the range the editor offers. */
fun clampEveryDays(value: Int): Int = value.coerceIn(EVERY_DAYS_MIN, EVERY_DAYS_MAX)

/** A − and + stepper for the "every N days" count. Each button stops at its limit, so the value is never out of range. */
@Composable
fun EveryDaysStepper(value: Int, onChange: (Int) -> Unit, modifier: Modifier = Modifier) {
    val current = clampEveryDays(value)
    Row(
        modifier = modifier,
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        IconButton(enabled = current > EVERY_DAYS_MIN, onClick = { onChange(clampEveryDays(current - 1)) }) {
            Icon(Icons.Rounded.Remove, contentDescription = stringResource(R.string.editor_every_less))
        }
        Text(
            text = stringResource(R.string.editor_repeat_every_count, current),
            style = MaterialTheme.typography.titleSmall,
            color = MaterialTheme.colorScheme.onSurface,
        )
        IconButton(enabled = current < EVERY_DAYS_MAX, onClick = { onChange(clampEveryDays(current + 1)) }) {
            Icon(Icons.Rounded.Add, contentDescription = stringResource(R.string.editor_every_more))
        }
    }
}
