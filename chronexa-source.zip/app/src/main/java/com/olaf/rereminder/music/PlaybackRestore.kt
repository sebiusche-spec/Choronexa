// Part of Chronexa, a derivative of reReminder 4.0.1 — GNU GPL v3. See NOTICE.
package com.olaf.rereminder.music

import android.content.Context
import android.net.Uri
import com.olaf.rereminder.R

/**
 * Shows the saved playback state when the Music Studio opens with nothing loaded, paused. It never starts
 * playback. Songs that can no longer be opened are dropped with a message.
 */
object PlaybackRestore {

    fun showSaved(context: Context, library: MusicLibrary) {
        if (MusicPlayback.state.value.queue.current != null) return
        val saved = PlaybackStateStore.forContext(context).load() ?: return
        val restored = restoreAccessible(saved) { canOpen(context, it) }
        if (restored == null) {
            MusicPlayback.publish(PlaybackUi(problem = context.getString(R.string.music_nothing_to_resume)))
            return
        }
        val snapshot = restored.snapshot
        val track = snapshot.order.getOrNull(snapshot.index)?.let { uri -> library.tracks.firstOrNull { it.uri == uri } }
        MusicPlayback.publish(
            PlaybackUi(
                queue = snapshot.toQueue(),
                playing = false,
                positionMs = snapshot.positionMs,
                durationMs = track?.durationMs ?: 0L,
                title = track?.title.orEmpty(),
                artist = track?.artist.orEmpty(),
                problem = if (restored.skipped > 0) context.getString(R.string.music_restore_skipped) else null,
            ),
        )
    }

    private fun canOpen(context: Context, uri: String): Boolean = runCatching {
        context.contentResolver.openInputStream(Uri.parse(uri))?.use { it.read() >= -1 } ?: false
    }.getOrDefault(false)
}
