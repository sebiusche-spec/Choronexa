// Part of Chronexa, a derivative of reReminder 4.0.1 — GNU GPL v3. See NOTICE.
package com.olaf.rereminder.ui.music

import android.content.Context
import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode as AnimRepeat
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.KeyboardArrowUp
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Repeat
import androidx.compose.material.icons.rounded.RepeatOne
import androidx.compose.material.icons.rounded.Remove
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material.icons.rounded.SearchOff
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.SkipPrevious
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material.icons.rounded.StarBorder
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import com.olaf.rereminder.music.PlaybackRestore
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.olaf.rereminder.R
import com.olaf.rereminder.music.MusicImport
import com.olaf.rereminder.music.MusicLibrary
import com.olaf.rereminder.music.MusicPlayback
import com.olaf.rereminder.music.MusicPlaybackService
import com.olaf.rereminder.music.MusicRepository
import com.olaf.rereminder.music.PLAYLIST_FAVORITES
import com.olaf.rereminder.music.PlaybackUi
import com.olaf.rereminder.music.RepeatMode
import com.olaf.rereminder.music.Track
import com.olaf.rereminder.music.addToLibrary
import com.olaf.rereminder.music.addTrackTo
import com.olaf.rereminder.music.allSongs
import com.olaf.rereminder.music.contentsOf
import com.olaf.rereminder.music.createPlaylist
import com.olaf.rereminder.music.deletePlaylist
import com.olaf.rereminder.music.removeFromPlaylist
import com.olaf.rereminder.music.renamePlaylist
import com.olaf.rereminder.music.reorder
import com.olaf.rereminder.music.searchTracks
import com.olaf.rereminder.music.toggleFavorite
import com.olaf.rereminder.ui.components.EmptyState
import com.olaf.rereminder.ui.components.GlowCard
import com.olaf.rereminder.ui.components.NeonIconButton
import com.olaf.rereminder.ui.components.NeonSearchField
import com.olaf.rereminder.ui.theme.ChronexaCyan
import com.olaf.rereminder.ui.theme.ChronexaNavy
import com.olaf.rereminder.ui.theme.ChronexaViolet
import com.olaf.rereminder.ui.theme.rememberReduceMotion

/** The scope value for "every song in the library". */
private const val ALL_SONGS = "__all__"

/**
 * The Music Studio: the phone's songs, playlists and playback, all read from the real library and the
 * real playback service. Nothing here is sample data.
 */
@Composable
fun MusicStudioRoute() {
    val context = LocalContext.current
    val repository = remember(context) { MusicRepository.get(context) }
    val library by repository.library.collectAsStateWithLifecycle()
    val playback by MusicPlayback.state.collectAsStateWithLifecycle()

    // Offer the saved queue and position if nothing is loaded. It is shown paused; Play resumes it.
    LaunchedEffect(Unit) { PlaybackRestore.showSaved(context, library) }

    // Every library change goes through here, so a refused or failed save is shown rather than silently lost.
    var saveError by remember { mutableStateOf<String?>(null) }
    val saveFailed = stringResource(R.string.music_save_failed)
    val change: ((MusicLibrary) -> MusicLibrary) -> Boolean = { transform ->
        val saved = repository.update(transform)
        saveError = if (saved) null else saveFailed
        saved
    }

    var scope by remember { mutableStateOf(ALL_SONGS) }
    var query by remember { mutableStateOf("") }
    var fullPlayer by remember { mutableStateOf(false) }
    var newPlaylist by remember { mutableStateOf(false) }
    var renaming by remember { mutableStateOf(false) }
    var deleting by remember { mutableStateOf(false) }
    var membershipFor by remember { mutableStateOf<Track?>(null) }
    var sortByTitle by remember { mutableStateOf(false) }

    val scopeTracks: List<Track> = if (scope == ALL_SONGS) library.allSongs() else library.contentsOf(scope).tracks
    val visible = searchTracks(scopeTracks, query)
    val shown = if (sortByTitle) visible.sortedBy { it.title.lowercase() } else visible
    val scopePlaylist = library.playlists.firstOrNull { it.id == scope }
    val canReorder = scopePlaylist != null && !sortByTitle && query.isBlank()

    val importer = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) {
            val imported = uris.map { uri ->
                MusicImport.keepAccess(context, uri)
                MusicImport.track(context, uri)
            }
            change { lib ->
                imported.fold(lib) { acc, track ->
                    val withTrack = acc.addToLibrary(track)
                    if (scopePlaylist != null) withTrack.addTrackTo(scope, track) else withTrack
                }
            }
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(ChronexaNavy, Color(0xFF0B1024)))),
    ) {
        Column(modifier = Modifier.fillMaxSize().padding(horizontal = 18.dp, vertical = 12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = stringResource(R.string.music_title),
                    style = MaterialTheme.typography.headlineMedium,
                    color = MaterialTheme.colorScheme.onBackground,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.weight(1f),
                )
                NeonIconButton(
                    icon = Icons.Rounded.Add,
                    contentDescription = stringResource(R.string.music_add_songs),
                    onClick = { importer.launch(arrayOf("audio/*")) },
                )
            }

            repository.status?.let { Notice(it) }
            playback.problem?.let { Notice(it) }
            saveError?.let { Notice(it) }

            NeonSearchField(
                value = query,
                onValueChange = { query = it.take(60) },
                placeholder = stringResource(R.string.music_search),
                modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
            )

            LazyRow(
                modifier = Modifier.padding(top = 10.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                item {
                    FilterChip(
                        selected = scope == ALL_SONGS,
                        onClick = { scope = ALL_SONGS },
                        label = { Text(stringResource(R.string.music_all_songs, library.allSongs().size)) },
                    )
                }
                item {
                    FilterChip(
                        selected = sortByTitle,
                        onClick = { sortByTitle = !sortByTitle },
                        label = { Text(stringResource(R.string.music_sort_title)) },
                    )
                }
                items(library.playlists, key = { it.id }) { playlist ->
                    FilterChip(
                        selected = scope == playlist.id,
                        onClick = { scope = playlist.id },
                        label = { Text("${playlist.name} (${playlist.trackUris.size})") },
                    )
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                OutlinedButton(
                    onClick = { startPlayback(context, visible.map { it.uri }, visible.firstOrNull()?.uri, shuffle = false, scopeId = scope) },
                    enabled = visible.isNotEmpty(),
                ) { Text(stringResource(R.string.music_play_all)) }
                OutlinedButton(
                    onClick = { startPlayback(context, visible.map { it.uri }, visible.randomOrNull()?.uri, shuffle = true, scopeId = scope) },
                    enabled = visible.isNotEmpty(),
                ) { Text(stringResource(R.string.music_shuffle)) }
                OutlinedButton(onClick = { newPlaylist = true }) { Text(stringResource(R.string.music_new_playlist)) }
            }
            if (scopePlaylist != null && !scopePlaylist.builtIn) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    TextButton(onClick = { renaming = true }) { Text(stringResource(R.string.music_rename)) }
                    TextButton(onClick = { deleting = true }) { Text(stringResource(R.string.music_delete_playlist)) }
                }
            }

            when {
                library.allSongs().isEmpty() -> EmptyNote(stringResource(R.string.music_empty_library))
                scopeTracks.isEmpty() -> EmptyNote(stringResource(R.string.music_empty_scope))
                visible.isEmpty() -> EmptyNote(stringResource(R.string.music_no_match), Icons.Rounded.SearchOff)
                else -> LazyColumn(
                    modifier = Modifier.weight(1f).padding(top = 8.dp),
                    contentPadding = PaddingValues(bottom = if (playback.queue.current != null) 96.dp else 16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    itemsIndexed(shown, key = { _, t -> t.uri }) { index, track ->
                        val inPlaylist = scopePlaylist?.trackUris?.indexOf(track.uri) ?: -1
                        TrackRow(
                            track = track,
                            onMoveUp = if (canReorder && inPlaylist > 0) {
                                { change { it.reorder(scope, inPlaylist, inPlaylist - 1) } }
                            } else {
                                null
                            },
                            // Removes the song from this playlist only. The file and other playlists are untouched.
                            onRemove = if (scopePlaylist != null) ({
                                if (change { it.removeFromPlaylist(scope, track.uri) }) removeFromQueue(context, track.uri)
                            }) else null,
                            onMoveDown = if (canReorder && inPlaylist >= 0 && inPlaylist < (scopePlaylist?.trackUris?.size ?: 0) - 1) {
                                { change { it.reorder(scope, inPlaylist, inPlaylist + 1) } }
                            } else {
                                null
                            },
                            favorite = library.playlists.firstOrNull { it.id == PLAYLIST_FAVORITES }?.trackUris?.contains(track.uri) == true,
                            current = playback.queue.current == track.uri,
                            onPlay = {
                                startPlayback(context, shown.map { it.uri }, track.uri, shuffle = playback.queue.shuffle, scopeId = scope)
                            },
                            onFavorite = { change { it.toggleFavorite(track.uri) } },
                            onMembership = { membershipFor = track },
                        )
                    }
                }
            }
        }

        if (playback.queue.current != null) {
            MiniPlayer(
                state = playback,
                context = context,
                onOpen = { fullPlayer = true },
                modifier = Modifier.align(Alignment.BottomCenter).padding(12.dp),
            )
        }

        AnimatedVisibility(
            visible = fullPlayer && playback.queue.current != null,
            enter = fadeIn() + slideInVertically { it / 4 },
            exit = fadeOut() + slideOutVertically { it / 4 },
            modifier = Modifier.fillMaxSize(),
        ) {
            FullPlayer(state = playback, context = context, scopeName = scopePlaylist?.name, onClose = { fullPlayer = false })
        }
    }

    if (newPlaylist) {
        NameDialog(
            title = stringResource(R.string.music_new_playlist),
            initial = "",
            onConfirm = { name ->
                change { it.createPlaylist(name) }
                newPlaylist = false
            },
            onDismiss = { newPlaylist = false },
        )
    }
    if (renaming && scopePlaylist != null) {
        NameDialog(
            title = stringResource(R.string.music_rename),
            initial = scopePlaylist.name,
            onConfirm = { name ->
                change { it.renamePlaylist(scopePlaylist.id, name) }
                renaming = false
            },
            onDismiss = { renaming = false },
        )
    }
    if (deleting && scopePlaylist != null) {
        AlertDialog(
            onDismissRequest = { deleting = false },
            title = { Text(stringResource(R.string.music_delete_playlist)) },
            text = { Text(stringResource(R.string.music_delete_confirm)) },
            confirmButton = {
                TextButton(onClick = {
                    change { it.deletePlaylist(scopePlaylist.id) }
                    scope = ALL_SONGS
                    deleting = false
                }) { Text(stringResource(R.string.common_delete)) }
            },
            dismissButton = { TextButton(onClick = { deleting = false }) { Text(stringResource(R.string.common_cancel)) } },
        )
    }
    membershipFor?.let { track ->
        MembershipDialog(
            track = track,
            library = library,
            onToggle = { playlistId, inList ->
                val saved = change { lib ->
                    if (inList) lib.removeFromPlaylist(playlistId, track.uri) else lib.addTrackTo(playlistId, track)
                }
                if (saved && inList) removeFromQueue(context, track.uri)
            },
            onDismiss = { membershipFor = null },
        )
    }
}

/**
 * Tells the playback service that a song left a playlist, so a removed song is not played from the live queue.
 * Only sent when the library change was saved. A song that is not queued is ignored by the service.
 */
private fun removeFromQueue(context: Context, uri: String) {
    if (uri !in MusicPlayback.state.value.queue.order) return
    val intent = Intent(context, MusicPlaybackService::class.java)
        .setAction(MusicPlaybackService.ACTION_REMOVE_TRACK)
        .putExtra(MusicPlaybackService.EXTRA_URI, uri)
    runCatching { context.startService(intent) }
}

/** Starts playback of a list of songs, from one of them. Only the user's tap starts music. */
private fun startPlayback(context: Context, uris: List<String>, startUri: String?, shuffle: Boolean, scopeId: String) {
    if (uris.isEmpty()) return
    val intent = Intent(context, MusicPlaybackService::class.java)
        .setAction(MusicPlaybackService.ACTION_PLAY_QUEUE)
        .putStringArrayListExtra(MusicPlaybackService.EXTRA_URIS, ArrayList(uris))
        .putExtra(MusicPlaybackService.EXTRA_START_URI, startUri)
        .putExtra(MusicPlaybackService.EXTRA_SHUFFLE, shuffle)
        .putExtra(MusicPlaybackService.EXTRA_SCOPE, scopeId)
    MusicPlaybackService.send(context, intent)
}

/** Sends a transport command (toggle, next, previous, stop, shuffle, repeat) to the service. */
private fun command(context: Context, action: String, position: Long? = null) {
    val intent = Intent(context, MusicPlaybackService::class.java).setAction(action)
    if (position != null) intent.putExtra(MusicPlaybackService.EXTRA_POSITION, position)
    MusicPlaybackService.send(context, intent)
}

@Composable
private fun Notice(text: String) {
    Text(
        text = text,
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.error,
        modifier = Modifier.fillMaxWidth().padding(top = 6.dp),
    )
}

@Composable
private fun EmptyNote(text: String, icon: androidx.compose.ui.graphics.vector.ImageVector = Icons.Rounded.MusicNote) {
    EmptyState(icon = icon, body = text, modifier = Modifier.padding(top = 24.dp))
}

/** A generated artwork tile: a gradient with the song's initial. Used when no album art is available. */
@Composable
fun ArtTile(seed: String, size: androidx.compose.ui.unit.Dp, playing: Boolean = false) {
    val initial = seed.trim().firstOrNull()?.uppercaseChar()?.toString() ?: "♪"
    Box(
        modifier = Modifier
            .size(size)
            .clip(RoundedCornerShape(size * 0.25f))
            .background(Brush.linearGradient(listOf(ChronexaCyan.copy(alpha = 0.55f), ChronexaViolet.copy(alpha = 0.7f))))
            .border(1.dp, ChronexaCyan.copy(alpha = if (playing) 0.8f else 0.3f), RoundedCornerShape(size * 0.25f)),
        contentAlignment = Alignment.Center,
    ) {
        Text(text = initial, style = MaterialTheme.typography.titleLarge, color = Color.White, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun TrackRow(
    track: Track,
    favorite: Boolean,
    current: Boolean,
    onPlay: () -> Unit,
    onFavorite: () -> Unit,
    onMembership: () -> Unit,
    onMoveUp: (() -> Unit)? = null,
    onMoveDown: (() -> Unit)? = null,
    onRemove: (() -> Unit)? = null,
) {
    var menuOpen by remember { mutableStateOf(false) }
    GlowCard(glow = if (current) ChronexaCyan else ChronexaViolet, onClick = onPlay) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            ArtTile(seed = track.title, size = 46.dp, playing = current)
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = track.title,
                    style = MaterialTheme.typography.titleSmall,
                    color = if (current) ChronexaCyan else MaterialTheme.colorScheme.onSurface,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                Text(
                    text = track.artist.ifEmpty { stringResource(R.string.music_unknown_artist) } +
                        if (track.durationMs > 0) "  ·  ${formatDuration(track.durationMs)}" else "",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
            IconButton(onClick = onFavorite) {
                Icon(
                    imageVector = if (favorite) Icons.Rounded.Star else Icons.Rounded.StarBorder,
                    contentDescription = stringResource(R.string.music_favorite),
                    tint = if (favorite) ChronexaCyan else MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            // Everything else lives in one menu, so the row never runs out of room on a narrow phone.
            Box {
                IconButton(onClick = { menuOpen = true }) {
                    Icon(Icons.Rounded.MoreVert, contentDescription = stringResource(R.string.music_song_actions))
                }
                DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                    if (onRemove != null) {
                        DropdownMenuItem(
                            text = { Text(stringResource(R.string.music_remove_from_playlist)) },
                            leadingIcon = { Icon(Icons.Rounded.Remove, contentDescription = null) },
                            onClick = { menuOpen = false; onRemove() },
                        )
                    }
                    if (onMoveUp != null) {
                        DropdownMenuItem(
                            text = { Text(stringResource(R.string.music_move_up)) },
                            leadingIcon = { Icon(Icons.Rounded.KeyboardArrowUp, contentDescription = null) },
                            onClick = { menuOpen = false; onMoveUp() },
                        )
                    }
                    if (onMoveDown != null) {
                        DropdownMenuItem(
                            text = { Text(stringResource(R.string.music_move_down)) },
                            leadingIcon = { Icon(Icons.Rounded.KeyboardArrowDown, contentDescription = null) },
                            onClick = { menuOpen = false; onMoveDown() },
                        )
                    }
                    DropdownMenuItem(
                        text = { Text(stringResource(R.string.music_add_to_playlists)) },
                        onClick = { menuOpen = false; onMembership() },
                    )
                }
            }
        }
    }
}

/** Playlists a song belongs to, with one switch each. Removing a song never deletes its file. */
@Composable
private fun MembershipDialog(
    track: Track,
    library: MusicLibrary,
    onToggle: (String, Boolean) -> Unit,
    onDismiss: () -> Unit,
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(track.title, maxLines = 1, overflow = TextOverflow.Ellipsis) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(stringResource(R.string.music_add_to_playlists), style = MaterialTheme.typography.labelLarge)
                library.playlists.forEach { playlist ->
                    val inList = playlist.trackUris.contains(track.uri)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(playlist.name, modifier = Modifier.weight(1f))
                        Switch(checked = inList, onCheckedChange = { onToggle(playlist.id, inList) })
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text(stringResource(R.string.common_done)) } },
    )
}

@Composable
private fun NameDialog(title: String, initial: String, onConfirm: (String) -> Unit, onDismiss: () -> Unit) {
    var text by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            OutlinedTextField(
                value = text,
                onValueChange = { text = it.take(40) },
                singleLine = true,
                label = { Text(stringResource(R.string.music_playlist_name)) },
            )
        },
        confirmButton = { TextButton(enabled = text.isNotBlank(), onClick = { onConfirm(text) }) { Text(stringResource(R.string.common_save)) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text(stringResource(R.string.common_cancel)) } },
    )
}

@Composable
private fun MiniPlayer(state: PlaybackUi, context: Context, onOpen: () -> Unit, modifier: Modifier = Modifier) {
    GlowCard(glow = ChronexaCyan, onClick = onOpen, modifier = modifier) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            ArtTile(seed = state.title, size = 40.dp, playing = state.playing)
            Column(modifier = Modifier.weight(1f)) {
                Text(state.title.ifEmpty { stringResource(R.string.music_now_playing) }, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.titleSmall)
                Text(state.artist, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            IconButton(onClick = { command(context, MusicPlaybackService.ACTION_TOGGLE) }) {
                Icon(if (state.playing) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, contentDescription = stringResource(if (state.playing) R.string.music_pause else R.string.music_play))
            }
            IconButton(onClick = { command(context, MusicPlaybackService.ACTION_NEXT) }) {
                Icon(Icons.Rounded.SkipNext, contentDescription = stringResource(R.string.music_next))
            }
        }
    }
}

@Composable
private fun FullPlayer(state: PlaybackUi, context: Context, scopeName: String?, onClose: () -> Unit) {
    var dragging by remember { mutableFloatStateOf(-1f) }
    val duration = state.durationMs.coerceAtLeast(1L)
    val shown = if (dragging >= 0f) dragging else (state.positionMs.toFloat() / duration.toFloat()).coerceIn(0f, 1f)
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(ChronexaNavy, Color(0xFF13183A))))
            .padding(22.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text(
                text = scopeName ?: stringResource(R.string.music_all_songs_short),
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.weight(1f),
            )
            IconButton(onClick = onClose) { Icon(Icons.Rounded.Close, contentDescription = stringResource(R.string.music_close)) }
        }
        SpinningArt(playing = state.playing, title = state.title)
        Visualizer(playing = state.playing)
        Text(state.title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text(state.artist, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Slider(
            value = shown,
            onValueChange = { dragging = it },
            onValueChangeFinished = {
                command(context, MusicPlaybackService.ACTION_SEEK, position = (dragging * duration).toLong())
                dragging = -1f
            },
            modifier = Modifier.fillMaxWidth(),
        )
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(formatDuration(state.positionMs), style = MaterialTheme.typography.labelMedium)
            Text(formatDuration(state.durationMs), style = MaterialTheme.typography.labelMedium)
        }
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            IconButton(onClick = { command(context, MusicPlaybackService.ACTION_SHUFFLE) }) {
                Icon(Icons.Rounded.Shuffle, contentDescription = stringResource(R.string.music_shuffle), tint = if (state.queue.shuffle) ChronexaCyan else MaterialTheme.colorScheme.onSurfaceVariant)
            }
            IconButton(onClick = { command(context, MusicPlaybackService.ACTION_PREVIOUS) }) {
                Icon(Icons.Rounded.SkipPrevious, contentDescription = stringResource(R.string.music_previous), modifier = Modifier.size(36.dp))
            }
            IconButton(onClick = { command(context, MusicPlaybackService.ACTION_TOGGLE) }, modifier = Modifier.size(64.dp).clip(CircleShape).background(ChronexaCyan.copy(alpha = 0.2f))) {
                Icon(if (state.playing) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, contentDescription = stringResource(if (state.playing) R.string.music_pause else R.string.music_play), modifier = Modifier.size(36.dp))
            }
            IconButton(onClick = { command(context, MusicPlaybackService.ACTION_NEXT) }) {
                Icon(Icons.Rounded.SkipNext, contentDescription = stringResource(R.string.music_next), modifier = Modifier.size(36.dp))
            }
            IconButton(onClick = { command(context, MusicPlaybackService.ACTION_REPEAT) }) {
                val repeatIcon = if (state.queue.repeat == RepeatMode.ONE) Icons.Rounded.RepeatOne else Icons.Rounded.Repeat
                Icon(repeatIcon, contentDescription = stringResource(repeatLabel(state.queue.repeat)), tint = if (state.queue.repeat == RepeatMode.OFF) MaterialTheme.colorScheme.onSurfaceVariant else ChronexaCyan)
            }
        }
    }
}

private fun repeatLabel(mode: RepeatMode): Int = when (mode) {
    RepeatMode.OFF -> R.string.music_repeat_off
    RepeatMode.ALL -> R.string.music_repeat_all
    RepeatMode.ONE -> R.string.music_repeat_one
}

/** Artwork that turns while a song plays. Not composed when paused or when reduced motion is on, so it costs nothing then. */
@Composable
private fun SpinningArt(playing: Boolean, title: String) {
    val reduce = rememberReduceMotion()
    if (playing && !reduce) {
        val transition = rememberInfiniteTransition(label = "spin")
        val angle by transition.animateFloat(
            initialValue = 0f,
            targetValue = 360f,
            animationSpec = infiniteRepeatable(tween(durationMillis = 14_000, easing = LinearEasing), AnimRepeat.Restart),
            label = "angle",
        )
        Box(modifier = Modifier.size(220.dp).rotate(angle), contentAlignment = Alignment.Center) { ArtTile(seed = title, size = 200.dp, playing = true) }
    } else {
        Box(modifier = Modifier.size(220.dp), contentAlignment = Alignment.Center) { ArtTile(seed = title, size = 200.dp, playing = playing) }
    }
}

/**
 * Bars that move only while a song is playing. Paused or idle, they sit at rest, so nothing is animated
 * that is not actually playing. Under reduced motion they stay at rest too.
 */
@Composable
private fun Visualizer(playing: Boolean) {
    val reduce = rememberReduceMotion()
    val phase = if (playing && !reduce) {
        val transition = rememberInfiniteTransition(label = "bars")
        transition.animateFloat(
            initialValue = 0f,
            targetValue = 1f,
            animationSpec = infiniteRepeatable(tween(durationMillis = 900, easing = LinearEasing), AnimRepeat.Reverse),
            label = "phase",
        ).value
    } else {
        0f
    }
    Row(modifier = Modifier.height(44.dp), verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        repeat(BAR_COUNT) { i ->
            val wave = if (playing && !reduce) kotlin.math.abs(kotlin.math.sin((phase * 6.28f) + i * 0.7f)) else 0f
            Box(
                modifier = Modifier
                    .size(width = 6.dp, height = (6 + wave * 36).dp)
                    .clip(RoundedCornerShape(3.dp))
                    .background(if (playing) ChronexaCyan.copy(alpha = 0.9f) else MaterialTheme.colorScheme.outline),
            )
        }
    }
}

private const val BAR_COUNT = 18

/** m:ss for a length in milliseconds. */
fun formatDuration(ms: Long): String {
    val total = (ms / 1000L).coerceAtLeast(0L)
    return String.format(java.util.Locale.ROOT, "%d:%02d", total / 60, total % 60)
}
