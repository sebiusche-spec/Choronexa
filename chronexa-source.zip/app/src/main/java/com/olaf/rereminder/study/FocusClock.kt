// Part of Chronexa, a derivative of reReminder 4.0.1 — GNU GPL v3. See NOTICE.
package com.olaf.rereminder.study

/** Where a focus session is in its life. [COMPLETED] is reached only when the countdown hits zero. */
enum class FocusState { IDLE, RUNNING, PAUSED, COMPLETED }

/**
 * A focus countdown that is calculated from timestamps, not from ticks.
 *
 * While running, elapsed time is the time banked before the last pause plus (now - the moment the
 * current run started). Nothing is decremented per frame, so recreating the Activity, backgrounding
 * the app, or the screen turning off does not change the answer. Callers pass the current time in,
 * which keeps this class pure and testable.
 *
 * Wall-clock time is used. If the user changes the clock during a session, the remaining time can
 * jump; a backwards jump never produces negative elapsed time.
 */
data class FocusClock(
    val plannedMillis: Long,
    val state: FocusState = FocusState.IDLE,
    /** Time banked from earlier runs, excluding the current run while RUNNING. */
    val bankedMillis: Long = 0L,
    /** Start of the current run. Meaningful only while RUNNING. */
    val runStartedAtMillis: Long = 0L,
) {
    fun elapsedMillis(nowMillis: Long): Long {
        val currentRun = if (state == FocusState.RUNNING) {
            (nowMillis - runStartedAtMillis).coerceAtLeast(0L)
        } else {
            0L
        }
        return (bankedMillis + currentRun).coerceIn(0L, plannedMillis)
    }

    fun remainingMillis(nowMillis: Long): Long =
        (plannedMillis - elapsedMillis(nowMillis)).coerceAtLeast(0L)

    /** Starts a new session from zero. Ignored while already running or paused. */
    fun start(nowMillis: Long): FocusClock = when (state) {
        FocusState.IDLE, FocusState.COMPLETED -> copy(
            state = FocusState.RUNNING,
            bankedMillis = 0L,
            runStartedAtMillis = nowMillis,
        )
        FocusState.RUNNING, FocusState.PAUSED -> this
    }

    fun pause(nowMillis: Long): FocusClock =
        if (state != FocusState.RUNNING) this else copy(
            state = FocusState.PAUSED,
            bankedMillis = elapsedMillis(nowMillis),
            runStartedAtMillis = 0L,
        )

    fun resume(nowMillis: Long): FocusClock =
        if (state != FocusState.PAUSED) this else copy(
            state = FocusState.RUNNING,
            runStartedAtMillis = nowMillis,
        )

    /** Abandons the session. Nothing is recorded for a reset session. */
    fun reset(): FocusClock = FocusClock(plannedMillis = plannedMillis)

    /**
     * Moves a running session to [FocusState.COMPLETED] once its time is up. Call this on a timer
     * or when the screen is shown again. A caller records a [FocusRecord] only when the state goes
     * from RUNNING to COMPLETED, which is the only way a session can be counted.
     */
    fun tick(nowMillis: Long): FocusClock {
        if (state != FocusState.RUNNING) return this
        if (elapsedMillis(nowMillis) < plannedMillis) return this
        return copy(
            state = FocusState.COMPLETED,
            bankedMillis = plannedMillis,
            runStartedAtMillis = 0L,
        )
    }

    /** True exactly once: at the transition into completion. */
    fun completedBy(previous: FocusClock): Boolean =
        previous.state == FocusState.RUNNING && state == FocusState.COMPLETED
}
