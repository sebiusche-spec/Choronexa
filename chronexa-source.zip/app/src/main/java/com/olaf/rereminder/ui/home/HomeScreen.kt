// Part of Chronexa, a derivative of reReminder 4.0.1 — GNU GPL v3. See NOTICE.
package com.olaf.rereminder.ui.home

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Alarm
import androidx.compose.material.icons.rounded.Timer
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.olaf.rereminder.R
import com.olaf.rereminder.study.Completion
import com.olaf.rereminder.study.Occurrence
import com.olaf.rereminder.study.StudyData
import com.olaf.rereminder.study.isOverdue
import com.olaf.rereminder.study.occurrencesStartingOn
import com.olaf.rereminder.study.summarizeDay
import com.olaf.rereminder.ui.components.GlowCard
import com.olaf.rereminder.ui.components.revealOnEnter
import com.olaf.rereminder.ui.format.formatCalendarDate
import com.olaf.rereminder.ui.format.formatClockTime
import com.olaf.rereminder.ui.format.formatCoarseCountdown
import com.olaf.rereminder.ui.study.AnimatedCheckbox
import com.olaf.rereminder.ui.study.EmptyState
import com.olaf.rereminder.ui.study.ProgressRing
import com.olaf.rereminder.ui.study.StudyViewModel
import com.olaf.rereminder.ui.study.accentFor
import com.olaf.rereminder.ui.study.clockLabel
import com.olaf.rereminder.ui.study.minutesLabel
import com.olaf.rereminder.ui.theme.ChronexaCyan
import com.olaf.rereminder.ui.theme.ChronexaViolet
import com.olaf.rereminder.ui.theme.Motion
import com.olaf.rereminder.ui.theme.pressScale
import java.time.Instant
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.ZoneId

@Composable
fun HomeRoute(
    onOpenSchedule: () -> Unit,
    onOpenFocus: () -> Unit,
    onOpenAlarms: () -> Unit,
    viewModel: HomeViewModel = viewModel(),
    study: StudyViewModel = viewModel(),
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    HomeScreen(
        state = state,
        onOpenSchedule = onOpenSchedule,
        onOpenFocus = onOpenFocus,
        onOpenAlarms = onOpenAlarms,
        onToggle = { task, date -> study.toggleCompletion(task.id, date) },
    )
}

@Composable
fun HomeScreen(
    state: HomeUiState,
    onOpenSchedule: () -> Unit,
    onOpenFocus: () -> Unit,
    onOpenAlarms: () -> Unit,
    onToggle: (com.olaf.rereminder.study.StudyTask, LocalDate) -> Unit,
) {
    val zone = ZoneId.systemDefault()
    val now = Instant.ofEpochMilli(state.now).atZone(zone).toLocalDateTime()
    val today = now.toLocalDate()
    val todays = occurrencesStartingOn(state.study.tasks, today)
    val progress = summarizeDay(state.study.tasks, state.study.completions, today)
    val upcoming = upcomingOccurrences(state.study, now, days = 7, limit = 3)

    LazyColumn(
        modifier = Modifier.fillMaxWidth(),
        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        item(key = "header") {
            Greeting(state)
        }

        item(key = "orb") {
            Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                EnergyOrb(size = 190.dp, energetic = state.focusRunning)
            }
        }

        item(key = "quick") {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                QuickAction(
                    label = stringResource(R.string.home_quick_add_task),
                    icon = Icons.Rounded.Add,
                    accent = ChronexaCyan,
                    onClick = onOpenSchedule,
                    modifier = Modifier.weight(1f),
                )
                QuickAction(
                    label = stringResource(R.string.home_quick_alarm),
                    icon = Icons.Rounded.Alarm,
                    accent = ChronexaViolet,
                    onClick = onOpenAlarms,
                    modifier = Modifier.weight(1f),
                )
                QuickAction(
                    label = stringResource(R.string.home_quick_focus),
                    icon = Icons.Rounded.Timer,
                    accent = ChronexaCyan,
                    onClick = onOpenFocus,
                    modifier = Modifier.weight(1f),
                )
            }
        }

        item(key = "alarm") { NextAlarmCard(state) }

        item(key = "progress") {
            GlowCard(glow = ChronexaCyan, modifier = Modifier.revealOnEnter(delayMillis = 60L)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                    ProgressRing(
                        progress = progress.percent / 100f,
                        modifier = Modifier.size(78.dp),
                        strokeWidth = 8.dp,
                        color = ChronexaCyan,
                    ) {
                        Text(
                            text = "${progress.percent}%",
                            style = MaterialTheme.typography.labelLarge,
                            color = MaterialTheme.colorScheme.onSurface,
                            fontWeight = FontWeight.SemiBold,
                        )
                    }
                    Column {
                        Text(
                            text = stringResource(R.string.home_progress_today),
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.onSurface,
                        )
                        Text(
                            text = if (progress.total == 0) {
                                stringResource(R.string.home_progress_no_tasks)
                            } else {
                                stringResource(R.string.schedule_done_summary, progress.completed, progress.total)
                            },
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
            }
        }

        item(key = "today_title") {
            Text(
                text = stringResource(R.string.home_today_tasks),
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onBackground,
                fontWeight = FontWeight.SemiBold,
            )
        }

        if (todays.isEmpty()) {
            item(key = "today_empty") {
                EmptyState(
                    title = stringResource(R.string.home_today_empty_title),
                    body = stringResource(R.string.home_today_empty_body),
                )
            }
        } else {
            items(todays.take(6), key = { "today-${it.task.id}" }) { occurrence ->
                val done = Completion(occurrence.task.id, today) in state.study.completions
                TodayRow(
                    occurrence = occurrence,
                    state = state.study,
                    completed = done,
                    overdue = isOverdue(occurrence, done, now),
                    onToggle = { onToggle(occurrence.task, today) },
                )
            }
        }

        item(key = "upcoming_title") {
            Text(
                text = stringResource(R.string.home_upcoming),
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onBackground,
                fontWeight = FontWeight.SemiBold,
            )
        }
        if (upcoming.isEmpty()) {
            item(key = "upcoming_empty") {
                Text(
                    text = stringResource(R.string.home_upcoming_empty),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        } else {
            items(upcoming, key = { "up-${it.task.id}-${it.startAt}" }) { occurrence ->
                UpcomingRow(occurrence, today)
            }
        }

        item(key = "focus") {
            GlowCard(glow = ChronexaViolet, modifier = Modifier.revealOnEnter(delayMillis = 120L)) {
                Text(
                    text = stringResource(R.string.home_focus_today),
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.secondary,
                    fontWeight = FontWeight.SemiBold,
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    text = minutesLabel(state.focusSecondsToday / 60),
                    style = MaterialTheme.typography.headlineSmall,
                    color = MaterialTheme.colorScheme.onSurface,
                    fontWeight = FontWeight.SemiBold,
                )
                Spacer(Modifier.height(8.dp))
                Button(onClick = onOpenFocus) { Text(stringResource(R.string.home_focus_open)) }
            }
        }
    }
}

/** The next occurrences that start after [now], looking [days] days ahead. */
private fun upcomingOccurrences(
    data: StudyData,
    now: LocalDateTime,
    days: Long,
    limit: Int,
): List<Occurrence> {
    val result = mutableListOf<Occurrence>()
    for (offset in 0L..days) {
        val day = now.toLocalDate().plusDays(offset)
        occurrencesStartingOn(data.tasks, day)
            .filter { it.startAt.isAfter(now) }
            .forEach { result += it }
        if (result.size >= limit) break
    }
    return result.sortedBy { it.startAt }.take(limit)
}

@Composable
private fun Greeting(state: HomeUiState) {
    val name = state.displayName
    val part = dayPartFor(state.hour)
    val text = when (part) {
        DayPart.MORNING -> if (name.isEmpty()) stringResource(R.string.home_greeting_morning_plain)
        else stringResource(R.string.home_greeting_morning, name)
        DayPart.AFTERNOON -> if (name.isEmpty()) stringResource(R.string.home_greeting_afternoon_plain)
        else stringResource(R.string.home_greeting_afternoon, name)
        DayPart.EVENING -> if (name.isEmpty()) stringResource(R.string.home_greeting_evening_plain)
        else stringResource(R.string.home_greeting_evening, name)
    }
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(
            text = formatCalendarDate(state.now),
            style = MaterialTheme.typography.labelMedium,
            color = ChronexaCyan,
            fontWeight = FontWeight.SemiBold,
        )
        Text(
            text = text,
            style = MaterialTheme.typography.headlineMedium,
            color = MaterialTheme.colorScheme.onBackground,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
        )
    }
}

@Composable
private fun NextAlarmCard(state: HomeUiState) {
    GlowCard(glow = ChronexaViolet, modifier = Modifier.revealOnEnter(delayMillis = 30L)) {
        Text(
            text = stringResource(R.string.home_next_alarm_label).uppercase(),
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.secondary,
            fontWeight = FontWeight.SemiBold,
            letterSpacing = 1.5.sp,
        )
        Spacer(Modifier.height(6.dp))
        val next = state.nextAlarm
        when {
            !state.masterEnabled -> Text(
                text = stringResource(R.string.home_next_alarm_paused),
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onSurface,
            )
            next == null -> Text(
                text = stringResource(R.string.home_next_alarm_none),
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onSurface,
            )
            else -> {
                Text(
                    text = next.name,
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onSurface,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                Text(
                    text = stringResource(
                        R.string.home_next_alarm_in,
                        formatClockTime(next.atMillis),
                        formatCoarseCountdown(next.atMillis - state.now),
                    ),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
    }
}

@Composable
private fun QuickAction(
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    accent: androidx.compose.ui.graphics.Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val interaction = remember { MutableInteractionSource() }
    Column(
        modifier = modifier
            .pressScale(interaction, pressedScale = 0.94f)
            .clip(RoundedCornerShape(18.dp))
            .background(accent.copy(alpha = 0.12f))
            .clickable(interactionSource = interaction, indication = null, onClick = onClick)
            .padding(vertical = 14.dp, horizontal = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        Icon(icon, contentDescription = null, tint = accent, modifier = Modifier.size(24.dp))
        Text(
            text = label,
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurface,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
    }
}

@Composable
private fun TodayRow(
    occurrence: Occurrence,
    state: StudyData,
    completed: Boolean,
    overdue: Boolean,
    onToggle: () -> Unit,
) {
    val subject = state.subjects.firstOrNull { it.id == occurrence.task.subjectId }
    val accent = subject?.let { accentFor(it.colorIndex) } ?: ChronexaCyan
    GlowCard(glow = accent, modifier = Modifier.revealOnEnter()) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            AnimatedCheckbox(
                checked = completed,
                onCheckedChange = { onToggle() },
                description = stringResource(R.string.schedule_complete_description, occurrence.task.title),
                accent = accent,
            )
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "${clockLabel(occurrence.task.startMinute)} · ${occurrence.task.title}",
                    style = MaterialTheme.typography.bodyLarge,
                    color = if (completed) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.onSurface,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                if (overdue) {
                    Text(
                        text = stringResource(R.string.schedule_overdue),
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.error,
                    )
                }
            }
        }
    }
}

@Composable
private fun UpcomingRow(occurrence: Occurrence, today: LocalDate) {
    val dayLabel = if (occurrence.date == today) {
        stringResource(R.string.home_today)
    } else {
        occurrence.date.toString()
    }
    Text(
        text = "$dayLabel · ${clockLabel(occurrence.task.startMinute)}  ${occurrence.task.title}",
        style = MaterialTheme.typography.bodyMedium,
        color = MaterialTheme.colorScheme.onSurface,
        maxLines = 1,
        overflow = TextOverflow.Ellipsis,
    )
}
