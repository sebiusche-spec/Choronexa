// Part of Chronexa, a derivative of reReminder 4.0.1 — GNU GPL v3. See NOTICE.
package com.olaf.rereminder.ui.home

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.olaf.rereminder.R
import com.olaf.rereminder.ui.components.GlowCard
import com.olaf.rereminder.ui.components.revealOnEnter
import com.olaf.rereminder.ui.format.formatCalendarDate
import com.olaf.rereminder.ui.format.formatClockTime
import com.olaf.rereminder.ui.format.formatCoarseCountdown
import com.olaf.rereminder.ui.theme.ChronexaCyan
import com.olaf.rereminder.ui.theme.ChronexaViolet

@Composable
fun HomeRoute(viewModel: HomeViewModel = viewModel()) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    HomeScreen(uiState)
}

@Composable
fun HomeScreen(state: HomeUiState) {
    Scaffold(containerColor = MaterialTheme.colorScheme.background) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(padding)
                .padding(horizontal = 20.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            Header(state)
            ClockCard(state)
            NextAlarmCard(state)
            TodayCard()
            ProgressCard(state)
            Spacer(Modifier.height(8.dp))
        }
    }
}

@Composable
private fun Header(state: HomeUiState) {
    val name = state.displayName
    val text = when (dayPartFor(state.hour)) {
        DayPart.MORNING -> if (name.isEmpty()) {
            stringResource(R.string.home_greeting_morning_plain)
        } else {
            stringResource(R.string.home_greeting_morning, name)
        }

        DayPart.AFTERNOON -> if (name.isEmpty()) {
            stringResource(R.string.home_greeting_afternoon_plain)
        } else {
            stringResource(R.string.home_greeting_afternoon, name)
        }

        DayPart.EVENING -> if (name.isEmpty()) {
            stringResource(R.string.home_greeting_evening_plain)
        } else {
            stringResource(R.string.home_greeting_evening, name)
        }
    }
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(
            text = stringResource(R.string.app_name).uppercase(),
            style = MaterialTheme.typography.labelMedium,
            color = ChronexaCyan,
            fontWeight = FontWeight.SemiBold,
            letterSpacing = 2.sp,
        )
        Text(
            text = text,
            style = MaterialTheme.typography.headlineMedium,
            color = MaterialTheme.colorScheme.onBackground,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
        )
    }
}

@Composable
private fun ClockCard(state: HomeUiState) {
    GlowCard(glow = ChronexaCyan, modifier = Modifier.revealOnEnter()) {
        Text(
            text = formatClockTime(state.now),
            style = MaterialTheme.typography.displayLarge,
            fontWeight = FontWeight.Light,
            color = MaterialTheme.colorScheme.onSurface,
        )
        Text(
            text = formatCalendarDate(state.now),
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

@Composable
private fun NextAlarmCard(state: HomeUiState) {
    GlowCard(glow = ChronexaViolet, modifier = Modifier.revealOnEnter(delayMillis = 80L)) {
        Text(
            text = stringResource(R.string.home_next_alarm_label).uppercase(),
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.secondary,
            fontWeight = FontWeight.SemiBold,
            letterSpacing = 1.5.sp,
        )
        Spacer(Modifier.height(8.dp))
        val next = state.nextAlarm
        when {
            !state.masterEnabled -> Text(
                text = stringResource(R.string.home_next_alarm_paused),
                style = MaterialTheme.typography.titleLarge,
                color = MaterialTheme.colorScheme.onSurface,
            )

            next == null -> Text(
                text = stringResource(R.string.home_next_alarm_none),
                style = MaterialTheme.typography.titleLarge,
                color = MaterialTheme.colorScheme.onSurface,
            )

            else -> {
                Text(
                    text = next.name,
                    style = MaterialTheme.typography.titleLarge,
                    color = MaterialTheme.colorScheme.onSurface,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                Text(
                    text = stringResource(
                        R.string.home_next_alarm_in,
                        formatClockTime(next.atMillis),
                        formatCoarseCountdown(next.atMillis - state.now),
                    ),
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
    }
}

@Composable
private fun TodayCard() {
    GlowCard(glow = ChronexaCyan, modifier = Modifier.revealOnEnter(delayMillis = 160L)) {
        Text(
            text = stringResource(R.string.home_tasks_title),
            style = MaterialTheme.typography.titleMedium,
            color = MaterialTheme.colorScheme.onSurface,
        )
        Spacer(Modifier.height(6.dp))
        Text(
            text = stringResource(R.string.home_tasks_empty),
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurface,
        )
        Text(
            text = stringResource(R.string.home_tasks_empty_body),
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

@Composable
private fun ProgressCard(state: HomeUiState) {
    GlowCard(glow = ChronexaViolet, modifier = Modifier.revealOnEnter(delayMillis = 240L)) {
        Text(
            text = stringResource(R.string.home_progress_title),
            style = MaterialTheme.typography.titleMedium,
            color = MaterialTheme.colorScheme.onSurface,
        )
        Spacer(Modifier.height(6.dp))
        if (state.totalCount == 0) {
            Text(
                text = stringResource(R.string.home_progress_none),
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        } else {
            val fraction = state.activeCount.toFloat() / state.totalCount
            LinearProgressIndicator(
                progress = { fraction },
                modifier = Modifier.fillMaxWidth(),
                color = MaterialTheme.colorScheme.primary,
                trackColor = MaterialTheme.colorScheme.surfaceVariant,
            )
            Spacer(Modifier.height(8.dp))
            Text(
                text = stringResource(R.string.home_progress_active, state.activeCount, state.totalCount),
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurface,
            )
        }
        Spacer(Modifier.height(4.dp))
        Text(
            text = stringResource(R.string.home_progress_pending),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}
