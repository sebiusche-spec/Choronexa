// Part of Chronexa, a derivative of reReminder 4.0.1 — GNU GPL v3. See NOTICE.
package com.olaf.rereminder.ui.study.todo

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.layout.Box
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.olaf.rereminder.R
import com.olaf.rereminder.study.StudyData
import com.olaf.rereminder.study.StudyStatus
import com.olaf.rereminder.study.TodoFilter
import com.olaf.rereminder.study.TodoItem
import com.olaf.rereminder.study.filterTodos
import com.olaf.rereminder.study.isOverdue
import com.olaf.rereminder.study.sortedTodos
import com.olaf.rereminder.study.validationError
import com.olaf.rereminder.ui.components.GlowCard
import com.olaf.rereminder.ui.components.revealOnEnter
import com.olaf.rereminder.ui.study.AnimatedCheckbox
import com.olaf.rereminder.ui.study.EmptyState
import com.olaf.rereminder.ui.study.StudyStatusBanner
import com.olaf.rereminder.ui.study.StudyViewModel
import com.olaf.rereminder.ui.study.SubjectTag
import com.olaf.rereminder.ui.study.StudyWarning
import com.olaf.rereminder.ui.study.accentFor
import com.olaf.rereminder.ui.theme.ChronexaCyan
import com.olaf.rereminder.study.DEFAULT_DUE_MINUTE
import com.olaf.rereminder.study.todoDueMoment
import com.olaf.rereminder.ui.study.clockLabel
import com.olaf.rereminder.ui.study.pickers.DatePickerSheet
import com.olaf.rereminder.ui.study.pickers.PickerField
import com.olaf.rereminder.ui.study.pickers.TimePickerSheet
import com.olaf.rereminder.ui.study.pickers.formatPickedDate
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.format.DateTimeFormatter
import java.time.format.FormatStyle
import java.util.Locale

/** The to-do list: real saved items, a checkbox per item, filters, and a full editor. */
@Composable
fun TodoRoute(viewModel: StudyViewModel = viewModel()) {
    val data by viewModel.data.collectAsStateWithLifecycle()
    val status by viewModel.status.collectAsStateWithLifecycle()
    var filter by remember { mutableStateOf(TodoFilter.PENDING) }
    var editing by remember { mutableStateOf<TodoItem?>(null) }
    var showEditor by remember { mutableStateOf(false) }

    BackHandler(enabled = showEditor) { showEditor = false }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        floatingActionButton = {
            if (!showEditor) {
                ExtendedFloatingActionButton(
                    onClick = {
                        editing = null
                        showEditor = true
                    },
                    icon = { Icon(Icons.Rounded.Add, contentDescription = null) },
                    text = { Text(stringResource(R.string.todo_add)) },
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = MaterialTheme.colorScheme.onPrimary,
                )
            }
        },
    ) { padding ->
        Box(modifier = Modifier.fillMaxSize().padding(padding)) {
            if (!showEditor) {
                TodoList(
                    data = data,
                    status = status,
                    filter = filter,
                    onFilter = { filter = it },
                    onToggle = { viewModel.toggleTodo(it.id) },
                    onOpen = {
                        editing = it
                        showEditor = true
                    },
                )
            } else {
                TodoEditor(
                    initial = editing,
                    data = data,
                    onSave = { item ->
                        val ok = viewModel.saveTodo(item)
                        if (ok) showEditor = false
                        ok
                    },
                    onDelete = { id ->
                        viewModel.deleteTodo(id)
                        showEditor = false
                    },
                    onClose = { showEditor = false },
                )
            }
        }
    }
}

@Composable
private fun TodoList(
    data: StudyData,
    status: StudyStatus,
    filter: TodoFilter,
    onFilter: (TodoFilter) -> Unit,
    onToggle: (TodoItem) -> Unit,
    onOpen: (TodoItem) -> Unit,
) {
    val now = LocalDateTime.now()
    val visible = sortedTodos(filterTodos(data.todos, filter))
    val pendingCount = data.todos.count { !it.done }
    val doneCount = data.todos.count { it.done }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item(key = "title") {
            Text(
                text = stringResource(R.string.todo_title),
                style = MaterialTheme.typography.headlineMedium,
                color = MaterialTheme.colorScheme.onBackground,
                fontWeight = FontWeight.SemiBold,
            )
        }
        if (status !is StudyStatus.Ready) {
            item(key = "status") { StudyStatusBanner(status) }
        }
        item(key = "filters") {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(
                    selected = filter == TodoFilter.PENDING,
                    onClick = { onFilter(TodoFilter.PENDING) },
                    label = { Text(stringResource(R.string.todo_filter_pending, pendingCount)) },
                )
                FilterChip(
                    selected = filter == TodoFilter.DONE,
                    onClick = { onFilter(TodoFilter.DONE) },
                    label = { Text(stringResource(R.string.todo_filter_done, doneCount)) },
                )
                FilterChip(
                    selected = filter == TodoFilter.ALL,
                    onClick = { onFilter(TodoFilter.ALL) },
                    label = { Text(stringResource(R.string.todo_filter_all)) },
                )
            }
        }
        if (visible.isEmpty()) {
            item(key = "empty") {
                EmptyState(
                    title = stringResource(
                        if (data.todos.isEmpty()) R.string.todo_empty_title else R.string.todo_filter_empty_title,
                    ),
                    body = stringResource(
                        if (data.todos.isEmpty()) R.string.todo_empty_body else R.string.todo_filter_empty_body,
                    ),
                )
            }
        } else {
            items(visible, key = { it.id }) { item ->
                TodoRow(
                    item = item,
                    subjectName = data.subjects.firstOrNull { it.id == item.subjectId }?.name,
                    subjectAccent = data.subjects.firstOrNull { it.id == item.subjectId }
                        ?.let { accentFor(it.colorIndex) },
                    overdue = item.isOverdue(now),
                    onToggle = { onToggle(item) },
                    onOpen = { onOpen(item) },
                )
            }
        }
    }
}

@Composable
private fun TodoRow(
    item: TodoItem,
    subjectName: String?,
    subjectAccent: androidx.compose.ui.graphics.Color?,
    overdue: Boolean,
    onToggle: () -> Unit,
    onOpen: () -> Unit,
) {
    val accent = subjectAccent ?: ChronexaCyan
    GlowCard(glow = accent, onClick = onOpen, modifier = Modifier.revealOnEnter()) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            AnimatedCheckbox(
                checked = item.done,
                onCheckedChange = { onToggle() },
                description = stringResource(R.string.todo_toggle_description, item.title),
                accent = accent,
            )
            Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(
                    text = item.title,
                    style = MaterialTheme.typography.titleMedium,
                    color = if (item.done) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.onSurface,
                    textDecoration = if (item.done) TextDecoration.LineThrough else null,
                )
                item.dueAt?.let {
                    Text(
                        text = stringResource(R.string.todo_due_label, formatDue(it)),
                        style = MaterialTheme.typography.bodySmall,
                        color = if (overdue) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    if (subjectName != null) SubjectTag(subjectName, accent)
                    if (overdue) {
                        Text(
                            text = stringResource(R.string.todo_overdue),
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.error,
                        )
                    }
                }
            }
        }
    }
}

private enum class TodoPicker { DATE, TIME }

/** The to-do editor. A due date is optional; a time can only be set once there is a date. */
@Composable
private fun TodoEditor(
    initial: TodoItem?,
    data: StudyData,
    onSave: (TodoItem) -> Boolean,
    onDelete: (Long) -> Unit,
    onClose: () -> Unit,
) {
    var title by remember(initial) { mutableStateOf(initial?.title ?: "") }
    var notes by remember(initial) { mutableStateOf(initial?.notes ?: "") }
    var subjectId by remember(initial) { mutableStateOf(initial?.subjectId) }
    var date by remember(initial) { mutableStateOf(initial?.dueAt?.toLocalDate()) }
    var minute by remember(initial) { mutableStateOf(initial?.dueAt?.let { it.hour * 60 + it.minute }) }
    var confirmDelete by remember { mutableStateOf(false) }
    var picker by remember { mutableStateOf<TodoPicker?>(null) }

    val candidate = TodoItem(
        id = initial?.id ?: 0L,
        title = title.trim(),
        notes = notes.trim(),
        subjectId = subjectId,
        dueAt = todoDueMoment(date, minute),
        done = initial?.done ?: false,
    )
    val errorKey: String? = candidate.validationError()

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onClose) {
                Icon(Icons.Rounded.Close, contentDescription = stringResource(R.string.todo_close))
            }
            Text(
                text = stringResource(if (initial == null) R.string.todo_new_title else R.string.todo_edit_title),
                style = MaterialTheme.typography.headlineSmall,
                color = MaterialTheme.colorScheme.onBackground,
                fontWeight = FontWeight.SemiBold,
            )
        }

        OutlinedTextField(
            value = title,
            onValueChange = { title = it.take(120) },
            label = { Text(stringResource(R.string.todo_title_label)) },
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
        )
        OutlinedTextField(
            value = notes,
            onValueChange = { notes = it.take(500) },
            label = { Text(stringResource(R.string.todo_notes_label)) },
            minLines = 2,
            modifier = Modifier.fillMaxWidth(),
        )

        Text(
            text = stringResource(R.string.todo_subject_label),
            style = MaterialTheme.typography.labelLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(
                selected = subjectId == null,
                onClick = { subjectId = null },
                label = { Text(stringResource(R.string.todo_subject_none)) },
            )
            data.subjects.forEach { s ->
                FilterChip(
                    selected = subjectId == s.id,
                    onClick = { subjectId = s.id },
                    label = { Text(s.name) },
                )
            }
        }

        Text(
            text = stringResource(R.string.picker_when_heading),
            style = MaterialTheme.typography.labelLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        PickerField(
            label = stringResource(R.string.picker_due_date_label),
            value = date?.let { formatPickedDate(it) } ?: stringResource(R.string.picker_no_date),
            onClick = { picker = TodoPicker.DATE },
            modifier = Modifier.fillMaxWidth(),
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { date = LocalDate.now() }) {
                Text(stringResource(R.string.todo_due_today))
            }
            TextButton(
                onClick = {
                    date = null
                    minute = null
                },
                enabled = date != null,
            ) {
                Text(stringResource(R.string.todo_due_clear))
            }
        }
        PickerField(
            label = stringResource(R.string.picker_due_time_label),
            value = minute?.let { clockLabel(it) } ?: stringResource(R.string.picker_no_time),
            onClick = { if (date != null) picker = TodoPicker.TIME },
            supporting = if (date == null) stringResource(R.string.picker_time_needs_date) else null,
            modifier = Modifier.fillMaxWidth(),
        )

        if (errorKey != null) {
            Text(
                text = stringResource(todoErrorRes(errorKey)),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.error,
            )
        }

        Row(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Button(onClick = { onSave(candidate) }, enabled = errorKey == null) {
                Text(stringResource(R.string.todo_save))
            }
            if (initial != null) {
                OutlinedButton(onClick = { confirmDelete = true }) {
                    Icon(Icons.Rounded.Delete, contentDescription = null, modifier = Modifier.padding(end = 4.dp))
                    Text(stringResource(R.string.todo_delete))
                }
            }
        }
    }

    when (picker) {
        TodoPicker.DATE -> DatePickerSheet(
            initial = date ?: LocalDate.now(),
            onConfirm = { date = it; picker = null },
            onDismiss = { picker = null },
        )
        TodoPicker.TIME -> TimePickerSheet(
            title = stringResource(R.string.picker_due_time_label),
            initialMinute = minute ?: DEFAULT_DUE_MINUTE,
            onConfirm = { minute = it; picker = null },
            onDismiss = { picker = null },
        )
        null -> Unit
    }

    if (confirmDelete && initial != null) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text(stringResource(R.string.todo_delete_confirm_title)) },
            text = { Text(stringResource(R.string.todo_delete_confirm_body)) },
            confirmButton = {
                TextButton(onClick = {
                    confirmDelete = false
                    onDelete(initial.id)
                }) { Text(stringResource(R.string.common_delete)) }
            },
            dismissButton = {
                TextButton(onClick = { confirmDelete = false }) { Text(stringResource(R.string.common_cancel)) }
            },
        )
    }
}

private fun formatDue(due: LocalDateTime): String =
    due.format(DateTimeFormatter.ofLocalizedDateTime(FormatStyle.MEDIUM, FormatStyle.SHORT).withLocale(Locale.getDefault()))

private fun todoErrorRes(key: String): Int = when (key) {
    "title_required" -> R.string.todo_error_title
    "invalid_date" -> R.string.todo_error_date
    "invalid_time" -> R.string.todo_error_time
    "time_needs_date" -> R.string.todo_error_time_needs_date
    else -> R.string.todo_error_title
}
