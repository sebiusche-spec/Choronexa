// Part of Chronexa, a derivative of reReminder 4.0.1 — GNU GPL v3. See NOTICE.
package com.olaf.rereminder.study

/** What an activity's alarm plays. The stored text is in [StudyTask.sound]. */
sealed interface AlarmSoundRef {
    /** The phone's default alarm sound. */
    data object DefaultTone : AlarmSoundRef
    /** No sound: the alarm is shown, but nothing plays. */
    data object Silent : AlarmSoundRef
    /** An audio file the user chose, stored as a content:// or file:// URI. */
    data class Custom(val uri: String) : AlarmSoundRef
}

const val SOUND_DEFAULT = "default"
const val SOUND_SILENT = "silent"

/**
 * Reads the stored sound text. Anything unknown becomes the default sound, so a damaged or future value
 * can never make an alarm play something the user did not pick.
 */
fun parseSoundRef(raw: String?): AlarmSoundRef {
    val value = raw?.trim().orEmpty()
    return when {
        value.isEmpty() || value == SOUND_DEFAULT -> AlarmSoundRef.DefaultTone
        value == SOUND_SILENT -> AlarmSoundRef.Silent
        value.startsWith("content://") || value.startsWith("file://") -> AlarmSoundRef.Custom(value)
        else -> AlarmSoundRef.DefaultTone
    }
}

/** What actually plays: the on/off switch overrides the chosen file, and the chosen file is kept. */
fun playbackSound(soundOn: Boolean, raw: String?): AlarmSoundRef =
    if (soundOn) parseSoundRef(raw) else AlarmSoundRef.Silent

/**
 * Whether an alarm should start playing. A code already ringing does not start a second copy, so one
 * alarm never plays twice. Code 0 means "no alarm" and never plays.
 */
fun shouldStartPlayback(ringingCodes: Set<Int>, code: Int): Boolean = code > 0 && code !in ringingCodes
