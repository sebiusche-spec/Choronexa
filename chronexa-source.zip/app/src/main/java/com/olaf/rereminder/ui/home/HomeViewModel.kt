// Part of Chronexa, a derivative of reReminder 4.0.1 — GNU GPL v3. See NOTICE.
package com.olaf.rereminder.ui.home

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.olaf.rereminder.data.ReminderRepository
import com.olaf.rereminder.data.displayName
import com.olaf.rereminder.utils.PreferenceHelper
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.stateIn
import java.time.Instant
import java.time.ZoneId

data class HomeUiState(
    val now: Long = 0L,
    val hour: Int = 12,
    val displayName: String = "",
    val masterEnabled: Boolean = true,
    val nextAlarm: NextAlarm? = null,
    val activeCount: Int = 0,
    val totalCount: Int = 0,
)

/**
 * Feeds the dashboard from the same reminder store the alarm engine writes to, so the "next
 * alarm" shown here can never disagree with what is actually scheduled.
 */
class HomeViewModel(application: Application) : AndroidViewModel(application) {

    private val app = application
    private val repository = ReminderRepository.get(application)
    private val preferences = PreferenceHelper(application)

    /** Emits once per minute, aligned to the minute boundary, and only while collected. */
    private val minuteTicker: Flow<Long> = flow {
        while (true) {
            val now = System.currentTimeMillis()
            emit(now)
            delay(MILLIS_PER_MINUTE - now % MILLIS_PER_MINUTE + 250L)
        }
    }

    val uiState: StateFlow<HomeUiState> =
        combine(repository.reminders, minuteTicker) { reminders, now ->
            val master = preferences.isMasterEnabled()
            HomeUiState(
                now = now,
                hour = Instant.ofEpochMilli(now).atZone(ZoneId.systemDefault()).hour,
                displayName = preferences.getDisplayName(),
                masterEnabled = master,
                nextAlarm = nextAlarmFrom(reminders, master, now) { it.displayName(app) },
                activeCount = reminders.count { it.enabled },
                totalCount = reminders.size,
            )
        }.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
            initialValue = HomeUiState(now = System.currentTimeMillis()),
        )

    private companion object {
        const val MILLIS_PER_MINUTE = 60_000L
        const val STOP_TIMEOUT_MILLIS = 5_000L
    }
}
