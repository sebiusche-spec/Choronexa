// Part of Chronexa, a derivative of reReminder 4.0.1 — GNU GPL v3. See NOTICE.
package com.olaf.rereminder.ui.home

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.olaf.rereminder.data.ReminderRepository
import com.olaf.rereminder.data.displayName
import com.olaf.rereminder.study.FocusState
import com.olaf.rereminder.study.StudyData
import com.olaf.rereminder.study.StudyRepository
import com.olaf.rereminder.study.focusSecondsOn
import com.olaf.rereminder.utils.PreferenceHelper
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.stateIn
import java.time.Instant
import java.time.ZoneId

data class HomeUiState(
    val now: Long = 0L,
    val hour: Int = 12,
    val displayName: String = "",
    val masterEnabled: Boolean = true,
    val nextAlarm: NextAlarm? = null,
    val activeCount: Int = 0,
    val totalCount: Int = 0,
    val study: StudyData = StudyData.initial(),
    val focusRunning: Boolean = false,
    val focusSecondsToday: Long = 0L,
)

/**
 * Feeds the dashboard from the same stores the rest of the app writes to. The "next alarm" comes
 * from the reminder store the alarm engine uses, so it cannot disagree with what is scheduled.
 */
class HomeViewModel(application: Application) : AndroidViewModel(application) {

    private val app = application
    private val reminders = ReminderRepository.get(application)
    private val study = StudyRepository.get(application)
    private val preferences = PreferenceHelper(application)

    /** Emits once a minute, aligned to the minute boundary, and only while collected. */
    private val minuteTicker: Flow<Long> = flow {
        while (true) {
            val now = System.currentTimeMillis()
            emit(now)
            delay(MILLIS_PER_MINUTE - now % MILLIS_PER_MINUTE + 250L)
        }
    }

    val uiState: StateFlow<HomeUiState> = combine(
        reminders.reminders,
        study.data,
        study.session,
        minuteTicker,
    ) { alarms, data, session, now ->
        val master = preferences.isMasterEnabled()
        val zone = ZoneId.systemDefault()
        val today = Instant.ofEpochMilli(now).atZone(zone).toLocalDate()
        HomeUiState(
            now = now,
            hour = Instant.ofEpochMilli(now).atZone(zone).hour,
            displayName = preferences.getDisplayName(),
            masterEnabled = master,
            nextAlarm = nextAlarmFrom(alarms, master, now) { it.displayName(app) },
            activeCount = alarms.count { it.enabled },
            totalCount = alarms.size,
            study = data,
            focusRunning = session.clock.state == FocusState.RUNNING,
            focusSecondsToday = focusSecondsOn(data.focusRecords, today, zone),
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
        initialValue = HomeUiState(now = System.currentTimeMillis()),
    )

    private companion object {
        const val MILLIS_PER_MINUTE = 60_000L
        const val STOP_TIMEOUT_MILLIS = 5_000L
    }
}
