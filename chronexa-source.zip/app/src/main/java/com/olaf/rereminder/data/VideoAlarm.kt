// Part of Chronexa, a derivative of reReminder 4.0.1 — GNU GPL v3. See NOTICE.
package com.olaf.rereminder.data

import kotlinx.serialization.Serializable

/** Which sound a video alarm plays: the video's own audio, the chosen ringtone, or both. */
@Serializable
enum class VideoAudioMode { VIDEO_AUDIO, RINGTONE, BOTH }

/**
 * A video the user picked for one alarm. [uri] is a content URI from the system file picker; the file itself is
 * never copied, and it can be removed or moved by the user at any time.
 */
@Serializable
data class VideoChoice(
    val uri: String,
    val name: String = "",
    val audio: VideoAudioMode = VideoAudioMode.VIDEO_AUDIO,
    /** Volume for the video's audio, 0 to 100. */
    val volumePercent: Int = 100,
    val loop: Boolean = true,
)

/** What an alarm plays when it fires, after checking that its video can still be opened. */
sealed interface VideoPlayback {
    /** No video is assigned: the alarm uses its normal sound, unchanged. */
    data object None : VideoPlayback

    /** The video plays. [playVideoAudio] and [playRingtone] say which sounds go with it. */
    data class Play(
        val uri: String,
        val playVideoAudio: Boolean,
        val playRingtone: Boolean,
        val volumePercent: Int,
        val loop: Boolean,
    ) : VideoPlayback

    /**
     * The video cannot be opened (moved, deleted, or permission lost). The alarm falls back to its ringtone, so it
     * still rings and can still be dismissed.
     */
    data object FallbackToRingtone : VideoPlayback
}

/** Decides what a video alarm plays. [canOpen] says whether the video's file can still be read. */
fun resolveVideoPlayback(video: VideoChoice?, canOpen: Boolean): VideoPlayback = when {
    video == null -> VideoPlayback.None
    !canOpen -> VideoPlayback.FallbackToRingtone
    else -> VideoPlayback.Play(
        uri = video.uri,
        playVideoAudio = video.audio != VideoAudioMode.RINGTONE,
        playRingtone = video.audio != VideoAudioMode.VIDEO_AUDIO,
        volumePercent = video.volumePercent.coerceIn(0, 100),
        loop = video.loop,
    )
}

/** This alarm with the given video assigned. Only the video changes: the sound, the schedule and the id stay as they are. */
fun Reminder.withVideo(video: VideoChoice?): Reminder = copy(video = video)

/** This alarm without its video. The ringtone and schedule are kept, so the alarm still rings as before. */
fun Reminder.withoutVideo(): Reminder = copy(video = null)
