// Part of Chronexa, a derivative of reReminder 4.0.1 — GNU GPL v3. See NOTICE.
package com.olaf.rereminder.data

import kotlinx.serialization.Serializable

/** Which sound a video alarm plays: the video's own audio, the chosen ringtone, or both. */
@Serializable
enum class VideoAudioMode { VIDEO_AUDIO, RINGTONE, BOTH }

/**
 * A video the user picked for one alarm. [uri] is a content URI from the system file picker; the file itself is
 * never copied, and it can be removed or moved by the user at any time.
 */
@Serializable
data class VideoChoice(
    val uri: String,
    val name: String = "",
    val audio: VideoAudioMode = VideoAudioMode.VIDEO_AUDIO,
    /** Volume for the video's audio, 0 to 100. */
    val volumePercent: Int = 100,
    val loop: Boolean = true,
    /** FILL crops the video to cover the screen; FIT (the default) shows all of it. Aspect ratio is kept either way. */
    val fill: Boolean = false,
)

/** What an alarm plays when it fires, after checking that its video can still be opened. */
sealed interface VideoPlayback {
    /** No video is assigned: the alarm uses its normal sound, unchanged. */
    data object None : VideoPlayback

    /** The video plays. [playVideoAudio] and [playRingtone] say which sounds go with it. */
    data class Play(
        val uri: String,
        val playVideoAudio: Boolean,
        val playRingtone: Boolean,
        val volumePercent: Int,
        val loop: Boolean,
        val fill: Boolean = false,
    ) : VideoPlayback

    /**
     * The video cannot be opened (moved, deleted, or permission lost). The alarm falls back to its ringtone, so it
     * still rings and can still be dismissed.
     */
    data object FallbackToRingtone : VideoPlayback
}

/** Decides what a video alarm plays. [canOpen] says whether the video's file can still be read. */
fun resolveVideoPlayback(video: VideoChoice?, canOpen: Boolean): VideoPlayback = when {
    video == null -> VideoPlayback.None
    !canOpen -> VideoPlayback.FallbackToRingtone
    else -> VideoPlayback.Play(
        uri = video.uri,
        playVideoAudio = video.audio != VideoAudioMode.RINGTONE,
        playRingtone = video.audio != VideoAudioMode.VIDEO_AUDIO,
        volumePercent = video.volumePercent.coerceIn(0, 100),
        loop = video.loop,
        fill = video.fill,
    )
}

/** Whether a picked file is an MP4 video we accept. Anything else is refused before it is saved. */
fun isSupportedVideo(mimeType: String?, fileName: String): Boolean =
    mimeType == "video/mp4" || (mimeType.isNullOrEmpty() && fileName.lowercase().endsWith(".mp4"))

/**
 * The choice after picking a different file: the new file replaces the old one, and the audio mode, volume and
 * looping the user set are kept.
 */
fun VideoChoice?.replacingFile(uri: String, name: String): VideoChoice =
    this?.copy(uri = uri, name = name) ?: VideoChoice(uri = uri, name = name)

/** This alarm with the given video assigned. Only the video changes: the sound, the schedule and the id stay as they are. */
fun Reminder.withVideo(video: VideoChoice?): Reminder = copy(video = video)

/** This alarm without its video. The ringtone and schedule are kept, so the alarm still rings as before. */
fun Reminder.withoutVideo(): Reminder = copy(video = null)

/** Whether the alarm's normal ringtone plays. It is kept whenever the video is not playing its own sound. */
fun VideoPlayback.ringtoneAllowed(): Boolean = when (this) {
    VideoPlayback.None -> true
    is VideoPlayback.Play -> playRingtone
    VideoPlayback.FallbackToRingtone -> true
}

/** Whether the video's own audio plays. */
fun VideoPlayback.videoAudioAllowed(): Boolean = this is VideoPlayback.Play && playVideoAudio

/**
 * The same playback with its sounds turned off when [audible] is false (the phone is muted or set to vibrate).
 * The video still shows and the alarm still vibrates; only the audio is removed.
 */
fun VideoPlayback.silencedFor(audible: Boolean): VideoPlayback =
    if (audible || this !is VideoPlayback.Play) this else copy(playVideoAudio = false, playRingtone = false)

/**
 * Whether an alarm rings through the full-screen alarm service. A video alarm always does, so the video plays on
 * the alarm screen; only the early reminders stay as ordinary notifications.
 */
fun ringsAsAlarmRoute(offset: Int, isAlarmStyle: Boolean, forced: Boolean, hasVideo: Boolean): Boolean =
    offset == 0 && (forced || isAlarmStyle || hasVideo)

/**
 * The size of the video drawn on the view, as a horizontal and vertical scale, keeping the aspect ratio.
 * FIT shows the whole video (bars may appear); FILL covers the view and crops the excess. Never stretches.
 */
fun videoScale(viewWidth: Int, viewHeight: Int, videoWidth: Int, videoHeight: Int, fill: Boolean): Pair<Float, Float> {
    if (viewWidth <= 0 || viewHeight <= 0 || videoWidth <= 0 || videoHeight <= 0) return 1f to 1f
    val byWidth = viewWidth.toFloat() / videoWidth
    val byHeight = viewHeight.toFloat() / videoHeight
    val scale = if (fill) maxOf(byWidth, byHeight) else minOf(byWidth, byHeight)
    val drawnWidth = videoWidth * scale
    val drawnHeight = videoHeight * scale
    return (drawnWidth / viewWidth) to (drawnHeight / viewHeight)
}

/** Where an alarm's ringing ends up. */
enum class AlarmPath { RINGING_SERVICE, FULL_SCREEN_NOTIFICATION, ORDINARY_NOTIFICATION }

/**
 * The path an alarm takes. An alarm routed to the alarm service rings there. When the service cannot start from the
 * background, the full-screen alarm notification is used, so an alarm (and its video) is never reduced to the
 * ordinary notification while that notification can be posted. Only other reminders use the ordinary notification.
 */
fun alarmPathFor(routedAsAlarm: Boolean, serviceStarted: Boolean, fullScreenPosted: Boolean): AlarmPath = when {
    !routedAsAlarm -> AlarmPath.ORDINARY_NOTIFICATION
    serviceStarted -> AlarmPath.RINGING_SERVICE
    fullScreenPosted -> AlarmPath.FULL_SCREEN_NOTIFICATION
    else -> AlarmPath.ORDINARY_NOTIFICATION
}

