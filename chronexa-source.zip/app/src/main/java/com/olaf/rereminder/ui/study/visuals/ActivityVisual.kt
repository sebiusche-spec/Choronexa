// Part of Chronexa, a derivative of reReminder 4.0.1 — GNU GPL v3. See NOTICE.
package com.olaf.rereminder.ui.study.visuals

import android.graphics.Paint
import android.graphics.Typeface
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.olaf.rereminder.study.resolveVisual
import com.olaf.rereminder.ui.theme.rememberReduceMotion
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

// Palette: Chronexa's dark-neon colours, with a few illustration tones for skin, teeth and food.
private val CYAN = Color(0xFF00E5FF)
private val PURPLE = Color(0xFF8A2BE2)
private val PINK = Color(0xFFFF2D95)
private val AMBER = Color(0xFFFFC36B)
private val WHITE = Color(0xFFEFF3FF)
private val SKIN = Color(0xFFF2C29B)
private val DARK = Color(0xFF1B1433)
private val PANEL = Color(0xFF0B0E1F)
private val GROUND = Color(0xFF14092C)
private val SKY_NIGHT = Color(0xFF0A1030)
private val SKY_DAWN = Color(0xFF3A1F5C)
private val SKY_HORIZON_NIGHT = Color(0xFF1B1446)
private val SKY_HORIZON = Color(0xFFFF9A5C)
private val BATH_TOP = Color(0xFF0C1B3A)
private val BATH_BOTTOM = Color(0xFF07122A)
private const val TAU = (2 * PI).toFloat()

/**
 * A small animated scene for a task: the activity is recognisable from its movement (a sunrise, a brush
 * sweeping across teeth, a pendulum swinging, a figure breathing). Compose Canvas and the platform's text
 * drawing only; nothing is downloaded or bundled.
 *
 * The animation runs only while the scene is composed, so a lazy list stops it when the task scrolls away.
 * With reduced motion on, the scene is drawn as a still frame. "none" draws nothing.
 */
@Composable
fun ActivityVisual(key: String, size: Dp, modifier: Modifier = Modifier) {
    val visual = resolveVisual(key)
    if (visual == "none") return
    val frame = Modifier
        .size(size)
        .clip(RoundedCornerShape(size * 0.25f))
        .background(PANEL)
    val paint = remember {
        Paint(Paint.ANTI_ALIAS_FLAG).apply { typeface = Typeface.MONOSPACE }
    }
    if (rememberReduceMotion()) {
        Canvas(modifier.then(frame)) { drawScene(visual, 0f, paint) }
    } else {
        LiveScene(visual = visual, modifier = modifier.then(frame), paint = paint)
    }
}

@Composable
private fun LiveScene(visual: String, modifier: Modifier, paint: Paint) {
    val transition = rememberInfiniteTransition(label = "activityScene")
    val phase by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(durationMillis = 4200, easing = LinearEasing), RepeatMode.Restart),
        label = "scenePhase",
    )
    Canvas(modifier) { drawScene(visual, phase, paint) }
}

/** Draws one scene at animation phase [p] in 0..1, so the loop ends where it began. */
private fun DrawScope.drawScene(visual: String, p: Float, paint: Paint) {
    val w = size.width
    val h = size.height
    val r = min(w, h) * 0.5f
    when (visual) {
        "wake" -> sunrise(w, h, p)
        "brush" -> brushing(w, h, p)
        "bath" -> bath(w, h, p)
        "meditate" -> meditation(w, h, p)
        "food" -> food(w, h, p)
        "maths" -> maths(w, h, p, paint)
        "physics" -> pendulum(w, h, p)
        "chemistry" -> molecule(w, h, r, p)
        "computing" -> code(w, h, p, paint)
        "study" -> reading(w, h, p)
        "exercise" -> exercise(w, h, p)
        "music" -> music(w, h, p)
        "sleep" -> sleep(w, h, p, paint)
        else -> calm(w, h, r, p)
    }
}

/** A value that rises from 0 to 1 and back, smoothly, over one loop. */
private fun swing(p: Float): Float = 0.5f - 0.5f * cos(TAU * p)

/** The part of a number after its whole part, always in 0..1. Used to wrap moving things around the scene. */
private fun fract(x: Float): Float = x - floor(x)

/** A sun rises behind a horizon while the sky warms and clouds drift. */
private fun DrawScope.sunrise(w: Float, h: Float, p: Float) {
    val horizon = h * 0.7f
    drawRect(
        Brush.verticalGradient(listOf(lerp(SKY_NIGHT, SKY_DAWN, p), lerp(SKY_HORIZON_NIGHT, SKY_HORIZON, p))),
        size = Size(w, h),
    )
    val rise = 0.5f - 0.5f * cos(PI.toFloat() * p) // 0 on the horizon at the start, fully risen at the end
    val fade = if (p > 0.85f) (1f - p) / 0.15f else 1f
    val sun = Offset(w * 0.5f, horizon - rise * h * 0.42f)
    val sunR = h * 0.12f
    drawCircle(AMBER, radius = sunR * 2.4f, center = sun, alpha = 0.18f * fade)
    drawCircle(AMBER, radius = sunR, center = sun, alpha = fade)
    for (i in 0 until 10) {
        val a = TAU * i / 10f + TAU * p * 0.2f
        drawLine(
            AMBER,
            sun + Offset(cos(a) * sunR * 1.3f, sin(a) * sunR * 1.3f),
            sun + Offset(cos(a) * sunR * 1.7f, sin(a) * sunR * 1.7f),
            strokeWidth = 2f,
            alpha = 0.7f * fade,
        )
    }
    for (i in 0 until 2) {
        val cx = w * fract(0.15f + 0.45f * i + p * 0.5f)
        drawCircle(WHITE, radius = h * 0.05f, center = Offset(cx, h * (0.22f + 0.1f * i)), alpha = 0.3f)
        drawCircle(WHITE, radius = h * 0.07f, center = Offset(cx + h * 0.06f, h * (0.19f + 0.1f * i)), alpha = 0.3f)
    }
    drawRect(GROUND, topLeft = Offset(0f, horizon), size = Size(w, h - horizon))
    drawLine(AMBER, Offset(0f, horizon), Offset(w, horizon), strokeWidth = 2f, alpha = 0.7f)
}

/** A toothbrush sweeps across a row of teeth, and bubbles rise from the brushing. */
private fun DrawScope.brushing(w: Float, h: Float, p: Float) {
    val top = h * 0.5f
    val bottom = h * 0.82f
    val toothW = w * 0.12f
    for (i in 0 until 6) {
        val x = w * 0.1f + i * toothW * 1.02f
        drawRoundRect(
            WHITE,
            topLeft = Offset(x, top),
            size = Size(toothW * 0.86f, bottom - top),
            cornerRadius = CornerRadius(toothW * 0.35f),
            alpha = 0.95f,
        )
    }
    drawRect(PINK, topLeft = Offset(w * 0.06f, bottom), size = Size(w * 0.88f, h * 0.04f), alpha = 0.7f)
    val bx = w * (0.14f + 0.72f * swing(p))
    drawLine(CYAN, Offset(bx - w * 0.1f, h * 0.06f), Offset(bx, h * 0.4f), strokeWidth = w * 0.05f, cap = StrokeCap.Round)
    drawRoundRect(
        CYAN,
        topLeft = Offset(bx - w * 0.08f, h * 0.36f),
        size = Size(w * 0.16f, h * 0.1f),
        cornerRadius = CornerRadius(w * 0.03f),
    )
    for (i in 0 until 6) {
        val t = fract(p + i * 0.17f)
        drawCircle(
            WHITE,
            radius = w * (0.016f + 0.01f * (i % 2)),
            center = Offset(w * (0.18f + 0.13f * i), h * (0.46f - 0.3f * t)),
            alpha = 0.7f * (1f - t),
        )
    }
}

/** A shower sprays falling droplets onto a pool, with steam rising from the warm water. */
private fun DrawScope.bath(w: Float, h: Float, p: Float) {
    drawRect(Brush.verticalGradient(listOf(BATH_TOP, BATH_BOTTOM)), size = Size(w, h))
    drawLine(WHITE, Offset(w * 0.12f, h * 0.08f), Offset(w * 0.32f, h * 0.08f), strokeWidth = w * 0.03f, cap = StrokeCap.Round)
    drawLine(WHITE, Offset(w * 0.32f, h * 0.08f), Offset(w * 0.32f, h * 0.16f), strokeWidth = w * 0.03f, cap = StrokeCap.Round)
    drawRoundRect(WHITE, topLeft = Offset(w * 0.22f, h * 0.16f), size = Size(w * 0.2f, h * 0.05f), cornerRadius = CornerRadius(h * 0.025f))
    for (i in 0 until 16) {
        val x = w * (0.2f + 0.45f * fract(i * 0.618f))
        val t = fract(p + i / 16f)
        val y = h * (0.24f + 0.55f * t)
        drawLine(CYAN, Offset(x, y), Offset(x - w * 0.01f, y + h * 0.05f), strokeWidth = 2f, cap = StrokeCap.Round, alpha = 0.35f + 0.5f * t)
    }
    val base = h * 0.82f
    val wave = Path()
    wave.moveTo(0f, h)
    for (x in 0..16) {
        wave.lineTo(w * x / 16f, base + h * 0.02f * sin(TAU * (x / 16f) * 2f + TAU * p))
    }
    wave.lineTo(w, h)
    wave.close()
    drawPath(wave, CYAN, alpha = 0.35f)
    for (i in 0 until 3) {
        val t = fract(p + i / 3f)
        drawCircle(WHITE, radius = w * 0.05f * (0.6f + t), center = Offset(w * (0.3f + 0.2f * i), h * (0.7f - 0.3f * t)), alpha = 0.18f * (1f - t))
    }
}

/** A seated figure with crossed legs. The arms and the aura rise and fall with each slow breath. */
private fun DrawScope.meditation(w: Float, h: Float, p: Float) {
    val breath = swing(p)
    val cx = w * 0.5f
    drawCircle(PURPLE, radius = w * (0.34f + 0.04f * breath), center = Offset(cx, h * 0.6f), alpha = 0.12f + 0.12f * breath)
    drawCircle(SKIN, radius = w * 0.09f, center = Offset(cx, h * 0.3f))
    drawRoundRect(
        PURPLE,
        topLeft = Offset(cx - w * 0.13f, h * 0.4f),
        size = Size(w * 0.26f, h * 0.3f),
        cornerRadius = CornerRadius(w * 0.1f),
    )
    drawOval(DARK, topLeft = Offset(cx - w * 0.26f, h * 0.66f), size = Size(w * 0.52f, h * 0.16f))
    val lift = breath * h * 0.06f
    drawLine(SKIN, Offset(cx - w * 0.12f, h * 0.44f), Offset(cx - w * 0.24f, h * 0.66f - lift), strokeWidth = w * 0.04f, cap = StrokeCap.Round)
    drawLine(SKIN, Offset(cx + w * 0.12f, h * 0.44f), Offset(cx + w * 0.24f, h * 0.66f - lift), strokeWidth = w * 0.04f, cap = StrokeCap.Round)
}

/** A bowl of food with steam rising in gentle waves, and a spoon that dips in and out. */
private fun DrawScope.food(w: Float, h: Float, p: Float) {
    val top = h * 0.52f + sin(TAU * p) * h * 0.012f
    for (i in 0 until 3) {
        val phase = TAU * (p + i / 3f)
        val steam = Path()
        val x0 = w * (0.38f + 0.12f * i)
        for (k in 0..10) {
            val y = top - h * 0.05f - h * 0.3f * (k / 10f)
            val x = x0 + w * 0.025f * sin(TAU * (k / 10f) * 1.5f + phase)
            if (k == 0) steam.moveTo(x, y) else steam.lineTo(x, y)
        }
        drawPath(steam, WHITE, alpha = 0.45f, style = Stroke(width = 3f))
    }
    drawArc(AMBER, startAngle = 0f, sweepAngle = 180f, useCenter = false, topLeft = Offset(w * 0.2f, top), size = Size(w * 0.6f, h * 0.34f), style = Stroke(width = w * 0.035f))
    drawLine(AMBER, Offset(w * 0.2f, top), Offset(w * 0.8f, top), strokeWidth = w * 0.03f, cap = StrokeCap.Round)
    for (i in 0 until 7) {
        drawCircle(WHITE, radius = w * 0.02f, center = Offset(w * (0.3f + 0.06f * i), top - h * 0.01f), alpha = 0.9f)
    }
    val dip = swing(p)
    drawLine(WHITE, Offset(w * 0.8f, h * 0.18f + dip * h * 0.2f), Offset(w * 0.66f, top - h * 0.06f + dip * h * 0.02f), strokeWidth = w * 0.02f, cap = StrokeCap.Round)
}

/** Formulas and numbers float upward, fade in and out, and a curve moves across the background grid. */
private fun DrawScope.maths(w: Float, h: Float, p: Float, paint: Paint) {
    for (i in 1 until 4) {
        drawLine(CYAN, Offset(0f, h * i / 4f), Offset(w, h * i / 4f), strokeWidth = 1f, alpha = 0.12f)
    }
    val curve = Path()
    for (x in 0..24) {
        val xx = w * x / 24f
        val yy = h * 0.5f + h * 0.12f * sin(TAU * (x / 24f) + TAU * p)
        if (x == 0) curve.moveTo(xx, yy) else curve.lineTo(xx, yy)
    }
    drawPath(curve, CYAN, alpha = 0.5f, style = Stroke(width = 2f))
    val formulas = listOf("x² + y² = r²", "∫ f(x) dx", "e^(iπ) + 1 = 0", "Σ n = n(n+1)/2", "a² + b² = c²")
    paint.textSize = min(w, h) * 0.07f
    for ((i, text) in formulas.withIndex()) {
        val t = fract(p + i / formulas.size.toFloat())
        val x = w * (0.06f + 0.14f * (i % 2))
        val y = h * (0.92f - 0.86f * t)
        paint.color = CYAN.copy(alpha = sin(PI.toFloat() * t)).toArgb()
        drawContext.canvas.nativeCanvas.drawText(text, x, y, paint)
    }
}

/** A pendulum swings from its support, and a wave ripples beneath it. */
private fun DrawScope.pendulum(w: Float, h: Float, p: Float) {
    val pivot = Offset(w * 0.5f, h * 0.12f)
    val angle = 0.6f * sin(TAU * p)
    val length = h * 0.55f
    val bob = Offset(pivot.x + sin(angle) * length, pivot.y + cos(angle) * length)
    drawRect(WHITE, topLeft = Offset(w * 0.3f, h * 0.05f), size = Size(w * 0.4f, h * 0.04f), alpha = 0.7f)
    drawLine(WHITE, pivot, bob, strokeWidth = 2f, alpha = 0.8f)
    drawCircle(PINK, radius = w * 0.07f, center = bob)
    val wave = Path()
    for (x in 0..24) {
        val xx = w * x / 24f
        val yy = h * 0.86f + h * 0.04f * sin(TAU * (x / 24f) * 2f - TAU * p)
        if (x == 0) wave.moveTo(xx, yy) else wave.lineTo(xx, yy)
    }
    drawPath(wave, CYAN, alpha = 0.5f, style = Stroke(width = 2f))
}

/** A water molecule turns slowly; its two hydrogen atoms stay bonded to the oxygen as it moves. */
private fun DrawScope.molecule(w: Float, h: Float, r: Float, p: Float) {
    val c = Offset(w * 0.5f, h * 0.5f)
    val theta = TAU * p * 0.5f
    val half = 0.91f
    val length = r * 0.6f
    val h1 = c + Offset(cos(theta - half) * length, sin(theta - half) * length)
    val h2 = c + Offset(cos(theta + half) * length, sin(theta + half) * length)
    drawLine(WHITE, c, h1, strokeWidth = 4f, cap = StrokeCap.Round, alpha = 0.7f)
    drawLine(WHITE, c, h2, strokeWidth = 4f, cap = StrokeCap.Round, alpha = 0.7f)
    drawCircle(PINK, radius = r * 0.22f, center = c)
    drawCircle(CYAN, radius = r * 0.12f, center = h1)
    drawCircle(CYAN, radius = r * 0.12f, center = h2)
    for (i in 0 until 4) {
        val t = fract(p + i * 0.25f)
        drawCircle(CYAN, radius = r * 0.03f, center = Offset(w * (0.12f + 0.25f * i), h * (0.9f - 0.8f * t)), alpha = 0.5f * (1f - t))
    }
}

/** Lines of code type out one after another, with a blinking cursor, on a small dark screen. */
private fun DrawScope.code(w: Float, h: Float, p: Float, paint: Paint) {
    drawRoundRect(Color(0xFF141A36), topLeft = Offset(w * 0.08f, h * 0.1f), size = Size(w * 0.84f, h * 0.8f), cornerRadius = CornerRadius(w * 0.05f))
    val lines = listOf("for i in range(5):", "  total += i", "  print(total)", "done = True")
    val typed = p * (lines.size + 1)
    paint.textSize = min(w, h) * 0.06f
    paint.color = CYAN.toArgb()
    var lastX = w * 0.15f
    var lastY = h * 0.25f
    for ((i, line) in lines.withIndex()) {
        val shown = min(1f, max(0f, typed - i))
        val count = (line.length * shown).toInt()
        if (count > 0) {
            val y = h * (0.25f + i * 0.16f)
            val text = line.substring(0, count)
            drawContext.canvas.nativeCanvas.drawText(text, w * 0.15f, y, paint)
            lastX = w * 0.15f + paint.measureText(text)
            lastY = y
        }
    }
    if (sin(TAU * p * 4f) > 0f) {
        drawRect(CYAN, topLeft = Offset(lastX + w * 0.01f, lastY - h * 0.06f), size = Size(w * 0.02f, h * 0.07f))
    }
}

/** An open book: the pages turn over in turn, with text lines on the pages. */
private fun DrawScope.reading(w: Float, h: Float, p: Float) {
    val turn = abs(cos(TAU * p * 0.5f))
    drawRect(PURPLE, topLeft = Offset(w * 0.18f, h * 0.28f), size = Size(w * 0.3f, h * 0.44f), alpha = 0.5f)
    drawRect(CYAN, topLeft = Offset(w * 0.52f, h * 0.28f), size = Size(w * 0.3f, h * 0.44f), alpha = 0.5f)
    drawRect(WHITE, topLeft = Offset(w * 0.5f, h * 0.28f), size = Size(w * 0.3f * turn, h * 0.44f), alpha = 0.8f)
    for (i in 0 until 4) {
        val y = h * (0.38f + i * 0.1f)
        drawLine(WHITE, Offset(w * 0.23f, y), Offset(w * 0.43f, y), strokeWidth = 1.5f, alpha = 0.45f)
        drawLine(WHITE, Offset(w * 0.57f, y), Offset(w * 0.77f, y), strokeWidth = 1.5f, alpha = 0.45f)
    }
}

/** A figure does a jumping jack: arms sweep up and down, legs spread and close, and a ring pulses. */
private fun DrawScope.exercise(w: Float, h: Float, p: Float) {
    val cx = w * 0.5f
    val up = swing(p)
    val neck = h * 0.36f
    val hip = h * 0.6f
    drawCircle(SKIN, radius = w * 0.07f, center = Offset(cx, h * 0.25f))
    drawLine(WHITE, Offset(cx, neck), Offset(cx, hip), strokeWidth = w * 0.05f, cap = StrokeCap.Round)
    val shoulder = Offset(cx, neck + h * 0.03f)
    drawLine(SKIN, shoulder, Offset(cx - w * 0.3f * up - w * 0.05f, neck - h * 0.2f * up + h * 0.06f), strokeWidth = w * 0.04f, cap = StrokeCap.Round)
    drawLine(SKIN, shoulder, Offset(cx + w * 0.3f * up + w * 0.05f, neck - h * 0.2f * up + h * 0.06f), strokeWidth = w * 0.04f, cap = StrokeCap.Round)
    val spread = 0.2f + 0.3f * up
    drawLine(SKIN, Offset(cx, hip), Offset(cx - w * spread, h * 0.92f), strokeWidth = w * 0.045f, cap = StrokeCap.Round)
    drawLine(SKIN, Offset(cx, hip), Offset(cx + w * spread, h * 0.92f), strokeWidth = w * 0.045f, cap = StrokeCap.Round)
    drawCircle(PINK, radius = w * (0.3f + 0.08f * up), center = Offset(cx, h * 0.5f), alpha = 0.25f, style = Stroke(width = 3f))
}

/** Equaliser bars rise and fall to the beat, with a sound wave flowing across the top. */
private fun DrawScope.music(w: Float, h: Float, p: Float) {
    for (i in 0 until 9) {
        val level = 0.5f + 0.5f * sin(TAU * p * (1f + (i % 3) * 0.4f) + i * 0.8f)
        val bh = h * (0.15f + 0.55f * level)
        drawRoundRect(
            if (i % 2 == 0) CYAN else PURPLE,
            topLeft = Offset(w * (0.1f + 0.09f * i), h * 0.82f - bh),
            size = Size(w * 0.06f, bh),
            cornerRadius = CornerRadius(w * 0.03f),
        )
    }
    val wave = Path()
    for (x in 0..24) {
        val xx = w * x / 24f
        val yy = h * 0.2f + h * 0.05f * sin(TAU * (x / 24f) * 2f + TAU * p)
        if (x == 0) wave.moveTo(xx, yy) else wave.lineTo(xx, yy)
    }
    drawPath(wave, PINK, alpha = 0.6f, style = Stroke(width = 2f))
}

/** A figure asleep under a blanket, breathing slowly, with a moon, twinkling stars and rising "z"s. */
private fun DrawScope.sleep(w: Float, h: Float, p: Float, paint: Paint) {
    drawCircle(PURPLE, radius = w * 0.12f, center = Offset(w * 0.78f, h * 0.2f), alpha = 0.85f)
    drawCircle(PANEL, radius = w * 0.1f, center = Offset(w * 0.83f, h * 0.17f))
    for (i in 0 until 4) {
        val twinkle = 0.5f + 0.5f * sin(TAU * (p + i * 0.25f))
        drawCircle(WHITE, radius = w * 0.012f, center = Offset(w * (0.1f + 0.2f * i), h * (0.12f + 0.1f * (i % 2))), alpha = 0.3f + 0.6f * twinkle)
    }
    val breath = swing(p)
    drawCircle(SKIN, radius = w * (0.13f + 0.005f * breath), center = Offset(w * 0.42f, h * 0.6f))
    drawArc(DARK, startAngle = 0f, sweepAngle = 180f, useCenter = false, topLeft = Offset(w * 0.35f, h * 0.58f), size = Size(w * 0.05f, h * 0.04f), style = Stroke(width = 2f))
    drawArc(DARK, startAngle = 0f, sweepAngle = 180f, useCenter = false, topLeft = Offset(w * 0.44f, h * 0.58f), size = Size(w * 0.05f, h * 0.04f), style = Stroke(width = 2f))
    drawRoundRect(PURPLE, topLeft = Offset(w * 0.2f, h * 0.72f), size = Size(w * 0.6f, h * 0.2f), cornerRadius = CornerRadius(w * 0.1f), alpha = 0.8f)
    paint.color = WHITE.toArgb()
    for (i in 0 until 3) {
        val t = fract(p + i / 3f)
        paint.textSize = min(w, h) * (0.06f + 0.04f * t)
        paint.alpha = ((1f - t) * 255).toInt()
        drawContext.canvas.nativeCanvas.drawText("z", w * (0.6f + 0.07f * i), h * (0.45f - 0.25f * t), paint)
    }
    paint.alpha = 255
}

/** Ripples spread out from the centre: a calm default for tasks with no more specific picture. */
private fun DrawScope.calm(w: Float, h: Float, r: Float, p: Float) {
    val c = Offset(w * 0.5f, h * 0.5f)
    for (i in 0 until 3) {
        val t = fract(p + i / 3f)
        drawCircle(CYAN, radius = r * (0.15f + 0.6f * t), center = c, alpha = 0.6f * (1f - t), style = Stroke(width = 2f))
    }
}
