# Chronexa Stage A — report

Branch: `chronexa/stage-a` (based on `chronexa/phase-1-audit`; upstream baseline on `backup/reReminder-4.0.1`).
Version: 5.0.0-alpha.1 (versionCode 9). Application ID unchanged: `com.olaf.rereminder`.

## Status

**Not compiled and not run.** The build environment used for this stage had no Android SDK, no
Gradle distribution and no network access, so neither `assembleDebug` nor the unit tests were run.
Verification was limited to the static checks listed below. The first real build is the
GitHub workflow in `docs/BUILD_ON_PHONE.md`.

## Verified statically

- Every XML resource parses (15 files).
- All 248 `R.string` references resolve to a defined string.
- No duplicate string names in `values/` or `values-de/`.
- Braces and parentheses balance in every new or changed Kotlin file.
- Every callee of a changed signature has been updated (SettingsRoute, SettingsScreen, the preview).
- The alarm engine (`service/`, `data/`, `utils/Reliability.kt`, `utils/NotificationHelper.kt`) and
  `AndroidManifest.xml` have zero changes against the baseline.
- The vector icon and the SVG source parse; the raster icons were rendered from the same geometry
  and reviewed visually at 512, 192, 144, 96, 72 and 48 px.

## Implemented

- Displayed name **Chronexa** (strings and fastlane title).
- Dashboard (`ui/home`): clock and date, next alarm with countdown (paused and empty states), today's
  tasks (empty state until the planner exists), progress across reminders.
- Display name: set in Settings → Profile; greeting uses time of day.
- Bottom navigation: Home, Schedule, Subjects, Focus, Achievements, Settings. Schedule is the
  existing reminder list. Subjects, Focus and Achievements are labelled "coming soon" screens.
- Chronexa palette: navy-black dark theme with cyan and violet accents; matching light theme.
  Dynamic colour off by default.
- Glowing card component with a single entrance animation. Static glow, no idle animation loops.
  Animation is skipped when system animations are disabled.
- Original vector launcher icon (clock, cyan glow, violet progress arc). Source SVG included.
- Unit tests for the greeting and next-alarm logic (`HomeLogicTest`).

## Preserved

Alarm scheduling, exact-alarm and battery guidance, boot and time-change re-arming, notification
channels, sounds, snooze, vibration, reminder storage and migration, the editor and its transitions,
the alarm screen. Only the navigation wiring and Settings' back arrow changed.

## Known limitations and risks

1. **Unverified compile.** Expect a small number of compile errors on the first build; send the log.
2. **Bottom bar with six items.** "Achievements" may truncate on narrow phones (labels are
   ellipsised, not wrapped). Check on a 360 dp-wide device.
3. **Double bottom padding is possible** on some screens because the list screen has its own
   scaffold. `consumeWindowInsets` is used to prevent it; verify visually.
4. **Install conflict.** A Chronexa build cannot install over the official reReminder (same package
   name, different signing key). See `docs/BUILD_ON_PHONE.md`.
5. **GPL §5 notices** are in every changed file and in `NOTICE`. Repeat the header for any new file.
