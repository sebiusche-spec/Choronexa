# Chronexa — Phase 1 Audit and Implementation Plan

Status: audit complete. No application source has been modified yet.
Backup: branch `backup/reReminder-4.0.1` holds the untouched upload (commit `e037db1`).
Work branch: `chronexa/phase-1-audit`.

## 1. Baseline identification

| Item | Value |
|---|---|
| Upstream | ProfessorQuantumUniverse/reReminder |
| Version | 4.0.1 (versionCode 8) |
| applicationId / namespace | `com.olaf.rereminder` |
| minSdk / compileSdk / targetSdk | 26 / 37 / 37 |
| Android Gradle Plugin | 9.3.1 (built-in Kotlin) |
| Kotlin / Compose compiler plugin | 2.4.20 |
| Compose BOM | 2026.09.00 |
| Gradle wrapper | 9.7.1 |
| Java target | 17 |
| License | GPLv3 |
| Tests | 4 unit test files (Schedule, ReminderCodec, Reliability, SetupState); instrumented test is the Android Studio template |
| CI | JDK 17, `lintDebug testDebugUnitTest assembleDebug` |

## 2. Build and environment status (important)

- This sandbox has JDK 21 but **no Android SDK, no Gradle distribution, no Gradle dependency cache, and no network access.**
- Consequence: **the project cannot be compiled, unit-tested, linted, or turned into an APK here.** No build claim is made in this audit.
- Version risk to verify on a machine with network: AGP 9.3.1, Kotlin 2.4.20, compileSdk 37 and Gradle 9.7.1 are recent. The build must be checked against them before any change is trusted. CI runs on JDK 17, which should be confirmed against AGP 9.x requirements.
- Recommended build environment: Android Studio (current stable) or the command line with Android SDK platform 37, build-tools, JDK 17, and internet access for Gradle.

## 3. Existing alarm engine (preserve)

Reviewed `ReminderScheduler`, `Schedule`, `Reminder`, `ReminderCodec`, `Storage`.

- One exact alarm per reminder via `setExactAndAllowWhileIdle`, with inexact fallback when exact alarms are denied. Permission is checked before every scheduling call, not cached.
- Deterministic grid: `anchorMillis` plus interval means syncing twice gives the same next alert. Syncing does not restart countdowns, which is the built-in guard against drift and duplicate scheduling loops.
- PendingIntent request codes are the reminder id; snooze uses `1_000_000 + id`. Changing this scheme would orphan existing alarms.
- Persistence: reminders in device-protected storage (`Storage.kt`) so boot receivers can re-arm before unlock. Serialised with kotlinx JSON, `ignoreUnknownKeys = true`, so additive schema changes are backward compatible.
- Boot, time-set, timezone, package-replaced and exact-alarm-state-change are all handled by `BootReceiver`.
- Full-screen alarm is `AlarmActivity` with `showWhenLocked` and `turnScreenOn`, and it falls back to a notification with sound when the full-screen intent cannot be used (4.0.1 fix).

**Assessment:** the engine already covers most of Phase 3. Phase 3 work is verification and additions, not a rewrite.

## 4. Requirement mapping

| Phase | Requirement | Current state |
|---|---|---|
| 2 | Rename to Chronexa | Not done. `app_name` is `reReminder` in `strings.xml` (`translatable=false`), plus README, fastlane, changelog. |
| 2 | Original icon | Not done. Current icon is the reReminder mipmap set plus `ic_launcher_foreground.xml`. |
| 2 | Premium dark UI, cyan/violet | Partial. Material 3 light and dark themes exist with an indigo/teal palette. Needs a new palette. |
| 2 | Dashboard, 6-tab nav | Not done. Current nav is a 4-route graph: list, editor, settings, setup. |
| 2 | Display-name greeting | Not done. |
| 3 | Multiple reminders, weekday schedules, sounds, vibration, snooze | Present. |
| 3 | Reboot, timezone, clock, app update | Present (`BootReceiver`). Needs device testing. |
| 3 | Exact-alarm and battery guidance | Present (`Reliability.kt`, `REQUEST_IGNORE_BATTERY_OPTIMIZATIONS`). |
| 3 | No guaranteed-alarm claims | Needs a copy review across strings. |
| 3 | No duplicate alarms or loops | Largely present by design (grid + fixed request codes). Needs tests for the new task alarms. |
| 4 | Study planner, subjects, tasks, overlap warning | Not present. Largest new feature. |
| 5 | Checklist, daily/weekly %, streaks, achievements | Not present. |
| 6 | Focus timer | Not present. |
| 7 | Storage, migration, graceful permission handling | Partial. Storage and migration exist for reminders. Task, history, settings and achievement stores are new. |
| 7 | No AI, cloud, analytics, ads, internet permission | Compliant now. The manifest has no `INTERNET` permission. Keep it that way. |
| 8 | Build, tests, APK | Blocked in this environment (section 2). |

## 5. Conflicts and decisions

1. **applicationId.** Renaming `com.olaf.rereminder` to a new id installs a second app and orphans every existing user's reminders. Recommendation: keep the id, change only the display name and branding. Requires your confirmation.
2. **Reminder model vs study tasks.** Reminders are interval-based (`Repeat`, `TimeWindow`). Study tasks are dated, time-ranged items with notes and repeat days. Recommendation: add a separate `StudyTask` model and feed its start times into the existing scheduler through a separate request-code range, so the reminder id space and its snooze range stay untouched.
3. **Focus timer without a service.** Store an `endAtMillis` timestamp and arm one exact alarm for it. Do not run a foreground service while counting. The pause/resume state is derived from stored values on each launch and on each return to foreground.
4. **DST-safe streaks.** Store completions as ISO local dates (`LocalDate`), and compute streaks with `LocalDate` arithmetic, never by subtracting 24-hour millisecond values.
5. **Storage.** Adding a new dependency such as Room or DataStore needs a technical reason. Preferred: JSON files in the existing device-protected directory, with a `schemaVersion` field and idempotent achievement IDs. Requires your confirmation.
6. **Full-screen intent.** Android 14+ restricts `USE_FULL_SCREEN_INTENT` for non-calling apps. The existing permission check should be verified on the target device.
7. **Scope.** The spec covers several weeks of work. It should land in verifiable stages (section 7), not as one change.

## 6. File-by-file plan

Phase numbers refer to the spec. "Keep" means no change.

| File | Action | Phase | Reason |
|---|---|---|---|
| `app/build.gradle.kts` | Modify (`versionName`, `versionCode`) | 2 | Version bump only. applicationId stays. |
| `app/src/main/res/values/strings.xml`, `values-de/strings.xml` | Modify | 2, 3 | Rename to Chronexa; remove guarantee wording; add new UI strings. |
| `res/mipmap-*`, `drawable/ic_launcher_foreground.xml`, `values/ic_launcher_background.xml` | Replace | 2 | Original Chronexa icon. |
| `res/values/colors.xml`, `values-night/colors.xml`, `ui/theme/Color.kt`, `Theme.kt` | Modify | 2 | Navy/black base, cyan and violet accents. |
| `ui/theme/Motion.kt` | Modify | 2 | Reduced-motion aware animation helpers. |
| `ui/navigation/ReReminderApp.kt` | Modify | 2 | Six destinations: Home, Schedule, Subjects, Focus, Achievements, Settings. Keep the existing alarm and editor routes. |
| `ui/home/*` (new) | Create | 2 | Dashboard: time, next alarm, today's tasks, streak, weekly completion. |
| `ui/main/MainScreen.kt`, `MainViewModel.kt` | Keep, route under Schedule/Reminders | 2, 3 | Reminder engine UI preserved. |
| `ui/editor/*` | Keep, extend for ringtone and vibration per reminder | 3 | Existing sound and vibration model already covers much of this. |
| `ui/settings/*` | Modify | 2, 7 | Display name; reliability screen stays. |
| `data/StudyTask.kt`, `data/Subject.kt`, `data/Completion.kt`, `data/FocusSession.kt`, `data/Achievement.kt` (new) | Create | 4–6 | New models with `schemaVersion`. |
| `data/StudyRepository.kt` (new) | Create | 4–7 | Persistence in device-protected storage, same pattern as `ReminderRepository`. |
| `domain/Streaks.kt`, `domain/Progress.kt` (new) | Create | 5 | Pure functions on `LocalDate`, unit-tested. |
| `domain/Overlap.kt` (new) | Create | 4 | Overlap detection that warns and never mutates schedules. |
| `service/ReminderScheduler.kt` | Modify (additive) | 4, 6 | Arm task-start and focus-end alarms in a separate request-code range. Existing reminder logic unchanged. |
| `service/AlarmReceiver.kt` | Modify (additive) | 4, 6 | Dispatch new action strings. Existing actions unchanged. |
| `service/BootReceiver.kt` | Modify (additive) | 3, 4, 6 | Re-arm study tasks and running focus timer after boot and time changes. |
| `focus/FocusTimer.kt` (new) | Create | 6 | Pure state machine: idle, running, paused, complete. |
| `ui/focus/*`, `ui/schedule/*`, `ui/subjects/*`, `ui/achievements/*` (new) | Create | 4–6 | Screens. |
| `ui/components/*` | Keep, extend | 2 | Glow and animated card components. |
| `utils/Reliability.kt` | Keep | 3 | Already covers exact alarms and battery optimisation. |
| `utils/NotificationHelper.kt` | Modify (additive) | 6 | Focus-complete notification on its own channel. |
| `AndroidManifest.xml` | Modify minimal | 2 | Label and icon. No new permissions. No `INTERNET`. |
| `test/.../domain/StreaksTest.kt`, `OverlapTest.kt`, `FocusTimerTest.kt`, `StudyRepositoryMigrationTest.kt` (new) | Create | 8 | Streak and DST cases, overlap, focus transitions, schema migration. |
| `README.md`, `CHANGELOG.md`, `fastlane/**` | Modify | 8 | Chronexa branding and changelog. |

## 7. Proposed delivery stages

Each stage must build and pass tests before the next one starts.

- **Stage A — Shell and brand.** Rename, icon, palette, six-destination navigation, dashboard with live data from existing reminders, display name. No alarm logic changes.
- **Stage B — Study planner.** Subjects, tasks, timetable, overlap warnings, task alarms through the existing scheduler, checklist completions.
- **Stage C — Progress.** Daily and weekly percentages, streaks, achievements, weekly goals.
- **Stage D — Focus timer.** Configurable sessions, end-time alarm, statistics.
- **Stage E — Hardening.** Migration tests, reboot and DST tests, documentation, changelog, APK build.

## 8. Decisions needed before Stage A

1. Keep `applicationId` as `com.olaf.rereminder`? (Recommended: yes.)
2. Can the build be run on a machine with Android SDK 37 and network access? Without it, no APK can be produced or verified.
3. Accept a vector icon I design (cyan/violet, original geometry) pending your review, or supply artwork?
4. Confirm the study-planner model above and the JSON storage approach.
5. Confirm the GPLv3 obligations apply: derivative source must remain GPLv3, with upstream attribution, and the source must be available with any binary distribution.
