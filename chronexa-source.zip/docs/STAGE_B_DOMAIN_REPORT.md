# Chronexa Stage B (domain core) — report

Branch: `chronexa/stage-b-domain`. Application ID, reminders, alarm scheduling, notifications,
boot handling and reminder storage are unchanged (checked against the baseline).

## Status

Logic and persistence only. **No UI, no alarm integration and no compile or test run in this
environment.** The cloud build (`build-chronexa.yml`, step "Unit tests and debug build") is the
first place these run.

## Added (package `com.olaf.rereminder.study`)

| File | Purpose |
|---|---|
| `StudyModel.kt` | Subjects (default five), tasks with minute-level slots, repeat rules, completion, focus records, settings, validation keys |
| `Schedule.kt` | Occurrences per date, overnight tasks, overlap detection (touching slots do not overlap), conflict check for editing, overdue rule, daily and weekly completion |
| `Streaks.kt` | Current and best streak with a stated rule (see below) |
| `FocusClock.kt` | Timestamp-based countdown: start, pause, resume, reset, completion; only the RUNNING→COMPLETED transition may record a session |
| `FocusStats.kt` | Completed focus seconds per day, range and subject, by local date in the device zone |
| `StudyCodec.kt` | Versioned JSON, ignores unknown fields, refuses to overwrite newer schemas, reports corrupt data instead of dropping it |
| `StudyStore.kt` | File I/O in device-protected storage: atomic writes, corrupt file moved aside, read-only for newer files |

## Streak rule

A day counts when every task scheduled for it is completed and at least one exists. A day with
nothing scheduled, or with an unfinished task, breaks the streak. Today does not break or count
while it is still in progress. This is deliberately strict: planning a day and finishing it is
what counts, so scheduling nothing is not a way to keep a streak alive.

## Known limits

- Overlap uses wall-clock time; a task spanning a daylight-saving change may be off by an hour.
- An overnight task belongs to its start date for completion and statistics.
- Focus timing uses wall-clock time. A manual clock change during a session can jump the remaining time.
- Store I/O (`StudyStore`) has no unit test; it needs a device or instrumented test.
- Completions and focus records are not yet pruned; they grow slowly with use.

## Not yet built

Schedule, Subjects, Focus and Achievements screens; the visual redesign and animation system;
connecting tasks to alarms (with duplicate-alarm protection); focus completion notification;
Settings for these values; achievements; the reduced-motion system beyond Stage A.
