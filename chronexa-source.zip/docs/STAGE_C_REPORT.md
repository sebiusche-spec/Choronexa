# Chronexa Stage C — report

Branch: `chronexa/stage-c-ui` (from `chronexa/stage-b-domain`; backup at `backup/stage-b-before-ui`).
Version 5.0.0-alpha.2 (versionCode 10).

## Status

Code written for all six screens, the energy orb, transitions and the settings. **Not compiled,
not unit-tested and not run on a device in this environment.** The first real check is the cloud
build (`build-chronexa.yml`). Expect a round of compile fixes.

## Step 1 — review of the foundation

- The Stage B logic was re-read against its tests. Two test expectations were wrong and were fixed
  in Stage B (week start for Sunday; a misleading comment).
- Upstream test files (`ReminderCodecTest.kt`, `ReliabilityTest.kt`) are unchanged.
- Fixed in this stage: focus completion is now dated when the countdown reached zero, not when the
  app noticed it.
- Found and fixed in this stage: five string keys that silently reused upstream reminder wording
  (for example "Delete timer") and would have shown the wrong text. They are now unique study keys.
- Found and fixed: a `dash` shell limitation that created literal folders, and a Compose drawing
  helper that had been written with a non-existent API. Neither reached the source tree.

## Implemented

| Area | Files | What works, in code |
|---|---|---|
| State | `study/StudyRepository.kt`, `study/StudyStats.kt`, `ui/study/StudyViewModel.kt` | Single source for data and the focus session; every change is saved before it is shown; subject delete keeps history |
| Home | `ui/home/HomeScreen.kt`, `HomeViewModel.kt`, `EnergyOrb.kt` | Date, greeting, orb, quick actions, next alarm, today's progress, today's tasks with checkboxes, upcoming, focus time |
| Schedule | `ui/study/schedule/ScheduleScreen.kt` | Week strip, day list, checkboxes, overlap and overdue markers, full editor with create, edit, delete, reschedule, repeat rules, overnight tasks, conflict warnings |
| Subjects | `ui/study/subjects/SubjectsScreen.kt` | Add, rename, delete; subject totals from real data |
| Focus | `ui/study/focus/FocusScreen.kt` | Ring timer, start, pause, resume, reset, modes, subject and label, history, daily and weekly totals |
| Achievements | `ui/study/achievements/AchievementsScreen.kt` | Daily and weekly counts, streaks with the rule shown, week bars, subject stats, milestones, empty states |
| Settings | `ui/settings/StudySettingsSection.kt`, `MainActivity.kt` | Durations, first day of week, theme, animation mode, About and licence |
| Motion | `ui/home/EnergyOrb.kt`, `ui/study/StudyUi.kt`, `ui/theme/ReduceMotion.kt` | Rotating rings and breathing core (idle and energetic), animated rings, animated checkbox, press feedback, running-only pulse; reduced motion honoured |

Animations run only while their screen is composed. Idle focus and an idle Home do not animate
continuously except for the orb, which stops when reduced motion is on.

## Not done

1. **Task-to-alarm integration (Step 5) is not implemented.** The alarm scheduler is built around the
   `Reminder` model and a request-code scheme (reminder id, snooze at 1,000,000 + id). Task alarms
   need their own identity range, cancellation on edit, reschedule and delete, and boot re-arming,
   all without changing the reminder engine. That was not done in this stage because a mistake
   produces duplicate or missing alarms, and it cannot be checked without a device. Schedules are
   stored and shown; they do not ring.
2. **Focus completion notification** is not implemented. A session is recorded when the app next
   sees the timer finish; nothing alerts the user in the background.
3. **Focus sessions survive recreation, not process death.** The running timer is held in memory.
   If Android kills the app, the unfinished session is lost and not recorded.
4. **"Hello, Sir".** The greeting is time-based with the display name, as in Stage A. A fixed
   "Sir" was not added.
5. **German translations** for the new strings are missing. The English text is used in German
   builds. Android lint would flag this; the cloud build runs unit tests and assembleDebug only.
6. **Subject bar lengths** are relative to the subject with the most completed tasks. They are not
   progress against a target, because no target exists.
7. **Overdue markers** are computed when a list is composed; they update when the screen is next
   composed rather than every minute.

## Physical-device checks still required

- Orb, rings and transitions: smoothness, battery use over 10 minutes, and reduced-motion behaviour.
- Focus timer: accuracy after locking the phone, after backgrounding, and after the Activity is
  recreated by rotation or a theme change.
- Schedule editor on a 360 dp phone: keyboard, the time fields, and the chips wrapping.
- Achievements and Home with real data across a midnight and a week boundary.
- Theme switching and recreation with the Settings screen open.
- Existing alarms: create, ring, snooze and boot recovery, unchanged by this stage.
