# Android integration plan — from the HTML prototype to the Compose app

Status: planning document. Nothing here changes the Android app yet.

## 1. What can and cannot be reused

The prototype is a design reference. The app must stay native Jetpack Compose. A WebView would
not give reliable alarms, notifications, boot recovery or exact-alarm handling, and the brief
rules out using one as a shortcut.

| Prototype screen | Android treatment | Notes |
|---|---|---|
| Home | Compose. `EnergyOrb` already exists; add the activity scene and the timeline card. | Reuse the current Home view model and extend it with activity status. |
| Planner (24-hour timeline) | New Compose screen. Canvas timeline, same 0.6 px-per-minute scale. | Reuse `StudyTask`, `Occurrence`, `findOverlaps`, `conflictsFor`, `summarizeDay`. |
| Activity editor | Compose dialog or sheet, using the Schedule editor's validation. | Add category, animation and reminder fields. |
| Alarms and reminders | Existing reminder list, plus a separate activity-alarm layer (section 4). | Keep the reminder engine unchanged. |
| To-do | Already implemented in Chronexa. | Visual polish only. |
| Focus timer | Already implemented; timestamp-based. | Add the completion notification (section 4). |
| Settings | Already implemented. | Add the animation choice and a reduced-motion explanation. |
| Animation scenes | Compose ports of the 13 CSS scenes. | Canvas or `Animatable`, drawn only while visible. |

## 2. Native features that must not be replaced by the prototype

- Reminder scheduling through `AlarmManager` (exact where allowed, inexact fallback), the existing
  request-code scheme and the snooze range.
- Notification channels, actions and full-screen alarm presentation.
- Boot, time-zone and clock-change re-arming (`BootReceiver`).
- The reminder database and its migrations.
- Permission checks and explanations: `POST_NOTIFICATIONS`, `SCHEDULE_EXACT_ALARM`, battery optimisation.

## 3. Data mapping

| Prototype field | Chronexa today | Change needed |
|---|---|---|
| `name`, `start`, `end`, `notes`, `subject` | `StudyTask` fields (title, startMinute, endMinute, notes, subjectId) | None. |
| `repeat`: once, daily, weekdays | `TaskRepeat` (NONE, DAILY, WEEKDAYS, WEEKLY) | None. |
| `category` | Not present | Add `category` with a default, plus a list of custom categories. |
| `animation` | Not present | Add with default `auto`. |
| `alert` | Not present | Add with default `false`. Only the alarm stage gives it meaning. |
| Completion | `Completion(taskId, date)` | None. Counted once per occurrence. |
| To-do | `TodoItem` | None. |

Storage: a schema bump (2 → 3) with defaulted fields. Files from schema 1 and 2 still load. A newer
file opens read-only and is never overwritten. The store's existing rules stay as they are.

## 4. Staged plan

Each stage is a separate branch and a separate reviewable change.

**Stage A — Planner screen in Compose (no alarms).**
Timeline, editor with category, animation and reminder fields, copy-day, weekly overview.
Port the pure logic tests from `prototype/tests/logic.test.js` to Kotlin unit tests.
Acceptance: unit tests pass; the existing reminder and To-do tests still pass.

**Stage B — Animation scenes.**
Compose ports of the scenes. Pause when the screen is not visible (lifecycle-aware). Honour
`rememberReduceMotion()` and the in-app motion setting.
Acceptance: no animation runs with the screen hidden; reduced motion stops all scenes.

**Stage C — Activity alarms (separate, reviewed change).**
Design before code:
- Identity: a persisted, collision-free id per activity alarm, in a request-code range that does not
  overlap reminder ids or snooze ids (1,000,000 + id). Record the current pending id on each activity.
- Replacement and cancellation: cancel the previous alarm before scheduling a new one, on edit,
  reschedule, disable and delete. Cancelling is idempotent.
- Boot, timezone and clock changes: re-arm from stored activities, as `BootReceiver` does for reminders.
- Exact alarms: check `canScheduleExactAlarms()`. If not allowed, fall back to an inexact alarm and
  say so in the UI. Never claim an exact time when only an inexact one is set.
- Duplicates: one alarm per activity occurrence; store the last armed occurrence to avoid re-arming.
- Permissions: request notifications only when the user first turns on a reminder, with an explanation
  first. Do not request anything else.
Acceptance: JVM tests for id allocation, cancel-before-replace, overnight occurrence times and
duplicate prevention; on-device checks for boot, timezone change and exact-alarm denial.

## 5. Not yet verified

- Any of the above on a real Android device.
- Visual match between the prototype and the Compose screens.
- Battery behaviour of the animation scenes.
