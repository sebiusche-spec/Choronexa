# Exact-alarm permissions

## Decision

| Permission | Where it applies | Decision |
|---|---|---|
| `USE_EXACT_ALARM` | Android 13+ (API 33+) | **Kept.** Granted at install; intended for apps whose core function is alarms, timers or calendars. Chronexa's alarm-style reminders and activity alarms are core functions. |
| `SCHEDULE_EXACT_ALARM` | Android 12 and 12L (API 31–32) | **Scoped to API 32 and below** (`maxSdkVersion="32"`). It is the only exact-alarm permission on those versions. On API 33+ it adds nothing, because `USE_EXACT_ALARM` already grants exact alarms. |

Target SDK is 37 and minimum SDK is 26. Both permissions were previously declared without a limit.

## Why not drop `SCHEDULE_EXACT_ALARM` completely

Devices on API 31–32 have no `USE_EXACT_ALARM`. Without `SCHEDULE_EXACT_ALARM` there, exact timing
would not be available at all, and the app would only use inexact alarms.

## Why keep `USE_EXACT_ALARM`

It is what makes exact timing work without a user prompt on API 33+. Using only
`SCHEDULE_EXACT_ALARM` there would mean a special-access prompt on first use, and on newer
versions exact alarms are denied until the user grants them.

## Risk to be aware of

Google Play restricts `USE_EXACT_ALARM` to apps whose core use is an alarm, timer or calendar.
Chronexa has alarm features at its core. If the store review disagrees, the fallback is to
rely on `SCHEDULE_EXACT_ALARM` on all versions and ask the user to grant it. The app already
handles that case: it reports that exact timing is off and sets an inexact alarm instead.

## Behaviour when exact alarms are not allowed

- The editor shows a warning and a button to allow exact timing.
- The alarm is still set, as an inexact alarm, and the editor says it may arrive a few minutes late.
- Nothing is described as exact when it is not.

## Not verified

These decisions were checked against the Android documentation for each API level, and the
manifest lookup is covered by `AlarmRegressionTest`. They have not been checked on a device, and
Play Console declarations have not been submitted.
