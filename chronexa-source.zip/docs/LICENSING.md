# Licensing and source distribution

Chronexa is derived from reReminder 4.0.1 and is therefore covered by the **GNU General Public
License, version 3**. The full text is in `LICENSE`. This document summarises what that means in
practice for this project. It is not legal advice; if you plan to sell the app, get advice from a
lawyer who knows software licensing.

## What GPLv3 requires when you distribute a build

Whenever you give someone a Chronexa APK, through any channel (a download link, a store, a file
shared directly), you must:

1. **Provide the corresponding source code** for that exact build, or a written offer valid for at
   least three years, under the same GPLv3 terms. The simplest way is to link to the public
   repository at the same commit as the build, and to keep the source zip with each release.
2. **Keep all existing copyright and licence notices** in the files you received, including the
   upstream copyright statements and `LICENSE`.
3. **Mark your modifications.** Modified files must carry a notice saying they were changed. Every
   Kotlin file changed for Stage A carries the header "Modified for Chronexa ... See NOTICE", and
   `NOTICE` lists what changed. Keep both up to date for later stages.
4. **Licence your modifications under GPLv3 as well.** You cannot add terms that restrict the
   recipient's rights (no extra "no redistribution" clauses, no DRM that prevents running modified
   builds, no proprietary licence for Chronexa's code).
5. **Do not restrict redistribution.** Recipients must be able to pass the software and its source
   on under GPLv3.

## What GPLv3 does allow

- Charging money for copies. Selling a GPL program is permitted, but the buyer keeps the same
  rights to share the source and copies they receive.
- Distributing through the Play Store or F-Droid, provided the source is available and the
  licence notices are kept.
- Private use and testing with no distribution at all, with no source obligations beyond your own
  records.

## Upstream attribution

- `README.md` names reReminder as the upstream project and links to it.
- `NOTICE` describes the origin and every modification category.
- Do not describe Chronexa as the original reReminder, and do not use the reReminder name or
  icon to suggest endorsement by the upstream project.

## Application ID

Chronexa keeps the upstream application ID `com.olaf.rereminder`. This is a compatibility choice
(see `docs/CHRONEXA_PHASE1_AUDIT.md`). It has two consequences:

- A Chronexa build **cannot update** an installation of the official reReminder, because Android
  only upgrades an app signed with the same key. Upgrading an official install requires that the
  official key signs the update, and only its publisher holds that key.
- If you publish Chronexa, use a different name and icon in every store listing so users are not
  confused with the official app, and consider a different application ID for the public release.

## Checklist before publishing a build

- [ ] Source for this exact build is public, or a written source offer is attached.
- [ ] `LICENSE` and `NOTICE` are in the repository and in the source archive.
- [ ] Changed files carry the modification header.
- [ ] `CHANGELOG.md` lists the changes in this version.
- [ ] No third-party trademark or logo is used without permission.
