# Build the Chronexa APK from your Android phone

You do not need a PC. GitHub builds the app on its own computers (free for private repositories,
with a monthly allowance of build minutes), and you download the finished APK to your phone.

## What you need

- An Android phone with a web browser.
- A free GitHub account (github.com, sign up in the browser).
- `chronexa-source.zip` (the project, downloaded to your phone).
- `build-chronexa.yml` (the build recipe, downloaded to your phone).

## Steps

1. **Create a private repository.** In the browser, go to github.com/new. Name it `chronexa-build`,
   choose **Private**, and tap **Create repository**.

2. **Upload the project zip.** On the repository page, tap **Add file → Upload files**, choose
   `chronexa-source.zip` from your Downloads folder, and tap **Commit changes**. Keep the zip
   **as a zip**; GitHub stores it as one file and the build unpacks it.

3. **Add the build recipe.** Tap **Add file → Create new file**. In the file name box, type
   exactly:

   `.github/workflows/build-chronexa.yml`

   (typing the slashes creates the folders). Open `build-chronexa.yml` on your phone, select all,
   copy, paste it into the large box, and tap **Commit changes**.

4. **Let it build.** Committing the recipe starts a build. You can also start one yourself: tap the
   **Actions** tab, choose **Build Chronexa APK**, then **Run workflow**. A build takes roughly
   10 to 20 minutes the first time, because Gradle downloads its dependencies.

5. **Download the APK.** When the run shows a green tick, tap it, scroll to **Artifacts**, and tap
   **chronexa-debug-apk**. Android downloads a zip; open it with the Files app and extract
   `app-debug.apk`.

6. **Install it.** Open `app-debug.apk` from Files or your browser's downloads. Android will ask you
   to allow installs from that app: turn that on, go back, and tap Install. If Play Protect warns
   about an unknown developer, choose **Install anyway**. This build is signed with a debug key,
   which is expected for a self-built app.

## Read this before installing over your current reReminder

Chronexa has the same package name as the official reReminder (`com.olaf.rereminder`) so that the
code and data layout stay compatible. Android treats that as the same app, so:

- **If the official reReminder is installed, Android will refuse the install** because the
  signatures differ. This protects you; it is not a bug.
- **To install Chronexa anyway, you must uninstall reReminder first.** Uninstalling deletes its
  reminders. Write down your reminders before you do this.
- **Testing on a spare phone avoids the problem entirely.** Android generally does not allow two
  apps with the same package name but different signatures on one phone, even in a second user
  profile.

## Troubleshooting

- **The run is red.** Open the failed step. Copy the last 30 lines of the log and send them to me;
  the build has not been compiled anywhere yet, so the first run may find compile errors.
- **"chronexa-source.zip is missing."** The zip is not in the repository root. Check step 2 and
  that the file name is exactly `chronexa-source.zip`.
- **No Artifacts appear.** The build failed before producing an APK; see the log.
- **Build minutes run out.** Private repositories get a monthly allowance; wait for the reset or
  make the repository public (only if you are happy for the source to be public, which GPLv3 means
  anyway for a distributed build).
