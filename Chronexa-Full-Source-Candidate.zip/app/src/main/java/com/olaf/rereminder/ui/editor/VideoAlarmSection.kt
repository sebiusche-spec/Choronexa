// Part of Chronexa, a derivative of reReminder 4.0.1 — GNU GPL v3. See NOTICE.
package com.olaf.rereminder.ui.editor

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.OpenableColumns
import android.widget.VideoView
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.olaf.rereminder.R
import com.olaf.rereminder.data.VideoAudioMode
import com.olaf.rereminder.data.VideoChoice
import com.olaf.rereminder.data.isSupportedVideo
import com.olaf.rereminder.data.replacingFile
import kotlin.math.roundToInt

/**
 * "Video alarm" for one alarm: pick an MP4 with the system picker, preview it, choose its audio, volume and
 * looping, or remove it. Only the video is chosen here; the alarm's time, repeat and ringtone are not touched.
 * The picked file is read in place and never copied or deleted. Playing it at the alarm time is a later step.
 */
@Composable
fun VideoAlarmSection(video: VideoChoice?, onChange: (VideoChoice?) -> Unit) {
    val context = LocalContext.current
    var problem by remember { mutableStateOf<Int?>(null) }
    var previewing by remember { mutableStateOf(false) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { picked: Uri? ->
        // Cancelling the picker returns null: nothing changes.
        if (picked == null) return@rememberLauncherForActivityResult
        val mime = context.contentResolver.getType(picked)
        val name = displayName(context, picked)
        when {
            !isSupportedVideo(mime, name) -> problem = R.string.video_unsupported
            !canOpen(context, picked) -> problem = R.string.video_unavailable
            else -> {
                runCatching {
                    context.contentResolver.takePersistableUriPermission(picked, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                problem = null
                onChange(video.replacingFile(picked.toString(), name))
            }
        }
    }

    Column(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Text(
            text = stringResource(R.string.video_title),
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.SemiBold,
        )
        if (video == null) {
            Text(
                text = stringResource(R.string.video_none),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Button(onClick = { problem = null; picker.launch(arrayOf("video/mp4")) }) {
                Text(stringResource(R.string.video_choose))
            }
        } else {
            Text(
                text = stringResource(R.string.video_selected, video.name.ifEmpty { video.uri.substringAfterLast('/') }),
                style = MaterialTheme.typography.bodyMedium,
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { problem = null; picker.launch(arrayOf("video/mp4")) }) {
                    Text(stringResource(R.string.video_replace))
                }
                TextButton(onClick = { previewing = !previewing }) {
                    Text(stringResource(if (previewing) R.string.video_stop_preview else R.string.video_preview))
                }
                TextButton(onClick = { previewing = false; problem = null; onChange(null) }) {
                    Text(stringResource(R.string.video_remove))
                }
            }
            if (previewing) {
                VideoPreview(
                    uri = video.uri,
                    loop = video.loop,
                    onProblem = { problem = R.string.video_unavailable; previewing = false },
                )
            }
            Row(
                modifier = Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                AudioChip(video, VideoAudioMode.VIDEO_AUDIO, R.string.video_audio_video, onChange)
                AudioChip(video, VideoAudioMode.RINGTONE, R.string.video_audio_ringtone, onChange)
                AudioChip(video, VideoAudioMode.BOTH, R.string.video_audio_both, onChange)
            }
            Text(
                text = stringResource(R.string.video_volume, video.volumePercent),
                style = MaterialTheme.typography.bodyMedium,
            )
            Slider(
                value = video.volumePercent / 100f,
                onValueChange = { onChange(video.copy(volumePercent = (it * 100f).roundToInt().coerceIn(0, 100))) },
                valueRange = 0f..1f,
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = stringResource(R.string.video_loop),
                    style = MaterialTheme.typography.bodyLarge,
                    modifier = Modifier.weight(1f),
                )
                Switch(checked = video.loop, onCheckedChange = { onChange(video.copy(loop = it)) })
            }
            Text(
                text = stringResource(R.string.video_note),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        problem?.let {
            Text(
                text = stringResource(it),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.error,
            )
        }
    }
}

@Composable
private fun AudioChip(video: VideoChoice, mode: VideoAudioMode, label: Int, onChange: (VideoChoice?) -> Unit) {
    FilterChip(
        selected = video.audio == mode,
        onClick = { onChange(video.copy(audio = mode)) },
        label = { Text(stringResource(label)) },
    )
}

/** The picked video, shown in a small player. It plays at the phone's media volume; the alarm will use the volume set above. */
@Composable
private fun VideoPreview(uri: String, loop: Boolean, onProblem: () -> Unit) {
    val holder = remember { arrayOfNulls<VideoView>(1) }
    AndroidView(
        modifier = Modifier.fillMaxWidth().height(180.dp),
        factory = { ctx ->
            VideoView(ctx).also { view ->
                holder[0] = view
                view.setVideoURI(Uri.parse(uri))
                view.setOnPreparedListener { player ->
                    player.isLooping = loop
                    view.start()
                }
                view.setOnErrorListener { _, _, _ ->
                    onProblem()
                    true
                }
            }
        },
    )
    // Stop playback as soon as the preview leaves the screen, so nothing keeps playing in the background.
    DisposableEffect(uri) {
        onDispose { holder[0]?.stopPlayback() }
    }
}

/** The file's name from the system, or its last path segment. */
private fun displayName(context: Context, uri: Uri): String = runCatching {
    context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
        if (cursor.moveToFirst()) cursor.getString(0) else null
    }
}.getOrNull() ?: uri.lastPathSegment.orEmpty()

/** Whether the app can still read the file. A moved, deleted or de-permitted file cannot be read. */
private fun canOpen(context: Context, uri: Uri): Boolean = runCatching {
    context.contentResolver.openInputStream(uri)?.use { it.read() >= -1 } ?: false
}.getOrDefault(false)
